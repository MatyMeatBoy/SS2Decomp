
bool sub_08067DC8(void)

{
  dword dVar1;
  undefined1 *puVar2;
  uint uVar3;
  
  dVar1 = DWORD_08067df8;
  uVar3 = *(uint *)DWORD_08067df8;
  if (uVar3 < 0x32) {
    puVar2 = (undefined1 *)(*(int *)DWORD_08067dfc + uVar3 * 0x88);
    *(undefined4 *)(puVar2 + 4) = 1;
    *puVar2 = 0x8d;
    *(undefined4 *)(puVar2 + 8) = *(undefined4 *)(*(int *)DWORD_08067e00 + 0x40);
    puVar2[1] = 1;
    *(int *)dVar1 = *(int *)dVar1 + 1;
  }
  return uVar3 < 0x32;
}


