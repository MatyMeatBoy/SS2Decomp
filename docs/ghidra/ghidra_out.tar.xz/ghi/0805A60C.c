
undefined4 sub_0805A60C(undefined4 param_1)

{
  undefined4 in_lr;
  
  sub_0802413C(param_1,0);
  return in_lr;
}


