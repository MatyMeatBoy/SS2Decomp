
undefined4 sub_08015CE0(void)

{
  int iVar1;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_08015d00;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) | 0x100000;
  return in_lr;
}


