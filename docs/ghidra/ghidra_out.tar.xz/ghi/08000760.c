
undefined4 sub_08000760(void)

{
  ushort uVar1;
  undefined2 uVar2;
  dword dVar3;
  dword dVar4;
  dword dVar5;
  dword dVar6;
  ushort uVar7;
  uint uVar8;
  undefined4 in_lr;
  
  dVar4 = DWORD_080007b0;
  dVar3 = DWORD_080007ac;
  uVar1 = *(ushort *)DWORD_080007b0;
  *(ushort *)DWORD_080007ac = uVar1;
  uVar8 = *(ushort *)DWORD_080007b4 ^ DWORD_080007b8;
  uVar7 = (ushort)uVar8;
  *(ushort *)dVar4 = uVar7;
  uVar7 = uVar7 & ~uVar1;
  *(ushort *)DWORD_080007bc = uVar7;
  dVar5 = DWORD_080007c0;
  uVar8 = uVar8 & 0xf0;
  if ((uVar1 & 0xf0) == uVar8) {
    uVar7 = *(short *)DWORD_080007c0 + 1;
    *(ushort *)DWORD_080007c0 = uVar7;
    dVar6 = DWORD_080007f0;
    uVar1 = *(ushort *)DWORD_080007c4;
    uVar2 = (undefined2)uVar8;
    if (uVar7 == uVar1) {
      *(undefined2 *)DWORD_080007c8 = uVar2;
    }
    else {
      if (uVar1 < uVar7) {
        uVar7 = *(ushort *)DWORD_080007f0;
        *(ushort *)DWORD_080007f0 = uVar7 + 1;
        if (*(ushort *)DWORD_080007f4 < uVar7) {
          *(undefined2 *)DWORD_080007f8 = uVar2;
          *(undefined2 *)dVar6 = 0;
          *(ushort *)dVar5 = uVar1;
          goto LAB_08000816;
        }
      }
      *(undefined2 *)DWORD_08000804 = 0;
    }
  }
  else {
    *(ushort *)DWORD_0800085c = uVar7;
    dVar5 = DWORD_08000860;
    *(undefined2 *)DWORD_08000864 = 0;
    *(undefined2 *)dVar5 = 0;
  }
LAB_08000816:
  dVar5 = DWORD_08000868;
  *(undefined2 *)DWORD_08000868 = 0;
  if (((*(byte *)dVar3 & 1) != 0) && ((*(byte *)dVar4 & 1) == 0)) {
    *(undefined2 *)dVar5 = 1;
  }
  if (((*(byte *)dVar3 & 2) != 0) && ((*(byte *)dVar4 & 2) == 0)) {
    *(ushort *)dVar5 = *(ushort *)dVar5 | 2;
  }
  return in_lr;
}


