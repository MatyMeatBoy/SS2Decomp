
undefined8 sub_080662C4(int param_1)

{
  dword dVar1;
  undefined4 uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  char *pcVar6;
  char *pcVar7;
  undefined1 *puVar8;
  undefined4 in_lr;
  
  dVar1 = DWORD_080662e0;
  uVar3 = *(uint *)DWORD_080662e0;
  if (uVar3 < 0x32) {
    pcVar6 = *(char **)DWORD_08066398;
    uVar5 = 0;
    if (uVar3 != 0) {
      pcVar7 = pcVar6;
      do {
        if ((*(int *)(pcVar6 + 4) == 1) && (*pcVar6 == -0x6f)) {
          iVar4 = param_1 * 0x2e0 + *(int *)DWORD_0806639c;
          if (*(short *)(pcVar6 + 0xe) == *(short *)(iVar4 + 2)) {
            CpuSet(iVar4 + 0x1fc,pcVar7 + 8,DWORD_080662f4);
            goto LAB_08066386;
          }
        }
        uVar5 = uVar5 + 1;
        pcVar6 = pcVar6 + 0x88;
        pcVar7 = pcVar7 + 0x88;
      } while (uVar5 < uVar3);
    }
    puVar8 = (undefined1 *)(*(int *)DWORD_08066398 + *(int *)DWORD_080662e0 * 0x88);
    *(undefined4 *)(puVar8 + 4) = 1;
    *puVar8 = 0x91;
    CpuSet(*(int *)DWORD_0806639c + param_1 * 0x2e0 + 0x1fc,puVar8 + 8,DWORD_080663a0);
    puVar8[1] = 1;
    *(int *)dVar1 = *(int *)dVar1 + 1;
LAB_08066386:
    uVar2 = 1;
  }
  else {
    uVar2 = 0;
  }
  return CONCAT44(in_lr,uVar2);
}


