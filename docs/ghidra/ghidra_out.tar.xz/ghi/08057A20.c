
void sub_08057A20(uint param_1,int param_2)

{
  dword dVar1;
  int iVar2;
  byte *pbVar3;
  
  if (param_2 == 0) {
    iVar2 = *(int *)DWORD_08057a54;
    dVar1 = DWORD_08057a58;
  }
  else {
    iVar2 = *(int *)DWORD_08057a34;
    dVar1 = DWORD_08057a38;
  }
  pbVar3 = (byte *)(iVar2 + dVar1 + (param_1 >> 3));
  *pbVar3 = (byte)(1 << (param_1 & 7)) | *pbVar3;
  return;
}


