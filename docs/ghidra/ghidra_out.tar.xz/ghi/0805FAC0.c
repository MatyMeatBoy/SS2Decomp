
undefined4 sub_0805FAC0(int param_1,undefined4 param_2,uint param_3,uint param_4)

{
  byte bVar1;
  dword dVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 in_lr;
  dword dStack_1c;
  
  dStack_1c = param_3;
  if (DWORD_0805fb74 < param_3) {
    dStack_1c = DWORD_0805fb74;
  }
  puVar4 = (undefined4 *)((param_4 & 0xff) * 0x34 + DWORD_0805fb78);
  cVar3 = sub_08000498(&dStack_1c,100);
  dVar2 = dStack_1c;
  bVar1 = (byte)dStack_1c;
  if (cVar3 != '\0') {
    sub_08007CF0(param_1 + -0xc,param_2,0,cVar3,0,puVar4 + 7,puVar4[2],*puVar4);
  }
  if ((bVar1 < 10) && (cVar3 != '\0')) {
    sub_08007CF0(param_1 + -6,param_2,0,0,0,puVar4 + 7,puVar4[2],*puVar4);
  }
  sub_08007CF0(param_1,param_2,0,dVar2 & 0xff,0,puVar4 + 7,puVar4[2],*puVar4);
  return in_lr;
}


