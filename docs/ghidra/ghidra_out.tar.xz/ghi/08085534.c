
undefined4 sub_08085534(undefined4 param_1,int param_2)

{
  dword dVar1;
  dword dVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  undefined4 in_lr;
  undefined2 uStack_24;
  undefined2 uStack_22;
  
  uVar3 = sub_080653CC();
  sub_0805865C(0x25);
  dVar2 = DWORD_080855c8;
  dVar1 = DWORD_080855c4;
  uStack_24 = 0;
  uStack_22 = 0;
  uVar5 = 0x1d;
  do {
    *(ushort *)dVar1 = *(ushort *)dVar1 & (ushort)DWORD_080855cc;
    if ((*(uint *)DWORD_080855d0 & 3) == 0) {
      param_2 = param_2 + -1;
    }
    sub_08065370(uVar3,0xe,&uStack_24,&uStack_22,1);
    sub_08065230(uVar3,param_1,param_2,0xe,uStack_24);
    sub_080003F0();
    uVar5 = uVar5 - 1 & 0xffff;
  } while (uVar5 != dVar2);
  iVar4 = sub_0800048C();
  *(undefined4 *)(iVar4 + 8) = 0;
  return in_lr;
}


