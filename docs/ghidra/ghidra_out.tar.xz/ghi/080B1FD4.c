
undefined4 sub_080B1FD4(void)

{
  dword dVar1;
  dword dVar2;
  dword dVar3;
  int iVar4;
  ushort *puVar5;
  uint uVar6;
  undefined4 in_lr;
  
  dVar1 = DWORD_080b2048;
  if (*(int *)DWORD_080b2048 != 0) {
    iVar4 = sub_08000470();
    if (iVar4 != 0) {
      sub_080003A8(*(undefined4 *)dVar1);
    }
    sub_08001538(*(undefined4 *)dVar1);
    *(undefined4 *)dVar1 = 0;
    dVar2 = DWORD_080b2050;
    dVar1 = DWORD_080b204c;
    uVar6 = 1;
    do {
      if ((*(uint *)dVar1 & 1 << uVar6) != 0) {
        puVar5 = (ushort *)(uVar6 * 0x2e0 + *(int *)dVar2 + 0x7a);
        *puVar5 = *puVar5 | 1;
      }
      dVar3 = DWORD_080b2054;
      uVar6 = uVar6 + 1 & 0xff;
    } while (uVar6 < 5);
    uVar6 = 0;
    do {
      *(undefined2 *)(uVar6 * 2 + dVar3) = 0;
      uVar6 = uVar6 + 1 & 0xff;
    } while (uVar6 < 2);
  }
  return in_lr;
}


