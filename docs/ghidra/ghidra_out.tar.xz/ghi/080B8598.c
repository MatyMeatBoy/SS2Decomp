
void SoftReset(void)

{
  dword dVar1;
  
  *puRam080b85ac = 0;
  *puRam080b85b0 = 0;
  dVar1 = DWORD_080b85d0;
  software_interrupt(1);
  software_interrupt(0);
  *(undefined1 *)DWORD_080b85d0 = 0xaa;
  *(undefined1 *)DWORD_080b85d4 = 0x55;
  *(undefined1 *)dVar1 = 0xb0;
  uRam0e000000 = 0;
  return;
}


