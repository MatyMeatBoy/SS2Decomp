
undefined4 m4aSoundMain(void)

{
  undefined4 in_lr;
  
  SoundMain();
  return in_lr;
}


