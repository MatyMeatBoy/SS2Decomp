
undefined4 sub_08033198(void)

{
  int iVar1;
  undefined4 uVar2;
  dword dVar3;
  uint uVar4;
  undefined4 in_lr;
  undefined2 uStack_28;
  undefined2 uStack_26;
  undefined1 auStack_24 [28];
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_080331d0;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) | 1;
  sub_0800D0F4();
  iVar1 = sub_080020F4();
  if (iVar1 == 0) {
    iVar1 = sub_0800CE30();
    if (iVar1 == 0) {
      iVar1 = *(int *)DWORD_080331f4;
      dVar3 = DWORD_080331f8;
    }
    else {
      iVar1 = *(int *)DWORD_080331d4;
      dVar3 = DWORD_080331d8;
    }
    if (((int)(uint)*(byte *)(iVar1 + dVar3) >> 3 & 1U) == 0) {
      while (iVar1 = sub_0805F184(), iVar1 != 0) {
        sub_080003F0();
      }
      while (iVar1 = sub_0805EF90(), iVar1 != 0) {
        sub_080003F0();
      }
      uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08033230);
      while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
        iVar1 = sub_0800CDF8();
        if (iVar1 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
      iVar1 = sub_0805CFA0();
      if (iVar1 < 0) {
        while (iVar1 = sub_0805F184(), iVar1 != 0) {
          sub_080003F0();
        }
        while (iVar1 = sub_0805EF90(), iVar1 != 0) {
          sub_080003F0();
        }
        uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08033430);
        while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
          iVar1 = sub_0800CDF8();
          if (iVar1 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
      }
      else {
        iVar1 = sub_0800CE30();
        if (iVar1 == 0) {
          if ((*(uint *)DWORD_080332b4 & 0x20) == 0) {
            sub_08006D08(0x33);
          }
          uStack_28 = 1;
          uStack_26 = 8;
          uVar4 = 0;
          do {
            auStack_24[uVar4] = 0;
            uVar4 = uVar4 + 1;
          } while (uVar4 < 0xc);
          iVar1 = 0;
          do {
            sub_0805AB20(&uStack_28);
            iVar1 = iVar1 + 1;
          } while (iVar1 == 0);
          iVar1 = sub_0800CE30();
          if (iVar1 == 0) {
            iVar1 = *(int *)DWORD_080332d4;
            dVar3 = DWORD_080332d8;
          }
          else {
            iVar1 = *(int *)DWORD_080332b8;
            dVar3 = DWORD_080332bc;
          }
          *(byte *)(iVar1 + dVar3) = *(byte *)(iVar1 + dVar3) | 8;
          while (iVar1 = sub_0805F184(), iVar1 != 0) {
            sub_080003F0();
          }
          while (iVar1 = sub_0805EF90(), iVar1 != 0) {
            sub_080003F0();
          }
          uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08033310);
          while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
            iVar1 = sub_0800CDF8();
            if (iVar1 != 0) {
              sub_0805EFBC();
              break;
            }
            sub_080003F0();
          }
        }
        else {
          if ((*(uint *)DWORD_0803337c & 0x20) == 0) {
            sub_08006D08(0x33);
          }
          uStack_28 = 1;
          uStack_26 = 9;
          uVar4 = 0;
          do {
            auStack_24[uVar4] = 0;
            uVar4 = uVar4 + 1;
          } while (uVar4 < 0xc);
          iVar1 = 0;
          do {
            sub_0805AB20(&uStack_28);
            iVar1 = iVar1 + 1;
          } while (iVar1 == 0);
          iVar1 = sub_0800CE30();
          if (iVar1 == 0) {
            iVar1 = *(int *)DWORD_0803339c;
            dVar3 = DWORD_080333a0;
          }
          else {
            iVar1 = *(int *)DWORD_08033380;
            dVar3 = DWORD_08033384;
          }
          *(byte *)(iVar1 + dVar3) = *(byte *)(iVar1 + dVar3) | 8;
          while (iVar1 = sub_0805F184(), iVar1 != 0) {
            sub_080003F0();
          }
          while (iVar1 = sub_0805EF90(), iVar1 != 0) {
            sub_080003F0();
          }
          uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_080333d8);
          while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
            iVar1 = sub_0800CDF8();
            if (iVar1 != 0) {
              sub_0805EFBC();
              break;
            }
            sub_080003F0();
          }
        }
      }
    }
    else {
      while (iVar1 = sub_0805F184(), iVar1 != 0) {
        sub_080003F0();
      }
      while (iVar1 = sub_0805EF90(), iVar1 != 0) {
        sub_080003F0();
      }
      uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08033484);
      while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
        iVar1 = sub_0800CDF8();
        if (iVar1 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
    }
  }
  else {
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_080334d8);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      iVar1 = sub_0800CDF8();
      if (iVar1 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
  }
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_0803351c;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


