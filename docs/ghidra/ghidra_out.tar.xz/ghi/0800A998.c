
undefined4 sub_0800A998(void)

{
  dword dVar1;
  int iVar2;
  uint *puVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  short *psVar7;
  uint uVar8;
  uint uVar9;
  undefined4 unaff_r10;
  undefined4 in_lr;
  uint uStack_2c;
  undefined4 uStack_28;
  uint *puStack_24;
  
  dVar1 = DWORD_0800aa20;
  *(undefined4 *)(DWORD_0800aa20 + 0x9c) = 1;
  iVar2 = sub_080020F4();
  iVar2 = iVar2 * 0x14c + DWORD_0800aa24;
  uVar5 = (*(int *)(iVar2 + 0x8c) >> 0xb) - 0xfU & 0xffff;
  uVar8 = (*(int *)(iVar2 + 0x90) >> 0xb) - 0xbU & 0xffff;
  sub_080003F0();
  sub_080003F0();
  if ((*(short *)(dVar1 + 0x8c) != 5) || (*(short *)(dVar1 + 0x90) != 0xd)) {
    if (*(short *)(dVar1 + 0x8c) == 10) {
      if ((*(short *)(dVar1 + 0x90) == 3) || (*(short *)(dVar1 + 0x90) == 0xd)) {
        sub_080092C8(1,*(undefined4 *)(dVar1 + 0x60),uVar5,0);
        sub_080092C8(2,*(undefined4 *)(dVar1 + 0x60),uVar5,0);
      }
      else {
        sub_080092C8(1,*(undefined4 *)(dVar1 + 0x60),uVar5,uVar8);
        sub_080092C8(2,*(undefined4 *)(dVar1 + 0x60),uVar5,uVar8);
      }
    }
    else {
      sub_080092C8(1,*(undefined4 *)(dVar1 + 0x60),uVar5,uVar8);
      sub_080092C8(2,*(undefined4 *)(dVar1 + 0x60),uVar5,uVar8);
    }
    sub_080092C8(3,*(undefined4 *)(DWORD_0800aa88 + 0x60),uVar5,uVar8);
  }
  sub_0800A34C(*(undefined2 *)(DWORD_0800aa88 + 0x8c),0,0);
  puVar3 = (uint *)(DWORD_0800aa88 + 0x9c);
  puStack_24 = &uStack_2c;
  do {
    if (((*puVar3 & 2) != 0) || (iVar4 = sub_0800CB78(), iVar4 != 0)) goto LAB_0800ace2;
    while (iVar4 = sub_0800CD34(), dVar1 = DWORD_0800ab7c, iVar4 != 0) {
      sub_080003F0();
    }
    if ((*puVar3 & 0xc) != 0) {
      iVar4 = sub_0800CD8C();
      if (iVar4 == 0) {
        uStack_28 = sub_080586B4(0);
      }
      sub_080003F4(DWORD_0800ab80);
      iVar4 = sub_080021A8();
      if (iVar4 != 0) {
LAB_0800ace2:
        *(undefined4 *)(DWORD_0800ad00 + 0x9c) = 0x80000000;
        return in_lr;
      }
      uVar5 = (*(int *)(iVar2 + 0x8c) >> 0xb) - 0xf;
      uVar6 = uVar5 & 0xffff;
      uVar8 = (*(int *)(iVar2 + 0x90) >> 0xb) - 0xb;
      uVar9 = uVar8 & 0xffff;
      if ((uVar5 & 0x8000) != 0) {
        uVar6 = 0;
      }
      if ((uVar8 & 0x8000) != 0) {
        uVar9 = 0;
      }
      uVar5 = *(ushort *)(dVar1 + 0x70) - 0x1e;
      if ((int)uVar5 < (int)uVar6) {
        uVar6 = uVar5 & 0xffff;
      }
      if (*(short *)(dVar1 + 0x7e) < 0) {
        *(short *)(dVar1 + 0x7e) = 0;
      }
      uVar5 = *(ushort *)(dVar1 + 0x72) - 0x14;
      if ((int)uVar5 < (int)uVar9) {
        uVar9 = uVar5 & 0xffff;
      }
      psVar7 = (short *)(dVar1 + 0x8c);
      if ((*psVar7 == 5) && (*(short *)(dVar1 + 0x90) == 0xd)) {
        sub_08000990(1,1);
        sub_080009F8(0x800,0,1);
        sub_080009C0(0x1700,0,1);
        uStack_2c = uStack_2c & DWORD_0800ac6c | DWORD_0800ac70;
        sub_08000AA8(0,&uStack_2c);
        *(short *)puStack_24 = (short)DWORD_0800ac74;
        sub_08000AA8(1,&uStack_2c);
        *(short *)puStack_24 = (short)DWORD_0800ac78;
        sub_08000AA8(2,&uStack_2c);
        sub_0800B650(0x2d,0x1d,0x6000000,0,0xf);
        sub_0800B9F0(0x2c,0x1e);
        sub_080003F0();
        sub_080003F0();
      }
      else {
        sub_08009138(*(undefined4 *)(dVar1 + 0xb0),*psVar7);
        if (*psVar7 == 10) {
          if ((*(short *)(dVar1 + 0x90) == 3) || (*(short *)(dVar1 + 0x90) == 0xd)) {
            sub_080092C8(1,*(undefined4 *)(dVar1 + 0x60),uVar6,0);
            sub_080092C8(2,*(undefined4 *)(dVar1 + 0x60),uVar6,0);
          }
          else {
            sub_080092C8(1,*(undefined4 *)(dVar1 + 0x60),uVar6,uVar9);
            sub_080092C8(2,*(undefined4 *)(dVar1 + 0x60),uVar6,uVar9);
          }
        }
        else {
          sub_080092C8(1,*(undefined4 *)(dVar1 + 0x60),uVar6,uVar9);
          sub_080092C8(2,*(undefined4 *)(dVar1 + 0x60),uVar6,uVar9);
        }
        sub_080092C8(3,*(undefined4 *)(DWORD_0800abc8 + 0x60),uVar6,uVar9);
      }
      unaff_r10 = 1;
      *puVar3 = *puVar3 & 0xfffffff3;
      sub_0800A34C(*(undefined2 *)DWORD_0800ac7c,uStack_28,1);
      iVar4 = sub_0801AB24();
      if (iVar4 == 0) {
        sub_0801AA34(0x14);
      }
      else {
        iVar4 = sub_0801AB24();
        if (iVar4 == 2) {
          sub_0801AB90(6);
        }
        else {
          sub_0801AB50(6);
        }
      }
    }
    dVar1 = DWORD_0800acfc;
    uVar5 = 1;
    psVar7 = (short *)(DWORD_0800acfc - 2);
    do {
      sub_08009594(uVar5 & 0xffff,(int)*psVar7,(int)*(short *)dVar1,unaff_r10);
      uVar5 = uVar5 + 1;
    } while (uVar5 < 4);
    unaff_r10 = 0;
    sub_08009B84();
    sub_080003F0();
    *puVar3 = *puVar3 | 0x40;
  } while( true );
}


