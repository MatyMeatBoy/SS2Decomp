
void sub_0800CE08(void)

{
  *(uint *)DWORD_0800ce18 = *(uint *)DWORD_0800ce18 | 0x200;
  return;
}


