
undefined4 sub_0805A2B8(void)

{
  undefined4 in_lr;
  
  sub_08028AAC(8,DWORD_0805a2dc,DWORD_0805a2dc,0);
  if ((*(uint *)DWORD_0805a2e0 & 0x20) == 0) {
    sub_08006D08(0x23);
  }
  return in_lr;
}


