
undefined4 sub_080A4BE0(void)

{
  dword dVar1;
  int iVar2;
  undefined4 in_lr;
  
  dVar1 = DWORD_080a4bf8;
  iVar2 = sub_08001494(0x28);
  *(int *)dVar1 = iVar2;
  *(undefined4 *)(iVar2 + 8) = 0;
  return in_lr;
}


