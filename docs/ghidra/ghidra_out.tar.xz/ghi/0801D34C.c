
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 sub_0801D34C(void)

{
  char cVar1;
  undefined1 uVar2;
  byte bVar3;
  int iVar4;
  uint uVar5;
  ushort uVar6;
  ushort *puVar7;
  int iVar8;
  undefined4 in_lr;
  
  iVar4 = sub_080020F4();
  iVar8 = iVar4 * 0x14c + DWORD_0801d384;
  iVar4 = sub_0805AD18();
  uVar6 = *(ushort *)(*(int *)DWORD_0801d388 + 10);
  if (uVar6 == 8) {
    uVar6 = 6;
  }
  switch(uVar6 & 0xff) {
  case 0:
    uVar6 = *(ushort *)(iVar8 + 0x10);
    if (uVar6 == 2) {
code_r0x0801d714:
      uVar5 = (uint)*(ushort *)(*_UNK_0801d71c + 0x38);
      goto code_r0x0801d7a6;
    }
    if (uVar6 < 3) {
code_r0x0801d6fa:
      if (uVar6 == 1) goto code_r0x0801d706;
    }
    else if (uVar6 == 3) {
      uVar5 = (uint)*(ushort *)(*_UNK_0801d3cc + 0x3c);
      goto code_r0x0801d7a6;
    }
    break;
  case 1:
    if (*(short *)(iVar8 + 0x10) == 5) {
code_r0x0801d706:
      uVar5 = (uint)*(ushort *)(*_UNK_0801d710 + 0x34);
      goto code_r0x0801d7a6;
    }
    if (*(short *)(iVar8 + 0x10) == 9) {
      iVar8 = *_UNK_0801d494 + (uint)*(ushort *)(*_UNK_0801d494 + 0x68) * 0x10;
      if (*(char *)(iVar8 + 0x79) == '\0') {
        iVar8 = 0;
      }
      else {
        iVar8 = sub_08007290(*(ushort *)(iVar8 + 0x72) | 0xb0000);
      }
      if (*(char *)(iVar8 + 0x9b) == '\t') {
        uVar2 = *(undefined1 *)(iVar8 + 0xa7);
      }
      else {
        uVar2 = 0;
      }
      switch(uVar2) {
      case 1:
code_r0x0801d4ec:
        uVar5 = (uint)*(ushort *)(iVar4 + 0xac);
        if (*(ushort *)(*_UNK_0801d504 + 0x38) <= uVar5) {
          uVar5 = (uint)*(ushort *)(*_UNK_0801d504 + 0x38);
        }
        goto code_r0x0801d7a6;
      case 2:
code_r0x0801d508:
        uVar5 = (uint)*(ushort *)(iVar4 + 0xac);
        if (*(ushort *)(*_UNK_0801d520 + 0x3c) <= uVar5) {
          uVar5 = (uint)*(ushort *)(*_UNK_0801d520 + 0x3c);
        }
        goto code_r0x0801d7a6;
      case 3:
        puVar7 = (ushort *)(*_UNK_0801d534 + 0x40);
        break;
      case 4:
        puVar7 = (ushort *)(*_UNK_0801d548 + 0x44);
        break;
      case 5:
code_r0x0801d438:
        puVar7 = (ushort *)(*_UNK_0801d454 + 0x48);
        break;
      case 6:
        puVar7 = (ushort *)(*_UNK_0801d55c + 0x4c);
        break;
      default:
        goto LAB_0801d7a4;
      }
code_r0x0801d444:
      uVar5 = (uint)*(ushort *)(iVar4 + 0xac);
      if (*puVar7 <= uVar5) {
        uVar5 = (uint)*puVar7;
      }
      goto code_r0x0801d7a6;
    }
    break;
  case 2:
    uVar6 = *(ushort *)(iVar8 + 0x10);
    if (uVar6 == 7) goto code_r0x0801d706;
    if (uVar6 < 8) {
      if (uVar6 == 3) goto code_r0x0801d714;
    }
    else if (uVar6 == 9) {
      iVar8 = *_UNK_0801d408 + (uint)*(ushort *)(*_UNK_0801d408 + 0x68) * 0x10;
      if (*(char *)(iVar8 + 0x79) == '\0') {
        iVar8 = 0;
      }
      else {
        iVar8 = sub_08007290(*(ushort *)(iVar8 + 0x72) | 0xb0000);
      }
      if (*(char *)(iVar8 + 0x9b) == '\t') {
        cVar1 = *(char *)(iVar8 + 0xa7);
      }
      else {
        cVar1 = '\0';
      }
      if (cVar1 == '\a') goto code_r0x0801d438;
    }
    break;
  case 3:
    uVar6 = *(ushort *)(iVar8 + 0x10);
    if (uVar6 == 2) goto code_r0x0801d706;
joined_r0x0801d62c:
    if (uVar6 == 4) goto code_r0x0801d714;
    break;
  case 4:
    uVar6 = *(ushort *)(iVar8 + 0x10);
    if (uVar6 == 5) goto code_r0x0801d706;
    if (uVar6 < 6) goto joined_r0x0801d62c;
    if (uVar6 == 9) {
      iVar8 = *_UNK_0801d654 + (uint)*(ushort *)(*_UNK_0801d654 + 0x68) * 0x10;
      if (*(char *)(iVar8 + 0x79) == '\0') {
        iVar8 = 0;
      }
      else {
        iVar8 = sub_08007290(*(ushort *)(iVar8 + 0x72) | 0xb0000);
      }
      if (*(char *)(iVar8 + 0x9b) == '\t') {
        uVar2 = *(undefined1 *)(iVar8 + 0xa7);
      }
      else {
        uVar2 = 0;
      }
      switch(uVar2) {
      case 8:
        goto code_r0x0801d508;
      case 9:
        puVar7 = (ushort *)(*_UNK_0801d6b8 + 0x40);
        break;
      case 10:
        puVar7 = (ushort *)(*_UNK_0801d6cc + 0x44);
        break;
      case 0xb:
        goto code_r0x0801d438;
      case 0xc:
        puVar7 = (ushort *)(*_UNK_0801d6e0 + 0x4c);
        break;
      default:
        goto LAB_0801d7a4;
      }
      goto code_r0x0801d444;
    }
    break;
  case 5:
    if (*(short *)(iVar8 + 0x10) == 6) goto code_r0x0801d706;
    if (*(short *)(iVar8 + 0x10) == 8) goto code_r0x0801d714;
    break;
  case 6:
    if (*(short *)(iVar8 + 0x10) == 5) goto code_r0x0801d706;
    if (*(short *)(iVar8 + 0x10) == 9) {
      iVar8 = *_UNK_0801d58c + (uint)*(ushort *)(*_UNK_0801d58c + 0x68) * 0x10;
      if (*(char *)(iVar8 + 0x79) == '\0') {
        iVar8 = 0;
      }
      else {
        iVar8 = sub_08007290(*(ushort *)(iVar8 + 0x72) | 0xb0000);
      }
      if (*(char *)(iVar8 + 0x9b) == '\t') {
        uVar2 = *(undefined1 *)(iVar8 + 0xa7);
      }
      else {
        uVar2 = 0;
      }
      switch(uVar2) {
      case 0xd:
        goto code_r0x0801d4ec;
      case 0xe:
        goto code_r0x0801d508;
      case 0xf:
        puVar7 = (ushort *)(*_UNK_0801d5f4 + 0x40);
        break;
      case 0x10:
        puVar7 = (ushort *)(*_UNK_0801d608 + 0x44);
        break;
      case 0x11:
        goto code_r0x0801d438;
      case 0x12:
        puVar7 = (ushort *)(*_UNK_0801d61c + 0x4c);
        break;
      default:
        goto LAB_0801d7a4;
      }
      goto code_r0x0801d444;
    }
    break;
  case 7:
    uVar6 = *(ushort *)(iVar8 + 0x10);
    if (uVar6 == 8) goto code_r0x0801d714;
    if (uVar6 < 9) goto code_r0x0801d6fa;
    if (uVar6 != 9) break;
    iVar8 = *_UNK_0801d73c + (uint)*(ushort *)(*_UNK_0801d73c + 0x68) * 0x10;
    if (*(char *)(iVar8 + 0x79) == '\0') {
      iVar8 = 0;
    }
    else {
      iVar8 = sub_08007290(*(ushort *)(iVar8 + 0x72) | 0xb0000);
    }
    if (*(char *)(iVar8 + 0x9b) == '\t') {
      bVar3 = *(byte *)(iVar8 + 0xa7);
    }
    else {
      bVar3 = 0;
    }
    if (bVar3 == 0x14) goto code_r0x0801d438;
    if (bVar3 < 0x15) {
      if (bVar3 == 0x13) {
        puVar7 = (ushort *)(*_UNK_0801d78c + 0x40);
        goto code_r0x0801d444;
      }
    }
    else if (bVar3 == 0x15) {
      puVar7 = (ushort *)(*_UNK_0801d7a0 + 0x44);
      goto code_r0x0801d444;
    }
  }
LAB_0801d7a4:
  uVar5 = 0;
code_r0x0801d7a6:
  return CONCAT44(in_lr,uVar5);
}


