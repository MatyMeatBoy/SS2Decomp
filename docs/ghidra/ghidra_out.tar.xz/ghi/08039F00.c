
undefined4 sub_08039F00(undefined4 param_1)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  short *psVar6;
  short *psVar7;
  dword dVar8;
  uint uVar9;
  undefined4 in_lr;
  undefined2 uStack_38;
  undefined2 uStack_36;
  undefined1 auStack_34 [28];
  
  iVar2 = sub_080020F4();
  iVar2 = iVar2 * 0x14c + DWORD_08039f50;
  *(uint *)(iVar2 + 0x30) = *(uint *)(iVar2 + 0x30) | 1;
  sub_0800D0F4();
  sub_08028AAC(param_1,0x6f,0xdd,0);
  sub_0802949C(param_1,0);
  iVar2 = sub_080020F4();
  iVar3 = sub_0800CE30();
  if (iVar3 == 0) {
    iVar3 = *(int *)DWORD_08039fa4;
    dVar8 = DWORD_08039fa8;
  }
  else {
    iVar3 = *(int *)DWORD_08039f54;
    dVar8 = DWORD_08039f58;
  }
  bVar1 = *(byte *)(iVar3 + dVar8);
  if (9 < bVar1) {
    if (iVar2 == 0) {
      while (iVar2 = sub_0805F184(), iVar2 != 0) {
        sub_080003F0();
      }
      while (iVar2 = sub_0805EF90(), iVar2 != 0) {
        sub_080003F0();
      }
      uVar5 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803a3c0);
      while (iVar2 = sub_0805EEFC(uVar5), iVar2 == 0) {
        iVar2 = sub_0800CDF8();
        if (iVar2 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
    }
    else {
      while (iVar2 = sub_0805F184(), iVar2 != 0) {
        sub_080003F0();
      }
      while (iVar2 = sub_0805EF90(), iVar2 != 0) {
        sub_080003F0();
      }
      uVar5 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803a414);
      while (iVar2 = sub_0805EEFC(uVar5), iVar2 == 0) {
        iVar2 = sub_0800CDF8();
        if (iVar2 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
    }
    goto LAB_0803a432;
  }
  if (iVar2 != 0) {
    while (iVar2 = sub_0805F184(), iVar2 != 0) {
      sub_080003F0();
    }
    while (iVar2 = sub_0805EF90(), iVar2 != 0) {
      sub_080003F0();
    }
    uVar5 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803a364);
    while (iVar2 = sub_0805EEFC(uVar5), iVar2 == 0) {
      iVar2 = sub_0800CDF8();
      if (iVar2 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
    goto LAB_0803a432;
  }
  iVar2 = 0;
  uVar9 = 0;
  psVar6 = (short *)(*(int *)DWORD_08039fac + 0x150);
  do {
    if ((*psVar6 == 1) && (psVar6[1] == 0x2e)) {
      iVar2 = iVar2 + 1;
    }
    psVar6 = psVar6 + 8;
    uVar9 = uVar9 + 1;
  } while (uVar9 < 0x19);
  if (iVar2 < 1) {
    while (iVar2 = sub_0805F184(), iVar2 != 0) {
      sub_080003F0();
    }
    while (iVar2 = sub_0805EF90(), iVar2 != 0) {
      sub_080003F0();
    }
    uVar5 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803a2fc);
    while (iVar2 = sub_0805EEFC(uVar5), iVar2 == 0) {
      iVar2 = sub_0800CDF8();
      if (iVar2 != 0) goto LAB_0803a316;
      sub_080003F0();
    }
  }
  else {
    while (iVar3 = sub_0805F184(), iVar3 != 0) {
      sub_080003F0();
    }
    uVar5 = sub_0805DF38(1,0xf,2,0,0xfffffffe,DWORD_08039fd8);
    while (iVar3 = sub_0805EEFC(uVar5), iVar3 == 0) {
      sub_080003F0();
    }
    iVar3 = sub_0805EF14(uVar5);
    if (iVar3 == 0) {
      while (iVar2 = sub_0805F184(), iVar2 != 0) {
        sub_080003F0();
      }
      while (iVar2 = sub_0805EF90(), iVar2 != 0) {
        sub_080003F0();
      }
      uVar5 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803a2ac);
      while (iVar2 = sub_0805EEFC(uVar5), iVar2 == 0) {
        iVar2 = sub_0800CDF8();
        if (iVar2 != 0) goto LAB_0803a316;
        sub_080003F0();
      }
    }
    else {
      iVar3 = (uint)bVar1 + iVar2;
      while (iVar4 = sub_0805F184(), iVar4 != 0) {
        sub_080003F0();
      }
      while (iVar4 = sub_0805EF90(), iVar4 != 0) {
        sub_080003F0();
      }
      uVar5 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803a030);
      while (iVar4 = sub_0805EEFC(uVar5), iVar4 == 0) {
        iVar4 = sub_0800CDF8();
        if (iVar4 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
      dVar8 = DWORD_0803a09c;
      uVar9 = 0;
      do {
        iVar4 = *(int *)dVar8 + uVar9 * 0x10;
        psVar6 = (short *)(iVar4 + 0x150);
        if ((*psVar6 == 1) && (psVar7 = (short *)(iVar4 + 0x152), *psVar7 == 0x2e)) {
          iVar2 = iVar2 + -1;
          *psVar6 = 0;
          *psVar7 = 0;
          if (iVar2 == 0) break;
        }
        uVar9 = uVar9 + 1;
      } while (uVar9 < 0x19);
      iVar2 = sub_0800CE30();
      if (iVar2 == 0) {
        iVar2 = *(int *)DWORD_0803a0bc;
        dVar8 = DWORD_0803a0c0;
      }
      else {
        iVar2 = *(int *)DWORD_0803a0a0;
        dVar8 = DWORD_0803a0a4;
      }
      *(char *)(iVar2 + dVar8) = (char)iVar3;
      if (9 < iVar3) {
        while (iVar2 = sub_0805F184(), iVar2 != 0) {
          sub_080003F0();
        }
        while (iVar2 = sub_0805EF90(), iVar2 != 0) {
          sub_080003F0();
        }
        uVar5 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803a0f8);
        while (iVar2 = sub_0805EEFC(uVar5), iVar2 == 0) {
          iVar2 = sub_0800CDF8();
          if (iVar2 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
        sub_08068070(DWORD_0803a164,iVar3);
        iVar2 = sub_0800CE30();
        if (iVar2 == 0) {
          if ((*(uint *)DWORD_0803a168 & 0x20) == 0) {
            sub_08006D08(0x33);
          }
          uStack_38 = 6;
          uStack_36 = 0x58;
          uVar9 = 0;
          do {
            auStack_34[uVar9] = 0;
            uVar9 = uVar9 + 1;
          } while (uVar9 < 0xc);
          iVar2 = 0;
          do {
            sub_0805AB20(&uStack_38);
            iVar2 = iVar2 + 1;
          } while (iVar2 == 0);
          while (iVar2 = sub_0805F184(), iVar2 != 0) {
            sub_080003F0();
          }
          while (iVar2 = sub_0805EF90(), iVar2 != 0) {
            sub_080003F0();
          }
          uVar5 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803a1a0);
          while (iVar2 = sub_0805EEFC(uVar5), iVar2 == 0) {
            iVar2 = sub_0800CDF8();
            if (iVar2 != 0) {
              sub_0805EFBC();
              break;
            }
            sub_080003F0();
          }
        }
        else {
          if ((*(uint *)DWORD_0803a1fc & 0x20) == 0) {
            sub_08006D08(0x33);
          }
          uStack_38 = 6;
          uStack_36 = 0x23;
          uVar9 = 0;
          do {
            auStack_34[uVar9] = 0;
            uVar9 = uVar9 + 1;
          } while (uVar9 < 0xc);
          iVar2 = 0;
          do {
            sub_0805AB20(&uStack_38);
            iVar2 = iVar2 + 1;
          } while (iVar2 == 0);
          while (iVar2 = sub_0805F184(), iVar2 != 0) {
            sub_080003F0();
          }
          while (iVar2 = sub_0805EF90(), iVar2 != 0) {
            sub_080003F0();
          }
          uVar5 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803a234);
          while (iVar2 = sub_0805EEFC(uVar5), iVar2 == 0) {
            iVar2 = sub_0800CDF8();
            if (iVar2 != 0) {
              sub_0805EFBC();
              break;
            }
            sub_080003F0();
          }
        }
        iVar2 = sub_080020F4();
        iVar2 = iVar2 * 0x14c + DWORD_0803a274;
        *(uint *)(iVar2 + 0x30) = *(uint *)(iVar2 + 0x30) & 0xfffffffe;
        sub_0800D108();
        return in_lr;
      }
    }
  }
LAB_0803a31a:
  sub_080290E4(param_1,0);
  sub_08028D98(param_1,0,3,4);
LAB_0803a432:
  iVar2 = sub_080020F4();
  iVar2 = iVar2 * 0x14c + DWORD_0803a45c;
  *(uint *)(iVar2 + 0x30) = *(uint *)(iVar2 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
LAB_0803a316:
  sub_0805EFBC();
  goto LAB_0803a31a;
}


