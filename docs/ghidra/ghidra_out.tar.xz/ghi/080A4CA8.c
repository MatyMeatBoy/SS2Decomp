
undefined4 sub_080A4CA8(uint param_1,undefined1 param_2,undefined1 param_3,ushort param_4)

{
  undefined4 in_lr;
  
  param_1 = param_1 & 0xff;
  *(undefined1 *)(param_1 + DWORD_080a4cd0) = param_2;
  *(undefined1 *)(param_1 + DWORD_080a4cd4) = param_3;
  *(ushort *)(*(int *)(param_1 * 4 + DWORD_080a4cd8) + 8) = param_4 & 0xff;
  return in_lr;
}


