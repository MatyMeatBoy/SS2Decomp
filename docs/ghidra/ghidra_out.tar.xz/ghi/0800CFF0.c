
uint sub_0800CFF0(void)

{
  return *(uint *)DWORD_0800cffc >> 0x12 & 1;
}


