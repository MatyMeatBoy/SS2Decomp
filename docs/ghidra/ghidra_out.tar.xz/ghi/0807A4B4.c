
undefined8 sub_0807A4B4(int param_1,uint param_2)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  param_2 = param_2 & 0xff;
  sub_08013850();
  sub_0800CB30();
  iVar2 = sub_0807A20C(param_2);
  dVar1 = DWORD_0807a504;
  if (iVar2 == 0) {
    iVar3 = *(int *)DWORD_0807a504;
    iVar2 = param_2 * 0x6c + param_1;
    *(ushort *)(iVar3 + 10) = (ushort)*(byte *)(iVar2 + 1);
    *(ushort *)(iVar3 + 0xc) = (ushort)*(byte *)(iVar2 + 2);
    *(short *)(iVar3 + 0xe) = (short)param_2;
    *(undefined1 *)(param_1 + 4) = 0;
    uVar4 = 0;
    do {
      *(undefined1 *)(*(int *)dVar1 + uVar4) = *(undefined1 *)(iVar2 + 0x10 + uVar4);
      uVar4 = uVar4 + 1;
    } while (uVar4 < 10);
    sub_0801ACB8();
  }
  else {
    param_1 = param_2 * 0x6c + param_1;
    if (*(char *)(param_1 + 7) != '\0') {
      sub_0800CE08();
    }
    dVar1 = DWORD_0807a540;
    if (*(char *)(param_1 + 6) != '\0') {
      uVar4 = 0;
      do {
        *(undefined2 *)(*(int *)dVar1 + uVar4 * 0x20 + 0x1e6) = 0;
        uVar4 = uVar4 + 1;
      } while (uVar4 < 0x10);
    }
  }
  return CONCAT44(in_lr,1);
}


