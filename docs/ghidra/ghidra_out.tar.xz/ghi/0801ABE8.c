
undefined4 sub_0801ABE8(undefined2 param_1)

{
  undefined4 in_lr;
  
  *(undefined2 *)DWORD_0801ac14 = 1;
  *(undefined2 *)DWORD_0801ac18 = param_1;
  *(undefined2 *)DWORD_0801ac1c = 0;
  sub_08000420(100);
  *(ushort *)DWORD_0801ac20 = *(ushort *)DWORD_0801ac20 & 0xffdf | 0xc;
  return in_lr;
}


