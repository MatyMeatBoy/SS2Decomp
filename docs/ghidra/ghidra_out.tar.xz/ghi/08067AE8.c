
undefined4 sub_08067AE8(void)

{
  return 1;
}


