
undefined4 sub_08097EB0(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4)

{
  undefined4 in_lr;
  
  *(undefined2 *)DWORD_08097ed0 = param_4;
  *(undefined2 *)DWORD_08097ed4 = param_3;
  *(undefined2 *)DWORD_08097ed8 = 0;
  *(undefined4 *)DWORD_08097edc = param_1;
  *(undefined2 *)DWORD_08097ee0 = param_2;
  return in_lr;
}


