
undefined4 sub_080316A4(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_080316d0;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) | 1;
  sub_0800D0F4();
  sub_0802949C(param_1,0);
  while (iVar1 = sub_0805F184(), iVar1 != 0) {
    sub_080003F0();
  }
  uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,DWORD_080316fc);
  while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
    sub_080003F0();
  }
  iVar1 = sub_0805EF14(uVar2);
  if (iVar1 == 0) {
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,DWORD_08031740);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      sub_080003F0();
    }
    iVar1 = sub_0805EF14(uVar2);
    if (iVar1 == 0) {
      while (iVar1 = sub_0805F184(), iVar1 != 0) {
        sub_080003F0();
      }
      while (iVar1 = sub_0805EF90(), iVar1 != 0) {
        sub_080003F0();
      }
      uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08031794);
      while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
        iVar1 = sub_0800CDF8();
        if (iVar1 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
    }
    else {
      while (iVar1 = sub_0805F184(), iVar1 != 0) {
        sub_080003F0();
      }
      while (iVar1 = sub_0805EF90(), iVar1 != 0) {
        sub_080003F0();
      }
      uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_080317e8);
      while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
        iVar1 = sub_0800CDF8();
        if (iVar1 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
    }
  }
  else {
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803183c);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      iVar1 = sub_0800CDF8();
      if (iVar1 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
  }
  sub_08029788(param_1);
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_08031888;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


