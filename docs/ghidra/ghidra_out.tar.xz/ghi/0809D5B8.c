
undefined4 sub_0809D5B8(void)

{
  dword dVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined4 in_lr;
  
  dVar1 = DWORD_0809d5e0;
  uVar2 = sub_08001494(0x140);
  *(undefined4 *)dVar1 = uVar2;
  iVar4 = 0;
  iVar3 = 7;
  do {
    *(undefined4 *)(iVar4 + *(int *)dVar1 + 8) = 0;
    iVar4 = iVar4 + 0x28;
    iVar3 = iVar3 + -1;
  } while (-1 < iVar3);
  return in_lr;
}


