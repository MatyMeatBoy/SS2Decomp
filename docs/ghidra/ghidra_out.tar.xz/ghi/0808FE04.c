
undefined8 sub_0808FE04(undefined4 param_1)

{
  dword dVar1;
  dword dVar2;
  int iVar3;
  undefined4 uVar4;
  uint *puVar5;
  undefined4 unaff_r4;
  undefined4 in_lr;
  
  dVar1 = DWORD_0808fe90;
  if (*(short *)(*(int *)DWORD_0808fe90 + 0x10) == 0) {
    sub_0802704C(param_1);
    sub_08057328(0,DWORD_0808feb4);
  }
  else {
    iVar3 = sub_08056E90();
    if (iVar3 != 0) {
      sub_08058404(unaff_r4);
      sub_080570DC(1);
      sub_08056FB8(0,0);
      iVar3 = sub_080020F4();
      dVar2 = DWORD_0808fe94;
      *(undefined1 *)(iVar3 * 0x14c + DWORD_0808fe94 + 0x68) = 1;
      sub_08056E78();
      *(undefined2 *)(*(int *)dVar1 + 0x36) = 0;
      iVar3 = sub_080020F4();
      puVar5 = (uint *)(iVar3 * 0x14c + dVar2 + 0x30);
      *puVar5 = *puVar5 & 0xfffffffd;
      iVar3 = sub_080020F4();
      *(undefined2 *)(iVar3 * 0x14c + dVar2 + 0x20) = 0;
      iVar3 = sub_080020F4();
      *(undefined2 *)(iVar3 * 0x14c + dVar2 + 0x1c) = 4;
      iVar3 = *(int *)dVar1;
      *(undefined2 *)(iVar3 + 0x30) = 1;
      *(undefined2 *)(iVar3 + 0x24) = 1;
      uVar4 = 1;
      goto LAB_0808fea8;
    }
  }
  uVar4 = 0;
LAB_0808fea8:
  return CONCAT44(in_lr,uVar4);
}


