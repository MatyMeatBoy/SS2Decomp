
undefined4 sub_08015820(int param_1)

{
  short sVar1;
  dword dVar2;
  int iVar3;
  dword dVar4;
  int iVar5;
  undefined4 in_lr;
  
  dVar2 = DWORD_0801586c;
  iVar3 = sub_08000470(param_1 * 0x28 + DWORD_0801586c);
  if (iVar3 == 0) {
    sVar1 = *(short *)(param_1 * 0x14c + DWORD_0801588c + 0x10);
    dVar4 = DWORD_0801589c;
    if ((sVar1 == 1) || (dVar4 = DWORD_080158c0, sVar1 == 8)) {
      *(dword *)(param_1 * 0x28 + dVar2 + 0xc) = dVar4;
      *(undefined4 *)(param_1 * 0x28 + DWORD_080158c4 + 8) = 0x34;
      while( true ) {
        iVar3 = sub_08001494(0x400);
        dVar2 = DWORD_08015910;
        iVar5 = param_1 * 0x28;
        *(int *)(iVar5 + DWORD_08015910 + 0x20) = iVar3;
        if (iVar3 != 0) break;
        sub_080003F0();
      }
      *(int *)(iVar5 + dVar2 + 0x10) = iVar3 + 0x3fc;
      *(undefined4 *)(iVar5 + dVar2 + 0x24) = 0;
      sub_08000274(iVar5 + dVar2,param_1);
    }
  }
  else {
    iVar3 = sub_080020F4();
    if (iVar3 == param_1) {
      iVar3 = param_1 * 0x14c + DWORD_08015870;
      if ((1 < (ushort)(*(short *)(iVar3 + 0x20) - 10U)) &&
         ((*(uint *)(param_1 * 0x14c + DWORD_08015870 + 0x30) & 0x2000) == 0)) {
        *(undefined2 *)(iVar3 + 0x20) = 0;
      }
    }
  }
  return in_lr;
}


