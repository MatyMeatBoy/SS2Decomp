
void sub_080B6B10(void)

{
  byte *extraout_r1;
  char in_r3;
  code *UNRECOVERED_JUMPTABLE;
  
  sub_080B69AC();
  extraout_r1[0xc] = in_r3 - 0x40;
  *extraout_r1 = *extraout_r1 | 0xc;
                    /* WARNING: Could not recover jumptable at 0x080b6b22. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)();
  return;
}


