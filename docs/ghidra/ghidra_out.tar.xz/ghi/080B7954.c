
undefined4 m4aMPlayStop(int param_1)

{
  uint uVar1;
  int iVar2;
  undefined4 in_lr;
  
  if (*(dword *)(param_1 + 0x34) == DWORD_080b7990) {
    *(dword *)(param_1 + 0x34) = *(dword *)(param_1 + 0x34) + 1;
    *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) | 0x80000000;
    uVar1 = (uint)*(byte *)(param_1 + 8);
    iVar2 = *(int *)(param_1 + 0x2c);
    if (uVar1 != 0) {
      do {
        TrackStop(param_1,iVar2);
        uVar1 = uVar1 - 1;
        iVar2 = iVar2 + 0x50;
      } while (0 < (int)uVar1);
    }
    *(dword *)(param_1 + 0x34) = DWORD_080b7990;
  }
  return in_lr;
}


