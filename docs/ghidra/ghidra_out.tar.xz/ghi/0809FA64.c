
undefined4 sub_0809FA64(undefined2 param_1)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  undefined4 in_lr;
  
  iVar3 = *(int *)DWORD_0809fa78;
  if (iVar3 != 0) {
    for (bVar1 = 0; bVar1 < 4; bVar1 = bVar1 + 1) {
      iVar2 = sub_08000470(iVar3);
      if ((iVar2 == 0) && (*(int *)(iVar3 + 8) == 0)) {
        iVar2 = sub_08001494(0x200);
        *(int *)(iVar3 + 0x20) = iVar2;
        if (iVar2 == 0) {
          return in_lr;
        }
        *(int *)(iVar3 + 0x10) = iVar2 + 0x1fc;
        *(dword *)(iVar3 + 0xc) = DWORD_0809fac8;
        *(undefined4 *)(iVar3 + 0x24) = 0;
        *(undefined4 *)(iVar3 + 8) = 0x40;
        sub_08000274(iVar3,param_1);
        return in_lr;
      }
      iVar3 = iVar3 + 0x28;
    }
  }
  return in_lr;
}


