
undefined4 sub_080A9844(void)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  uVar4 = 0;
  iVar3 = *(int *)DWORD_080a9878;
  do {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 != 0) {
      sub_080003A8(iVar3);
    }
    dVar1 = DWORD_080a9878;
    iVar3 = iVar3 + 0x28;
    uVar4 = uVar4 + 1;
  } while (uVar4 < 3);
  sub_08001538(*(undefined4 *)DWORD_080a9878);
  *(undefined4 *)dVar1 = 0;
  return in_lr;
}


