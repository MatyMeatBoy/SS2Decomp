
undefined8 sub_080683DC(int param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  undefined4 in_lr;
  
  uVar1 = sub_08002164();
  iVar5 = 0;
  uVar4 = 0;
  if (uVar1 != 0) {
    do {
      uVar3 = 0;
      uVar6 = uVar4 + 1;
      iVar2 = uVar4 * 0x28;
      while (*(int *)(iVar2 + DWORD_08068418) != param_1) {
        uVar3 = uVar3 + 1;
        if (*(uint *)(uVar4 * 4 + DWORD_08068414) < uVar3) goto LAB_0806843a;
        iVar2 = uVar3 * 4 + uVar4 * 0x28;
      }
      iVar5 = iVar5 + 1;
LAB_0806843a:
      uVar4 = uVar6;
    } while (uVar6 < uVar1);
  }
  return CONCAT44(in_lr,iVar5);
}


