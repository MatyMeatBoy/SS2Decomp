
undefined4 sub_08052060(void)

{
  dword dVar1;
  dword dVar2;
  dword dVar3;
  dword dVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  undefined4 in_lr;
  undefined1 auStack_2c [12];
  dword dStack_20;
  undefined4 uStack_1c;
  
  dVar1 = DWORD_08052074;
  iVar6 = *(int *)DWORD_08052078 + DWORD_0805207c;
  for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
    iVar5 = sub_08000470(iVar6);
    if (iVar5 == 0) goto LAB_08052098;
    iVar6 = iVar6 + 0x28;
  }
LAB_080520c2:
  dVar1 = DWORD_080520d0;
  iVar6 = *(int *)DWORD_080520d4 + DWORD_080520d8;
  for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
    iVar5 = sub_08000470(iVar6);
    if (iVar5 == 0) goto LAB_080520f4;
    iVar6 = iVar6 + 0x28;
  }
LAB_0805211e:
  dVar1 = DWORD_0805212c;
  iVar6 = *(int *)DWORD_08052130 + DWORD_08052134;
  for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
    iVar5 = sub_08000470(iVar6);
    if (iVar5 == 0) goto LAB_08052150;
    iVar6 = iVar6 + 0x28;
  }
LAB_0805217a:
  iVar6 = sub_080020F4();
  dVar4 = DWORD_080522c8;
  dVar3 = DWORD_08052268;
  dVar2 = DWORD_08052208;
  dVar1 = DWORD_080521a8;
  if (iVar6 == 1) {
    iVar6 = *(int *)DWORD_0805220c + DWORD_08052210;
    for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
      iVar5 = sub_08000470(iVar6);
      if (iVar5 == 0) goto LAB_0805222c;
      iVar6 = iVar6 + 0x28;
    }
  }
  else if (iVar6 < 2) {
    if (iVar6 == 0) {
      iVar6 = *(int *)DWORD_080521ac + DWORD_080521b0;
      for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
        iVar5 = sub_08000470(iVar6);
        if (iVar5 == 0) goto LAB_080521ce;
        iVar6 = iVar6 + 0x28;
      }
    }
  }
  else if (iVar6 == 2) {
    iVar6 = *(int *)DWORD_0805226c + DWORD_08052270;
    for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
      iVar5 = sub_08000470(iVar6);
      if (iVar5 == 0) goto LAB_0805228c;
      iVar6 = iVar6 + 0x28;
    }
  }
  else if (iVar6 == 3) {
    iVar6 = *(int *)DWORD_080522cc + DWORD_080522d0;
    for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
      iVar5 = sub_08000470(iVar6);
      if (iVar5 == 0) goto LAB_080522ec;
      iVar6 = iVar6 + 0x28;
    }
  }
LAB_08052316:
  dVar1 = DWORD_08052338;
  uVar7 = *(uint *)(*(int *)DWORD_08052334 + 0x38) & 0x10;
  if (uVar7 != 0) {
    uVar7 = 1;
  }
  if (uVar7 == 0) {
    iVar6 = *(int *)DWORD_08052334 + DWORD_0805233c;
    for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
      iVar5 = sub_08000470(iVar6);
      if (iVar5 == 0) {
        dStack_20 = dVar1;
        uStack_1c = 0;
        *(undefined4 *)(iVar6 + 8) = 0x3c;
        iVar5 = sub_08001494(0x400);
        *(int *)(iVar6 + 0x20) = iVar5;
        *(dword *)(iVar6 + 0xc) = DWORD_080523a4;
        *(int *)(iVar6 + 0x10) = iVar5 + 0x3fc;
        *(undefined4 *)(iVar6 + 0x24) = 0;
        sub_08000274(iVar6,auStack_2c,6);
        sub_080003F0();
        sub_080003F0();
        break;
      }
      iVar6 = iVar6 + 0x28;
    }
  }
  iVar6 = sub_0800CC98();
  if (iVar6 == 0) {
    iVar6 = sub_0801AB24();
    if (iVar6 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar6 < 2) {
      if (iVar6 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar6 == 2) {
      sub_0801AB90(6);
    }
    while (iVar6 = sub_0801AAE0(), iVar6 == 0) {
      sub_080003F0();
    }
  }
  return in_lr;
LAB_08052098:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar6 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar6 + 8) = 0x3c;
  *(dword *)(iVar6 + 0xc) = dVar1;
  *(int *)(iVar6 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar6 + 0x24) = 0;
  sub_08000274(iVar6,0x3b);
  goto LAB_080520c2;
LAB_080520f4:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar6 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar6 + 8) = 0x3c;
  *(dword *)(iVar6 + 0xc) = dVar1;
  *(int *)(iVar6 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar6 + 0x24) = 0;
  sub_08000274(iVar6,0x3c);
  goto LAB_0805211e;
LAB_08052150:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar6 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar6 + 8) = 0x3c;
  *(dword *)(iVar6 + 0xc) = dVar1;
  *(int *)(iVar6 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar6 + 0x24) = 0;
  sub_08000274(iVar6,0x3d);
  goto LAB_0805217a;
LAB_0805222c:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar6 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar6 + 8) = 0x3c;
  *(dword *)(iVar6 + 0xc) = dVar2;
  *(int *)(iVar6 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar6 + 0x24) = 0;
  sub_08000274(iVar6,0x3f);
  goto LAB_08052316;
LAB_0805228c:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar6 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar6 + 8) = 0x3c;
  *(dword *)(iVar6 + 0xc) = dVar3;
  *(int *)(iVar6 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar6 + 0x24) = 0;
  sub_08000274(iVar6,0x40);
  goto LAB_08052316;
LAB_080522ec:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar6 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar6 + 8) = 0x3c;
  *(dword *)(iVar6 + 0xc) = dVar4;
  *(int *)(iVar6 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar6 + 0x24) = 0;
  sub_08000274(iVar6,0x41);
  goto LAB_08052316;
LAB_080521ce:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar6 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar6 + 8) = 0x3c;
  *(dword *)(iVar6 + 0xc) = dVar1;
  *(int *)(iVar6 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar6 + 0x24) = 0;
  sub_08000274(iVar6,0x3e);
  goto LAB_08052316;
}


