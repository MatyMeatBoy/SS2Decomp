
void sub_08097D3C(undefined1 param_1,char param_2)

{
  undefined1 uVar1;
  dword dVar2;
  
  dVar2 = DWORD_08097d5c;
  *(undefined1 *)(DWORD_08097d5c + 0xc) = param_1;
  uVar1 = (undefined1)
          ((uint)((int)param_2 * (int)*(short *)((uint)*(byte *)(dVar2 + 0xc) * 2 + DWORD_08097d60))
          >> 8);
  *(undefined1 *)(dVar2 + 0xd) = uVar1;
  *(undefined1 *)(dVar2 + 0xe) = uVar1;
  return;
}


