
undefined4 sub_0805EF90(void)

{
  uint uVar1;
  
  uVar1 = 0;
  do {
    if (((int)(uint)*(byte *)DWORD_0805efa8 >> uVar1 & 1U) != 0) {
      return 1;
    }
    uVar1 = uVar1 + 1 & 0xff;
  } while (uVar1 < 4);
  return 0;
}


