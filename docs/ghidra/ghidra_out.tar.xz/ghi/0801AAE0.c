
bool sub_0801AAE0(void)

{
  return (*(ushort *)DWORD_0801aaf4 & 0x16) == 0;
}


