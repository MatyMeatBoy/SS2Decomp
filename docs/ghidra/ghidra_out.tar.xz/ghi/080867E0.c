
undefined4 sub_080867E0(void)

{
  dword dVar1;
  undefined4 in_lr;
  
  dVar1 = DWORD_080867f4;
  sub_08001538(*(undefined4 *)DWORD_080867f4);
  *(undefined4 *)dVar1 = 0;
  return in_lr;
}


