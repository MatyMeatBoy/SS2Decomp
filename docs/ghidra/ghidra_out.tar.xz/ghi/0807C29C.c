
void sub_0807C29C(void)

{
  int iVar1;
  uint uVar2;
  
  if ((*(uint *)(*(int *)DWORD_0807c33c + 0x28) & 1) != 0) {
    *(undefined2 *)DWORD_0807c340 = 0;
    *(ushort *)DWORD_0807c344 = (ushort)DWORD_0807c348 & *(ushort *)DWORD_0807c344;
  }
  iVar1 = sub_0801AAE0();
  if (iVar1 == 0) {
    *(undefined2 *)DWORD_0807c344 = 0;
  }
  iVar1 = sub_0800CD8C();
  if (iVar1 != 0) {
    *(undefined2 *)DWORD_0807c34c = 0;
    *(undefined2 *)DWORD_0807c344 = 0;
    *(undefined2 *)DWORD_0807c340 = 0;
  }
  iVar1 = sub_0800CF10();
  if (((((iVar1 != 0) || (iVar1 = sub_0805F184(), iVar1 != 0)) ||
       (iVar1 = sub_0800CDF8(), iVar1 != 0)) || (iVar1 = sub_0800D060(), iVar1 != 0)) &&
     ((iVar1 = sub_0801AAE0(), iVar1 != 0 && (iVar1 = sub_0801AC78(), iVar1 != 0)))) {
    *(undefined4 *)(*(int *)DWORD_0807c33c + 0x24) = 0;
  }
  uVar2 = *(uint *)(*(int *)DWORD_0807c33c + 0x18);
  if (0x15 < uVar2) {
    uVar2 = func_0x0807fb38();
  }
                    /* WARNING: Could not recover jumptable at 0x0807c338. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(uVar2 * 4 + DWORD_0807c350))();
  return;
}


