
undefined4 sub_08099720(void)

{
  undefined4 in_lr;
  
  if (*(short *)(*(int *)DWORD_08099750 + 0x5c) != 0) {
    sub_08099788();
    sub_080656EC();
  }
  sub_08068384();
  *(undefined4 *)DWORD_08099754 = 0;
  sub_08016ECC(*(undefined2 *)DWORD_08099758);
  return in_lr;
}


