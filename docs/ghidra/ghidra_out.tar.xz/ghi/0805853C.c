
uint sub_0805853C(uint param_1,int param_2)

{
  int iVar1;
  dword dVar2;
  
  if (param_2 == 0) {
    iVar1 = *(int *)DWORD_08058550;
    dVar2 = DWORD_08058554;
  }
  else {
    iVar1 = *(int *)DWORD_0805856c;
    dVar2 = DWORD_08058570;
  }
  return (int)(uint)*(byte *)(iVar1 + dVar2 + (param_1 >> 3)) >> (param_1 & 7) & 1;
}


