
void sub_08057D14(undefined4 param_1)

{
  *(undefined4 *)(*(int *)DWORD_08057d1c + 0x50) = param_1;
  return;
}


