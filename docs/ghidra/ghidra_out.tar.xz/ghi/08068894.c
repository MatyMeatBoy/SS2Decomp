
undefined4 sub_08068894(undefined4 param_1,undefined4 param_2)

{
  dword dVar1;
  int iVar2;
  undefined4 in_lr;
  
  dVar1 = DWORD_080688a8;
  iVar2 = sub_08000470(*(undefined4 *)DWORD_080688a8);
  if (iVar2 == 0) {
    while( true ) {
      iVar2 = sub_08001494(0x800);
      *(int *)(*(int *)dVar1 + 0x20) = iVar2;
      if (iVar2 != 0) break;
      sub_080003F0();
    }
    iVar2 = *(int *)DWORD_080688e8;
    *(dword *)(iVar2 + 0xc) = DWORD_080688ec;
    *(dword *)(iVar2 + 0x10) = *(int *)(iVar2 + 0x20) + DWORD_080688f0;
    *(undefined4 *)(iVar2 + 8) = 0x65;
    *(undefined4 *)(iVar2 + 0x24) = 0;
    sub_08000274(iVar2,param_1,param_2);
  }
  return in_lr;
}


