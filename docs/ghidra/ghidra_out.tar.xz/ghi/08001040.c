
undefined4 sub_08001040(ushort param_1)

{
  ushort uVar1;
  dword dVar2;
  dword dVar3;
  dword dVar4;
  undefined4 in_lr;
  
  dVar4 = DWORD_080010a8;
  dVar2 = DWORD_080010a4;
  dVar3 = DWORD_080010a0;
  uVar1 = *(ushort *)DWORD_0800109c;
  while ((uVar1 & 3) != 0) {
    uVar1 = *(ushort *)DWORD_0800109c;
  }
  *(undefined2 *)DWORD_080010a0 = 0;
  *(undefined2 *)dVar4 = 0;
  param_1 = param_1 | *(ushort *)dVar2;
  *(ushort *)dVar2 = param_1;
  dVar2 = DWORD_0800109c;
  *(ushort *)DWORD_0800109c = param_1;
  dVar4 = DWORD_080010a8;
  uVar1 = *(ushort *)dVar2;
  while ((uVar1 & 3) != 0) {
    uVar1 = *(ushort *)dVar2;
  }
  *(undefined2 *)dVar3 = 1;
  *(undefined2 *)dVar4 = 1;
  return in_lr;
}


