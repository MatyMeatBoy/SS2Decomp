
undefined4 sub_08055174(void)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  dVar1 = DWORD_08055184;
  iVar3 = *(int *)DWORD_08055188 + DWORD_0805518c;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_080551a8;
    iVar3 = iVar3 + 0x28;
  }
LAB_080551d2:
  dVar1 = DWORD_080551e0;
  iVar3 = *(int *)DWORD_080551e4 + DWORD_080551e8;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08055204;
    iVar3 = iVar3 + 0x28;
  }
LAB_0805522e:
  dVar1 = DWORD_0805523c;
  iVar3 = *(int *)DWORD_08055240 + DWORD_08055244;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08055260;
    iVar3 = iVar3 + 0x28;
  }
LAB_0805528a:
  dVar1 = DWORD_08055298;
  iVar3 = *(int *)DWORD_0805529c + DWORD_080552a0;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_080552bc;
    iVar3 = iVar3 + 0x28;
  }
LAB_080552e6:
  dVar1 = DWORD_080552f4;
  iVar3 = *(int *)DWORD_080552f8 + DWORD_080552fc;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08055318;
    iVar3 = iVar3 + 0x28;
  }
LAB_08055342:
  dVar1 = DWORD_08055350;
  iVar3 = *(int *)DWORD_08055354 + DWORD_08055358;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08055374;
    iVar3 = iVar3 + 0x28;
  }
LAB_0805539e:
  dVar1 = DWORD_080553ac;
  iVar3 = *(int *)DWORD_080553b0 + DWORD_080553b4;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_080553d0;
    iVar3 = iVar3 + 0x28;
  }
LAB_080553fa:
  dVar1 = DWORD_08055408;
  iVar3 = *(int *)DWORD_0805540c + DWORD_08055410;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_0805542c;
    iVar3 = iVar3 + 0x28;
  }
LAB_08055456:
  dVar1 = DWORD_08055464;
  iVar3 = *(int *)DWORD_08055468 + DWORD_0805546c;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08055488;
    iVar3 = iVar3 + 0x28;
  }
LAB_080554b2:
  dVar1 = DWORD_080554c0;
  iVar3 = *(int *)DWORD_080554c4 + DWORD_080554c8;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_080554e4;
    iVar3 = iVar3 + 0x28;
  }
LAB_0805550e:
  iVar3 = sub_0800CC98();
  if (iVar3 == 0) {
    iVar3 = sub_0801AB24();
    if (iVar3 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar3 < 2) {
      if (iVar3 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar3 == 2) {
      sub_0801AB90(6);
    }
    while (iVar3 = sub_0801AAE0(), iVar3 == 0) {
      sub_080003F0();
    }
  }
  return in_lr;
LAB_080551a8:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x29);
  goto LAB_080551d2;
LAB_08055204:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x2a);
  goto LAB_0805522e;
LAB_08055260:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x2b);
  goto LAB_0805528a;
LAB_080552bc:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x2c);
  goto LAB_080552e6;
LAB_08055318:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x2d);
  goto LAB_08055342;
LAB_08055374:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x2e);
  goto LAB_0805539e;
LAB_080553d0:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x2f);
  goto LAB_080553fa;
LAB_0805542c:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x30);
  goto LAB_08055456;
LAB_08055488:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x31);
  goto LAB_080554b2;
LAB_080554e4:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x32);
  goto LAB_0805550e;
}


