
ushort sub_0805A6DC(void)

{
  return *(ushort *)(*(int *)DWORD_0805a6ec + 4) >> 7 & 1;
}


