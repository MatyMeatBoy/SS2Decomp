
undefined4 sub_08001204(void)

{
  dword dVar1;
  undefined4 in_lr;
  undefined4 uStack_c;
  
  sub_08009014();
  sub_0800086C();
  *(undefined4 *)DWORD_08001268 = 1;
  if ((*(byte *)DWORD_0800126c & 0x80) == 0) {
    VBlankIntrWait();
    *(int *)DWORD_08001270 = *(int *)DWORD_08001270 + 1;
  }
  dVar1 = DWORD_08001274;
  uStack_c = 0xa0;
  CpuFastSet(&uStack_c,DWORD_08001274,DWORD_08001278);
  sub_08000760();
  sub_08000420(1);
  sub_08001348(dVar1,0x7000000,0x400);
  *(undefined2 *)DWORD_0800127c = 0;
  sub_0801A558();
  return in_lr;
}


