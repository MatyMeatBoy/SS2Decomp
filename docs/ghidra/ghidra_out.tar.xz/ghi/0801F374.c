
undefined4 sub_0801F374(ushort *param_1,ushort *param_2,int param_3,uint param_4)

{
  dword dVar1;
  short sVar2;
  ushort uVar3;
  ushort uVar4;
  int iVar5;
  uint uVar6;
  undefined4 uVar7;
  ushort *puVar8;
  ushort *puVar9;
  undefined4 in_lr;
  undefined4 uStack_2c;
  uint uStack_28;
  int iStack_24;
  
  iVar5 = sub_080682A4();
  if (iVar5 == 0) {
    iStack_24 = 0;
    if ((param_4 & 1) == 0) {
      param_2[6] = 10;
      uVar6 = sub_0801E5B0(param_1,param_2,param_3,0);
      dVar1 = DWORD_0801f660;
      uStack_28 = uStack_28 & DWORD_0801f660 | uVar6 & 0xffff;
      uVar6 = uStack_2c & DWORD_0801f664 | (uint)*(byte *)(param_3 + 0xa9) << 0x10;
      uVar6 = DWORD_0801f664 & uVar6 |
              ((uVar6 >> 0x10) + (uint)(byte)param_1[0x39]) * 0x1000000 >> 8;
      uStack_2c = DWORD_0801f664 & uVar6 |
                  ((uVar6 >> 0x10) - *(int *)(param_2 + 0x108)) * 0x1000000 >> 8;
      if ((uStack_2c >> 0x10 & 0x80) != 0) {
        uStack_2c = uStack_2c & DWORD_0801f664;
      }
      if (*(int *)(param_2 + 0x108) == 0xff) {
        uStack_2c = uStack_2c & DWORD_0801f664;
      }
      iVar5 = ArcTan2((*(int *)(param_2 + 10) - *(int *)(param_1 + 0x46)) * 0x100 >> 0x10,
                      (*(int *)(param_2 + 0xc) - *(int *)(param_1 + 0x48)) * 0x100 >> 0x10);
      uStack_2c = uStack_2c & DWORD_0801f66c |
                  (uint)*(byte *)(((uint)(iVar5 << 0x10) >> 0x1c) + DWORD_0801f668) << 0x18;
      if ((param_1[0x10] == 5) && (param_1[8] == 8)) {
        uVar6 = __divsi3((uStack_28 & 0xffff) *
                         (((uint)(*(int *)(*(int *)(param_1 + 0xa4) + 4) << 0xf) >> 0x1d) + 5),10);
        uStack_28 = uStack_28 & dVar1 | uVar6 & 0xffff;
      }
      if ((*(char *)((int)param_2 + DWORD_0801f670) == '\x01') && ((byte)param_1[0x3b] != 0)) {
        uVar6 = __divsi3((uStack_28 & 0xffff) * (uint)(byte)param_1[0x3b],10);
        uStack_28 = uStack_28 & DWORD_0801f660 | uVar6 & 0xffff;
      }
      if ((*(char *)((int)param_2 + DWORD_0801f670) == '\x02') &&
         (*(byte *)((int)param_1 + 0x75) != 0)) {
        uVar6 = __divsi3((uStack_28 & 0xffff) * (uint)*(byte *)((int)param_1 + 0x75),10);
        uStack_28 = uStack_28 & DWORD_0801f660 | uVar6 & 0xffff;
      }
      if (param_1[6] == 2) {
        if (*(char *)((int)param_2 + DWORD_0801f670) == '\x01') {
          iVar5 = sub_0801E0AC(*(int *)DWORD_0801f674 + 0x30,4);
          uVar6 = __divsi3((uStack_28 & 0xffff) * (((uint)(iVar5 << 0x10) >> 0xe) + 10),10);
          uStack_28 = uStack_28 & DWORD_0801f660 | uVar6 & 0xffff;
        }
        uVar6 = sub_0801E0AC(*(int *)DWORD_0801f674 + 0x30,3);
        sVar2 = __divsi3((int)(short)param_2[0x104],5);
        sVar2 = __divsi3((uVar6 & 0xffff) * 100,sVar2 + 0x32);
        uVar7 = sub_080008C8();
        uVar6 = __umodsi3(uVar7,100);
        if (uVar6 < (uint)(int)sVar2) {
          iStack_24 = 1;
          sub_0805865C(0x132);
        }
      }
      puVar9 = param_1 + 0x62;
      uVar6 = uStack_28 & 0xffff;
      sVar2 = __divsi3(uVar6 * (int)(char)param_1[0x35],100);
      *puVar9 = *puVar9 + sVar2;
      puVar8 = param_1 + 0x61;
      sVar2 = __divsi3(uVar6 * (int)*(char *)((int)param_1 + 0x6b),100);
      *puVar8 = sVar2 * 10 + *puVar8;
      if ((short)param_1[0x31] < (short)*puVar9) {
        *puVar9 = param_1[0x31];
      }
      if ((short)param_1[0x30] < (short)*puVar8) {
        *puVar8 = param_1[0x30];
      }
    }
    else {
      uVar6 = sub_0801E5B0(param_1,param_2,param_3,1);
      uStack_28 = uStack_28 & DWORD_0801f3d4 | uVar6 & 0xffff | 0x8000;
      uStack_2c = uStack_2c & DWORD_0801f3d8 & DWORD_0801f3dc & DWORD_0801f3e0;
    }
    sub_08069388(&uStack_2c,param_2 + 0x10c,0,*(undefined2 *)(param_3 + 0xbc),*param_2 + 4);
    iVar5 = sub_0801E244(param_2,uStack_2c._1_1_);
    if (iVar5 == 0) {
      iVar5 = sub_0801E104(param_2,0);
      if (iVar5 != 0) {
        sub_0801DB94(*param_2 + 4,iVar5,uStack_2c._1_1_);
      }
    }
    else {
      sub_0801DB94(*param_2 + 4,iVar5,uStack_2c._1_1_);
    }
    if (uStack_2c._1_1_ == '\x03') {
      sub_08021E44(*param_2 + 4,1);
    }
    uStack_2c = CONCAT31(uStack_2c._1_3_,(char)param_2[1]);
    iVar5 = sub_080020F4();
    param_2[0x2d] =
         (ushort)(1 << (*(ushort *)(iVar5 * 0x14c + DWORD_0801f788) & 0xff)) | param_2[0x2d];
    *(undefined4 *)(param_2 + 0x2a) = *(undefined4 *)(param_1 + 0x6e);
    puVar8 = param_2 + 0x25;
    *puVar8 = ((ushort)DWORD_0801f78c & (ushort)uStack_28) + *puVar8;
    *(uint *)(param_2 + 0x26) = uStack_28 & 0xffff;
    param_2[0x31] = (ushort)uStack_2c._1_1_;
    if (*(char *)((int)param_2 + DWORD_0801f790) != '\x03') {
      param_2[0x36] = 0;
      param_2[0x35] = 0;
      param_2[0x34] = (ushort)DWORD_0801f794;
    }
    sub_0801F2CC(param_2,&uStack_2c);
    param_2[0x2c] = *param_1;
    sub_080660EC(&uStack_2c);
    sub_08069080(param_2 + 0x10c,*puVar8,0,*param_1,*param_2 + 4,*(undefined2 *)(param_3 + 0xbc));
    if (param_1[6] == 5) {
      uVar3 = sub_0801E0AC(*(int *)DWORD_0801f798 + 0x30,6);
      uVar4 = sub_080008C8();
      if ((uVar4 & 0x3f) < uVar3) {
        sub_080680B4(param_2[1],6);
      }
    }
    if (iStack_24 != 0) {
      sub_08068030(param_2[1]);
    }
  }
  return in_lr;
}


