
undefined8 sub_0801E538(void)

{
  short sVar1;
  undefined4 in_lr;
  
  sVar1 = sub_0801CCC8();
  return CONCAT44(in_lr,(uint)(sVar1 != 0));
}


