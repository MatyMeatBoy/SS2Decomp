
undefined4 sub_0809FAEC(void)

{
  dword dVar1;
  int iVar2;
  undefined4 in_lr;
  
  dVar1 = DWORD_0809fb14;
  if (*(int *)DWORD_0809fb14 != 0) {
    iVar2 = sub_08000470();
    if (iVar2 != 0) {
      sub_080003A8(*(undefined4 *)dVar1);
    }
    sub_08001538(*(undefined4 *)dVar1);
    *(undefined4 *)dVar1 = 0;
  }
  return in_lr;
}


