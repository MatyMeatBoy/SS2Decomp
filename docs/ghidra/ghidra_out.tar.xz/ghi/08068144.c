
undefined8 sub_08068144(undefined4 param_1)

{
  dword dVar1;
  int iVar2;
  undefined4 uVar3;
  undefined1 *puVar4;
  undefined4 in_lr;
  
  dVar1 = DWORD_0806817c;
  if ((*(uint *)DWORD_0806817c < 0x32) && (iVar2 = sub_0800CFF0(), iVar2 == 0)) {
    puVar4 = (undefined1 *)(*(int *)DWORD_08068180 + *(int *)dVar1 * 0x88);
    *(undefined4 *)(puVar4 + 4) = 1;
    *puVar4 = 0xa7;
    *(undefined4 *)(puVar4 + 8) = param_1;
    puVar4[1] = 1;
    *(int *)dVar1 = *(int *)dVar1 + 1;
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  return CONCAT44(in_lr,uVar3);
}


