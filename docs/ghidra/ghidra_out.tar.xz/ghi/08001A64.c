
undefined4 sub_08001A64(void)

{
  dword dVar1;
  undefined4 in_lr;
  
  sub_08000EF4();
  sub_08000FD4(0xc0);
  sub_08000F2C();
  dVar1 = DWORD_08001a94;
  *(short *)DWORD_08001a94 = (short)DWORD_08001a98;
  *(dword *)(dVar1 - 0x1c) = DWORD_08001a9c;
  *(undefined2 *)(dVar1 + 0xda) = 0xc0;
  *(undefined1 *)(DWORD_08001aa0 + 8) = 0;
  return in_lr;
}


