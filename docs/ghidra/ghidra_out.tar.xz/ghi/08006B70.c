
undefined4 sub_08006B70(int param_1,undefined2 param_2,undefined4 param_3,dword param_4)

{
  dword dVar1;
  undefined4 in_lr;
  
  dVar1 = DWORD_08006b94;
  if ((((param_1 != 1) && (dVar1 = DWORD_08006b8c, param_1 != 0)) &&
      (dVar1 = DWORD_08006b9c, param_1 != 2)) && (dVar1 = DWORD_08006bb0, param_1 != 3)) {
    dVar1 = param_4;
  }
  m4aMPlayVolumeControl(dVar1,0xf,param_2);
  return in_lr;
}


