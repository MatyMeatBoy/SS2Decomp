
undefined4 sub_080A705C(void)

{
  byte bVar1;
  char cVar2;
  undefined2 uVar3;
  short sVar4;
  dword dVar5;
  dword dVar6;
  dword dVar7;
  ushort uVar8;
  short sVar9;
  undefined4 uVar10;
  int iVar11;
  int iVar12;
  int *piVar13;
  short *psVar14;
  int iVar15;
  int iVar16;
  ushort *puVar17;
  bool bVar18;
  int *piVar19;
  undefined4 uVar20;
  int iVar21;
  uint uVar22;
  undefined4 *puVar23;
  int iStack_4;
  undefined4 *puVar24;
  undefined4 *puVar25;
  
  dVar7 = DWORD_080a71a0;
  dVar6 = DWORD_080a7198;
  dVar5 = DWORD_080a7194;
  iVar11 = DWORD_080a7194 - 0x20;
  puVar23 = (undefined4 *)(&stack0xffffffe0 + DWORD_080a7194);
  puVar24 = (undefined4 *)(&stack0xffffffe0 + DWORD_080a7194);
  puVar25 = (undefined4 *)(&stack0xffffffe0 + DWORD_080a7194);
  *(int *)(&stack0x000001f0 + DWORD_080a7194) = *(int *)DWORD_080a7198 + 0x204;
  uVar3 = *(undefined2 *)DWORD_080a71a0;
  *(undefined4 *)(&stack0xffffffe0 + DWORD_080a7194) = 1;
  sub_08065158(&stack0xfffffff0 + DWORD_080a7194,DWORD_080a719c,uVar3,0xffffffff);
  (&stack0x0000000c)[dVar5] = (char)*(undefined2 *)dVar7;
  uVar22 = 0;
  *(undefined1 **)(&stack0x00000200 + dVar5) = &stack0x00000024 + dVar5;
  *(undefined1 **)(&stack0x000001f8 + dVar5) = &stack0x00000178 + dVar5;
  *(undefined1 **)(&stack0x00000204 + dVar5) = &stack0x00000028 + dVar5;
  *(undefined1 **)(&stack0x00000208 + dVar5) = &stack0x0000002c + dVar5;
  iVar21 = *(int *)dVar6;
  do {
    iVar12 = uVar22 * 0x14;
    iVar15 = iVar12 + iVar11;
    (&stack0x00000034)[iVar15 + 0x20] = 1;
    uVar10 = *(undefined4 *)(iVar21 + 0x14);
    *(undefined4 *)(&stack0x00000024 + iVar15 + 0x20) = uVar10;
    *(undefined4 *)(&stack0x00000174 + uVar22 * 8 + dVar5) = uVar10;
    iVar16 = *(int *)(&stack0x000001f8 + dVar5);
    uVar10 = *(undefined4 *)(iVar21 + 0x18);
    *(undefined4 *)(*(int *)(&stack0x00000204 + dVar5) + iVar12) = uVar10;
    *(undefined4 *)(iVar16 + uVar22 * 8) = uVar10;
    *(int *)(*(int *)(&stack0x00000208 + dVar5) + iVar12) = iVar12 + 0x1e;
    (&stack0x00000035)[iVar15 + 0x20] = 1;
    (&stack0x000001d4)[uVar22 + dVar5] = 0;
    *(undefined2 *)(&stack0x00000032 + iVar15 + 0x20) = 0;
    *(undefined2 *)(&stack0x00000030 + iVar15 + 0x20) = 0;
    (&stack0x000001e0)[uVar22 + dVar5] = 0x18;
    uVar22 = uVar22 + 1 & 0xff;
  } while (uVar22 < 0xc);
  sub_0805865C(0x1a2);
  *(undefined4 *)DWORD_080a71a4 = 0;
  *(undefined4 *)(&stack0x000001f4 + dVar5) = *(undefined4 *)(&stack0x00000200 + dVar5);
  do {
    uVar22 = 0;
    do {
      iVar21 = uVar22 * 0x14;
      piVar19 = (int *)(*(int *)(&stack0x00000208 + dVar5) + iVar21);
      iVar11 = *piVar19;
      *(uint *)(&stack0x000001fc + dVar5) = uVar22 * 4;
      if (iVar11 == 0) {
        if ((&stack0x000001d4)[uVar22 + dVar5] == '\0') {
          cVar2 = (&stack0x000001e0)[uVar22 + dVar5];
          if (cVar2 == '\0') {
            (&stack0x000001d4)[uVar22 + dVar5] = '\x01';
            iVar15 = *(int *)(&stack0x000001f4 + dVar5);
            *(undefined1 *)(iVar15 + iVar21 + 0x11) = 0;
            iVar11 = sub_080020F4();
            dVar6 = DWORD_080a747c;
            uVar20 = *(undefined4 *)(iVar15 + iVar21);
            uVar10 = *(undefined4 *)(iVar11 * 0x14c + DWORD_080a747c + 0x8c);
            iVar11 = sub_080020F4();
            iVar15 = (int)(short)((short)((uint)uVar20 >> 8) - (short)((uint)uVar10 >> 8));
            iVar11 = (((*(int *)(*(int *)(&stack0x00000204 + dVar5) + iVar21) >> 8) + 8) -
                     (*(int *)(iVar11 * 0x14c + dVar6 + 0x90) >> 8)) * 0x10000 >> 0x10;
            uVar8 = Sqrt(iVar15 * iVar15 + iVar11 * iVar11);
            if ((((((uVar8 < 0xc) && (iVar11 = sub_0800CDF8(), iVar11 == 0)) &&
                  (iVar11 = sub_0800CD8C(), iVar11 == 0)) &&
                 (((iVar11 = sub_0800CCCC(), dVar7 = DWORD_080a7480, iVar11 == 0 &&
                   (*(short *)(*(int *)DWORD_080a7480 + 0xc) != 0xb)) &&
                  ((iVar11 = sub_080020F4(),
                   (*(uint *)(iVar11 * 0x14c + dVar6 + 0x30) & 0x2000) == 0 &&
                   ((iVar11 = sub_080020F4(), *(char *)(iVar11 * 0x14c + dVar6 + 0x68) != '\0' &&
                    (iVar11 = sub_080020F4(), *(short *)(iVar11 * 0x14c + dVar6 + 0x20) != 0xe))))))
                 )) && (iVar11 = sub_080020F4(), *(short *)(iVar11 * 0x14c + dVar6 + 0x20) != 0xb))
               && (iVar11 = sub_080020F4(), *(short *)(iVar11 * 0x14c + dVar6 + 0x20) != 0xc)) {
              iVar11 = sub_080020F4();
              if (*(int *)((uint)**(ushort **)dVar7 * 4 + iVar11 * 0x14c + dVar6 + 0xe4) !=
                  *(int *)(*(ushort **)dVar7 + 0x28)) {
                iVar11 = sub_080020F4();
                *(undefined2 *)(iVar11 * 0x14c + dVar6 + 0x20) = 10;
                iVar11 = sub_080020F4();
                *(short *)(iVar11 * 0x14c + dVar6 + 0xb0) = (short)DWORD_080a7484;
                iVar11 = sub_080020F4();
                uVar10 = *(undefined4 *)dVar7;
                iVar21 = sub_080020F4();
                sVar9 = sub_0801ED8C(uVar10,iVar21 * 0x14c + dVar6);
                psVar14 = (short *)(iVar11 * 0x14c + dVar6 + 0x88);
                *psVar14 = sVar9 + *psVar14;
                iVar11 = sub_080020F4();
                puVar17 = *(ushort **)dVar7;
                iVar21 = *(int *)(puVar17 + 0x28);
                *(int *)((uint)*puVar17 * 4 + iVar11 * 0x14c + dVar6 + 0xe4) = iVar21;
                *(int *)(puVar17 + 0x28) = iVar21 + 1;
                iVar11 = sub_080020F4();
                sVar9 = *(short *)(iVar11 * 0x14c + dVar6 + 0xc4);
                iVar11 = sub_080020F4();
                if ((int)(uint)*(ushort *)(iVar11 * 0x14c + dVar6 + 0x88) < (int)sVar9) {
                  sub_08015C14();
                  *(undefined1 *)DWORD_080a7488 = 0;
                  iVar11 = sub_0800CE68();
                  if ((iVar11 != 0) || (iVar11 = sub_0800CC98(), iVar11 != 0)) {
                    sub_0800D038();
                  }
                }
                dVar6 = DWORD_080a748c;
                iVar11 = sub_080020F4();
                *(dword *)dVar6 = *(int *)(iVar11 * 0x14c + DWORD_080a747c + 0x90) + DWORD_080a7490;
              }
            }
          }
          else {
            (&stack0x000001e0)[uVar22 + dVar5] = cVar2 + -1;
            iVar15 = *(int *)(&stack0x000001f4 + dVar5);
            iVar12 = uVar22 * 8;
            iVar11 = __divsi3(*(int *)(&stack0x00000114 + iVar12 + dVar5) -
                              *(int *)(&stack0x00000174 + iVar12 + dVar5),0x18);
            *(int *)(iVar15 + iVar21) = *(int *)(iVar15 + iVar21) + iVar11;
            iVar15 = *(int *)(&stack0x00000204 + dVar5);
            iVar11 = __divsi3(*(int *)(&stack0x00000118 + iVar12 + dVar5) -
                              *(int *)(*(int *)(&stack0x000001f8 + dVar5) + iVar12),0x18);
            *(int *)(iVar15 + iVar21) = *(int *)(iVar15 + iVar21) + iVar11;
          }
        }
      }
      else {
        *piVar19 = iVar11 + -1;
        iVar11 = sub_08096594(0);
        piVar13 = (int *)(iVar11 * 0x14c + DWORD_080a71a8 + 0x148);
        *(uint *)(&stack0x00000114 + uVar22 * 8 + dVar5) = (uint)(*(ushort *)*piVar13 >> 4) << 8;
        *(uint *)(&stack0x00000118 + uVar22 * 8 + dVar5) =
             ((uint)*(ushort *)(*piVar13 + 2) << 0x14) >> 0xc;
        if (*piVar19 == 0) {
          sub_0805865C(0x1a2);
        }
      }
      iVar11 = sub_0800CCCC();
      if ((((iVar11 == 0) && (iVar11 = sub_0800CC98(), iVar11 == 0)) &&
          (iVar11 = sub_0800CD8C(), iVar11 == 0)) && (iVar11 = sub_0800CD34(), iVar11 == 0)) {
        sub_08000AF0(*(ushort *)DWORD_080a7494 + 0x10,
                     *(int *)((int)&iStack_4 + dVar5) +
                     (uint)*(ushort *)(*(int *)(&stack0x000001f0 + dVar5) + 0xd6) * 0x20,1);
        iVar11 = (*(int *)(&stack0x000001fc + dVar5) + uVar22) * 4;
        piVar19 = (int *)(*(int *)(&stack0x00000200 + dVar5) + iVar11);
        iVar21 = *piVar19;
        iVar15 = *(int *)(*(int *)(&stack0x00000204 + dVar5) + iVar11);
        iVar11 = DWORD_080a7498 + dVar5;
        *puVar23 = 0;
        *(undefined4 *)(&stack0xffffffe4 + dVar5) = 0;
        sub_0800BC08((iVar21 << 8) >> 0x10,(iVar15 << 8) >> 0x10,&stack0x000001ec + dVar5,
                     &stack0xffffffe0 + iVar11);
        bVar1 = *(byte *)(piVar19 + 4);
        *puVar24 = 1;
        sub_08065370(&stack0xfffffff0 + dVar5,bVar1 + 5,piVar19 + 3,(int)piVar19 + 0xe);
        sVar9 = *(short *)(&stack0x000001ec + dVar5);
        sVar4 = *(short *)(&stack0xffffffe0 + iVar11);
        bVar1 = *(byte *)(piVar19 + 4);
        iVar11 = piVar19[3];
        *puVar25 = 0;
        *(undefined1 **)(&stack0xffffffe4 + dVar5) = &stack0x0000000c + dVar5;
        *(undefined4 *)(&stack0xffffffe8 + dVar5) = *(undefined4 *)(&stack0xfffffff8 + dVar5);
        *(undefined4 *)(&stack0xffffffec + dVar5) = *(undefined4 *)(&stack0xfffffff0 + dVar5);
        sub_08007870((int)sVar9,(int)sVar4,bVar1 + 5,(short)iVar11);
      }
      uVar22 = uVar22 + 1 & 0xff;
    } while (uVar22 < 0xc);
    bVar18 = false;
    uVar22 = 0;
    cVar2 = *(char *)(*(int *)(&stack0x00000200 + dVar5) + 0x11);
    while (cVar2 == '\0') {
      uVar22 = uVar22 + 1 & 0xff;
      if (0xb < uVar22) goto LAB_080a74bc;
      cVar2 = *(char *)(*(int *)(&stack0x00000200 + dVar5) + uVar22 * 0x14 + 0x11);
    }
    bVar18 = true;
LAB_080a74bc:
    sub_080003F0();
    if (!bVar18) {
      sub_08097A38(0);
      iVar11 = sub_0800048C();
      *(undefined4 *)(iVar11 + 8) = 0;
      return *(undefined4 *)(&stack0x00000228 + dVar5);
    }
  } while( true );
}


