
undefined8 sub_080850C0(int param_1,uint param_2,int param_3)

{
  bool bVar1;
  char cVar2;
  ushort uVar3;
  uint uVar4;
  char *pcVar5;
  undefined4 *puVar6;
  undefined4 in_lr;
  uint uStack_28;
  char *pcStack_24;
  
  pcStack_24 = (char *)(param_1 + 2);
  uVar4 = 0;
  while (cVar2 = *pcStack_24, cVar2 != -3) {
    if (cVar2 == -9) {
      pcVar5 = (char *)(param_3 + uVar4);
      bVar1 = false;
      uVar3 = 0;
      pcStack_24 = pcStack_24 + 1;
      puVar6 = (undefined4 *)DWORD_08085130;
      uStack_28 = param_2 & 0xffff;
      do {
        cVar2 = sub_08000498(&uStack_28,*puVar6);
        *pcVar5 = cVar2 + 'A';
        if (((bVar1) || ((char)(cVar2 + 'A') != 'A')) || (uVar3 == 5)) {
          pcVar5 = pcVar5 + 1;
          bVar1 = true;
          uVar4 = uVar4 + 1 & 0xffff;
        }
        uVar3 = uVar3 + 1;
        puVar6 = puVar6 + 1;
      } while (uVar3 < 6);
    }
    else {
      *(char *)(uVar4 + param_3) = cVar2;
      pcStack_24 = pcStack_24 + 1;
      uVar4 = uVar4 + 1 & 0xffff;
    }
  }
  *(undefined1 *)(param_3 + uVar4) = 0xfd;
  return CONCAT44(in_lr,(uVar4 - 1) + param_3);
}


