
undefined4
sub_08029E0C(uint param_1,uint param_2,undefined2 param_3,uint param_4,uint param_5,uint param_6)

{
  ushort uVar1;
  int iVar2;
  ushort *puVar3;
  undefined4 in_lr;
  undefined1 uStack_30;
  undefined1 uStack_2f;
  undefined1 uStack_2e;
  undefined1 uStack_2d;
  ushort uStack_2c;
  uint uStack_28;
  uint uStack_24;
  
  uStack_28 = param_5 & 0xffff;
  uStack_24 = param_6 & 0xffff;
  if (((((*(uint *)DWORD_08029f48 & 1 << (param_1 & 0xff)) != 0) &&
       (puVar3 = (ushort *)(*(int *)DWORD_08029f4c + param_1 * 0x2e0), (char)puVar3[0xee] != '\0'))
      && (puVar3[6] != 0xb)) && (puVar3[6] != 10)) {
    if (*(char *)((int)puVar3 + DWORD_08029f50) != '\x03') {
      sub_08069388(&uStack_30,(int)puVar3 + (DWORD_08029f50 - 0xe),param_4 & 0xffff,param_2 & 0xffff
                   ,*puVar3 + 4);
      iVar2 = sub_0801E104(puVar3,0);
      if (iVar2 != 0) {
        sub_0801DB94(*puVar3 + 4,iVar2,uStack_2f);
      }
    }
    uStack_2c = sub_08021D00(param_2 & 0xffff,param_3);
    puVar3[6] = 10;
    puVar3[0x25] = uStack_2c;
    *(uint *)(puVar3 + 0x26) = (uint)uStack_2c;
    uStack_2e = (undefined1)uStack_28;
    uStack_30 = (undefined1)puVar3[1];
    uStack_2d = (undefined1)uStack_24;
    if ((uStack_28 & 0x80) != 0) {
      uStack_2e = 0;
    }
    if (*(int *)(puVar3 + 0x108) == 0xff) {
      uStack_2e = 0;
    }
    sub_0801F2CC(puVar3,&uStack_30);
    uVar1 = sub_080020F4();
    puVar3[0x2c] = uVar1;
    sub_080660EC(&uStack_30);
    if (*(char *)((int)puVar3 + DWORD_08029f50) != '\x03') {
      sub_08069080(puVar3 + 0x10c,uStack_2c,param_4,param_1,param_1 + 4,param_2);
    }
  }
  return in_lr;
}


