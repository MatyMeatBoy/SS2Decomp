
undefined8 sub_08096154(int param_1,uint *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  ushort *puVar5;
  uint uVar6;
  uint uVar7;
  dword *pdVar8;
  uint *puVar9;
  dword dVar10;
  uint *puVar11;
  int iVar12;
  uint *puVar13;
  int iVar14;
  uint uVar15;
  undefined4 in_lr;
  dword dStack_44;
  uint auStack_40 [7];
  int iStack_24;
  
  pdVar8 = &dStack_44;
  uVar1 = sub_08002164();
  iVar2 = *(int *)(param_1 + 0x14);
  iVar3 = *(int *)(param_1 + 0x18);
  uVar6 = 0;
  dVar10 = DWORD_08096254;
  if (uVar1 != 0) {
    do {
      iStack_24 = uVar6 << 3;
      *pdVar8 = DWORD_08096258;
      if (((*(uint *)(dVar10 + 0x30) & 0x2000) == 0) &&
         ((*(uint *)(dVar10 + 0x30) & DWORD_0809625c) == 0)) {
        puVar5 = *(ushort **)(dVar10 + 0x148);
        if ((*puVar5 & 0xf) != 0xb) {
          iVar12 = (iVar2 >> 8) - (uint)(*puVar5 >> 4);
          iVar14 = (iVar3 >> 8) - (puVar5[1] & 0xfff);
          *pdVar8 = iVar12 * iVar12 + iVar14 * iVar14;
        }
        *(uint *)((int)auStack_40 + iStack_24) = uVar6;
      }
      pdVar8 = pdVar8 + 2;
      uVar6 = uVar6 + 1;
      dVar10 = dVar10 + 0x14c;
    } while (uVar6 < uVar1);
  }
  uVar6 = 0;
  if (uVar1 != 0) {
    do {
      uVar15 = uVar6 + 1;
      if (uVar15 < uVar1) {
        puVar13 = auStack_40 + uVar6 * 2 + -1;
        puVar11 = auStack_40 + uVar6 * 2;
        puVar9 = auStack_40 + uVar15 * 2 + -1;
        uVar6 = uVar15;
        do {
          if ((int)*puVar9 < (int)*puVar13) {
            uVar4 = *puVar9 ^ *puVar13;
            *puVar13 = uVar4;
            uVar4 = *puVar9 ^ uVar4;
            *puVar9 = uVar4;
            *puVar13 = *puVar13 ^ uVar4;
            uVar7 = *puVar11;
            uVar4 = puVar9[1];
            *puVar11 = uVar7 ^ uVar4;
            uVar4 = puVar9[1] ^ uVar7 ^ uVar4;
            puVar9[1] = uVar4;
            *puVar11 = *puVar11 ^ uVar4;
          }
          puVar9 = puVar9 + 2;
          uVar6 = uVar6 + 1;
        } while (uVar6 < uVar1);
      }
      uVar6 = uVar15;
    } while (uVar15 < uVar1);
  }
  uVar1 = Sqrt(dStack_44);
  if ((int)*param_2 < (int)(uVar1 & 0xffff)) {
    auStack_40[0] = 10;
  }
  else {
    *param_2 = uVar1 & 0xffff;
  }
  return CONCAT44(in_lr,auStack_40[0]);
}


