
undefined4 sub_080A7DEC(void)

{
  undefined4 in_lr;
  
  if (*(short *)(*(int *)DWORD_080a7e28 + 0x5c) != 0) {
    sub_080A7E94();
    sub_080A7F5C();
    sub_080A8014();
    sub_080A80D8();
    sub_0805867C(DWORD_080a7e2c);
  }
  sub_08068384();
  *(undefined4 *)DWORD_080a7e30 = 0;
  sub_08016ECC(*(undefined2 *)DWORD_080a7e34);
  return in_lr;
}


