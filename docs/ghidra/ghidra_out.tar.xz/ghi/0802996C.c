
undefined4 sub_0802996C(void)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  uint *puVar4;
  undefined2 *puVar5;
  undefined4 in_lr;
  
  iVar2 = sub_080020F4();
  dVar1 = DWORD_08029a74;
  puVar5 = (undefined2 *)(iVar2 * 0x14c + DWORD_08029a74);
  puVar5[0x62] = puVar5[0x31];
  puVar5[0x61] = puVar5[0x30];
  *(undefined1 *)(puVar5 + 0x34) = 1;
  puVar4 = (uint *)(iVar2 * 0x14c + dVar1 + 0x30);
  *puVar4 = *puVar4 & DWORD_08029a78;
  do {
    iVar3 = sub_0801E1D8(puVar5,6,100);
    if (iVar3 == 0) break;
    sub_0801DB94(*puVar5,iVar3,0);
  } while (iVar3 != 0);
  puVar5 = (undefined2 *)(iVar2 * 0x14c + DWORD_08029a74);
  do {
    iVar3 = sub_0801E1D8(puVar5,7,100);
    if (iVar3 == 0) break;
    sub_0801DB94(*puVar5,iVar3,0);
  } while (iVar3 != 0);
  puVar5 = (undefined2 *)(iVar2 * 0x14c + DWORD_08029a74);
  do {
    iVar3 = sub_0801E1D8(puVar5,5,100);
    if (iVar3 == 0) break;
    sub_0801DB94(*puVar5,iVar3,0);
  } while (iVar3 != 0);
  puVar5 = (undefined2 *)(iVar2 * 0x14c + DWORD_08029a74);
  do {
    iVar3 = sub_0801E1D8(puVar5,4,100);
    if (iVar3 == 0) break;
    sub_0801DB94(*puVar5,iVar3,0);
  } while (iVar3 != 0);
  puVar5 = (undefined2 *)(iVar2 * 0x14c + DWORD_08029a74);
  do {
    iVar2 = sub_0801E1D8(puVar5,2,100);
    if (iVar2 == 0) {
      return in_lr;
    }
    sub_0801DB94(*puVar5,iVar2,0);
  } while (iVar2 != 0);
  return in_lr;
}


