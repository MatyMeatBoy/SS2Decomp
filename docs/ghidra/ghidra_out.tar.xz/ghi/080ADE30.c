
undefined8 sub_080ADE30(ushort *param_1)

{
  dword dVar1;
  ushort uVar2;
  short sVar3;
  int iVar4;
  int iVar5;
  short *psVar6;
  int iVar7;
  uint uVar8;
  undefined4 uVar9;
  undefined4 in_lr;
  
  uVar9 = 0;
  iVar4 = sub_080020F4();
  dVar1 = DWORD_080adfe8;
  iVar7 = *(int *)(param_1 + 10);
  iVar4 = *(int *)(iVar4 * 0x14c + DWORD_080adfec);
  iVar5 = sub_080020F4();
  iVar7 = (iVar7 - iVar4) * 0x100 >> 0x10;
  iVar4 = (*(int *)(param_1 + 0xc) - *(int *)(iVar5 * 0x14c + dVar1 + 0x90)) * 0x100 >> 0x10;
  uVar2 = Sqrt(iVar7 * iVar7 + iVar4 * iVar4);
  if (((((uVar2 < 0x10) && (iVar4 = sub_0800CDF8(), iVar4 == 0)) &&
       (iVar4 = sub_0800CCCC(), iVar4 == 0)) &&
      (((iVar4 = sub_0800CD8C(), iVar4 == 0 && (uVar2 = param_1[6], uVar2 != 0xe)) &&
       ((uVar2 != 0xb &&
        ((uVar2 != 10 && (iVar4 = sub_080020F4(), *(short *)(iVar4 * 0x14c + dVar1 + 200) == 0))))))
      )) && ((iVar4 = sub_080020F4(), (*(uint *)(iVar4 * 0x14c + dVar1 + 0x30) & 0x2000) == 0 &&
             ((((iVar4 = sub_080020F4(), *(char *)(iVar4 * 0x14c + dVar1 + 0x68) != '\0' &&
                (iVar4 = sub_080020F4(), *(short *)(iVar4 * 0x14c + dVar1 + 0x20) != 0xe)) &&
               (iVar4 = sub_080020F4(), *(short *)(iVar4 * 0x14c + dVar1 + 0x20) != 0xb)) &&
              (iVar4 = sub_080020F4(), *(short *)(iVar4 * 0x14c + dVar1 + 0x20) != 0xc)))))) {
    iVar4 = sub_080020F4();
    if (*(int *)((uint)*param_1 * 4 + iVar4 * 0x14c + dVar1 + 0xe4) != *(int *)(param_1 + 0x28)) {
      iVar4 = sub_080020F4();
      *(undefined2 *)(iVar4 * 0x14c + dVar1 + 0x20) = 10;
      iVar4 = sub_080020F4();
      *(short *)(iVar4 * 0x14c + dVar1 + 0xb0) = (short)DWORD_080adff0;
      iVar4 = sub_080020F4();
      iVar5 = sub_080020F4();
      sVar3 = sub_0801ED8C(param_1,iVar5 * 0x14c + dVar1);
      psVar6 = (short *)(iVar4 * 0x14c + dVar1 + 0x88);
      *psVar6 = sVar3 + *psVar6;
      iVar4 = sub_080020F4();
      iVar5 = *(int *)(param_1 + 0x28);
      *(int *)((uint)*param_1 * 4 + iVar4 * 0x14c + dVar1 + 0xe4) = iVar5;
      *(int *)(param_1 + 0x28) = iVar5 + 1;
      iVar4 = sub_080020F4();
      iVar7 = *(int *)(iVar4 * 0x14c + DWORD_080adfec);
      iVar4 = *(int *)(param_1 + 10);
      iVar5 = sub_080020F4();
      iVar4 = ArcTan2((iVar7 - iVar4) * 0x100 >> 0x10,
                      (*(int *)(iVar5 * 0x14c + dVar1 + 0x90) - *(int *)(param_1 + 0xc)) * 0x100 >>
                      0x10);
      uVar8 = (uint)(iVar4 << 0x10) >> 0x1d;
      if (0x80000000 < (uint)(iVar4 * 0x80000)) {
        if (uVar8 < 7) {
          uVar8 = uVar8 + 1;
        }
        else {
          uVar8 = 0;
        }
      }
      if (uVar8 == 0) {
        iVar4 = sub_080020F4();
        psVar6 = (short *)(iVar4 * 0x14c + DWORD_080ae02c + 0xca);
        sVar3 = 6;
      }
      else if (uVar8 == 1) {
        iVar4 = sub_080020F4();
        psVar6 = (short *)(iVar4 * 0x14c + DWORD_080ae07c + 0xca);
        sVar3 = 7;
      }
      else {
        iVar4 = sub_080020F4();
        sVar3 = (short)uVar8 + -2;
        psVar6 = (short *)(iVar4 * 0x14c + DWORD_080ae014 + 0xca);
      }
      *psVar6 = sVar3;
      iVar4 = sub_080020F4();
      dVar1 = DWORD_080ae07c;
      *(undefined2 *)(iVar4 * 0x14c + DWORD_080ae07c + 0xcc) = 0x400;
      iVar4 = sub_080020F4();
      *(undefined2 *)(iVar4 * 0x14c + dVar1 + 200) = 8;
      uVar9 = 1;
    }
  }
  return CONCAT44(in_lr,uVar9);
}


