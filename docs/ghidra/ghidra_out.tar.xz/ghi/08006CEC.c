
undefined4 sub_08006CEC(uint param_1)

{
  undefined4 in_lr;
  
  if ((param_1 & 0xffff) <= DWORD_08006d04) {
    m4aSongNumContinue(param_1 & 0xffff);
  }
  return in_lr;
}


