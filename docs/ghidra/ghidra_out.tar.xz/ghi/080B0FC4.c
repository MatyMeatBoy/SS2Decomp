
/* WARNING: Possible PIC construction at 0x080b1034: Changing call to branch */
/* WARNING: Possible PIC construction at 0x080b1200: Changing call to branch */
/* WARNING: Possible PIC construction at 0x080b1a30: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x080b1038) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_080B0FC4(ushort *param_1)

{
  bool bVar1;
  undefined2 *puVar2;
  dword dVar3;
  int *piVar4;
  byte *pbVar5;
  dword dVar6;
  byte bVar7;
  char cVar8;
  undefined1 uVar9;
  ushort uVar10;
  short sVar11;
  undefined2 uVar12;
  int iVar13;
  uint uVar14;
  undefined4 *puVar15;
  undefined4 uVar16;
  uint uVar17;
  uint uVar18;
  ushort *puVar19;
  uint *puVar20;
  int iVar21;
  undefined4 in_lr;
  undefined4 auStack_118 [13];
  undefined4 auStack_e4 [13];
  undefined4 auStack_b0 [7];
  undefined1 uStack_94;
  short sStack_7c;
  short sStack_7a;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 *puStack_70;
  ushort *puStack_6c;
  int iStack_68;
  uint uStack_64;
  uint uStack_60;
  dword dStack_5c;
  undefined4 uStack_58;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  int iStack_38;
  uint uStack_34;
  int iStack_30;
  ushort *puStack_2c;
  ushort *puStack_28;
  ushort *puStack_24;
  
  *puRam080b1038 = param_1;
  puStack_6c = param_1 + 0x102;
  sub_0801623C(param_1,uRam080b103c,0);
  sub_08019F60(puStack_6c);
  sub_0801A0A4(param_1);
  puVar19 = puRam080b1040;
  uVar10 = sub_08016E04(param_1[0x16c],0);
  *puVar19 = uVar10;
  puVar20 = puRam080b1048;
  puVar2 = (undefined2 *)DWORD_080b11cc;
  uVar14 = uRam080b1044;
  while (DWORD_080b11cc = (dword)puVar2, uVar10 == uVar14) {
    param_1[6] = 0xb;
    iVar13 = sub_0800CB78();
    if ((iVar13 != 0) || (iVar13 = sub_08056E90(), iVar13 != 0)) {
      *puVar20 = *puVar20 & ~(1 << (*param_1 & 0xff));
      return in_lr;
    }
    sub_080003F0();
    puVar2 = (undefined2 *)DWORD_080b11cc;
    uVar14 = (uint)*(ushort *)DWORD_080b11cc;
  }
  sub_08065158(auStack_118,DWORD_080b11d0,*puVar2,0xffffffff,0);
  sub_08065158(auStack_e4,DWORD_080b11d4,*puVar2,0xffffffff,0);
  sub_08065158(auStack_b0,DWORD_080b11d8,*puVar2,0xffffffff,0);
  puVar19 = puStack_6c;
  uVar10 = puStack_6c[3];
  param_1[0xeb] = uVar10 * 3;
  param_1[0x2e] = uVar10 * 3;
  uVar10 = puStack_6c[2];
  param_1[0xea] = uVar10 * 0x14;
  param_1[0x2f] = uVar10 * 0x14;
  param_1[6] = 0;
  uStack_60 = 0;
  dStack_5c = DWORD_080b11dc;
  uStack_54 = 0;
  uStack_50 = 0;
  *(byte *)((int)param_1 + 0x1fd) = 3;
  *(byte *)(param_1 + 0xff) = 3;
  puStack_6c[0x14] = 0xb3;
  iVar13 = sub_08007290(0xb00b3);
  uStack_64 = (uint)*(byte *)(iVar13 + 0x9b);
  puVar19[0x12] = 2;
  *(byte *)((int)puVar19 + 0x27) = 0;
  param_1[0x28] = 1;
  dVar3 = DWORD_080b11e0;
  param_1[0x29] = 0;
  uVar14 = 0;
  puStack_24 = param_1 + 0x36;
  puStack_28 = param_1 + 0x35;
  puStack_2c = param_1 + 0x34;
  do {
    uVar18 = 0;
    do {
      *(undefined4 *)((short)uVar18 * 4 + ((int)(uVar14 * 0x10000) >> 0x10) * 0x14c + dVar3) = 0;
      uVar17 = (int)(short)uVar18 + 1;
      uVar18 = uVar17 & 0xffff;
    } while ((int)(uVar17 * 0x10000) >> 0x10 < 5);
    uVar18 = uVar14 * 0x10000 + 0x10000;
    uVar14 = uVar18 >> 0x10;
  } while ((int)uVar18 >> 0x10 < 4);
  *puStack_24 = 0;
  *puStack_28 = 0;
  *puStack_2c = 0;
  uStack_34 = 0;
  uStack_3c = 0;
  uStack_44 = 0;
  iStack_38 = 0;
  uStack_40 = 0;
  uStack_4c = 0;
  sub_08098044();
  sub_080B2330();
  uStack_78 = *(undefined4 *)(*(int *)DWORD_080b11e4 + 0x14);
  uStack_74 = *(undefined4 *)(*(int *)DWORD_080b11e4 + 0x18);
  sub_08097FE4();
  sub_08097A4C();
  *(byte *)(param_1 + 0xfe) = (byte)param_1[0xfe] & 0xf0 | (byte)*param_1 & 0xf;
  *(ushort *)((int)param_1 + DWORD_080b11e8) = param_1[1];
  *(byte *)(param_1 + 0x100) = 0xff;
  iStack_30 = 0;
  sub_08067C18();
  while (iVar13 = sub_08067C08(), iVar13 == 0) {
    sub_080003F0();
  }
  sub_08067BF8();
  sub_0806849C();
  do {
    iVar13 = sub_0800CB78();
    if ((iVar13 != 0) || (iVar13 = sub_08056E90(), iVar13 != 0)) break;
    if ((param_1[6] == 10) && (uStack_54 == 0)) {
      uStack_54 = 8;
    }
    iVar13 = sub_08058DB0();
    if (iVar13 == 0) {
      sub_0801C8F0(*(undefined4 *)DWORD_080b1244);
      switch(*(byte *)((int)param_1 + DWORD_080b1248)) {
      case 1:
        param_1[6] = 0;
        iVar13 = sub_08067C08();
        if (iVar13 != 0) {
          *(byte *)((int)param_1 + _UNK_080b12ac) = (byte)param_1[0xff];
          sub_08067BF8();
        }
        break;
      case 2:
        param_1[6] = 0;
        bVar7 = sub_08068490();
        *(byte *)(param_1 + 0x100) = bVar7;
        if (bVar7 != 0xff) {
          *_UNK_080b12e8 = bVar7;
          *(byte *)(param_1 + 0x100) = 0xff;
          bVar7 = 9;
          goto code_r0x080b15d8;
        }
        break;
      case 3:
        uStack_60 = 0;
        iVar13 = sub_08056F78();
        if (iVar13 != 0) {
          bVar7 = 4;
          goto code_r0x080b15d8;
        }
        break;
      case 4:
        uStack_60 = 1;
        param_1[6] = 1;
        if (uStack_3c < 8) {
          iVar13 = sub_08096594(0);
          uVar14 = (byte)param_1[0xfe] & 0xf | iVar13 << 4;
          *(byte *)(param_1 + 0xfe) = (byte)uVar14;
          iVar13 = ((uVar14 << 0x18) >> 0x1c) * 0x14c + _UNK_080b1394;
          if ((uStack_34 & uStack_60) == 0) {
            cVar8 = sub_08097A74(param_1,iVar13,0x140,0x50);
            if (cVar8 == '\0') {
              uStack_34 = uStack_34 + 1 & 0xff;
              uStack_4c = 0;
              *(byte *)(param_1 + 0xff) = 6;
              *(byte *)((int)param_1 + _UNK_080b13dc) = 1;
              sub_08067C18();
            }
          }
          else {
            cVar8 = sub_08097A74(param_1,iVar13,0x140,0x1c);
            if (cVar8 == '\0') {
              uStack_34 = uStack_34 + 1 & 0xff;
              uStack_3c = uStack_3c + 1 & 0xff;
              *(byte *)(param_1 + 0xff) = 5;
              *(byte *)((int)param_1 + _UNK_080b1398) = 1;
              sub_08067C18();
              sub_08058CC4(uStack_64);
            }
          }
        }
        else {
          *(byte *)(param_1 + 0xff) = 10;
          *(byte *)((int)param_1 + _UNK_080b13f8) = 1;
          sub_08067C18();
        }
        break;
      case 5:
        uStack_60 = 2;
        param_1[6] = 2;
        if (param_1[0x37] != 0) {
          *(int *)(param_1 + 0x28) = *(int *)(param_1 + 0x28) + 1;
          uStack_40 = uStack_40 + 1 & 0xff;
          iVar13 = __modsi3(4);
          if (iVar13 == 0) {
            *(byte *)(param_1 + 0xff) = 0xd;
            param_1[6] = 0;
          }
          else {
            uStack_40 = 0;
            *(byte *)(param_1 + 0xff) = 8;
            param_1[6] = 9;
          }
          *(byte *)((int)param_1 + _UNK_080b1460) = 1;
          sub_08067C18();
        }
        break;
      case 6:
        uStack_60 = 9;
        param_1[6] = 9;
        piVar4 = _UNK_080b14d0;
        iVar13 = *_UNK_080b14d0;
        uVar9 = sub_08096594(0);
        sub_08095F10(iVar13,uVar9);
        puVar19 = (ushort *)*piVar4;
        puVar19[0x34] = puVar19[4];
        bVar1 = 0x1e < uStack_4c;
        uStack_4c = uStack_4c + 1 & 0xffff;
        if (bVar1) {
          uStack_4c = 0;
          sub_0807386C(*puVar19 + 4,0xd,(byte)puVar19[0xfe] >> 4,5,5);
          iVar13 = *piVar4;
          *(int *)(iVar13 + 0x50) = *(int *)(iVar13 + 0x50) + 1;
          bVar7 = 7;
          goto code_r0x080b15d8;
        }
        break;
      case 7:
        uStack_60 = 9;
        param_1[6] = 9;
        piVar4 = _UNK_080b1528;
        iVar13 = *_UNK_080b1528;
        uVar9 = sub_08096594(0);
        sub_08095F10(iVar13,uVar9);
        *(short *)(*piVar4 + 0x68) = *(short *)(*piVar4 + 8) + 8;
        bVar1 = 0x1e < uStack_4c;
        uStack_4c = uStack_4c + 1 & 0xffff;
        if (bVar1) {
          uStack_4c = 0;
          sub_08097A38();
          *(byte *)(param_1 + 0xff) = 4;
          iVar13 = _UNK_080b152c;
          goto code_r0x080b15de;
        }
        break;
      case 8:
        uStack_60 = 9;
        param_1[6] = 9;
        uVar18 = 0;
        uVar14 = 1;
        do {
          if ((1 << ((int)(short)uVar14 & 0xffU) & *_UNK_080b15b8) != 0) {
            uVar18 = uVar18 * 0x10000 + 0x10000 >> 0x10;
          }
          uVar17 = (int)(short)uVar14 + 1;
          uVar14 = uVar17 & 0xffff;
        } while ((int)(uVar17 * 0x10000) >> 0x10 < 5);
        if ((short)uVar18 < 2) {
          iVar13 = sub_08002204();
          if (iVar13 == 1) {
            sVar11 = sub_0800086C();
            iVar21 = (int)sVar11;
            iVar13 = iVar21;
            if (iVar21 < 0) {
              iVar13 = iVar21 + 3;
            }
            iVar13 = (iVar21 + (iVar13 >> 2) * -4) * 0x10000 >> 0x10;
            if (iVar13 < 0) {
              iVar13 = -iVar13;
            }
            *(byte *)(param_1 + 0x100) = (char)iVar13 + 1;
            iVar21 = sub_08068450((byte)param_1[0x100]);
            iVar13 = _UNK_080b15e8;
            if (iVar21 != 1) goto code_r0x080b15de;
            bVar7 = 2;
          }
          else {
            *(byte *)(param_1 + 0x100) = 0xff;
            bVar7 = 2;
          }
        }
        else {
          bVar7 = 0xd;
        }
code_r0x080b15d8:
        *(byte *)(param_1 + 0xff) = bVar7;
        iVar13 = _UNK_080b15e8;
code_r0x080b15de:
        *(byte *)((int)param_1 + iVar13) = 1;
        sub_08067C18();
        break;
      case 9:
        uStack_60 = 9;
        param_1[6] = 9;
        *puStack_2c = param_1[4] + 8;
        sub_080B236C(uStack_78,uStack_74);
        *(byte *)(param_1 + 0xff) = 0xd;
        *(byte *)((int)param_1 + _UNK_080b161c) = 1;
        sub_08067C18();
        break;
      case 10:
        uStack_60 = 9;
        param_1[6] = 9;
        *(byte *)(param_1 + 0xff) = 0xb;
        *(byte *)((int)param_1 + _UNK_080b1640) = 1;
        sub_08067C18();
        break;
      case 0xb:
        uStack_60 = 9;
        param_1[6] = 9;
        *puStack_2c = param_1[4] + 8;
        if (iStack_38 == 0) {
          iStack_38 = 1;
          uStack_3c = 0;
          sub_08098088(*(undefined4 *)(param_1 + 10),*(undefined4 *)(param_1 + 0xc),1);
          sub_0801A0B0(param_1);
        }
        else {
          cVar8 = sub_080980F0();
          if (cVar8 == '\0') {
            uVar14 = ((uStack_44 + 1) * 0x10000 & 0xf0000) >> 0x10;
            uVar18 = 0;
            uStack_44 = uVar14;
code_r0x080b1770:
            sub_08009088(0,0,uVar14,uVar18);
          }
          else {
            iStack_38 = 0;
            *(byte *)(param_1 + 0xff) = 0xc;
            *(byte *)((int)param_1 + _UNK_080b1698) = 1;
            sub_08067C18();
          }
        }
        break;
      case 0xc:
        uStack_60 = 9;
        param_1[6] = 9;
        *puStack_2c = param_1[4] + 8;
        pbVar5 = _UNK_080b1708;
        iVar13 = _UNK_080b1704;
        if (iStack_38 == 0) {
          iStack_38 = 1;
          puVar15 = (undefined4 *)((uint)*_UNK_080b1708 * 8 + _UNK_080b1704);
          sub_08098088(*puVar15,puVar15[1],1);
          *(undefined4 *)(param_1 + 10) = *(undefined4 *)((uint)*pbVar5 * 8 + iVar13);
          *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)((uint)*pbVar5 * 8 + iVar13 + 4);
          if (*pbVar5 == 8) {
            bVar7 = 0;
          }
          else {
            bVar7 = *pbVar5 + 1;
            *pbVar5 = bVar7;
          }
          *pbVar5 = bVar7;
        }
        else {
          cVar8 = sub_080980F0();
          if (cVar8 == '\0') {
            uVar18 = ((uStack_44 - 1) * 0x10000 & 0xf0000) >> 0x10;
            uVar14 = 0;
            uStack_44 = uVar18;
            goto code_r0x080b1770;
          }
          iStack_38 = 0;
          uStack_44 = 0;
          sub_0801A0A4(param_1);
          sub_08009088(0,0,0,0);
          uStack_4c = 0;
          *(byte *)(param_1 + 0xff) = 6;
          *(byte *)((int)param_1 + _UNK_080b1754) = 1;
          sub_08067C18();
        }
        break;
      case 0xd:
        uStack_60 = 0;
        param_1[6] = 0;
        bVar1 = 0x3c < uStack_4c;
        uStack_4c = uStack_4c + 1 & 0xffff;
        if (bVar1) {
          uStack_4c = 0;
          sub_08097A38();
          *(byte *)(param_1 + 0xff) = 4;
          *(byte *)((int)param_1 + _UNK_080b17c4) = 1;
          sub_08067C18();
        }
      }
    }
    if (uStack_60 == 1) {
      puStack_70 = auStack_118;
      *puStack_2c = param_1[4] + 8;
      uStack_58 = 1;
    }
    else if ((int)uStack_60 < 2) {
      if (uStack_60 == 0) {
        puStack_70 = auStack_118;
        *puStack_2c = param_1[4];
        uStack_58 = 1;
      }
    }
    else if (uStack_60 == 2) {
      puStack_70 = auStack_e4;
      *puStack_2c = param_1[4];
      uStack_58 = 0;
    }
    else if (uStack_60 == 9) {
      puStack_70 = auStack_b0;
      uStack_58 = 0;
    }
    puVar15 = puStack_70;
    iVar13 = *(int *)DWORD_080b185c;
    if (dStack_5c != *(ushort *)(iVar13 + 0x68)) {
      dStack_5c = (dword)*(ushort *)(iVar13 + 0x68);
      *(undefined2 *)(iVar13 + 0x6c) = 0;
      *(undefined2 *)(iVar13 + 0x6a) = 0;
    }
    *(char *)(puStack_70 + 7) = (char)*(undefined2 *)DWORD_080b1860;
    sub_08000AF0(*(ushort *)DWORD_080b1860 + 0x10,puVar15[3],1);
    uVar14 = sub_08098004();
    if ((uVar14 & 1) == 0) {
      uVar9 = sub_0800BC44(*(int *)(param_1 + 10) >> 8,*(int *)(param_1 + 0xc) >> 8,0);
    }
    else {
      uVar9 = sub_08097FF8();
    }
    iVar13 = sub_0800CD8C();
    if (iVar13 == 0) {
      uVar10 = sub_08065370(puStack_70,*puStack_2c,puStack_28,puStack_24,uStack_58);
      param_1[0x37] = uVar10;
    }
    sub_0800BC08((*(int *)(param_1 + 10) << 8) >> 0x10,(*(int *)(param_1 + 0xc) << 8) >> 0x10,
                 &sStack_7c,&sStack_7a,0,0);
    if (uStack_54 == 0) {
      iVar13 = sub_0800CCCC();
      if (((iVar13 == 0) && (iVar13 = sub_0800CC98(), iVar13 == 0)) &&
         (iVar13 = sub_0800CD34(), iVar13 == 0)) {
        if (uStack_44 == 0) {
          sub_08007870((int)sStack_7c,(int)sStack_7a,*puStack_2c,*puStack_28,uVar9,puStack_70 + 7,
                       puStack_70[2],*puStack_70);
        }
        else {
          sub_08007974((int)sStack_7c,(int)sStack_7a,*puStack_2c,*puStack_28,uVar9,1,0,
                       puStack_70 + 7,puStack_70[2],*puStack_70);
        }
      }
    }
    else {
      uVar14 = uStack_54 - 1 & 0xffff;
      uVar18 = uStack_54 & 1;
      uStack_54 = uVar14;
      if (((uVar18 != 0) && (iVar13 = sub_0800CCCC(), iVar13 == 0)) &&
         ((iVar13 = sub_0800CC98(), iVar13 == 0 && (iVar13 = sub_0800CD34(), iVar13 == 0)))) {
        sub_08007870((int)sStack_7c,(int)sStack_7a,*puStack_2c,*puStack_28,uVar9,puStack_70 + 7,
                     puStack_70[2],*puStack_70);
      }
    }
    iVar13 = *(int *)(param_1 + 0x26);
    if ((iVar13 != 0) && (iStack_68 != iVar13)) {
      uStack_50 = 10;
      uStack_48 = 0;
      iStack_68 = iVar13;
    }
    if (uStack_50 == 0) {
      iStack_68 = 0;
      param_1[0x26] = 0;
      param_1[0x27] = 0;
    }
    else {
      iVar13 = sub_0800CC98();
      if (((iVar13 == 0) && (iVar13 = sub_0800CCCC(), iVar13 == 0)) &&
         (iVar13 = sub_0800CD34(), iVar13 == 0)) {
        sub_0801A120(param_1,iStack_68,(int)(short)uStack_48);
      }
      if ((uStack_50 & 2) != 0) {
        uStack_48 = uStack_48 * 0x10000 + DWORD_080b19f4 >> 0x10;
      }
      uStack_50 = uStack_50 - 1 & 0xffff;
    }
    sVar11 = sub_08019CE8(param_1);
    if (sVar11 != 0) {
      iStack_30 = 1;
    }
    sub_08020680(param_1);
    sub_080003F0();
  } while (iStack_30 == 0);
  dVar3 = DWORD_080b1bc4;
  *(uint *)DWORD_080b1bc0 = *(uint *)DWORD_080b1bc0 & ~(1 << (**(ushort **)DWORD_080b1bc4 & 0xff));
  iVar13 = sub_080020F4();
  puVar20 = (uint *)(iVar13 * 0x14c + DWORD_080b1bc8 + 0x30);
  *puVar20 = *puVar20 | 1;
  sub_08009088(0,0,0,0);
  sub_08098060();
  sub_080B1FD4();
  puStack_70 = auStack_b0;
  uStack_94 = (undefined1)*(undefined2 *)DWORD_080b1bcc;
  iVar13 = *(int *)dVar3;
  *(undefined2 *)(iVar13 + 0x6c) = 0;
  *(undefined2 *)(iVar13 + 0x6a) = 0;
  *(undefined2 *)(iVar13 + 0x68) = 0;
  uStack_48 = 0;
  uStack_50 = 10;
  do {
    iVar13 = sub_080020F4();
    puVar20 = (uint *)(iVar13 * 0x14c + DWORD_080b1bc8 + 0x30);
    *puVar20 = *puVar20 | 1;
    iVar13 = sub_0800CCCC();
    if (((iVar13 == 0) && (iVar13 = sub_0800CC98(), iVar13 == 0)) &&
       (iVar13 = sub_0800CD34(), iVar13 == 0)) {
      sub_08000AF0(*(ushort *)DWORD_080b1bcc + 0x10,puStack_70[3],1);
      uVar9 = sub_0800BC44(*(int *)(*(int *)dVar3 + 0x14) >> 8,*(int *)(*(int *)dVar3 + 0x18) >> 8,0
                          );
      iVar13 = *(int *)dVar3;
      uVar12 = sub_08065370(puStack_70,*(undefined2 *)(iVar13 + 0x68),iVar13 + 0x6a,iVar13 + 0x6c,1)
      ;
      iVar13 = *(int *)dVar3;
      *(undefined2 *)(iVar13 + 0x6e) = uVar12;
      sub_0800BC08((*(int *)(iVar13 + 0x14) << 8) >> 0x10,(*(int *)(iVar13 + 0x18) << 8) >> 0x10,
                   &sStack_7c,&sStack_7a,0,0);
      sub_08007870((int)sStack_7c,(int)sStack_7a,*(undefined2 *)(*(int *)dVar3 + 0x68),
                   *(undefined2 *)(*(int *)dVar3 + 0x6a),uVar9,puStack_70 + 7,puStack_70[2],
                   *puStack_70);
      sub_0801A120(param_1,iStack_68,(int)(short)uStack_48);
    }
    if ((uStack_50 & 2) != 0) {
      uStack_48 = uStack_48 * 0x10000 + DWORD_080b1bd0 >> 0x10;
    }
    sub_080B23C8();
    sub_080003F0();
    uStack_50 = uStack_50 - 1 & 0xffff;
  } while (uStack_50 != DWORD_080b1bd4);
  sub_080683CC();
  dVar3 = DWORD_080b1bc4;
  sub_08067CA8(*(undefined2 *)(*(int *)DWORD_080b1bc4 + 2));
  sub_08068330(DWORD_080b1bd8);
  while (iVar13 = sub_080682B8(DWORD_080b1ccc), iVar13 == 0) {
    iVar13 = sub_080020F4();
    puVar20 = (uint *)(iVar13 * 0x14c + DWORD_080b1cc4 + 0x30);
    *puVar20 = *puVar20 | 1;
    iVar13 = sub_0800CCCC();
    if (((iVar13 == 0) && (iVar13 = sub_0800CC98(), iVar13 == 0)) &&
       ((iVar13 = sub_0800CD8C(), iVar13 == 0 && (iVar13 = sub_0800CD34(), iVar13 == 0)))) {
      sub_08000AF0(*(ushort *)DWORD_080b1cc8 + 0x10,puStack_70[3],1);
      uVar9 = sub_0800BC44(*(int *)(*(int *)dVar3 + 0x14) >> 8,*(int *)(*(int *)dVar3 + 0x18) >> 8,0
                          );
      iVar13 = *(int *)dVar3;
      uVar12 = sub_08065370(puStack_70,*(undefined2 *)(iVar13 + 0x68),iVar13 + 0x6a,iVar13 + 0x6c,1)
      ;
      iVar13 = *(int *)dVar3;
      *(undefined2 *)(iVar13 + 0x6e) = uVar12;
      sub_0800BC08((*(int *)(iVar13 + 0x14) << 8) >> 0x10,(*(int *)(iVar13 + 0x18) << 8) >> 0x10,
                   &sStack_7c,&sStack_7a,0,0);
      sub_08007870((int)sStack_7c,(int)sStack_7a,*(undefined2 *)(*(int *)dVar3 + 0x68),
                   *(undefined2 *)(*(int *)dVar3 + 0x6a),uVar9,puStack_70 + 7,puStack_70[2],
                   *puStack_70);
    }
    sub_080B23C8();
    sub_080003F0();
  }
  sub_08065E38(DWORD_080b1ccc);
  dVar6 = DWORD_080b1cd4;
  dVar3 = DWORD_080b1cd0;
  while (iVar13 = sub_08058DB0(), iVar13 != 0) {
    iVar13 = sub_080020F4();
    puVar20 = (uint *)(iVar13 * 0x14c + dVar3);
    *puVar20 = *puVar20 | 1;
    iVar13 = sub_0800CCCC();
    if (((iVar13 == 0) && (iVar13 = sub_0800CC98(), iVar13 == 0)) &&
       (iVar13 = sub_0800CD34(), iVar13 == 0)) {
      sub_08000AF0(*(ushort *)DWORD_080b1de8 + 0x10,puStack_70[3],1);
      uVar9 = sub_0800BC44(*(int *)(*(int *)dVar6 + 0x14) >> 8,*(int *)(*(int *)dVar6 + 0x18) >> 8,0
                          );
      iVar13 = *(int *)dVar6;
      uVar12 = sub_08065370(puStack_70,*(undefined2 *)(iVar13 + 0x68),iVar13 + 0x6a,iVar13 + 0x6c,1)
      ;
      iVar13 = *(int *)dVar6;
      *(undefined2 *)(iVar13 + 0x6e) = uVar12;
      sub_0800BC08((*(int *)(iVar13 + 0x14) << 8) >> 0x10,(*(int *)(iVar13 + 0x18) << 8) >> 0x10,
                   &sStack_7c,&sStack_7a,0,0);
      sub_08007870((int)sStack_7c,(int)sStack_7a,*(undefined2 *)(*(int *)dVar6 + 0x68),
                   *(undefined2 *)(*(int *)dVar6 + 0x6a),uVar9,puStack_70 + 7,puStack_70[2],
                   *puStack_70);
    }
    sub_080B23C8();
    sub_080003F0();
  }
  sub_080586B4(0);
  iVar13 = sub_080020F4();
  puVar20 = (uint *)(iVar13 * 0x14c + DWORD_080b1dec + 0x30);
  *puVar20 = *puVar20 | 1;
  iVar13 = sub_0805A318();
  if (iVar13 == 0) {
    uVar16 = sub_0805DF38(1,0xe,0x19,2,0x3c,DWORD_080b1e20);
    iVar13 = *(int *)DWORD_080b1e24;
  }
  else {
    uVar16 = sub_0805DF38(1,0xe,0x19,2,0x3c,DWORD_080b1df0);
    iVar13 = *(int *)DWORD_080b1df4;
  }
  *(undefined4 *)(iVar13 + 0x720) = uVar16;
  dVar3 = DWORD_080b1e28;
  while (iVar13 = sub_0805EEFC(*(undefined4 *)(*(int *)DWORD_080b1fa4 + 0x720)), iVar13 == 0) {
    iVar13 = sub_080020F4();
    puVar20 = (uint *)(iVar13 * 0x14c + DWORD_080b1f9c + 0x30);
    *puVar20 = *puVar20 | 1;
    iVar13 = sub_0800CCCC();
    if (((iVar13 == 0) && (iVar13 = sub_0800CC98(), iVar13 == 0)) &&
       ((iVar13 = sub_0800CD8C(), iVar13 == 0 && (iVar13 = sub_0800CD34(), iVar13 == 0)))) {
      sub_08000AF0(*(ushort *)DWORD_080b1fa0 + 0x10,puStack_70[3],1);
      uVar9 = sub_0800BC44(*(int *)(*(int *)dVar3 + 0x14) >> 8,*(int *)(*(int *)dVar3 + 0x18) >> 8,0
                          );
      iVar13 = *(int *)dVar3;
      uVar12 = sub_08065370(puStack_70,*(undefined2 *)(iVar13 + 0x68),iVar13 + 0x6a,iVar13 + 0x6c,1)
      ;
      iVar13 = *(int *)dVar3;
      *(undefined2 *)(iVar13 + 0x6e) = uVar12;
      sub_0800BC08((*(int *)(iVar13 + 0x14) << 8) >> 0x10,(*(int *)(iVar13 + 0x18) << 8) >> 0x10,
                   &sStack_7c,&sStack_7a,0,0);
      sub_08007870((int)sStack_7c,(int)sStack_7a,*(undefined2 *)(*(int *)dVar3 + 0x68),
                   *(undefined2 *)(*(int *)dVar3 + 0x6a),uVar9,puStack_70 + 7,puStack_70[2],
                   *puStack_70);
    }
    sub_080B23C8();
    sub_080003F0();
  }
  iVar13 = sub_080020F4();
  iVar21 = DWORD_080b1f9c + 0x30;
  puVar20 = (uint *)(iVar13 * 0x14c + iVar21);
  *puVar20 = *puVar20 & 0xfffffffe;
  sub_080B23FC();
  sub_080B2454();
  iVar13 = sub_080020F4();
  if (((*(uint *)(iVar13 * 0x14c + iVar21) & 0x2000) == 0) &&
     (*(short *)(*(int *)DWORD_080b1fa8 + 0x5a) != 0)) {
    uVar16 = sub_0801E46C(*(undefined4 *)DWORD_080b1fac,puStack_6c);
    uStack_48 = 0x1d;
    do {
      iVar13 = *(int *)DWORD_080b1fa8;
      *(int *)(iVar13 + 0x18) = *(int *)(iVar13 + 0x18) + -0x20;
      sub_0806171C(iVar13,uVar16);
      sub_080003F0();
      uVar14 = uStack_48 * 0x10000 + DWORD_080b1fb0;
      uStack_48 = uVar14 >> 0x10;
    } while ((int)uVar14 >> 0x10 != -1);
    sub_0801E4CC(*(undefined4 *)DWORD_080b1fac,uVar16);
  }
  sub_08056E24();
  while (iVar13 = sub_08056E90(), iVar13 == 0) {
    sub_080003F0();
  }
  sub_080B2424();
  return in_lr;
}


