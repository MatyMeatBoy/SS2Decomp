
void sub_08065204(undefined4 *param_1)

{
  param_1[4] = 0xffffffff;
  param_1[2] = 0;
  *param_1 = 0;
  param_1[3] = 0;
  return;
}


