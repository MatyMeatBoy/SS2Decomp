
undefined8 sub_0801674C(undefined4 param_1,undefined4 param_2)

{
  dword dVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined2 *puVar5;
  undefined4 in_lr;
  
  uVar3 = 0;
  do {
    if ((1 << (uVar3 & 0xff) & *(uint *)DWORD_080167f8) == 0) goto LAB_08016774;
    uVar3 = uVar3 + 1;
  } while ((int)uVar3 < 5);
  uVar3 = 0xffffffff;
LAB_08016774:
  if (-1 < (int)uVar3) {
    *(uint *)DWORD_080167f8 = *(uint *)DWORD_080167f8 | 1 << (uVar3 & 0xff);
    puVar5 = (undefined2 *)(*(int *)DWORD_080167fc + uVar3 * 0x2e0);
    *puVar5 = (short)uVar3;
    *(uint *)(puVar5 + 0x28) = (uVar3 + 4) * 0x1000000;
    dVar1 = DWORD_08016800;
    iVar4 = uVar3 * 0x28;
    *(undefined4 *)(iVar4 + DWORD_08016800 + 0xc) = param_1;
    iVar2 = sub_08001494(0x800);
    *(int *)(iVar4 + dVar1 + 0x20) = iVar2;
    *(dword *)(iVar4 + dVar1 + 0x10) = iVar2 + DWORD_08016804;
    *(undefined4 *)(iVar4 + dVar1 + 8) = 0x3c;
    *(undefined4 *)(iVar4 + dVar1 + 0x18) = 0;
    *(undefined4 *)(iVar4 + dVar1) = 0;
    *(undefined4 *)(iVar4 + dVar1 + 0x24) = param_2;
    sub_08000274((undefined4 *)(iVar4 + dVar1),puVar5);
  }
  return CONCAT44(in_lr,(uint)(-1 < (int)uVar3));
}


