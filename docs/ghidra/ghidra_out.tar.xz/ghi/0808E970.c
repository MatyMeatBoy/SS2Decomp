
undefined4 sub_0808E970(void)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 in_lr;
  
  while (iVar2 = sub_08056E90(), iVar2 == 0) {
    iVar2 = sub_08058DB0();
    if (iVar2 == 0) {
      if ((*(uint *)DWORD_0808e9b0 & 0x7f) == 0) {
        uVar1 = sub_080008C8();
        iVar2 = __umodsi3(uVar1,0x140);
        sub_08068070(DWORD_0808e9b4,iVar2 + 0x50);
      }
    }
    sub_080003F0();
  }
  return in_lr;
}


