
undefined4 sub_08026858(void)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  ushort *puVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  bool bVar9;
  uint unaff_r10;
  undefined4 in_lr;
  undefined4 auStack_68 [2];
  undefined4 uStack_60;
  int iStack_5c;
  undefined1 auStack_4c [15];
  undefined1 uStack_3d;
  undefined2 uStack_34;
  undefined2 uStack_32;
  ushort uStack_30;
  short sStack_2e;
  int iStack_2c;
  uint uStack_28;
  uint uStack_24;
  
  uStack_34 = 0;
  uStack_32 = 0;
  bVar9 = false;
  iStack_2c = sub_08007290(DWORD_080268dc);
  iVar2 = sub_080020F4();
  iVar8 = iVar2 * 0x14c + DWORD_080268e0;
  sub_08065158(auStack_68,DWORD_080268e4,0xe,0xffffffff,0);
  sub_08000AF0(0x1e,iStack_5c + 0x1e0,1);
  uStack_3d = 0xe;
  iVar2 = sub_0800CF48();
  if ((iVar2 == 0) &&
     (uVar4 = (uint)*(ushort *)(*(int *)DWORD_080268e8 + 4) << 0x10, (uVar4 >> 0x18 & 1) == 0)) {
    if ((uVar4 >> 0x14 & 1) == 0) {
LAB_080268f0:
      while (iVar2 = sub_0800CDF8(), iVar2 != 0) {
        sub_080003F0();
      }
      iVar2 = sub_080021A8();
      if (iVar2 != 0) {
        return in_lr;
      }
      uStack_30 = (ushort)((uint)*(undefined4 *)(iVar8 + 0x8c) >> 8);
      sStack_2e = (short)((uint)*(undefined4 *)(iVar8 + 0x90) >> 8);
      iVar2 = sub_0806569C();
      if ((iVar2 == 0) && (*(short *)(iVar8 + 0x20) != 0xe)) {
        iVar2 = (short)uStack_30 + -0xf0;
        if (iVar2 < 0) {
          iVar2 = -iVar2;
        }
        if (0x17 < iVar2) goto LAB_080269f0;
        iVar2 = sStack_2e + -0x88;
        if (iVar2 < 0) {
          iVar2 = -iVar2;
        }
        if (0xf < iVar2) goto LAB_080269f0;
        iVar2 = sub_0800CCCC();
        if ((iVar2 != 0) && (*(short *)(DWORD_080269b0 + 0x90) == 0x13)) {
          iVar2 = iStack_2c + 2;
          uVar4 = sub_0801A638(iVar2);
          sub_0801A3D0(iVar2,0xf - (uVar4 >> 1) & 0xffff,0x12);
          uVar4 = *(uint *)(iVar8 + 0x30);
          if ((uVar4 & 0x400) == 0) {
            if ((*(ushort *)(iVar8 + 0x14) & 1) != 0) {
              *(uint *)(iVar8 + 0x30) = uVar4 | DWORD_080269b4;
              sub_08067D74();
              *(undefined4 *)(iVar8 + 0xd8) = 0;
            }
            uStack_28 = 0;
          }
          else {
            uVar6 = uStack_28 + 1;
            bVar9 = 0x3c < uStack_28;
            uStack_28 = uVar6;
            if ((bVar9) && ((*(ushort *)DWORD_080269e4 & 2) != 0)) {
              *(uint *)(iVar8 + 0x30) = uVar4 & DWORD_080269e8;
              sub_08057328(0,DWORD_080269ec);
            }
          }
        }
        bVar9 = true;
      }
      else {
LAB_080269f0:
        if (bVar9) {
          bVar9 = false;
          sub_0801A664(0x12,2);
        }
        *(uint *)(iVar8 + 0x30) = *(uint *)(iVar8 + 0x30) & DWORD_08026a1c;
      }
      iVar2 = sub_08002204();
      if (iVar2 == 0) goto LAB_08026aae;
      iVar2 = 0;
      uStack_24 = unaff_r10 + 1;
      for (uVar4 = 0; uVar6 = sub_08002164(), uVar4 < uVar6; uVar4 = uVar4 + 1) {
        puVar5 = *(ushort **)(uVar4 * 0x14c + DWORD_08026a94 + 0x148);
        uStack_30 = *puVar5 >> 4;
        sStack_2e = (short)(puVar5[1] & 0xfff);
        iVar3 = (short)uStack_30 + -0xf0;
        if (iVar3 < 0) {
          iVar3 = -iVar3;
        }
        if (iVar3 < 0x18) {
          iVar3 = (puVar5[1] & 0xfff) - 0x88;
          if (iVar3 < 0) {
            iVar3 = -iVar3;
          }
          if ((iVar3 < 0x10) && ((int)((uint)*(byte *)((int)puVar5 + 7) * 0x8000000) < 0)) {
            iVar2 = iVar2 + 1;
          }
        }
      }
      iVar3 = sub_08002164();
      unaff_r10 = uStack_24;
      if (iVar2 != iVar3) {
        unaff_r10 = 0;
      }
      if (unaff_r10 < 3) goto LAB_08026aae;
      *(dword *)(*(int *)DWORD_08026a98 + 0x40) = DWORD_08026a9c;
      while (iVar2 = sub_08067DC8(), iVar2 == 0) {
        sub_080003F0();
      }
    }
LAB_08026b42:
    sub_0805865C(0x24);
    uVar4 = 1;
    do {
      while (iVar2 = sub_0800CDF8(), iVar2 != 0) {
        sub_080003F0();
      }
      iVar2 = sub_080021A8();
      if (iVar2 != 0) {
        return in_lr;
      }
      sub_08065370(auStack_68,1,&uStack_34,&uStack_32,1);
      iVar2 = sub_0800CC98();
      if (((iVar2 == 0) && (iVar2 = sub_0800CCCC(), iVar2 != 0)) &&
         (*(short *)(DWORD_08026c4c + 0x90) == 0x13)) {
        sub_08000AF0(0x1e,iStack_5c + 0x1e0,1);
        sub_0800BC08(0xf0,0x88,&uStack_30,&sStack_2e,0x30,0);
        sub_08008E74((int)(short)uStack_30,(int)sStack_2e,1,uStack_34,3,auStack_4c,uStack_60,
                     auStack_68[0]);
      }
      sub_080003F0();
      bVar9 = uVar4 < 100;
      uVar4 = uVar4 + 1;
    } while (bVar9);
    sub_0800D014();
    dVar1 = DWORD_08026c50;
    uVar4 = 0;
    do {
      uVar6 = 0;
      uVar7 = uVar4 + 1;
      do {
        *(undefined1 *)(*(int *)dVar1 + 0x1c8 + uVar6 + uVar4 * 5) = 0;
        uVar6 = uVar6 + 1;
      } while (uVar6 < 5);
      uVar4 = uVar7;
    } while (uVar7 < 0x14);
    sub_080003F0();
    sub_0801A664(0x12,2);
    sub_0800CDAC();
    sub_08057624(3);
  }
  return in_lr;
LAB_08026aae:
  sub_08065370(auStack_68,1,&uStack_34,&uStack_32,1);
  iVar2 = sub_0800CC98();
  if (((iVar2 == 0) && (iVar2 = sub_0800CCCC(), iVar2 != 0)) &&
     (*(short *)(DWORD_08026b58 + 0x90) == 0x13)) {
    sub_08000AF0(0x1e,iStack_5c + 0x1e0,1);
    sub_0800BC08(0xf0,0x88,&uStack_30,&sStack_2e,0x30,0);
    sub_08008E74((int)(short)uStack_30,(int)sStack_2e,1,uStack_34,3,auStack_4c,uStack_60,
                 auStack_68[0]);
  }
  sub_080003F0();
  if ((*(ushort *)(*(int *)DWORD_08026b5c + 4) >> 4 & 1) != 0) goto LAB_08026b42;
  goto LAB_080268f0;
}


