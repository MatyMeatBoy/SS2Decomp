
undefined4 sub_08058620(short *param_1)

{
  dword dVar1;
  uint uVar2;
  undefined4 in_lr;
  
  dVar1 = DWORD_08058654;
  uVar2 = (uint)*(ushort *)(*(int *)DWORD_08058654 + 10);
  if (*param_1 != 0) {
    *(short **)(*(int *)DWORD_08058654 + DWORD_08058658 + uVar2 * 4) = param_1;
    sub_08023ED8(param_1,uVar2);
    *(short *)(*(int *)dVar1 + 10) = *(short *)(*(int *)dVar1 + 10) + 1;
  }
  return in_lr;
}


