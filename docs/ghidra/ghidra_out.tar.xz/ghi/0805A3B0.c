
undefined4 sub_0805A3B0(void)

{
  undefined4 in_lr;
  
  if ((*(uint *)DWORD_0805a3e4 & 0x20) == 0) {
    sub_08006D08(DWORD_0805a3e8);
  }
  sub_08028AAC(7,DWORD_0805a3ec,DWORD_0805a3ec,0);
  sub_08028D98(6,0,0xfffffff4,0x3c);
  return in_lr;
}


