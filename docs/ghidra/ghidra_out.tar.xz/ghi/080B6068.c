
undefined8 sub_080B6068(void)

{
  dword dVar1;
  dword dVar2;
  dword dVar3;
  int iVar4;
  byte bVar5;
  undefined4 in_lr;
  
  sub_080586B4(0);
  *(undefined1 *)DWORD_080b60dc = 1;
  iVar4 = sub_0800CC98();
  if ((iVar4 == 0) && (iVar4 = sub_0800CD8C(), iVar4 == 0)) {
    sub_080009C0(0x1f00,0x2000,1);
    dVar1 = DWORD_080b60e0;
    *(undefined2 *)(DWORD_080b60e0 + 0x38) = 0x3f;
    *(undefined2 *)(dVar1 + 0x3a) = 0x3b;
  }
  dVar2 = DWORD_080b60e4;
  bVar5 = *(char *)DWORD_080b60e4 + 1;
  *(byte *)DWORD_080b60e4 = bVar5;
  dVar3 = DWORD_080b60e8;
  dVar1 = DWORD_080b60e0;
  *(ushort *)(DWORD_080b60e0 + 0x30) = (ushort)*(byte *)dVar2 << 8 | 0xf0 - *(byte *)dVar2;
  *(ushort *)(dVar1 + 0x34) = (ushort)*(byte *)dVar3 << 8 | 0xa0 - *(byte *)dVar3;
  if (0x77 < bVar5) {
    sub_080009F8(0x400,0,1);
  }
  return CONCAT44(in_lr,(uint)(0x77 < bVar5));
}


