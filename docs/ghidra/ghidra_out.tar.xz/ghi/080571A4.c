
undefined4 sub_080571A4(uint param_1,uint param_2,undefined1 param_3)

{
  int iVar1;
  undefined4 in_lr;
  
  iVar1 = sub_08002204();
  if (iVar1 != 0) {
    *(undefined1 *)(*(int *)DWORD_080571d4 + 0x1c8 + (param_2 & 0xff) + (param_1 & 0xff) * 5) =
         param_3;
  }
  return in_lr;
}


