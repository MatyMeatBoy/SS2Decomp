
undefined4 sub_08065654(void)

{
  dword dVar1;
  dword dVar2;
  int iVar3;
  undefined4 in_lr;
  
  dVar1 = DWORD_0806565c;
  while( true ) {
    iVar3 = sub_08001494(0x400);
    *(int *)(dVar1 + 0x20) = iVar3;
    dVar2 = DWORD_08065694;
    if (iVar3 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(DWORD_08065694 + 8) = 0x34;
  *(dword *)(dVar2 + 0xc) = DWORD_08065698;
  *(int *)(dVar2 + 0x10) = *(int *)(dVar2 + 0x20) + 0x3fc;
  *(undefined4 *)(dVar2 + 0x24) = 0;
  sub_08000274();
  return in_lr;
}


