
undefined4 sub_080B22E8(void)

{
  undefined4 in_lr;
  
  if (*(short *)(*(int *)DWORD_080b2324 + 0x5c) != 0) {
    sub_08009088(0,0,0,0);
    sub_08098060();
    sub_080B1FD4();
  }
  sub_08068384();
  *(undefined4 *)DWORD_080b2328 = 0;
  sub_08016ECC(*(undefined2 *)DWORD_080b232c);
  return in_lr;
}


