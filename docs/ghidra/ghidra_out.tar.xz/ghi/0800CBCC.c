
undefined8 sub_0800CBCC(void)

{
  dword dVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 in_lr;
  
  uVar2 = sub_08002164();
  dVar1 = DWORD_0800cbe8;
  if (uVar2 <= *(uint *)DWORD_0800cbe8) {
    uVar3 = sub_08002164();
    *(undefined4 *)dVar1 = uVar3;
  }
  return CONCAT44(in_lr,*(undefined4 *)dVar1);
}


