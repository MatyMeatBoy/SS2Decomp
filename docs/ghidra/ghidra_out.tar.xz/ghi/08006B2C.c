
undefined4 sub_08006B2C(void)

{
  dword dVar1;
  int iVar2;
  undefined4 in_lr;
  
  iVar2 = sub_08001494(0x400);
  dVar1 = DWORD_08006b58;
  *(dword *)(DWORD_08006b58 + 0xc) = DWORD_08006b5c;
  *(int *)(dVar1 + 0x10) = iVar2 + 0x3fc;
  *(int *)(dVar1 + 0x20) = iVar2;
  *(undefined4 *)(dVar1 + 8) = 1;
  *(undefined4 *)(dVar1 + 0x24) = 0;
  sub_08000274();
  return in_lr;
}


