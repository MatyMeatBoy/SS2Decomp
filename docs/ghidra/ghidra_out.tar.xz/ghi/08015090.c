
undefined4 sub_08015090(void)

{
  undefined2 uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 in_lr;
  
  iVar2 = sub_080020F4();
  iVar2 = iVar2 * 0x14c + DWORD_08015148;
  if ((*(short *)(iVar2 + 0xb6) == 0) && (*(short *)(iVar2 + 0x20) == 5)) {
    piVar4 = (int *)((uint)*(ushort *)(iVar2 + 0x26) * 4 + DWORD_0801514c);
    do {
      *(undefined4 *)(iVar2 + 0x94) = *(undefined4 *)(iVar2 + 0x8c);
      *(undefined4 *)(iVar2 + 0x98) = *(undefined4 *)(iVar2 + 0x90);
      uVar1 = sub_0800CCCC();
      iVar3 = __divsi3(*piVar4 << 3,10);
      uVar1 = sub_08013E90(iVar3 + *(short *)(iVar2 + 0x40),(undefined4 *)(iVar2 + 0x8c),
                           *(undefined2 *)(iVar2 + 0x1c),uVar1,0);
      *(undefined2 *)(iVar2 + 0x1c) = uVar1;
      sub_08013CEC(iVar2);
      sub_080003F0();
      if (*(short *)(iVar2 + 0xb6) != 0) break;
    } while (*(short *)(iVar2 + 0x20) == 5);
  }
  if ((1 < (ushort)(*(short *)(iVar2 + 0x20) - 10U)) && ((*(uint *)(iVar2 + 0x30) & 0x2000) == 0)) {
    *(undefined2 *)(iVar2 + 0x20) = 0;
  }
  *(undefined2 *)(iVar2 + 0x24) = 0;
  *(undefined2 *)(iVar2 + 0x28) = *(undefined2 *)(iVar2 + 0x26);
  *(undefined2 *)(iVar2 + 0x26) = 0;
  *(undefined2 *)(iVar2 + 0x122) = 0;
  return in_lr;
}


