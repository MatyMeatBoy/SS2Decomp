
undefined4 sub_08065AFC(void)

{
  dword dVar1;
  int iVar2;
  uint *puVar3;
  undefined4 in_lr;
  
  dVar1 = DWORD_08065b4c;
  iVar2 = sub_08000470(DWORD_08065b4c);
  if (iVar2 == 0) {
    iVar2 = sub_080020F4();
    puVar3 = (uint *)(iVar2 * 0x14c + DWORD_08065b50 + 0x30);
    *puVar3 = *puVar3 | 0x80;
    *(undefined4 *)(dVar1 + 8) = 0x3c;
    iVar2 = sub_08001638(0x400);
    *(int *)(dVar1 + 0x20) = iVar2;
    *(dword *)(dVar1 + 0xc) = DWORD_08065b54;
    *(int *)(dVar1 + 0x10) = iVar2 + 0x3fc;
    *(undefined4 *)(dVar1 + 0x24) = 0;
    sub_08000274(dVar1);
  }
  return in_lr;
}


