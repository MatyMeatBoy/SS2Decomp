
undefined4 sub_08000968(void)

{
  dword dVar1;
  undefined4 in_lr;
  
  sub_080010AC(0x18);
  dVar1 = DWORD_0800098c;
  *(byte *)DWORD_0800098c = *(byte *)DWORD_0800098c | 0x80;
  Ram04000000 = *(undefined2 *)dVar1;
  sub_08006C14();
  return in_lr;
}


