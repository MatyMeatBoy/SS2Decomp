
undefined4 sub_08088914(void)

{
  dword dVar1;
  int iVar2;
  undefined4 in_lr;
  
  iVar2 = sub_08001494(0x1000);
  dVar1 = DWORD_08088940;
  *(int *)(DWORD_08088940 + 0x20) = iVar2;
  *(dword *)(dVar1 + 0x10) = iVar2 + DWORD_08088944;
  *(undefined4 *)(dVar1 + 8) = 100;
  *(undefined4 *)(dVar1 + 0x24) = 0;
  *(dword *)(dVar1 + 0xc) = DWORD_08088948;
  sub_08000274(dVar1,0);
  return in_lr;
}


