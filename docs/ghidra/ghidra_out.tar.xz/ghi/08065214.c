
undefined4 sub_08065214(int param_1)

{
  undefined4 in_lr;
  
  sub_08000AF0(*(int *)(param_1 + 0x14) + 0x10,
               *(int *)(param_1 + 0xc) + *(int *)(param_1 + 0x14) * 0x20,
               *(undefined4 *)(param_1 + 0x18));
  return in_lr;
}


