
undefined4 sub_0800C9F4(uint param_1,int *param_2)

{
  uint *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  ushort *puVar5;
  int iVar6;
  uint *puVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  undefined4 in_lr;
  
  uVar8 = param_1 >> 0x10;
  while (puVar1 = (uint *)sub_08001494(uVar8 << 5), puVar1 == (uint *)0x0) {
    sub_080003F0();
  }
  iVar6 = (param_1 & 0xffff) * 0x20;
  CpuSet(iVar6 + DWORD_0800cb20,puVar1,uVar8 << 3 | 0x4000000);
  uVar10 = 100;
  uVar3 = 0;
  iVar2 = *param_2;
  while (iVar2 == 0) {
    puVar5 = (ushort *)(iVar6 + DWORD_0800cb20);
    uVar9 = 0;
    puVar7 = puVar1;
    if (uVar8 != 0) {
      do {
        uVar4 = (*puVar7 & 0x1f) * uVar10 >> 10;
        if (0x1f < uVar4) {
          uVar4 = 0x1f;
        }
        *(byte *)puVar5 = (byte)*puVar5 & 0xe0 | (byte)uVar4 & 0x1f;
        uVar4 = ((*puVar7 << 0x16) >> 0x1b) * uVar10 >> 10;
        if (0x1f < uVar4) {
          uVar4 = 0x1f;
        }
        *puVar5 = (ushort)DWORD_0800cb24 & *puVar5 | (ushort)((uVar4 & 0x1f) << 5);
        uVar4 = ((*puVar7 << 0x11) >> 0x1b) * uVar10 >> 10;
        if (0x1f < uVar4) {
          uVar4 = 0x1f;
        }
        *(byte *)((int)puVar5 + 1) = *(byte *)((int)puVar5 + 1) & 0x83 | (byte)((uVar4 & 0x1f) << 2)
        ;
        uVar9 = uVar9 + 1;
        puVar5 = puVar5 + 1;
        puVar7 = (uint *)((int)puVar7 + 2);
      } while (uVar9 < uVar8 << 4);
    }
    sub_08000B38();
    sub_080003F0();
    uVar10 = (*(short *)(DWORD_0800cb28 + uVar3 * 2) * 200 >> 8) + DWORD_0800cb2c & 0xffff;
    uVar3 = uVar3 + 4 & 0xffff;
    if (0x100 < uVar3) {
      uVar3 = 0;
    }
    iVar2 = *param_2;
  }
  sub_08001538(puVar1);
  return in_lr;
}


