
undefined4 sub_0804A478(void)

{
  short sVar1;
  dword dVar2;
  dword dVar3;
  short sVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int unaff_r10;
  undefined4 in_lr;
  undefined1 auStack_44 [4];
  undefined1 auStack_40 [4];
  undefined1 auStack_3c [4];
  undefined1 auStack_38 [4];
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  undefined1 *puStack_28;
  undefined1 *puStack_24;
  
  sub_0804A89C(0);
  dVar2 = DWORD_0804a4fc;
  sVar4 = *(short *)(DWORD_0804a4f8 + 0x80);
  sVar1 = *(short *)(DWORD_0804a4f8 + 0x82);
  iVar6 = 0;
  puStack_28 = auStack_3c;
  puStack_24 = auStack_38;
  do {
    sub_080659F4(auStack_44,(int)sVar4,0,iVar6);
    sub_080659F4(auStack_40,(int)sVar1,(int)dVar2 >> 0x10,iVar6);
    sub_0800BB80((int)auStack_44._0_2_,(int)auStack_40._0_2_);
    sub_080003F0();
    dVar3 = DWORD_0804a500;
    iVar6 = iVar6 + 0x22;
  } while (iVar6 < 0x401);
  iVar6 = *(int *)DWORD_0804a504 + DWORD_0804a508;
  for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
    iVar5 = sub_08000470(iVar6);
    if (iVar5 == 0) goto LAB_0804a524;
    iVar6 = iVar6 + 0x28;
  }
LAB_0804a550:
  dVar2 = DWORD_0804a560;
  iVar6 = *(int *)DWORD_0804a564 + DWORD_0804a568;
  for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
    iVar5 = sub_08000470(iVar6);
    if (iVar5 == 0) goto LAB_0804a584;
    iVar6 = iVar6 + 0x28;
  }
LAB_0804a5b0:
  dVar2 = DWORD_0804a5c0;
  iVar6 = *(int *)DWORD_0804a5c4 + DWORD_0804a5c8;
  for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
    iVar5 = sub_08000470(iVar6);
    if (iVar5 == 0) goto LAB_0804a5e4;
    iVar6 = iVar6 + 0x28;
  }
LAB_0804a610:
  dVar2 = DWORD_0804a620;
  iVar6 = *(int *)DWORD_0804a624 + DWORD_0804a628;
  for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
    iVar5 = sub_08000470(iVar6);
    if (iVar5 == 0) goto LAB_0804a644;
    iVar6 = iVar6 + 0x28;
  }
LAB_0804a670:
  sub_0802A080(0x8c,0x82,200,100);
  if ((unaff_r10 != 0) && (iVar6 = sub_08000470(unaff_r10), iVar6 != 0)) {
    sub_080003A8(unaff_r10);
  }
  if ((iStack_34 != 0) && (iVar6 = sub_08000470(), iVar6 != 0)) {
    sub_080003A8(iStack_34);
  }
  if ((iStack_30 != 0) && (iVar6 = sub_08000470(iStack_30), iVar6 != 0)) {
    sub_080003A8(iStack_30);
  }
  if ((iStack_2c != 0) && (iVar6 = sub_08000470(iStack_2c), iVar6 != 0)) {
    sub_080003A8(iStack_2c);
  }
  sVar4 = 1;
  do {
    sub_080003F0();
    iVar6 = sub_080021A8();
    if (iVar6 != 0) break;
    sVar4 = sVar4 + -1;
  } while (sVar4 != 0);
  sub_0805EFBC();
  do {
    sub_080003F0();
    iVar6 = sub_0805F184();
  } while (iVar6 != 0);
  sVar4 = *(short *)(DWORD_0804a75c + 0x80);
  sVar1 = *(short *)(DWORD_0804a75c + 0x82);
  iVar6 = 0;
  do {
    sub_080659F4(puStack_28,(int)sVar4,0,iVar6);
    sub_080659F4(puStack_24,(int)sVar1,0,iVar6);
    sub_0800BB80((int)auStack_3c._0_2_,(int)auStack_38._0_2_);
    sub_080003F0();
    dVar2 = DWORD_0804a760;
    iVar6 = iVar6 + 0x66;
  } while (iVar6 < 0x401);
  iVar6 = *(int *)DWORD_0804a764 + DWORD_0804a768;
  for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
    iVar5 = sub_08000470(iVar6);
    if (iVar5 == 0) goto LAB_0804a784;
    iVar6 = iVar6 + 0x28;
  }
LAB_0804a7ae:
  dVar2 = DWORD_0804a7bc;
  iVar6 = *(int *)DWORD_0804a7c0 + DWORD_0804a7c4;
  for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
    iVar5 = sub_08000470(iVar6);
    if (iVar5 == 0) goto LAB_0804a7e0;
    iVar6 = iVar6 + 0x28;
  }
LAB_0804a80a:
  sVar4 = 0x1e;
  do {
    sub_080003F0();
    iVar6 = sub_080021A8();
    if (iVar6 != 0) break;
    sVar4 = sVar4 + -1;
  } while (sVar4 != 0);
  iVar6 = sub_0800CB9C();
  if (iVar6 == 0) {
    if ((*(uint *)DWORD_0804a844 & 0x20) == 0) {
      *(undefined4 *)DWORD_0804a848 = 2;
      sub_08006CB4();
    }
  }
  else {
    sub_080586B4(0);
  }
  dVar2 = DWORD_0804a898;
  iVar6 = *(int *)DWORD_0804a894;
  uVar7 = 0;
  do {
    if (((*(uint *)dVar2 & 1 << (uVar7 & 0xff)) != 0) && (*(short *)(iVar6 + 0xc) == 0xc)) {
      *(undefined2 *)(iVar6 + 0xc) = 0;
    }
    uVar7 = uVar7 + 1;
    iVar6 = iVar6 + 0x2e0;
  } while (uVar7 < 5);
  sub_08019F04();
  return in_lr;
LAB_0804a524:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar6 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar6 + 8) = 0x3c;
  *(dword *)(iVar6 + 0xc) = dVar3;
  *(int *)(iVar6 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar6 + 0x24) = 0;
  sub_08000274(iVar6,1);
  unaff_r10 = iVar6;
  goto LAB_0804a550;
LAB_0804a584:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar6 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar6 + 8) = 0x3c;
  *(dword *)(iVar6 + 0xc) = dVar2;
  *(int *)(iVar6 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar6 + 0x24) = 0;
  sub_08000274(iVar6,2);
  iStack_34 = iVar6;
  goto LAB_0804a5b0;
LAB_0804a5e4:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar6 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar6 + 8) = 0x3c;
  *(dword *)(iVar6 + 0xc) = dVar2;
  *(int *)(iVar6 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar6 + 0x24) = 0;
  sub_08000274(iVar6,3);
  iStack_30 = iVar6;
  goto LAB_0804a610;
LAB_0804a644:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar6 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar6 + 8) = 0x3c;
  *(dword *)(iVar6 + 0xc) = dVar2;
  *(int *)(iVar6 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar6 + 0x24) = 0;
  sub_08000274(iVar6,4);
  iStack_2c = iVar6;
  goto LAB_0804a670;
LAB_0804a784:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar6 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar6 + 8) = 0x3c;
  *(dword *)(iVar6 + 0xc) = dVar2;
  *(int *)(iVar6 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar6 + 0x24) = 0;
  sub_08000274(iVar6,5);
  goto LAB_0804a7ae;
LAB_0804a7e0:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar6 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar6 + 8) = 0x3c;
  *(dword *)(iVar6 + 0xc) = dVar2;
  *(int *)(iVar6 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar6 + 0x24) = 0;
  sub_08000274(iVar6,6);
  goto LAB_0804a80a;
}


