
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_0804D330(undefined4 param_1)

{
  short sVar1;
  short sVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined4 in_lr;
  undefined2 uStack_3c;
  undefined2 uStack_3a;
  undefined1 auStack_38 [12];
  undefined1 auStack_2c [4];
  undefined1 auStack_28 [4];
  undefined1 *puStack_24;
  
  switch(param_1) {
  case 0:
    puStack_24 = auStack_38;
    while (iVar4 = sub_0805F184(), iVar4 != 0) {
      sub_080003F0();
    }
    while (iVar4 = sub_0805EF90(), iVar4 != 0) {
      sub_080003F0();
    }
    uVar6 = sub_0805DF38(1,0xf,2,0,0x2d,_UNK_0804d3ac);
    while (iVar5 = sub_0805EEFC(uVar6), iVar4 = _UNK_0804d438, iVar5 == 0) {
      sub_080003F0();
    }
    sVar1 = *(short *)(_UNK_0804d434 + 0x80);
    sVar2 = *(short *)(_UNK_0804d434 + 0x82);
    iVar5 = 0;
    do {
      sub_080659F4(auStack_2c,(int)sVar1,0,iVar5);
      sub_080659F4(auStack_28,(int)sVar2,iVar4 >> 0x10,iVar5);
      sub_0800BB80((int)auStack_2c._0_2_,(int)auStack_28._0_2_);
      sub_080003F0();
      iVar5 = iVar5 + 0x22;
    } while (iVar5 < 0x401);
    iVar4 = sub_080020F4();
    iVar4 = iVar4 * 0x14c + _UNK_0804d43c;
    *(uint *)(iVar4 + 0x30) = *(uint *)(iVar4 + 0x30) & 0xfffffffe;
    sub_0800D108();
    while (iVar4 = sub_0805F184(), iVar4 != 0) {
      sub_080003F0();
    }
    while (iVar4 = sub_0805EF90(), iVar4 != 0) {
      sub_080003F0();
    }
    uVar6 = sub_0805DF38(1,0xf,2,0,0x2d,_UNK_0804d474);
    while (iVar4 = sub_0805EEFC(uVar6), iVar4 == 0) {
      sub_080003F0();
    }
    while (iVar4 = sub_0805F184(), iVar4 != 0) {
      sub_080003F0();
    }
    while (iVar4 = sub_0805EF90(), iVar4 != 0) {
      sub_080003F0();
    }
    uVar6 = sub_0805DF38(1,0xf,2,0,0x2d,_UNK_0804d4d4);
    uStack_3c = 1;
    uStack_3a = 0x1c;
    uVar7 = 0;
    do {
      puStack_24[uVar7] = 0;
      uVar7 = uVar7 + 1;
    } while (uVar7 < 0xc);
    while (iVar4 = sub_08067B9C(0xe800,0x8c00,&uStack_3c), iVar4 == 0) {
      sub_080003F0();
    }
    while (iVar4 = sub_0805EEFC(uVar6), uVar3 = _UNK_0804d50c, iVar4 == 0) {
      sub_080003F0();
    }
    iVar4 = *_UNK_0804d510 + _UNK_0804d514;
    for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
      iVar5 = sub_08000470(iVar4);
      if (iVar5 == 0) goto code_r0x0804d530;
      iVar4 = iVar4 + 0x28;
    }
    goto code_r0x0804d560;
  case 1:
    sub_08019EB8(*(undefined2 *)(*_UNK_0804d958 + 2),3);
    uVar6 = 1;
    break;
  case 2:
    sub_08019EB8(*(undefined2 *)(*_UNK_0804d974 + 0x2e2),3);
    uVar6 = 2;
    break;
  case 3:
    sub_08019EB8(*(undefined2 *)(*_UNK_0804d990 + 0x5c2),3);
    uVar6 = 3;
    break;
  case 4:
    sub_08019EB8(*(undefined2 *)(*_UNK_0804d9ac + 0x8a2),3);
    uVar6 = 4;
    break;
  case 5:
    sub_08019EB8(*(undefined2 *)(*_UNK_0804d9cc + 0xb82),3);
    uVar6 = 5;
    break;
  case 6:
    sub_08028D98(1,0,0xfffffffc,4);
    sub_08028D98(1,0,4,4);
    sub_08028D98(2,0,0xfffffffc,4);
    sub_08028D98(2,0,4,4);
    sub_08028D98(4,0,0xfffffffc,4);
    sub_08028D98(4,0,4,4);
    sub_08028D98(5,0,0xfffffffc,4);
    sub_08028D98(5,0,4,4);
    return in_lr;
  default:
    return in_lr;
  }
  sub_0802949C(uVar6,0);
  return in_lr;
code_r0x0804d530:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar4 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar4 + 8) = 0x3c;
  *(undefined4 *)(iVar4 + 0xc) = uVar3;
  *(int *)(iVar4 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  sub_08000274(iVar4,6);
code_r0x0804d560:
  while (iVar4 = sub_0805F184(), iVar4 != 0) {
    sub_080003F0();
  }
  while (iVar4 = sub_0805EF90(), iVar4 != 0) {
    sub_080003F0();
  }
  uVar6 = sub_0805DF38(1,0xf,2,0,0x2d,_UNK_0804d590);
  while (iVar4 = sub_0805EEFC(uVar6), iVar4 == 0) {
    sub_080003F0();
  }
  while (iVar4 = sub_0805F184(), iVar4 != 0) {
    sub_080003F0();
  }
  while (iVar4 = sub_0805EF90(), iVar4 != 0) {
    sub_080003F0();
  }
  uVar6 = sub_0805DF38(1,0xf,2,0,0x2d,_UNK_0804d604);
  sub_0805D37C(0xe800,0x8c00,6);
  sub_080687A8();
  uStack_3c = 1;
  uStack_3a = 2;
  uVar7 = 0;
  do {
    puStack_24[uVar7] = 0;
    uVar7 = uVar7 + 1;
  } while (uVar7 < 0xc);
  while (iVar4 = sub_08067B9C(0xe800,0x8c00,&uStack_3c), iVar4 == 0) {
    sub_080003F0();
  }
  while (iVar4 = sub_0805EEFC(uVar6), uVar3 = _UNK_0804d63c, iVar4 == 0) {
    sub_080003F0();
  }
  iVar4 = *_UNK_0804d640 + _UNK_0804d644;
  for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
    iVar5 = sub_08000470(iVar4);
    if (iVar5 == 0) goto code_r0x0804d660;
    iVar4 = iVar4 + 0x28;
  }
  goto code_r0x0804d690;
code_r0x0804d790:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar4 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar4 + 8) = 0x3c;
  *(undefined4 *)(iVar4 + 0xc) = uVar3;
  *(int *)(iVar4 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  sub_08000274(iVar4,6);
  goto code_r0x0804d7c0;
code_r0x0804d8c0:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar4 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar4 + 8) = 0x3c;
  *(undefined4 *)(iVar4 + 0xc) = uVar3;
  *(int *)(iVar4 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  sub_08000274(iVar4,6);
  goto code_r0x0804d8f0;
code_r0x0804d660:
  while( true ) {
    iVar5 = sub_08001494(0x400);
    *(int *)(iVar4 + 0x20) = iVar5;
    if (iVar5 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar4 + 8) = 0x3c;
  *(undefined4 *)(iVar4 + 0xc) = uVar3;
  *(int *)(iVar4 + 0x10) = iVar5 + 0x3fc;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  sub_08000274(iVar4,6);
code_r0x0804d690:
  while (iVar4 = sub_0805F184(), iVar4 != 0) {
    sub_080003F0();
  }
  while (iVar4 = sub_0805EF90(), iVar4 != 0) {
    sub_080003F0();
  }
  uVar6 = sub_0805DF38(1,0xf,2,0,0x2d,_UNK_0804d6c0);
  while (iVar4 = sub_0805EEFC(uVar6), iVar4 == 0) {
    sub_080003F0();
  }
  while (iVar4 = sub_0805F184(), iVar4 != 0) {
    sub_080003F0();
  }
  while (iVar4 = sub_0805EF90(), iVar4 != 0) {
    sub_080003F0();
  }
  uVar6 = sub_0805DF38(1,0xf,2,0,0x2d,_UNK_0804d734);
  sub_0805D37C(0xe800,0x8c00,6);
  sub_080687A8();
  uStack_3c = 1;
  uStack_3a = 0x2f;
  uVar7 = 0;
  do {
    puStack_24[uVar7] = 0;
    uVar7 = uVar7 + 1;
  } while (uVar7 < 0xc);
  while (iVar4 = sub_08067B9C(0xe800,0x8c00,&uStack_3c), iVar4 == 0) {
    sub_080003F0();
  }
  while (iVar4 = sub_0805EEFC(uVar6), uVar3 = _UNK_0804d76c, iVar4 == 0) {
    sub_080003F0();
  }
  iVar4 = *_UNK_0804d770 + _UNK_0804d774;
  for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
    iVar5 = sub_08000470(iVar4);
    if (iVar5 == 0) goto code_r0x0804d790;
    iVar4 = iVar4 + 0x28;
  }
code_r0x0804d7c0:
  while (iVar4 = sub_0805F184(), iVar4 != 0) {
    sub_080003F0();
  }
  while (iVar4 = sub_0805EF90(), iVar4 != 0) {
    sub_080003F0();
  }
  uVar6 = sub_0805DF38(1,0xf,2,0,0x2d,_UNK_0804d7f0);
  while (iVar4 = sub_0805EEFC(uVar6), iVar4 == 0) {
    sub_080003F0();
  }
  while (iVar4 = sub_0805F184(), iVar4 != 0) {
    sub_080003F0();
  }
  while (iVar4 = sub_0805EF90(), iVar4 != 0) {
    sub_080003F0();
  }
  uVar6 = sub_0805DF38(1,0xf,2,0,0x2d,_UNK_0804d864);
  sub_0805D37C(0xe800,0x8c00,6);
  sub_080687A8();
  uStack_3c = 1;
  uStack_3a = 0x1a;
  uVar7 = 0;
  do {
    puStack_24[uVar7] = 0;
    uVar7 = uVar7 + 1;
  } while (uVar7 < 0xc);
  while (iVar4 = sub_08067B9C(0xe800,0x8c00,&uStack_3c), iVar4 == 0) {
    sub_080003F0();
  }
  while (iVar4 = sub_0805EEFC(uVar6), uVar3 = _UNK_0804d89c, iVar4 == 0) {
    sub_080003F0();
  }
  iVar4 = *_UNK_0804d8a0 + _UNK_0804d8a4;
  for (uVar7 = 0; uVar7 < 0x1e; uVar7 = uVar7 + 1) {
    iVar5 = sub_08000470(iVar4);
    if (iVar5 == 0) goto code_r0x0804d8c0;
    iVar4 = iVar4 + 0x28;
  }
code_r0x0804d8f0:
  while (iVar4 = sub_0805F184(), iVar4 != 0) {
    sub_080003F0();
  }
  while (iVar4 = sub_0805EF90(), iVar4 != 0) {
    sub_080003F0();
  }
  uVar6 = sub_0805DF38(1,0xf,2,0,0x2d,_UNK_0804d920);
  while (iVar4 = sub_0805EEFC(uVar6), iVar4 == 0) {
    sub_080003F0();
  }
  sub_0805D37C(0xe800,0x8c00,6);
  sub_080687A8();
  return in_lr;
}


