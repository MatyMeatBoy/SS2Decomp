
undefined4 sub_08067AD0(void)

{
  return 1;
}


