
uint sub_0800CC98(void)

{
  return *(uint *)DWORD_0800cca4 >> 2 & 1;
}


