
undefined4 sub_0805EFBC(void)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  undefined4 in_lr;
  
  iVar3 = *(int *)DWORD_0805efe0;
  uVar2 = 0;
  do {
    if (((int)(uint)*(byte *)DWORD_0805efe4 >> uVar2 & 1U) != 0) {
      while( true ) {
        iVar1 = sub_0805EE6C(iVar3 + uVar2 * 0x88);
        if (iVar1 != 0) break;
        sub_080003F0();
      }
      while (iVar1 = sub_0805EEFC(iVar3 + uVar2 * 0x88), iVar1 == 0) {
        sub_080003F0();
      }
    }
    uVar2 = uVar2 + 1 & 0xff;
  } while (uVar2 < 4);
  return in_lr;
}


