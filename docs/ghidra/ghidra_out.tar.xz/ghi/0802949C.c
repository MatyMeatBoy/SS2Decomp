
undefined4 sub_0802949C(uint param_1,uint param_2)

{
  byte bVar1;
  ushort uVar2;
  short sVar3;
  short sVar4;
  int iVar5;
  uint *puVar6;
  dword dVar7;
  uint uVar8;
  uint uVar9;
  ushort uVar10;
  int unaff_r9;
  int unaff_r10;
  undefined4 in_lr;
  uint *puStack_2c;
  uint uStack_28;
  uint uStack_24;
  
  if (param_1 < 0x100001) {
    if (param_1 == 0) {
      iVar5 = sub_080020F4();
      unaff_r10 = iVar5 * 0x14c + DWORD_08029578;
      uStack_28 = *(uint *)(unaff_r10 + 0x8c);
      uStack_24 = *(uint *)(unaff_r10 + 0x90);
    }
    else {
      if (4 < param_1 - 1) {
        return in_lr;
      }
      unaff_r9 = *(int *)DWORD_08029520 + (param_1 - 1) * 0x2e0;
      uStack_28 = *(uint *)(unaff_r9 + 0x14);
      uStack_24 = *(uint *)(unaff_r9 + 0x18);
    }
  }
  else {
    puStack_2c = (uint *)(*(int *)DWORD_080294e8 + DWORD_080294ec);
    uVar8 = 0;
    do {
      if (*puStack_2c == param_1) goto LAB_080294d4;
      uVar8 = uVar8 + 1;
      puStack_2c = puStack_2c + 0x1c;
    } while (uVar8 < 0xf);
    sub_080003F0();
    puStack_2c = (uint *)0x0;
LAB_080294d4:
    if (puStack_2c == (uint *)0x0) {
      return in_lr;
    }
    uStack_28 = puStack_2c[2];
    uStack_24 = puStack_2c[3];
  }
  if (param_2 < 0x100001) {
    if (param_2 == 0) {
      iVar5 = sub_080020F4();
      iVar5 = iVar5 * 0x14c + DWORD_080295d0;
      uVar8 = *(uint *)(iVar5 + 0x8c);
      uVar9 = *(uint *)(iVar5 + 0x90);
    }
    else {
      if (4 < param_2 - 1) {
        return in_lr;
      }
      iVar5 = *(int *)DWORD_080295a8 + (param_2 - 1) * 0x2e0;
      uVar8 = *(uint *)(iVar5 + 0x14);
      uVar9 = *(uint *)(iVar5 + 0x18);
    }
  }
  else {
    puVar6 = (uint *)(*(int *)DWORD_0802957c + DWORD_08029580);
    uVar8 = 0;
    do {
      if (*puVar6 == param_2) goto LAB_0802956a;
      uVar8 = uVar8 + 1;
      puVar6 = puVar6 + 0x1c;
    } while (uVar8 < 0xf);
    sub_080003F0();
    puVar6 = (uint *)0x0;
LAB_0802956a:
    if (puVar6 == (uint *)0x0) {
      return in_lr;
    }
    uVar8 = puVar6[2];
    uVar9 = puVar6[3];
  }
  if (param_1 < 0x100001) {
    if (param_1 == 0) {
      *(undefined2 *)(unaff_r10 + 0x1e) = *(undefined2 *)(unaff_r10 + 0x1c);
    }
    else {
      *(undefined2 *)(unaff_r9 + 10) = *(undefined2 *)(unaff_r9 + 8);
    }
  }
  else {
    *(short *)((int)puStack_2c + 0x26) = (short)puStack_2c[9];
  }
  iVar5 = ArcTan2((int)((uVar8 - uStack_28) * 0x100) >> 0x10,
                  (int)((uVar9 - uStack_24) * 0x100) >> 0x10);
  bVar1 = *(byte *)((iVar5 * 0x10000 + 0x8000000U >> 0x1c) + DWORD_08029618);
  uVar10 = (ushort)bVar1;
  if (param_1 < 0x100001) {
    if (param_1 == 0) {
      sVar3 = *(short *)(unaff_r10 + 0x1c);
    }
    else {
      sVar3 = *(short *)(unaff_r9 + 8);
    }
  }
  else {
    sVar3 = (short)puStack_2c[9];
  }
  iVar5 = (int)(short)(sVar3 - (ushort)bVar1);
  if (iVar5 < 0) {
    dVar7 = DWORD_0802967c;
    if (iVar5 == -4 || -iVar5 < 4) {
      dVar7 = 1;
    }
  }
  else {
    dVar7 = 1;
    if (iVar5 < 5) {
      dVar7 = DWORD_08029644;
    }
  }
  sVar3 = (short)dVar7;
  if (param_1 < 0x100001) {
    if (param_1 == 0) {
      uVar8 = (uint)*(ushort *)(unaff_r10 + 0x1c);
      uVar2 = *(ushort *)(unaff_r10 + 0x1c);
      while (uVar2 != uVar10) {
        sub_080290E4(0,(int)(short)uVar8);
        sVar4 = 2;
        do {
          sub_080003F0();
          iVar5 = sub_080021A8();
          if (iVar5 != 0) break;
          sVar4 = sVar4 + -1;
        } while (sVar4 != 0);
        uVar9 = (int)(short)uVar8 + (int)sVar3;
        uVar8 = uVar9 & 0xffff;
        iVar5 = (int)(uVar9 * 0x10000) >> 0x10;
        if (iVar5 < 8) {
          if (iVar5 < 0) {
            uVar8 = 7;
          }
        }
        else {
          uVar8 = 0;
        }
        uVar2 = *(ushort *)(unaff_r10 + 0x1c);
      }
    }
    else {
      uVar8 = (uint)*(ushort *)(unaff_r9 + 8);
      uVar2 = *(ushort *)(unaff_r9 + 8);
      while (uVar2 != uVar10) {
        sub_080290E4(param_1,(int)(short)uVar8);
        sVar4 = 2;
        do {
          sub_080003F0();
          iVar5 = sub_080021A8();
          if (iVar5 != 0) break;
          sVar4 = sVar4 + -1;
        } while (sVar4 != 0);
        uVar9 = (int)(short)uVar8 + (int)sVar3;
        uVar8 = uVar9 & 0xffff;
        iVar5 = (int)(uVar9 * 0x10000) >> 0x10;
        if (iVar5 < 8) {
          if (iVar5 < 0) {
            uVar8 = 7;
          }
        }
        else {
          uVar8 = 0;
        }
        uVar2 = *(ushort *)(unaff_r9 + 8);
      }
    }
  }
  else {
    uVar8 = (uint)(ushort)puStack_2c[9];
    uVar2 = (ushort)puStack_2c[9];
    while (uVar2 != uVar10) {
      sub_080290E4(param_1,(int)(short)uVar8);
      sVar4 = 2;
      do {
        sub_080003F0();
        iVar5 = sub_080021A8();
        if (iVar5 != 0) break;
        sVar4 = sVar4 + -1;
      } while (sVar4 != 0);
      uVar9 = (int)(short)uVar8 + (int)sVar3;
      uVar8 = uVar9 & 0xffff;
      iVar5 = (int)(uVar9 * 0x10000) >> 0x10;
      if (iVar5 < 8) {
        if (iVar5 < 0) {
          uVar8 = 7;
        }
      }
      else {
        uVar8 = 0;
      }
      uVar2 = (ushort)puStack_2c[9];
    }
  }
  return in_lr;
}


