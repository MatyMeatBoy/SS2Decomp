
void sub_080A4CFC(undefined1 param_1)

{
  *(undefined1 *)DWORD_080a4d04 = param_1;
  return;
}


