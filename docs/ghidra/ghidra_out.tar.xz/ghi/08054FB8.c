
undefined4 sub_08054FB8(void)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  dVar1 = DWORD_08054fc8;
  iVar3 = *(int *)DWORD_08054fcc + DWORD_08054fd0;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08054fec;
    iVar3 = iVar3 + 0x28;
  }
LAB_08055016:
  dVar1 = DWORD_08055024;
  iVar3 = *(int *)DWORD_08055028 + DWORD_0805502c;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08055048;
    iVar3 = iVar3 + 0x28;
  }
LAB_08055072:
  dVar1 = DWORD_08055080;
  iVar3 = *(int *)DWORD_08055084 + DWORD_08055088;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_080550a4;
    iVar3 = iVar3 + 0x28;
  }
LAB_080550ce:
  dVar1 = DWORD_080550dc;
  iVar3 = *(int *)DWORD_080550e0 + DWORD_080550e4;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08055100;
    iVar3 = iVar3 + 0x28;
  }
LAB_0805512a:
  iVar3 = sub_0800CC98();
  if (iVar3 == 0) {
    iVar3 = sub_0801AB24();
    if (iVar3 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar3 < 2) {
      if (iVar3 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar3 == 2) {
      sub_0801AB90(6);
    }
    while (iVar3 = sub_0801AAE0(), iVar3 == 0) {
      sub_080003F0();
    }
  }
  return in_lr;
LAB_08054fec:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x25);
  goto LAB_08055016;
LAB_08055048:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x26);
  goto LAB_08055072;
LAB_080550a4:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x27);
  goto LAB_080550ce;
LAB_08055100:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x28);
  goto LAB_0805512a;
}


