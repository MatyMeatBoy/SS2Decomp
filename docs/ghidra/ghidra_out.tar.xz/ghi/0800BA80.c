
void sub_0800BA80(uint param_1)

{
  undefined2 *puVar1;
  
  puVar1 = (undefined2 *)((param_1 & 0xffff) * 0x18 + DWORD_0800baa0);
  if (*(int *)(puVar1 + 6) != 0) {
    puVar1[9] = 0;
    puVar1[8] = 0;
    puVar1[1] = 0;
    *puVar1 = 0;
  }
  return;
}


