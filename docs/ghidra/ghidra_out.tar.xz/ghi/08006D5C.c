
undefined4 sub_08006D5C(uint param_1)

{
  undefined4 in_lr;
  
  if ((param_1 & 0xffff) <= DWORD_08006d74) {
    m4aSongNumStop(param_1 & 0xffff);
  }
  return in_lr;
}


