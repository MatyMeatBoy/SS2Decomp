
undefined4 sub_08065BD0(int param_1,int param_2)

{
  int iVar1;
  ushort *puVar2;
  int iVar3;
  int iVar4;
  undefined4 in_lr;
  short sStack_18;
  short sStack_16;
  
  iVar4 = param_1 * 0x14c + DWORD_08065c4c;
  param_2 = param_2 + -1;
  if (param_2 != -1) {
    iVar3 = iVar4 + 2;
    do {
      iVar1 = sub_0800CC98();
      if (iVar1 == 0) {
        puVar2 = *(ushort **)(iVar4 + 0x148);
        sub_0800BC08(*puVar2 >> 4,puVar2[1] & 0xfff,&sStack_18,&sStack_16,0x30,1);
        iVar1 = sub_0801A638(iVar3);
        sub_0801A764(iVar3,(int)sStack_18 + iVar1 * -4,sStack_16 + -0x30);
      }
      sub_080003F0();
      param_2 = param_2 + -1;
    } while (param_2 != -1);
  }
  return in_lr;
}


