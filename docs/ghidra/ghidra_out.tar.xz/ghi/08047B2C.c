
undefined4 sub_08047B2C(int param_1)

{
  short sVar1;
  short sVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 in_lr;
  undefined1 auStack_28 [4];
  undefined1 auStack_24 [4];
  
  if (param_1 == 2) {
    if ((*(uint *)DWORD_0804809c & 0x20) == 0) {
      sub_08006D08(0x45);
    }
    sub_08019EB8(*(undefined2 *)(*(int *)DWORD_080480a0 + 2),3);
    sub_0802949C(1,0);
  }
  else if (param_1 < 3) {
    if (param_1 == 0) {
      sVar2 = 0x1e;
      do {
        sub_080003F0();
        iVar3 = sub_080021A8();
        if (iVar3 != 0) break;
        sVar2 = sVar2 + -1;
      } while (sVar2 != 0);
      sub_08028AAC(1,0x40,0xb0,0x1e);
      sVar2 = 0x1e;
      do {
        sub_080003F0();
        iVar3 = sub_080021A8();
        if (iVar3 != 0) break;
        sVar2 = sVar2 + -1;
      } while (sVar2 != 0);
      while (iVar3 = sub_0805F184(), iVar3 != 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805EF90(), iVar3 != 0) {
        sub_080003F0();
      }
      uVar4 = sub_0805DF38(1,0xf,2,0,0x2d,0x140000);
      while (iVar3 = sub_0805EEFC(uVar4), iVar3 == 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805F184(), iVar3 != 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805EF90(), iVar3 != 0) {
        sub_080003F0();
      }
      uVar4 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_08047c28);
      sub_08028D98(2,0,0xfffffffd,3);
      sub_08028D98(2,0,3,3);
      while (iVar3 = sub_0805EEFC(uVar4), iVar3 == 0) {
        sub_080003F0();
      }
      sVar2 = *(short *)(DWORD_08047cac + 0x80);
      sVar1 = *(short *)(DWORD_08047cac + 0x82);
      iVar3 = 0;
      do {
        sub_080659F4(auStack_28,(int)sVar2,0,iVar3);
        sub_080659F4(auStack_24,(int)sVar1,0,iVar3);
        sub_0800BB80((int)auStack_28._0_2_,(int)auStack_24._0_2_);
        sub_080003F0();
        iVar3 = iVar3 + 0x22;
      } while (iVar3 < 0x401);
      iVar3 = sub_080020F4();
      iVar3 = iVar3 * 0x14c + DWORD_08047cb0;
      *(uint *)(iVar3 + 0x30) = *(uint *)(iVar3 + 0x30) & 0xfffffffe;
      sub_0800D108();
      while (iVar3 = sub_0805F184(), iVar3 != 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805EF90(), iVar3 != 0) {
        sub_080003F0();
      }
      uVar4 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_08047d00);
      sub_08028D98(1,0,0xfffffffd,3);
      sub_08028D98(1,0,3,3);
      while (iVar3 = sub_0805EEFC(uVar4), iVar3 == 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805F184(), iVar3 != 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805EF90(), iVar3 != 0) {
        sub_080003F0();
      }
      uVar4 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_08047d60);
      sub_08028D98(2,0,0xfffffffd,3);
      sub_08028D98(2,0,3,3);
      while (iVar3 = sub_0805EEFC(uVar4), iVar3 == 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805F184(), iVar3 != 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805EF90(), iVar3 != 0) {
        sub_080003F0();
      }
      uVar4 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_08047dc0);
      sub_08028D98(1,0,0xfffffffd,3);
      sub_08028D98(1,0,3,3);
      while (iVar3 = sub_0805EEFC(uVar4), iVar3 == 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805F184(), iVar3 != 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805EF90(), iVar3 != 0) {
        sub_080003F0();
      }
      uVar4 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_08047e20);
      sub_08028D98(2,0,0xfffffffd,3);
      sub_08028D98(2,0,3,3);
      while (iVar3 = sub_0805EEFC(uVar4), iVar3 == 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805F184(), iVar3 != 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805EF90(), iVar3 != 0) {
        sub_080003F0();
      }
      uVar4 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_08047e80);
      sub_08028D98(1,0,0xfffffffd,3);
      sub_08028D98(1,0,3,3);
      while (iVar3 = sub_0805EEFC(uVar4), iVar3 == 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805F184(), iVar3 != 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805EF90(), iVar3 != 0) {
        sub_080003F0();
      }
      uVar4 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_08047ee0);
      sub_08028D98(2,0,0xfffffffd,3);
      sub_08028D98(2,0,3,3);
      while (iVar3 = sub_0805EEFC(uVar4), iVar3 == 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805F184(), iVar3 != 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805EF90(), iVar3 != 0) {
        sub_080003F0();
      }
      uVar4 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_08047f40);
      sub_08028D98(1,0,0xfffffffd,3);
      sub_08028D98(1,0,3,3);
      while (iVar3 = sub_0805EEFC(uVar4), iVar3 == 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805F184(), iVar3 != 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805EF90(), iVar3 != 0) {
        sub_080003F0();
      }
      uVar4 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_08047fa0);
      sub_08028D98(2,0,0xfffffffd,3);
      sub_08028D98(2,0,3,3);
      while (iVar3 = sub_0805EEFC(uVar4), iVar3 == 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805F184(), iVar3 != 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805EF90(), iVar3 != 0) {
        sub_080003F0();
      }
      uVar4 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_08048000);
      sub_08028D98(1,0,0xfffffffd,3);
      sub_08028D98(1,0,3,3);
      while (iVar3 = sub_0805EEFC(uVar4), iVar3 == 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805F184(), iVar3 != 0) {
        sub_080003F0();
      }
      while (iVar3 = sub_0805EF90(), iVar3 != 0) {
        sub_080003F0();
      }
      uVar4 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_08048060);
      sub_08028D98(2,0,0xfffffffd,3);
      sub_08028D98(2,0,3,3);
      while (iVar3 = sub_0805EEFC(uVar4), iVar3 == 0) {
        sub_080003F0();
      }
    }
  }
  else if (param_1 == 3) {
    if ((*(uint *)DWORD_080480e0 & 0x20) == 0) {
      sub_08006D08(0x45);
    }
    sub_08019EB8(*(undefined2 *)(*(int *)DWORD_080480e4 + 0x2e2),3);
    sub_0802949C(2,0);
  }
  return in_lr;
}


