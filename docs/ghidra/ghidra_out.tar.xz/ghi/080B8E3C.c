
undefined8 VerifyEraseSector_Core(char *param_1)

{
  char cVar1;
  int iVar2;
  undefined4 in_lr;
  
  iVar2 = *(int *)(*(int *)DWORD_080b8e48 + 4);
  while ((iVar2 != 0 && (cVar1 = *param_1, param_1 = param_1 + 1, cVar1 == -1))) {
    iVar2 = iVar2 + -1;
  }
  return CONCAT44(in_lr,iVar2);
}


