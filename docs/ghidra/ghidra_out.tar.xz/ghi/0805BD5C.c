
undefined8 sub_0805BD5C(short *param_1,int param_2)

{
  short sVar1;
  ushort uVar2;
  int iVar3;
  int iVar4;
  ushort *puVar5;
  undefined4 uVar6;
  short *psVar7;
  short sVar8;
  undefined2 *puVar9;
  ushort *puVar10;
  undefined4 in_lr;
  
  iVar3 = sub_080020F4();
  puVar9 = (undefined2 *)(iVar3 * 0x14c + DWORD_0805be20);
  if ((((param_1 != (short *)0x0) && (iVar3 = sub_0800CDF8(), iVar3 == 0)) && (puVar9[0x10] != 0xb))
     && (((*(uint *)(puVar9 + 0x18) & 0x2000) == 0 && (*param_1 == 1)))) {
    iVar3 = sub_08007290((ushort)param_1[1] | 0x100000);
    sVar1 = *(short *)(iVar3 + 0xa0);
    if ((sVar1 == 1) || (sVar1 == 0x13)) {
      iVar4 = __divsi3((param_2 * 0x28 + 100) * (uint)*(ushort *)(iVar3 + 0xa2),100);
      puVar5 = puVar9 + 0x62;
      psVar7 = puVar9 + 0x31;
      uVar2 = *puVar5;
      if ((short)*puVar5 < *psVar7) {
        *puVar5 = (ushort)((uint)uVar2 + iVar4);
        sVar8 = *psVar7;
        iVar4 = (int)(((uint)uVar2 + iVar4) * 0x10000) >> 0x10;
        if (*psVar7 < iVar4) {
LAB_0805c19c:
          puVar9[0x62] = sVar8;
        }
        else {
joined_r0x0805be18:
          if (iVar4 < 0) {
            puVar9[0x62] = 0;
          }
        }
        if (*(short *)(iVar3 + 0xa2) != 0) {
          sub_08074DE8(*puVar9,8);
        }
        if (((*(uint *)(puVar9 + 0x18) & 0x20000) != 0) &&
           ((int)((uint)(ushort)puVar9[0x31] << 0x10) >> 0x11 <= (int)(short)puVar9[0x62])) {
          *(uint *)(puVar9 + 0x18) = *(uint *)(puVar9 + 0x18) & DWORD_0805c1e0;
        }
LAB_0805c1d8:
        sub_0805865C(0x91);
        goto LAB_0805c1ec;
      }
    }
    else {
      if (sVar1 != 2) {
        if (sVar1 == 6) {
          iVar3 = *(int *)DWORD_0805bea4;
          if ((int)DWORD_0805bea8 < (int)*(short *)(iVar3 + 0x10)) goto LAB_0805c1e4;
          *(short *)(iVar3 + 0x10) = *(short *)(iVar3 + 0x10) + 1;
LAB_0805c1ec:
          if (sVar1 != 1) {
            sub_0805865C(0x20);
          }
        }
        else {
          if (sVar1 == 7) {
            iVar3 = *(int *)DWORD_0805becc;
            if ((int)DWORD_0805bed0 < (int)*(short *)(iVar3 + 0x12)) goto LAB_0805c1e4;
            *(short *)(iVar3 + 0x12) = *(short *)(iVar3 + 0x12) + 1;
            goto LAB_0805c1ec;
          }
          if (sVar1 == 9) {
            iVar3 = *(int *)DWORD_0805bef4;
            if (0x14c < *(short *)(iVar3 + 0x16)) goto LAB_0805c1e4;
            *(short *)(iVar3 + 0x16) = *(short *)(iVar3 + 0x16) + 1;
            goto LAB_0805c1ec;
          }
          if (sVar1 == 8) {
            iVar3 = *(int *)DWORD_0805bf18;
            if ((int)DWORD_0805bf1c < (int)*(short *)(iVar3 + 0x14)) goto LAB_0805c1e4;
            *(short *)(iVar3 + 0x14) = *(short *)(iVar3 + 0x14) + 1;
            goto LAB_0805c1ec;
          }
          if (sVar1 == 3) {
            iVar3 = sub_0801E1D8(puVar9,6,100);
            if (iVar3 == 0) {
              iVar3 = sub_0801E1D8(puVar9,7,100);
              if (iVar3 == 0) goto LAB_0805c1e4;
              sub_0801DB94(*puVar9,iVar3,0);
              sub_0805867C(0x73);
            }
            else {
              sub_0801DB94(*puVar9,iVar3,0);
              sub_0805867C(0x73);
              iVar3 = sub_0801E1D8(puVar9,7,100);
              if (iVar3 != 0) {
                sub_0801DB94(*puVar9,iVar3,0);
              }
            }
            goto LAB_0805c1ec;
          }
          if ((sVar1 == 5) || (sVar1 == 0xc)) goto LAB_0805c1e4;
          if (sVar1 == 4) {
            if ((((((*(char *)(puVar9 + 0x34) != '\0') && (iVar3 = sub_08058DB0(), iVar3 == 0)) &&
                  (iVar3 = sub_0800D11C(), iVar3 == 0)) &&
                 ((iVar3 = sub_0800CCCC(), iVar3 == 0 && (puVar9[0x10] != 5)))) &&
                (((((iVar3 = sub_0800CDC0(), iVar3 == 0 &&
                    (((ushort)puVar9[0x32] < 10 &&
                     (sVar8 = *(short *)(DWORD_0805c064 + 0x8c), sVar8 != 0xb)))) && (sVar8 != 0xe))
                  && ((((sVar8 != 2 || (*(short *)(DWORD_0805c064 + 0x90) != 7)) &&
                       ((sVar8 != 5 || (*(short *)(DWORD_0805c064 + 0x90) != 10)))) &&
                      ((sVar8 != 8 || (*(short *)(DWORD_0805c064 + 0x90) != 0x11)))))) &&
                 ((sVar8 != 0x13 || (*(short *)(DWORD_0805c064 + 0x90) != 2)))))) &&
               ((sVar8 != 0x15 ||
                ((*(short *)(DWORD_0805c064 + 0x90) != 2 && (*(short *)(DWORD_0805c064 + 0x90) != 4)
                 ))))) {
              sub_0805865C(0x75);
              puVar9[0x10] = 0xc;
              puVar9[0x11] = 1;
              sub_08015C14();
              goto LAB_0805c1ec;
            }
            goto LAB_0805c1e4;
          }
          if (sVar1 != 10) {
            if (sVar1 == 0xb) {
              iVar3 = sub_0800D1B0();
              if ((iVar3 == 0) &&
                 (((iVar3 = sub_0801E1D8(puVar9,6,100), iVar3 != 0 ||
                   (iVar3 = sub_0801E1D8(puVar9,7,100), iVar3 != 0)) ||
                  (iVar3 = sub_0801E164(puVar9,0), iVar3 != 0)))) {
                sub_0801DB94(*puVar9,iVar3,7);
                *(int *)(iVar3 + 0x18) = param_2;
                sub_0805865C(0x73);
                goto LAB_0805c1ec;
              }
            }
            else if ((sVar1 != 0xd) && (sVar1 != 0xe)) {
              if (sVar1 == 0x10) {
                sub_080665B0(*(undefined2 *)(iVar3 + 0xa2));
                goto LAB_0805c12a;
              }
              if (sVar1 == 0x11) {
                puVar9[0x61] = puVar9[0x30];
                puVar9[0x62] = puVar9[0x31];
                goto LAB_0805c1ec;
              }
              if (sVar1 == 0x12) {
                iVar4 = __divsi3((param_2 * 0x28 + 100) * (uint)*(ushort *)(iVar3 + 0xa2),100);
                puVar5 = puVar9 + 0x62;
                psVar7 = puVar9 + 0x31;
                uVar2 = *puVar5;
                if ((short)*puVar5 < *psVar7) {
                  *puVar5 = (ushort)((uint)uVar2 + iVar4);
                  sVar8 = *psVar7;
                  iVar4 = (int)(((uint)uVar2 + iVar4) * 0x10000) >> 0x10;
                  if (*psVar7 < iVar4) goto LAB_0805c19c;
                  goto joined_r0x0805be18;
                }
              }
            }
            goto LAB_0805c1e4;
          }
          iVar3 = sub_0800D1B0();
          if ((iVar3 != 0) ||
             (((iVar3 = sub_0801E1D8(puVar9,6,100), iVar3 == 0 &&
               (iVar3 = sub_0801E1D8(puVar9,7,100), iVar3 == 0)) &&
              (iVar3 = sub_0801E164(puVar9,0), iVar3 == 0)))) goto LAB_0805c1e4;
          sub_0801DB94(*puVar9,iVar3,6);
          *(int *)(iVar3 + 0x18) = param_2;
          sub_0805865C(0x73);
        }
        uVar6 = 1;
        goto LAB_0805c1fa;
      }
      puVar10 = puVar9 + 0x61;
      puVar5 = puVar9 + 0x30;
      uVar2 = *puVar10;
      if ((short)*puVar10 < (short)*puVar5) {
        iVar3 = __divsi3((param_2 * 0x28 + 100) * (uint)*(ushort *)(iVar3 + 0xa2),100);
        iVar3 = iVar3 * 10 + (uint)uVar2;
        *puVar10 = (ushort)iVar3;
        iVar3 = iVar3 * 0x10000 >> 0x10;
        if ((short)*puVar5 < iVar3) {
          *puVar10 = *puVar5;
        }
        else if (iVar3 < 0) {
          *puVar10 = 0;
        }
        goto LAB_0805c1d8;
      }
    }
LAB_0805c1e4:
    sub_0805865C(0x61);
  }
LAB_0805c12a:
  uVar6 = 0;
LAB_0805c1fa:
  return CONCAT44(in_lr,uVar6);
}


