
bool sub_08067E48(void)

{
  return *(int *)(*(int *)DWORD_08067e5c + 4) == 2;
}


