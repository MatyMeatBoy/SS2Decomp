
undefined4 sub_080010DC(void)

{
  undefined4 in_lr;
  
  if (*(int *)DWORD_080010fc != 0) {
    _call_via_r0();
  }
  *(undefined2 *)DWORD_08001100 = 2;
  *(ushort *)DWORD_08001104 = *(ushort *)DWORD_08001104 | 2;
  return in_lr;
}


