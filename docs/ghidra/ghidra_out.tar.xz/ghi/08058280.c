
undefined4 sub_08058280(void)

{
  dword dVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_lr;
  
  dVar1 = DWORD_080582bc;
  iVar2 = *(int *)DWORD_080582b8;
  uVar3 = 0;
  do {
    if (((*(uint *)dVar1 & 1 << (uVar3 & 0xff)) != 0) && (*(short *)(iVar2 + 0xc) == 0xc)) {
      *(undefined2 *)(iVar2 + 0xc) = 0;
    }
    uVar3 = uVar3 + 1;
    iVar2 = iVar2 + 0x2e0;
  } while (uVar3 < 5);
  sub_08019F04();
  return in_lr;
}


