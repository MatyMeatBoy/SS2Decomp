
undefined4 sub_08095518(undefined4 param_1,char param_2)

{
  undefined4 in_lr;
  uint uStack_c;
  
  sub_08000A34(1,0,0,0,0);
  sub_080009F8(0xf00,0,0);
  sub_08000990(2,0);
  if (param_2 == '\x01') {
    sub_080009C0(0x1400,0x8000,0);
  }
  else {
    sub_080009C0(0x1400,0,0);
  }
  uStack_c = uStack_c & DWORD_080955c4 | DWORD_080955c8;
  sub_08000AA8(2,&uStack_c);
  sub_080921E4(5,0x1c);
  sub_080955CC();
  sub_080955EC(0,0);
  sub_080955F8(0xf8,0xf8);
  sub_08095604(0x200);
  sub_0800CBF8(1);
  sub_0800CC48(1);
  sub_08098010(1);
  sub_08000940();
  return in_lr;
}


