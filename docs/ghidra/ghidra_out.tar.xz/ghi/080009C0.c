
undefined4 sub_080009C0(ushort param_1,ushort param_2,short param_3)

{
  ushort uVar1;
  undefined4 in_lr;
  
  uVar1 = param_2 & 0xe000 | param_1 & 0x1f00 | *(ushort *)DWORD_080009f4;
  *(ushort *)DWORD_080009f4 = uVar1;
  if (param_3 != 0) {
    Ram04000000 = uVar1;
  }
  return in_lr;
}


