
undefined4 sub_0800B9F0(uint param_1,int param_2)

{
  int iVar1;
  undefined4 in_lr;
  uint uStack_10;
  
  iVar1 = sub_08007290();
  uStack_10 = param_1 & 0x40000000;
  if (uStack_10 == 0) {
    uStack_10 = sub_08000BC8(iVar1 + 4,&uStack_10);
  }
  else {
    uStack_10 = iVar1 + 4;
  }
  if ((*(byte *)DWORD_0800ba38 & 0x80) == 0) {
    sub_08001348(uStack_10,param_2 * 0x800 + 0x6000000,0x1000);
  }
  else {
    CpuFastSet(uStack_10,param_2 * 0x800 + 0x6000000,0x400);
  }
  if ((param_1 & 0x40000000) == 0) {
    sub_080003F0();
    sub_08001538(uStack_10);
  }
  return in_lr;
}


