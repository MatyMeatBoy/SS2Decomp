
undefined4 sub_0802A19C(void)

{
  undefined2 uVar1;
  undefined2 uVar2;
  int iVar3;
  undefined2 *puVar4;
  undefined2 *puVar5;
  undefined4 in_lr;
  
  sub_0800CE40();
  sub_0801ABE8(10);
  while (iVar3 = sub_0801AAE0(), iVar3 == 0) {
    sub_080003F0();
  }
  sub_0800BB54();
  sub_080003F0();
  sub_080003F0();
  sub_080003F0();
  sub_080003F0();
  sub_0800CCA8();
  puVar5 = (undefined2 *)(DWORD_0802a204 + 0x7c);
  uVar1 = *puVar5;
  puVar4 = (undefined2 *)(DWORD_0802a204 + 0x7e);
  uVar2 = *puVar4;
  sub_080867F8();
  sub_080003F4(DWORD_0802a208);
  *puVar5 = uVar1;
  *puVar4 = uVar2;
  sub_0800CCB8();
  sub_08000420(DWORD_0802a20c);
  sub_0800CE54();
  while (iVar3 = sub_0801AAE0(), iVar3 == 0) {
    sub_080003F0();
  }
  return in_lr;
}


