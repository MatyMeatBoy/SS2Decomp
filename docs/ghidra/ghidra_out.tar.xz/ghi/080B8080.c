
undefined4 m4aMPlayTempoControl(int param_1,ushort param_2)

{
  undefined4 in_lr;
  
  if (*(dword *)(param_1 + 0x34) == DWORD_080b80a4) {
    *(ushort *)(param_1 + 0x1e) = param_2;
    *(short *)(param_1 + 0x20) = (short)((uint)*(ushort *)(param_1 + 0x1c) * (uint)param_2 >> 8);
  }
  return in_lr;
}


