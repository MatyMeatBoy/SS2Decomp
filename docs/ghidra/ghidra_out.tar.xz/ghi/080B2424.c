
undefined4 sub_080B2424(void)

{
  dword dVar1;
  int iVar2;
  undefined4 in_lr;
  
  dVar1 = DWORD_080b2450;
  if (*(int *)DWORD_080b2450 != 0) {
    iVar2 = sub_08000470();
    if (iVar2 != 0) {
      sub_080003A8(*(undefined4 *)dVar1);
    }
    if (*(int *)dVar1 != 0) {
      sub_08001538();
      *(undefined4 *)dVar1 = 0;
    }
  }
  return in_lr;
}


