
void sub_08000EC8(void)

{
  *(undefined2 *)DWORD_08000ee4 = 0x2000;
  *(undefined2 *)DWORD_08000ee8 = 0;
  *(undefined4 *)DWORD_08000eec = 0;
  *(undefined4 *)DWORD_08000ef0 = 0;
  return;
}


