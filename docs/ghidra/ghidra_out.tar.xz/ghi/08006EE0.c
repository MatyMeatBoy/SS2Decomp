
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 sub_08006EE0(uint param_1,int param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  undefined4 in_lr;
  undefined8 uVar3;
  
  uVar2 = (param_1 << 4) >> 0x14;
  if (0x16 < uVar2) {
LAB_080070d8:
    param_3 = 0;
    goto LAB_08007158;
  }
  switch(uVar2) {
  default:
    param_3 = param_2 + *(int *)(param_2 + 8 + uVar2 * 4);
    break;
  case 7:
    param_3 = param_2 + *(int *)(param_2 + 0xc);
    break;
  case 8:
    param_3 = param_2 + *(int *)(param_2 + 0x20);
    break;
  case 9:
    param_3 = param_2 + *(int *)(param_2 + 0x14);
    break;
  case 10:
    goto LAB_080070d8;
  case 0xb:
    param_3 = (_UNK_08006f88 & param_1) * 0xc4 + _UNK_08006f8c;
    break;
  case 0xc:
    param_3 = (_UNK_08006fa0 & param_1) * 0xb8 + _UNK_08006fa4;
    break;
  case 0xd:
    param_3 = (_UNK_08006fb8 & param_1) * 0xb8 + _UNK_08006fbc;
    break;
  case 0xe:
    param_3 = (_UNK_08006fd0 & param_1) * 0xb8 + _UNK_08006fd4;
    break;
  case 0xf:
    param_3 = (_UNK_08006fe8 & param_1) * 0xb4 + _UNK_08006fec;
    break;
  case 0x10:
    param_3 = (_UNK_08007000 & param_1) * 0xac + _UNK_08007004;
    break;
  case 0x11:
    param_3 = (_UNK_08007018 & param_1) * 0xb0 + _UNK_0800701c;
    break;
  case 0x12:
    param_3 = (_UNK_08007030 & param_1) * 0xa4 + _UNK_08007034;
    break;
  case 0x13:
    param_3 = (_UNK_08007048 & param_1) * 0xb0 + _UNK_0800704c;
    break;
  case 0x14:
    if (*_UNK_08007064 < 5) {
                    /* WARNING: Could not recover jumptable at 0x08007060. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar3 = (**(code **)(*_UNK_08007064 * 4 + _UNK_08007068))();
      return uVar3;
    }
    break;
  case 0x15:
    param_3 = (_UNK_080070c8 & param_1) * 0xa8 + _UNK_080070cc;
    break;
  case 0x16:
    param_3 = _UNK_080070d4;
  }
  switch(uVar2) {
  case 0:
  case 2:
    param_1 = _UNK_0800711c & param_1;
    break;
  case 1:
  case 3:
  case 6:
    iVar1 = (_UNK_08007140 & param_1) << 3;
    goto code_r0x0800714e;
  case 4:
    param_1 = _UNK_08007134 & param_1;
    break;
  case 5:
    param_1 = _UNK_08007128 & param_1;
    break;
  case 7:
  case 8:
  case 9:
    param_1 = (_UNK_08007160 & param_1) * 2 + 1;
    break;
  default:
    goto LAB_08007158;
  }
  iVar1 = param_1 << 2;
code_r0x0800714e:
  param_3 = param_3 + *(int *)(param_3 + 4 + iVar1);
LAB_08007158:
  return CONCAT44(in_lr,param_3);
}


