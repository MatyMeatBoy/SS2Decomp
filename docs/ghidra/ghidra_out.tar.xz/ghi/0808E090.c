
undefined8 sub_0808E090(undefined4 param_1)

{
  dword dVar1;
  dword dVar2;
  int iVar3;
  undefined4 uVar4;
  uint *puVar5;
  undefined4 in_lr;
  
  dVar1 = DWORD_0808e100;
  if (*(short *)(*(int *)DWORD_0808e100 + 0x10) == 0) {
    sub_0800CD9C();
    sub_0802704C(param_1);
    sub_0801674C(DWORD_0808e128,DWORD_0808e12c);
  }
  else {
    iVar3 = sub_08056E90();
    if (iVar3 != 0) {
      sub_08056FB8(0,2);
      sub_0800CDAC();
      sub_08056E78();
      *(undefined2 *)(*(int *)dVar1 + 0x36) = 3;
      sub_0805D518();
      sub_08057BD0(*(undefined2 *)(DWORD_0808e104 + 0x8c));
      iVar3 = sub_080020F4();
      dVar2 = DWORD_0808e108;
      puVar5 = (uint *)(iVar3 * 0x14c + DWORD_0808e108 + 0x30);
      *puVar5 = *puVar5 & 0xfffffffd;
      iVar3 = sub_080020F4();
      *(undefined2 *)(iVar3 * 0x14c + dVar2 + 0x20) = 0;
      iVar3 = *(int *)dVar1;
      uVar4 = 1;
      *(undefined2 *)(iVar3 + 0x30) = 1;
      *(undefined2 *)(iVar3 + 0x24) = 1;
      goto LAB_0808e120;
    }
  }
  uVar4 = 0;
LAB_0808e120:
  return CONCAT44(in_lr,uVar4);
}


