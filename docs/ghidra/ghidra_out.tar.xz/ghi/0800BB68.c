
uint sub_0800BB68(void)

{
  uint uVar1;
  
  uVar1 = *(uint *)(DWORD_0800bb7c + 0x9c) & 0xc;
  if (uVar1 != 0) {
    uVar1 = 1;
  }
  return uVar1;
}


