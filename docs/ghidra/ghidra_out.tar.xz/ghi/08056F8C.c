
void sub_08056F8C(void)

{
  *(ushort *)(*(int *)DWORD_08056f9c + 4) =
       (ushort)DWORD_08056fa0 & *(ushort *)(*(int *)DWORD_08056f9c + 4);
  return;
}


