
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_08058CC4(undefined4 param_1)

{
  undefined4 in_lr;
  
  switch(param_1) {
  case 1:
  case 4:
  case 5:
  case 7:
  case 9:
    if ((*_UNK_08058d2c & 0x20) == 0) {
      sub_08006D08(0x13);
    }
    break;
  case 2:
    if ((*_UNK_08058d14 & 0x20) == 0) {
      sub_08006D08(0x14);
    }
    break;
  case 6:
  case 8:
    if ((*_UNK_08058d48 & 0x20) == 0) {
      sub_08006D08(0x1b);
    }
  }
  return in_lr;
}


