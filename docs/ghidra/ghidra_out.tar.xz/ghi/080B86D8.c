
undefined4 StartFlashTimer(uint param_1)

{
  dword dVar1;
  dword dVar2;
  dword dVar3;
  undefined2 *puVar4;
  undefined2 *puVar5;
  undefined4 in_lr;
  
  dVar1 = DWORD_080b8764;
  puVar4 = (undefined2 *)((param_1 & 0xff) * 6 + *(int *)DWORD_080b875c);
  *(undefined2 *)DWORD_080b8760 = *(undefined2 *)DWORD_080b8764;
  *(undefined2 *)dVar1 = 0;
  dVar2 = DWORD_080b8768;
  puVar5 = *(undefined2 **)DWORD_080b8768;
  puVar5[1] = 0;
  dVar3 = DWORD_080b8770;
  *(ushort *)DWORD_080b876c = *(ushort *)DWORD_080b876c | (ushort)(8 << *(sbyte *)DWORD_080b8770);
  *(undefined1 *)DWORD_080b8774 = 0;
  *(undefined2 *)DWORD_080b8778 = *puVar4;
  *puVar5 = puVar4[1];
  *(undefined2 **)dVar2 = puVar5 + 1;
  puVar5[1] = puVar4[2];
  *(undefined2 **)dVar2 = puVar5;
  *(short *)DWORD_080b877c = (short)(8 << *(sbyte *)dVar3);
  *(undefined2 *)dVar1 = 1;
  return in_lr;
}


