
undefined4 sub_0809975C(void)

{
  dword dVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  dVar1 = DWORD_08099784;
  uVar2 = sub_08001494(0xa00);
  *(undefined4 *)dVar1 = uVar2;
  uVar4 = 0;
  iVar3 = 0;
  do {
    *(undefined4 *)(iVar3 + *(int *)dVar1 + 8) = 0;
    iVar3 = iVar3 + 0x28;
    uVar4 = uVar4 + 1;
  } while (uVar4 < 0x40);
  return in_lr;
}


