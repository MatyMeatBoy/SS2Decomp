
undefined4 sub_080659F4(int *param_1,int param_2,int param_3,int param_4)

{
  undefined4 in_lr;
  
  if (param_2 == param_3) {
    *param_1 = param_2;
  }
  else {
    *param_1 = (param_4 * param_3 >> 10) + (param_2 * (0x400 - param_4) >> 10);
  }
  return in_lr;
}


