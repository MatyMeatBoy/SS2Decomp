
undefined4 sub_0805B688(uint param_1,uint param_2)

{
  ushort uVar1;
  short sVar2;
  undefined2 uVar3;
  dword dVar4;
  char cVar5;
  byte bVar6;
  undefined1 uVar7;
  int iVar8;
  uint uVar9;
  undefined4 uVar10;
  ushort *puVar11;
  uint uVar12;
  uint *puVar13;
  int iVar14;
  int *piVar15;
  uint *puVar16;
  uint uVar17;
  undefined4 in_lr;
  undefined4 auStack_bc [2];
  undefined4 uStack_b4;
  undefined1 auStack_a0 [24];
  undefined2 uStack_88;
  undefined2 uStack_86;
  short sStack_78;
  short sStack_76;
  int iStack_74;
  uint uStack_70;
  int iStack_6c;
  uint uStack_68;
  dword dStack_64;
  dword dStack_60;
  int iStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  undefined2 *puStack_4c;
  int iStack_48;
  uint uStack_44;
  int iStack_40;
  int iStack_3c;
  uint uStack_38;
  dword dStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  
  uStack_54 = param_1 & 0xffff;
  uStack_50 = param_2 & 0xffff;
  puStack_4c = (undefined2 *)(uStack_54 * 0x14c + DWORD_0805b7b8);
  uStack_24 = sub_080020F4();
  uStack_24 = uStack_24 & 0xffff;
  sub_08065158(auStack_bc,DWORD_0805b7bc,0,0x80000000,0);
  piVar15 = (int *)(puStack_4c + 0xa4);
  uVar1 = *(ushort *)(*piVar15 + 6);
  uStack_88 = 1;
  uStack_86 = (undefined2)uStack_50;
  iStack_48 = sub_08007290(uStack_50 | 0x100000);
  uStack_28 = (uint)*(byte *)(iStack_48 + 0xa8);
  puVar11 = (ushort *)*piVar15;
  iStack_5c = (uint)(*puVar11 >> 4) << 8;
  uStack_58 = ((uint)puVar11[1] << 0x14) >> 0xc;
  iStack_3c = 0x1000;
  sVar2 = *(short *)((uint)(*(byte *)((int)puVar11 + 3) >> 4) * 2 + DWORD_0805b7c0);
  if (((puStack_4c[0x10] != 0xd) && (iVar8 = sub_0800CCCC(), iVar8 == 0)) &&
     (iVar8 = sub_0800CD34(), iVar8 == 0)) {
    sub_0805865C(0x17);
  }
  dVar4 = DWORD_0805b7c8;
  uStack_2c = (uint)(*(byte *)(*(int *)(puStack_4c + 0xa4) + 3) >> 4);
  iStack_40 = (((uint)uVar1 << 0x17) >> 0x1b) * 4 + 8;
  uStack_38 = 0;
  dStack_34 = DWORD_0805b7c4;
  iVar14 = (int)sVar2;
  iVar8 = __divsi3(iStack_40 * *(short *)((iVar14 + 0x40) * 2 + DWORD_0805b7c8) * 2,10);
  iStack_5c = iStack_5c + iVar8;
  iVar8 = __divsi3(iStack_40 * *(short *)(iVar14 * 2 + dVar4) * 2,10);
  uStack_58 = uStack_58 + iVar8;
  cVar5 = sub_0801DE60();
  if (cVar5 == '\0') {
    uVar9 = sub_0801E0AC(*(int *)DWORD_0805b7cc + 0x30,5);
    uVar9 = uVar9 & 0xffff;
  }
  else {
    uVar9 = 0;
  }
  while ((int)uStack_38 < 2) {
    uStack_30 = 0;
    iVar8 = sub_08056E90();
    if (iVar8 != 0) {
      uStack_30 = 1;
      break;
    }
    iStack_74 = iStack_5c;
    uStack_70 = uStack_58;
    dStack_64 = DWORD_0805b800;
    dStack_60 = DWORD_0805b804;
    puVar13 = (uint *)(iStack_48 + 0xa4);
    iVar8 = 0;
    if ((*puVar13 & 1) != 0) {
      uVar17 = 0;
      while( true ) {
        uVar12 = sub_08002164();
        iVar8 = uStack_30 * 0x10000;
        if ((uVar12 <= uVar17) || (iVar8 != 0)) break;
        if (uVar17 != uStack_54) {
          piVar15 = (int *)(uVar17 * 0x14c + DWORD_0805b890 + 0x148);
          puVar11 = (ushort *)*piVar15;
          bVar6 = (byte)*puVar11 & 0xf;
          if (((bVar6 != 0xe) && (bVar6 != 0xc)) &&
             (((puVar11[2] & 0x20) == 0 &&
              (puVar16 = (uint *)(uVar17 * 0x14c + DWORD_0805b890 + 0x30), (*puVar16 & 0x400) == 0))
             )) {
            iStack_6c = (uint)(*puVar11 >> 4) << 8;
            uStack_68 = ((uint)*(ushort *)(*piVar15 + 2) << 0x14) >> 0xc;
            iVar8 = sub_08021FE0(&iStack_74,&iStack_6c,&dStack_64,&dStack_60);
            if (iVar8 != 0) {
              if (uStack_54 == uStack_24) {
                uVar1 = *(ushort *)(iStack_48 + 0xa0);
                if (uVar1 == 0xd) {
                  sub_0806818C(*puStack_4c,4,iStack_74,uStack_70,uVar9);
                }
                else if (uVar1 < 0xe) {
                  if (uVar1 == 5) {
                    if (*(short *)(DWORD_0805b8bc + 0x8c) != 0xb) {
                      if ((*puVar16 & 0x2000) == 0) {
                        sub_08067F4C(uStack_50,uVar17,uVar9);
                      }
                      else {
                        sub_08068144(uVar17);
                      }
                    }
                  }
                  else {
LAB_0805b908:
                    sub_08067F4C(uStack_50,uVar17,uVar9);
                  }
                }
                else if (uVar1 == 0xe) {
                  sub_0806818C(*puStack_4c,5,iStack_74,uStack_70,uVar9);
                }
                else {
                  if (uVar1 != 0xf) goto LAB_0805b908;
                  sub_0806823C(*puStack_4c,0,iStack_74,uStack_70,uVar9);
                }
                uStack_30 = 1;
              }
              else {
                uStack_30 = 1;
              }
            }
          }
        }
        uVar17 = uVar17 + 1 & 0xffff;
      }
    }
    if (iVar8 != 0) {
      return in_lr;
    }
    if ((*puVar13 & 0x3e) != 0) {
      uVar17 = 0;
      do {
        if ((((*(uint *)DWORD_0805b9e8 & 1 << (uVar17 & 0xff)) != 0) &&
            (iVar8 = *(int *)DWORD_0805b9ec + uVar17 * 0x2e0, *(short *)(iVar8 + 0xc) != 0xc)) &&
           ((*(char *)(iVar8 + 0x1dc) != '\0' || ((*puVar13 & 0x3c) != 0)))) {
          dStack_60 = (dword)CONCAT12(*(undefined1 *)(iVar8 + DWORD_0805b9f4),
                                      (ushort)*(byte *)(iVar8 + DWORD_0805b9f0));
          iVar14 = sub_08021FE0(&iStack_74,iVar8 + 0x14,&dStack_64);
          if (iVar14 != 0) {
            uVar12 = 0;
            if (*(short *)(iVar8 + 0xc) != 0xb) {
              uVar12 = *(uint *)(iVar8 + 0x54) ^ uStack_44;
              uVar12 = (-uVar12 | uVar12) >> 0x1f;
            }
            if (uVar12 != 0) {
              if (*(char *)(iVar8 + 0x1dc) == '\0') {
                bVar6 = *(byte *)(iVar8 + DWORD_0805b9f8);
                if (bVar6 == 5) {
                  if ((*puVar13 & 8) != 0) {
                    *(undefined2 *)(iVar8 + 0xc) = 0xc;
                    *(undefined2 *)(iVar8 + 0xe) = 8;
                    goto LAB_0805ba50;
                  }
                }
                else if (bVar6 < 6) {
                  if (bVar6 != 4) goto LAB_0805ba50;
                  if ((*puVar13 & 4) != 0) {
                    *(undefined2 *)(iVar8 + 0xc) = 0xc;
                    goto LAB_0805ba4c;
                  }
                }
                else if (bVar6 == 6) {
                  if ((*puVar13 & 0x10) != 0) {
                    *(undefined2 *)(iVar8 + 0xc) = 0xc;
LAB_0805ba4c:
                    *(undefined2 *)(iVar8 + 0xe) = 8;
                    goto LAB_0805ba50;
                  }
                }
                else if (bVar6 == 7) {
                  if ((*puVar13 & 0x20) != 0) {
                    *(undefined2 *)(iVar8 + 0xc) = 0xc;
                    goto LAB_0805ba4c;
                  }
                }
                else {
LAB_0805ba50:
                  if (*(short *)(iVar8 + 0xc) == 0xc) {
                    uStack_30 = uStack_30 * 0x10000 + 0x10000 >> 0x10;
                    break;
                  }
                }
              }
              else {
                uStack_30 = 1;
                uVar12 = sub_080020F4();
                if (uStack_54 == uVar12) {
                  uVar1 = *(ushort *)(iStack_48 + 0xa0);
                  if (uVar1 == 0xe) {
                    sub_0806818C(*puStack_4c,5,iStack_74,uStack_70,uVar9);
                  }
                  else if (uVar1 < 0xf) {
                    if (uVar1 == 0xd) {
                      uVar3 = *puStack_4c;
LAB_0805bac4:
                      sub_0806818C(uVar3,4,iStack_74,uStack_70,uVar9);
                    }
                    else {
LAB_0805bad4:
                      sub_08067F04(uStack_50,*(undefined2 *)(iVar8 + 2),uVar9);
                    }
                  }
                  else {
                    if (uVar1 != 0xf) {
                      if (uVar1 == 0x12) {
                        uVar3 = *puStack_4c;
                        goto LAB_0805bac4;
                      }
                      goto LAB_0805bad4;
                    }
                    sub_0806823C(*puStack_4c,0,iStack_74,uStack_70,uVar9);
                  }
                }
              }
            }
          }
        }
        uVar17 = uVar17 + 1 & 0xffff;
      } while (uVar17 < 5);
    }
    if ((short)uStack_30 != 0) {
      return in_lr;
    }
    if ((*(ushort *)(iStack_48 + 0xa0) < 0x10) && (0xc < *(ushort *)(iStack_48 + 0xa0))) {
      uVar10 = __divsi3(iStack_40 << 8,10);
      sub_08013E90(uVar10,&iStack_74,uStack_2c & 0xffff,4,0);
    }
    else {
      uVar10 = __divsi3(iStack_40 << 8,10);
      sub_08013E90(uVar10,&iStack_74,uStack_2c & 0xffff,0,0);
    }
    iStack_5c = iStack_74;
    uStack_58 = uStack_70;
    if (uVar9 != 0) {
      uVar9 = uVar9 - 1;
    }
    iStack_3c = iStack_3c - dStack_34;
    dStack_34 = dStack_34 + 0x40;
    if (iStack_3c < 0) {
      iStack_40 = iStack_40 >> 2;
      dStack_34 = -(0x100 >> (uStack_38 & 0xff));
      uStack_38 = uStack_38 + 1;
      iStack_3c = 0x100;
    }
    iVar8 = sub_0800CC98();
    if (((iVar8 == 0) && (iVar8 = sub_0800CD8C(), iVar8 == 0)) &&
       (iVar8 = sub_0800CCCC(), iVar8 == 0)) {
      sub_0800BC08((iStack_5c << 8) >> 0x10,(int)(uStack_58 << 8) >> 0x10,&sStack_78,&sStack_76,0x30
                   ,0);
      uVar7 = sub_0800BC44(iStack_5c >> 8,(int)uStack_58 >> 8,0);
      sub_08007870((int)sStack_78,(int)sStack_76 - (iStack_3c >> 8),0,uStack_28,uVar7,auStack_a0,
                   uStack_b4,auStack_bc[0]);
      sub_08007870((int)sStack_78,(int)sStack_76,0,0xfe,uVar7,auStack_a0,uStack_b4,auStack_bc[0]);
    }
    sub_080003F0();
  }
  if ((uStack_30 & 0xffff) != 0) {
    return in_lr;
  }
  if (uStack_54 != uStack_24) {
    return in_lr;
  }
  uVar1 = *(ushort *)(iStack_48 + 0xa0);
  if (uVar1 == 0xe) {
    uVar3 = *puStack_4c;
    uVar10 = 3;
LAB_0805bc6e:
    sub_0806818C(uVar3,uVar10,iStack_74,uStack_70,uVar9);
    iVar8 = 5;
  }
  else {
    if (uVar1 < 0xf) {
      if (uVar1 == 0xd) {
        uVar3 = *puStack_4c;
        uVar10 = 2;
        goto LAB_0805bc6e;
      }
    }
    else if (uVar1 == 0xf) {
      sub_0806823C(*puStack_4c,0,iStack_74,uStack_70,uVar9);
      iVar8 = 5;
      goto LAB_0805bc9c;
    }
    sub_08066520(iStack_5c,uStack_58,*(undefined2 *)(DWORD_0805bd58 + 0x90),&uStack_88);
    iVar8 = 0x1e;
  }
LAB_0805bc9c:
  sub_0805B4CC(&iStack_5c,&uStack_58);
  if (iVar8 != 0) {
    do {
      iVar8 = iVar8 + -1;
      iVar14 = sub_0800CC98();
      if (((iVar14 == 0) && (iVar14 = sub_0800CD8C(), iVar14 == 0)) &&
         (iVar14 = sub_0800CCCC(), iVar14 == 0)) {
        sub_0800BC08((iStack_5c << 8) >> 0x10,(int)(uStack_58 << 8) >> 0x10,&sStack_78,&sStack_76,
                     0x30,0);
        uVar7 = sub_0800BC44(iStack_5c >> 8,(int)uStack_58 >> 8,0);
        sub_08007870((int)sStack_78,(int)sStack_76,0,uStack_28,uVar7,auStack_a0,uStack_b4,
                     auStack_bc[0]);
        sub_08007870((int)sStack_78,(int)sStack_76,0,0xfe,uVar7,auStack_a0,uStack_b4,auStack_bc[0]);
      }
      sub_080003F0();
    } while (iVar8 != 0);
  }
  return in_lr;
}


