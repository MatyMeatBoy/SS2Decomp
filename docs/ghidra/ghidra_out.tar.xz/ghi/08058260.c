
undefined8 sub_08058260(void)

{
  int iVar1;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  return CONCAT44(in_lr,*(int *)(iVar1 * 0x14c + DWORD_0805827c + 0x90) >> 8);
}


