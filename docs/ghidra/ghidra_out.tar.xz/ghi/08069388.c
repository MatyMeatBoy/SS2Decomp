
undefined4 sub_08069388(int param_1,int param_2,uint param_3,undefined2 param_4,uint param_5)

{
  short sVar1;
  undefined1 uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 in_lr;
  
  param_3 = param_3 & 0xffff;
  param_5 = param_5 & 0xffff;
  uVar3 = sub_080008C8();
  uVar4 = __umodsi3(uVar3,100);
  switch(param_4) {
  case 2:
    iVar6 = (100 - *(short *)(param_2 + 2)) * (param_3 * 10 + 5);
    uVar3 = 100;
    break;
  case 3:
    sVar1 = *(short *)(param_2 + 4);
    goto code_r0x08069416;
  default:
    uVar7 = 0;
    *(undefined1 *)(param_1 + 1) = 0;
    goto code_r0x08069432;
  case 5:
    iVar6 = (100 - *(short *)(param_2 + 8)) * (param_3 * 10 + 5);
    uVar3 = 0x19;
    break;
  case 6:
  case 7:
    sVar1 = *(short *)(param_2 + 10);
code_r0x08069416:
    iVar6 = (100 - sVar1) * (param_3 * 10 + 5);
    uVar3 = 0x32;
  }
  uVar7 = __divsi3(iVar6,uVar3);
code_r0x08069432:
  uVar5 = sub_080020F4();
  if ((param_5 == uVar5) || ((iVar6 = sub_0800CF80(), iVar6 != 0 && (param_5 < 4)))) {
    uVar7 = __udivsi3(uVar7 * (int)*(char *)(param_5 * 0x14c + DWORD_0806946c + 0x73),100);
  }
  if (uVar4 < uVar7) {
    uVar2 = (undefined1)param_4;
  }
  else {
    uVar2 = 0;
  }
  *(undefined1 *)(param_1 + 1) = uVar2;
  if ((3 < param_5) &&
     (*(char *)(param_5 * 0x2e0 + *(int *)DWORD_080694a4 + DWORD_080694a8) == '\x03')) {
    *(undefined1 *)(param_1 + 1) = 0;
  }
  return in_lr;
}


