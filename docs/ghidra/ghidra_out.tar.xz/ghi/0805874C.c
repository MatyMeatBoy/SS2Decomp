
undefined4 sub_0805874C(void)

{
  undefined4 in_lr;
  
  sub_0801A388();
  return in_lr;
}


