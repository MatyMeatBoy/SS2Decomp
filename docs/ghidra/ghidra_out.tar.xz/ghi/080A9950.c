
/* WARNING: Possible PIC construction at 0x080a9a3c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x080a9cb0: Changing call to branch */
/* WARNING: Possible PIC construction at 0x080a9ce4: Changing call to branch */
/* WARNING: Possible PIC construction at 0x080aa8b6: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x080a9a40) */

undefined4 sub_080A9950(int param_1)

{
  int *piVar1;
  int *piVar2;
  ushort *puVar3;
  dword dVar4;
  dword dVar5;
  dword dVar6;
  dword dVar7;
  undefined1 uVar8;
  undefined1 uVar9;
  ushort uVar10;
  undefined2 uVar11;
  short sVar12;
  uint uVar13;
  undefined4 uVar14;
  uint uVar15;
  undefined2 *puVar16;
  uint uVar17;
  uint *puVar18;
  int iVar19;
  byte *pbVar20;
  int iVar21;
  undefined1 *puVar22;
  int iVar23;
  undefined4 *puVar24;
  undefined4 in_lr;
  undefined4 auStack_fc [2];
  undefined4 uStack_f4;
  int iStack_f0;
  undefined1 auStack_e0 [24];
  undefined4 auStack_c8 [7];
  undefined1 auStack_ac [24];
  short sStack_94;
  short sStack_92;
  short sStack_90;
  short sStack_8e;
  int iStack_8c;
  int iStack_78;
  uint uStack_74;
  uint uStack_70;
  uint uStack_6c;
  undefined4 uStack_64;
  uint uStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  undefined4 *puStack_38;
  undefined4 *puStack_34;
  undefined4 *puStack_30;
  short *psStack_2c;
  undefined4 *puStack_28;
  ushort *puStack_24;
  
  piVar2 = piRam080a9a40;
  *piRam080a9a40 = param_1;
  puVar18 = puRam080a9a44;
  *puRam080a9a44 = *puRam080a9a44 | 2;
  piVar1 = piRam080a9a48;
  iVar21 = *piRam080a9a4c;
  *piRam080a9a48 = iVar21 + 0x2e0;
  uVar14 = uRam080a9a54;
  iStack_8c = param_1 + 0x204;
  iVar23 = iVar21 + iRam080a9a50;
  sub_0801623C(param_1,uRam080a9a54,0);
  sub_0801623C(*piVar1,uVar14,1);
  sub_08019F60(iVar23);
  sub_08019F60(iStack_8c);
  sub_0801A0B0(*piVar1);
  sub_0801A0B0(*piVar2);
  *(undefined1 *)(iVar21 + iRam080a9a58) = 1;
  puVar16 = (undefined2 *)*piVar1;
  *puVar16 = 1;
  puVar16[1] = 5;
  puVar16[0x24] = *(undefined2 *)(iRam080a9a5c + 0x90);
  uVar14 = uRam080a9a60;
  iVar21 = *piVar2;
  *(undefined4 *)(iVar21 + 0x14) = uRam080a9a60;
  *(undefined4 *)(puVar16 + 10) = uVar14;
  *(undefined4 *)(iVar21 + 0x18) = 0x9700;
  *(undefined4 *)(puVar16 + 0xc) = 0x9700;
  puVar3 = puRam080a9a64;
  uVar10 = sub_08016E04(*(undefined2 *)(param_1 + 0x2d8),*(undefined2 *)(param_1 + iRam080a9a68));
  *puVar3 = uVar10;
  piVar1 = (int *)DWORD_080a9c80;
  uVar13 = uRam080a9a6c;
  while (DWORD_080a9c80 = (dword)piVar1, uVar10 == uVar13) {
    *(undefined2 *)(*piVar2 + 0xc) = 0xb;
    iVar21 = sub_0800CB78();
    if ((iVar21 != 0) || (iVar21 = sub_08056E90(), iVar21 != 0)) {
      *puVar18 = *puVar18 & ~(1 << (*(ushort *)*piVar2 & 0xff));
      return in_lr;
    }
    sub_080003F0();
    piVar1 = (int *)DWORD_080a9c80;
    uVar13 = (uint)*(ushort *)DWORD_080a9c7c;
  }
  iVar19 = *piVar1;
  sVar12 = *(short *)(iVar23 + 6) * 3;
  *(short *)(iVar19 + 0x1d6) = sVar12;
  *(short *)(iVar19 + 0x5c) = sVar12;
  sVar12 = *(short *)(iVar23 + 4) * 0x14;
  *(short *)(iVar19 + 0x1d4) = sVar12;
  *(short *)(iVar19 + 0x5e) = sVar12;
  dVar4 = DWORD_080a9c84;
  iVar21 = *(int *)DWORD_080a9c84;
  sVar12 = *(short *)(iStack_8c + 6) * 3;
  *(short *)(iVar21 + 0x1d6) = sVar12;
  *(short *)(iVar21 + 0x5c) = sVar12;
  sVar12 = *(short *)(iStack_8c + 4) * 0x14;
  *(short *)(iVar21 + 0x1d4) = sVar12;
  *(short *)(iVar21 + 0x5e) = sVar12;
  *(undefined2 *)(iVar19 + 0xc) = 0;
  *(undefined2 *)(iVar21 + 0xc) = 0;
  dVar5 = DWORD_080a9c88;
  uStack_70 = 0;
  uStack_74 = 0;
  uStack_6c = 0;
  uStack_40 = 0;
  *(undefined1 *)(iVar19 + DWORD_080a9c88) = 3;
  *(undefined1 *)(*piVar1 + 0x1fe) = 3;
  *(undefined1 *)(*(int *)dVar4 + dVar5) = 3;
  *(undefined1 *)(*(int *)dVar4 + 0x1fe) = 3;
  *(undefined4 *)(*piVar1 + 0x50) = 1;
  *(undefined4 *)(*(int *)dVar4 + 0x50) = 1;
  dVar6 = DWORD_080a9c90;
  dVar5 = DWORD_080a9c8c;
  dVar4 = DWORD_080a9c7c;
  uVar13 = 0;
  puStack_28 = auStack_c8;
  puStack_24 = (ushort *)(iStack_8c + 0xd6);
  do {
    uVar17 = 0;
    do {
      *(undefined4 *)((short)uVar17 * 4 + ((int)(uVar13 * 0x10000) >> 0x10) * 0x14c + dVar6) = 0;
      uVar15 = (int)(short)uVar17 + 1;
      uVar17 = uVar15 & 0xffff;
    } while ((int)(uVar15 * 0x10000) >> 0x10 < 5);
    uVar17 = uVar13 * 0x10000 + 0x10000;
    uVar13 = uVar17 >> 0x10;
  } while ((int)uVar17 >> 0x10 < 4);
  uStack_4c = 0;
  uStack_44 = 0;
  uStack_48 = 0;
  uStack_64 = 0;
  iStack_5c = 0;
  iStack_58 = 0xff;
  iStack_54 = 0;
  iStack_50 = 0xff;
  iVar21 = *piVar1;
  *(ushort *)(iVar21 + 0x68) = (ushort)*(byte *)(dVar5 + 1);
  iVar23 = *(int *)DWORD_080a9c84;
  *(ushort *)(iVar23 + 0x68) = (ushort)*(byte *)(dVar5 + 3);
  *(undefined2 *)(iVar21 + 0x6a) = 0;
  *(undefined2 *)(iVar21 + 0x6c) = 0;
  *(undefined2 *)(iVar23 + 0x6a) = 0;
  *(undefined2 *)(iVar23 + 0x6c) = 0;
  sub_08065158(auStack_fc,*(undefined4 *)((uint)*(byte *)dVar5 * 4 + DWORD_080a9c94),
               *(undefined2 *)dVar4,0xffffffff,1);
  sub_08065158(puStack_28,*(undefined4 *)((uint)*(byte *)(dVar5 + 2) * 4 + DWORD_080a9c94),
               *(undefined2 *)dVar4,0xffffffff,1);
  auStack_e0[0] = (undefined1)*(undefined2 *)dVar4;
  *(undefined1 *)(puStack_28 + 7) = auStack_e0[0];
  pbVar20 = (byte *)*piVar1 + 0x1fc;
  *pbVar20 = *pbVar20 & 0xf0 | *(byte *)*piVar1 & 0xf;
  dVar4 = DWORD_080a9c98;
  iVar21 = *piVar1;
  *(undefined2 *)(iVar21 + DWORD_080a9c98) = *(undefined2 *)(iVar21 + 2);
  *(undefined1 *)(iVar21 + 0x200) = 0xff;
  pbVar20 = *(byte **)DWORD_080a9c84 + 0x1fc;
  *pbVar20 = *pbVar20 & 0xf0 | **(byte **)DWORD_080a9c84 & 0xf;
  iVar21 = *(int *)DWORD_080a9c84;
  *(undefined2 *)(iVar21 + dVar4) = *(undefined2 *)(iVar21 + 2);
  *(undefined1 *)(iVar21 + 0x200) = 0xff;
  sub_08097FE4();
  sub_08097A4C();
  iStack_3c = 0;
  sub_08067C18();
  while (iVar21 = sub_08067C08(), iVar21 == 0) {
    sub_080003F0();
  }
  sub_08067BF8();
  sub_0806849C();
  do {
    iVar21 = sub_0800CB78();
    if ((iVar21 != 0) || (iVar21 = sub_08056E90(), iVar21 != 0)) break;
    if ((*(short *)(*(int *)DWORD_080a9d14 + 0xc) == 10) && (uStack_70 == 0)) {
      uStack_70 = 8;
    }
    if ((*(short *)(*(int *)DWORD_080a9d18 + 0xc) == 10) && (uStack_74 == 0)) {
      uStack_74 = 8;
    }
    iVar21 = sub_08058DB0();
    if (iVar21 == 0) {
      sub_0801C8F0(*(undefined4 *)DWORD_080a9d18);
      dVar4 = DWORD_080a9d14;
      sub_0801C8F0(*(undefined4 *)DWORD_080a9d14);
      uVar13 = *(byte *)(*(int *)dVar4 + DWORD_080a9d1c) - 1;
      if (uVar13 < 0xe) {
                    /* WARNING: Could not recover jumptable at 0x080a9d10. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        uVar14 = (**(code **)(uVar13 * 4 + DWORD_080a9d20))();
        return uVar14;
      }
      iVar23 = *(int *)DWORD_080aa57c;
      iVar21 = *(int *)DWORD_080aa580;
      *(undefined4 *)(iVar23 + 0x14) = *(undefined4 *)(iVar21 + 0x14);
      *(undefined4 *)(iVar23 + 0x18) = *(undefined4 *)(iVar21 + 0x18);
    }
    if ((iStack_58 != iStack_5c) || (iStack_50 != iStack_54)) {
      iStack_58 = iStack_5c;
      iStack_50 = iStack_54;
      iVar23 = *(int *)DWORD_080aa57c;
      *(undefined2 *)(iVar23 + 0x6c) = 0;
      *(undefined2 *)(iVar23 + 0x6a) = 0;
      dVar4 = DWORD_080aa580;
      iVar21 = *(int *)DWORD_080aa580;
      *(undefined2 *)(iVar21 + 0x6c) = 0;
      *(undefined2 *)(iVar21 + 0x6a) = 0;
      dVar5 = DWORD_080aa588;
      iVar21 = iStack_5c * 5 + iStack_54 * 10;
      *(ushort *)(iVar23 + 0x68) = (ushort)*(byte *)(iVar21 + DWORD_080aa588 + 1);
      dVar7 = DWORD_080aa590;
      dVar6 = DWORD_080aa58c;
      sub_08065158(auStack_fc,*(undefined4 *)((uint)*(byte *)(iVar21 + dVar5) * 4 + DWORD_080aa58c),
                   *(undefined2 *)DWORD_080aa590,0xffffffff,1);
      *(ushort *)(*(int *)dVar4 + 0x68) = (ushort)*(byte *)(iVar21 + dVar5 + 3);
      sub_08065158(puStack_28,*(undefined4 *)((uint)*(byte *)(iVar21 + dVar5 + 2) * 4 + dVar6),
                   *(undefined2 *)dVar7,0xffffffff,1);
      auStack_e0[0] = (undefined1)*(undefined2 *)dVar7;
      *(undefined1 *)(puStack_28 + 7) = auStack_e0[0];
    }
    uVar13 = sub_08098004();
    if ((uVar13 & 1) == 0) {
      uVar8 = sub_0800BC44(*(int *)(*(int *)DWORD_080aa6a0 + 0x14) >> 8,
                           *(int *)(*(int *)DWORD_080aa6a0 + 0x18) >> 8,0);
      uVar9 = sub_0800BC44(*(int *)(*(int *)DWORD_080aa6a4 + 0x14) >> 8,
                           *(int *)(*(int *)DWORD_080aa6a4 + 0x18) >> 8,0);
    }
    else {
      uVar8 = sub_08097FF8();
      uVar9 = sub_08097FF8();
    }
    dVar4 = DWORD_080aa6a8;
    sub_08000AF0(*(ushort *)DWORD_080aa6a8 + 0x10,iStack_f0 + (uint)*puStack_24 * 0x20,1);
    sub_08000AF0(*(ushort *)dVar4 + 0x10,puStack_28[3] + (uint)*puStack_24 * 0x20,1);
    iVar21 = sub_0800CD8C();
    dVar4 = DWORD_080aa6a0;
    if (iVar21 == 0) {
      iVar21 = *(int *)DWORD_080aa6a0;
      puVar22 = (undefined1 *)(iStack_54 * 10 + iStack_5c * 5 + DWORD_080aa6ac + 4);
      uVar11 = sub_08065370(auStack_fc,*(undefined2 *)(iVar21 + 0x68),iVar21 + 0x6a,iVar21 + 0x6c,
                            *puVar22);
      *(undefined2 *)(*(int *)dVar4 + 0x6e) = uVar11;
      dVar4 = DWORD_080aa6a4;
      iVar21 = *(int *)DWORD_080aa6a4;
      uVar11 = sub_08065370(puStack_28,*(undefined2 *)(iVar21 + 0x68),iVar21 + 0x6a,iVar21 + 0x6c,
                            *puVar22);
      *(undefined2 *)(*(int *)dVar4 + 0x6e) = uVar11;
    }
    sub_0800BC08((*(int *)(*(int *)DWORD_080aa6a0 + 0x14) << 8) >> 0x10,
                 (*(int *)(*(int *)DWORD_080aa6a0 + 0x18) << 8) >> 0x10,&sStack_94,&sStack_92,0,0);
    dVar4 = DWORD_080aa790;
    if ((*(char *)(*(int *)DWORD_080aa6a4 + 0x1fe) == '\x01') ||
       (*(char *)(*(int *)DWORD_080aa6a4 + DWORD_080aa6b0) == '\x01')) {
      if (iStack_5c == 0) {
        sStack_94 = sStack_94 + 9;
      }
      else {
        sStack_94 = sStack_94 + -9;
      }
      sStack_92 = sStack_92 + 0x15;
    }
    sub_0800BC08((*(int *)(*(int *)DWORD_080aa790 + 0x14) << 8) >> 0x10,
                 (*(int *)(*(int *)DWORD_080aa790 + 0x18) << 8) >> 0x10,&sStack_90,&sStack_8e,0,0);
    if (uStack_74 == 0) {
      iVar21 = sub_0800CCCC();
      if (((iVar21 == 0) && (iVar21 = sub_0800CC98(), iVar21 == 0)) &&
         (iVar21 = sub_0800CD34(), iVar21 == 0)) {
        sub_08007870((int)sStack_94,(int)sStack_92,*(undefined2 *)(*(int *)DWORD_080aa878 + 0x68),
                     *(undefined2 *)(*(int *)DWORD_080aa878 + 0x6a),uVar8,auStack_e0,uStack_f4,
                     auStack_fc[0]);
        sub_08007870((int)sStack_90,(int)sStack_8e,*(undefined2 *)(*(int *)dVar4 + 0x68),
                     *(undefined2 *)(*(int *)dVar4 + 0x6a),uVar9,auStack_ac,puStack_28[2],
                     auStack_c8[0]);
      }
    }
    else {
      uVar13 = uStack_74 - 1 & 0xffff;
      uVar17 = uStack_74 & 1;
      uStack_74 = uVar13;
      if (((uVar17 != 0) && (iVar21 = sub_0800CCCC(), iVar21 == 0)) &&
         ((iVar21 = sub_0800CC98(), iVar21 == 0 && (iVar21 = sub_0800CD34(), iVar21 == 0)))) {
        sub_08007870((int)sStack_94,(int)sStack_92,*(undefined2 *)(*(int *)DWORD_080aa794 + 0x68),
                     *(undefined2 *)(*(int *)DWORD_080aa794 + 0x6a),uVar8,auStack_e0,uStack_f4,
                     auStack_fc[0]);
      }
      iVar21 = sub_0800CCCC();
      if (((iVar21 == 0) && (iVar21 = sub_0800CC98(), iVar21 == 0)) &&
         (iVar21 = sub_0800CD34(), iVar21 == 0)) {
        sub_08007870((int)sStack_90,(int)sStack_8e,*(undefined2 *)(*(int *)DWORD_080aa790 + 0x68),
                     *(undefined2 *)(*(int *)DWORD_080aa790 + 0x6a),uVar9,auStack_ac,puStack_28[2],
                     auStack_c8[0]);
      }
    }
    puVar24 = (undefined4 *)DWORD_080aa878;
    iVar21 = *(int *)(*(int *)DWORD_080aa878 + 0x4c);
    if ((iVar21 != 0) && (iStack_78 != iVar21)) {
      uStack_6c = 10;
      uStack_60 = 0;
      iStack_78 = iVar21;
    }
    if (uStack_6c == 0) {
      iStack_78 = 0;
      *(undefined4 *)(*(int *)DWORD_080aa878 + 0x4c) = 0;
    }
    else {
      iVar21 = sub_0800CC98();
      if (((iVar21 == 0) && (iVar21 = sub_0800CCCC(), iVar21 == 0)) &&
         (iVar21 = sub_0800CD34(), iVar21 == 0)) {
        sub_0801A120(*(undefined4 *)DWORD_080aa878,iStack_78,(int)(short)uStack_60);
      }
      if ((uStack_6c & 2) != 0) {
        uStack_60 = uStack_60 * 0x10000 + DWORD_080aa87c >> 0x10;
      }
      uStack_6c = uStack_6c - 1 & 0xffff;
      puVar24 = (undefined4 *)DWORD_080aa878;
    }
    sVar12 = sub_08019CE8(*puVar24);
    if (sVar12 != 0) {
      iStack_3c = 1;
    }
    sub_080003F0();
  } while (iStack_3c == 0);
  *(undefined4 *)DWORD_080aa978 = 0;
  iVar21 = sub_080020F4();
  puVar18 = (uint *)(iVar21 * 0x14c + DWORD_080aa97c + 0x30);
  *puVar18 = *puVar18 | 1;
  dVar5 = DWORD_080aa984;
  dVar4 = DWORD_080aa980;
  iVar23 = *(int *)DWORD_080aa980;
  iVar19 = iStack_5c * 5 + 0x14;
  *(ushort *)(iVar23 + 0x68) = (ushort)*(byte *)(iVar19 + DWORD_080aa984 + 1);
  iVar21 = *(int *)DWORD_080aa988;
  *(ushort *)(iVar21 + 0x68) = (ushort)*(byte *)(iVar19 + dVar5 + 3);
  *(undefined2 *)(iVar23 + 0x6a) = 0;
  *(undefined2 *)(iVar23 + 0x6c) = 0;
  *(undefined2 *)(iVar21 + 0x6a) = 0;
  *(undefined2 *)(iVar21 + 0x6c) = 0;
  dVar7 = DWORD_080aa990;
  dVar6 = DWORD_080aa98c;
  sub_08065158(auStack_fc,*(undefined4 *)((uint)*(byte *)(iVar19 + dVar5) * 4 + DWORD_080aa98c),
               *(undefined2 *)DWORD_080aa990,0xffffffff,1);
  sub_08065158(puStack_28,*(undefined4 *)((uint)*(byte *)(iVar19 + dVar5 + 2) * 4 + dVar6),
               *(undefined2 *)dVar7,0xffffffff,1);
  puVar24 = puStack_28;
  auStack_e0[0] = (undefined1)*(undefined2 *)dVar7;
  *(undefined1 *)(puStack_28 + 7) = auStack_e0[0];
  sub_080683CC();
  sub_08067CA8(*(undefined2 *)(*(int *)dVar4 + 2));
  sub_08068330(DWORD_080aa994);
  puStack_38 = puVar24;
  while (iVar21 = sub_080682B8(DWORD_080aab68), iVar21 == 0) {
    iVar21 = sub_080020F4();
    puVar3 = puStack_24;
    puVar18 = (uint *)(iVar21 * 0x14c + DWORD_080aaa78 + 0x30);
    *puVar18 = *puVar18 | 1;
    dVar5 = DWORD_080aaa7c;
    sub_08000AF0(*(ushort *)DWORD_080aaa7c + 0x10,iStack_f0 + (uint)*puStack_24 * 0x20,1);
    sub_08000AF0(*(ushort *)dVar5 + 0x10,puStack_38[3] + (uint)*puVar3 * 0x20,1);
    uVar8 = sub_0800BC44(*(int *)(*(int *)dVar4 + 0x14) >> 8,*(int *)(*(int *)dVar4 + 0x18) >> 8,0);
    uVar9 = sub_0800BC44(*(int *)(*(int *)DWORD_080aaa80 + 0x14) >> 8,
                         *(int *)(*(int *)DWORD_080aaa80 + 0x18) >> 8,0);
    iVar21 = *(int *)dVar4;
    uVar11 = sub_08065370(auStack_fc,*(undefined2 *)(iVar21 + 0x68),iVar21 + 0x6a,iVar21 + 0x6c,0);
    *(undefined2 *)(*(int *)dVar4 + 0x6e) = uVar11;
    iVar21 = *(int *)DWORD_080aaa80;
    uVar11 = sub_08065370(puStack_38,*(undefined2 *)(iVar21 + 0x68),iVar21 + 0x6a,iVar21 + 0x6c,0);
    *(undefined2 *)(*(int *)DWORD_080aaa80 + 0x6e) = uVar11;
    sub_0800BC08((*(int *)(*(int *)dVar4 + 0x14) << 8) >> 0x10,
                 (*(int *)(*(int *)dVar4 + 0x18) << 8) >> 0x10,&sStack_94,&sStack_92,0,0);
    dVar5 = DWORD_080aab64;
    if (iStack_5c == 0) {
      sStack_94 = sStack_94 + 9;
    }
    else {
      sStack_94 = sStack_94 + -9;
    }
    sStack_92 = sStack_92 + 0x15;
    sub_0800BC08((*(int *)(*(int *)DWORD_080aab64 + 0x14) << 8) >> 0x10,
                 (*(int *)(*(int *)DWORD_080aab64 + 0x18) << 8) >> 0x10,&sStack_90,&sStack_8e,0,0);
    iVar21 = sub_0800CCCC();
    if (((iVar21 == 0) && (iVar21 = sub_0800CC98(), iVar21 == 0)) &&
       ((iVar21 = sub_0800CD8C(), iVar21 == 0 &&
        ((iVar21 = sub_0800CD34(), iVar21 == 0 &&
         (uVar13 = uStack_70 - 1 & 0xffff, uVar17 = uStack_70 & 1, uStack_70 = uVar13, uVar17 != 0))
        )))) {
      sub_08007870((int)sStack_94,(int)sStack_92,*(undefined2 *)(*(int *)dVar4 + 0x68),
                   *(undefined2 *)(*(int *)dVar4 + 0x6a),uVar8,auStack_e0,uStack_f4,auStack_fc[0]);
      sub_08007870((int)sStack_90,(int)sStack_8e,*(undefined2 *)(*(int *)dVar5 + 0x68),
                   *(undefined2 *)(*(int *)dVar5 + 0x6a),uVar9,auStack_ac,puStack_28[2],
                   auStack_c8[0]);
    }
    sub_080003F0();
  }
  sub_08065E38(DWORD_080aab68);
  puStack_34 = puStack_28;
  while (iVar21 = sub_08058DB0(), iVar21 != 0) {
    iVar21 = sub_080020F4();
    puVar18 = (uint *)(iVar21 * 0x14c + DWORD_080aac58 + 0x30);
    *puVar18 = *puVar18 | 1;
    dVar4 = DWORD_080aac5c;
    sub_08000AF0(*(ushort *)DWORD_080aac5c + 0x10,iStack_f0 + (uint)*puStack_24 * 0x20,1);
    sub_08000AF0(*(ushort *)dVar4 + 0x10,puStack_34[3] + (uint)*puStack_24 * 0x20,1);
    uVar8 = sub_0800BC44(*(int *)(*(int *)DWORD_080aac60 + 0x14) >> 8,
                         *(int *)(*(int *)DWORD_080aac60 + 0x18) >> 8,0);
    uVar9 = sub_0800BC44(*(int *)(*(int *)DWORD_080aac64 + 0x14) >> 8,
                         *(int *)(*(int *)DWORD_080aac64 + 0x18) >> 8,0);
    iVar21 = *(int *)DWORD_080aac60;
    uVar11 = sub_08065370(auStack_fc,*(undefined2 *)(iVar21 + 0x68),iVar21 + 0x6a,iVar21 + 0x6c,0);
    dVar4 = DWORD_080aac60;
    *(undefined2 *)(*(int *)DWORD_080aac60 + 0x6e) = uVar11;
    iVar21 = *(int *)DWORD_080aac64;
    uVar11 = sub_08065370(puStack_34,*(undefined2 *)(iVar21 + 0x68),iVar21 + 0x6a,iVar21 + 0x6c,0);
    *(undefined2 *)(*(int *)DWORD_080aac64 + 0x6e) = uVar11;
    sub_0800BC08((*(int *)(*(int *)dVar4 + 0x14) << 8) >> 0x10,
                 (*(int *)(*(int *)dVar4 + 0x18) << 8) >> 0x10,&sStack_94,&sStack_92,0,0);
    dVar4 = DWORD_080aad88;
    if (iStack_5c == 0) {
      sStack_94 = sStack_94 + 9;
    }
    else {
      sStack_94 = sStack_94 + -9;
    }
    sStack_92 = sStack_92 + 0x15;
    sub_0800BC08((*(int *)(*(int *)DWORD_080aad88 + 0x14) << 8) >> 0x10,
                 (*(int *)(*(int *)DWORD_080aad88 + 0x18) << 8) >> 0x10,&sStack_90,&sStack_8e,0,0);
    iVar21 = sub_0800CCCC();
    if ((((iVar21 == 0) && (iVar21 = sub_0800CC98(), iVar21 == 0)) &&
        (iVar21 = sub_0800CD8C(), iVar21 == 0)) &&
       ((iVar21 = sub_0800CD34(), iVar21 == 0 &&
        (uVar13 = uStack_70 - 1 & 0xffff, uVar17 = uStack_70 & 1, uStack_70 = uVar13, uVar17 != 0)))
       ) {
      sub_08007870((int)sStack_94,(int)sStack_92,*(undefined2 *)(*(int *)DWORD_080aad8c + 0x68),
                   *(undefined2 *)(*(int *)DWORD_080aad8c + 0x6a),uVar8,auStack_e0,uStack_f4,
                   auStack_fc[0]);
      sub_08007870((int)sStack_90,(int)sStack_8e,*(undefined2 *)(*(int *)dVar4 + 0x68),
                   *(undefined2 *)(*(int *)dVar4 + 0x6a),uVar9,auStack_ac,puStack_28[2],
                   auStack_c8[0]);
    }
    sub_080003F0();
  }
  sub_080586B4(0);
  iVar21 = sub_080020F4();
  puVar18 = (uint *)(iVar21 * 0x14c + DWORD_080aad90 + 0x30);
  *puVar18 = *puVar18 | 1;
  uVar14 = sub_0805DF38(1,0xe,0x19,2,0x3c,DWORD_080aad94);
  *(undefined4 *)(*(int *)DWORD_080aad98 + 0x720) = uVar14;
  dVar5 = DWORD_080aad8c;
  dVar4 = DWORD_080aad88;
  puStack_30 = puStack_28;
  psStack_2c = &sStack_90;
  while (iVar21 = sub_0805EEFC(*(undefined4 *)(*(int *)DWORD_080ab014 + 0x720)), iVar21 == 0) {
    iVar21 = sub_080020F4();
    puVar18 = (uint *)(iVar21 * 0x14c + DWORD_080aaea8 + 0x30);
    *puVar18 = *puVar18 | 1;
    iVar21 = sub_0800CCCC();
    if (((iVar21 == 0) && (iVar21 = sub_0800CC98(), iVar21 == 0)) &&
       ((iVar21 = sub_0800CD8C(), iVar21 == 0 &&
        (iVar21 = sub_0800CD34(), dVar6 = DWORD_080aaeac, iVar21 == 0)))) {
      sub_08000AF0(*(ushort *)DWORD_080aaeac + 0x10,iStack_f0 + (uint)*puStack_24 * 0x20,1);
      sub_08000AF0(*(ushort *)dVar6 + 0x10,puStack_30[3] + (uint)*puStack_24 * 0x20,1);
      uVar8 = sub_0800BC44(*(int *)(*(int *)dVar5 + 0x14) >> 8,*(int *)(*(int *)dVar5 + 0x18) >> 8,0
                          );
      uVar9 = sub_0800BC44(*(int *)(*(int *)dVar4 + 0x14) >> 8,*(int *)(*(int *)dVar4 + 0x18) >> 8,0
                          );
      iVar21 = *(int *)dVar5;
      uVar11 = sub_08065370(auStack_fc,*(undefined2 *)(iVar21 + 0x68),iVar21 + 0x6a,iVar21 + 0x6c,0)
      ;
      *(undefined2 *)(*(int *)dVar5 + 0x6e) = uVar11;
      iVar21 = *(int *)dVar4;
      uVar11 = sub_08065370(puStack_30,*(undefined2 *)(iVar21 + 0x68),iVar21 + 0x6a,iVar21 + 0x6c,0)
      ;
      *(undefined2 *)(*(int *)dVar4 + 0x6e) = uVar11;
      sub_0800BC08((*(int *)(*(int *)dVar5 + 0x14) << 8) >> 0x10,
                   (*(int *)(*(int *)dVar5 + 0x18) << 8) >> 0x10,&sStack_94,&sStack_92,0,0);
      if (iStack_5c == 0) {
        sStack_94 = sStack_94 + 9;
      }
      else {
        sStack_94 = sStack_94 + -9;
      }
      sStack_92 = sStack_92 + 0x15;
      sub_0800BC08((*(int *)(*(int *)dVar4 + 0x14) << 8) >> 0x10,
                   (*(int *)(*(int *)dVar4 + 0x18) << 8) >> 0x10,psStack_2c,&sStack_8e,0,0);
      sub_08007870((int)sStack_94,(int)sStack_92,*(undefined2 *)(*(int *)dVar5 + 0x68),
                   *(undefined2 *)(*(int *)dVar5 + 0x6a),uVar8,auStack_e0,uStack_f4,auStack_fc[0]);
      sub_08007870((int)*psStack_2c,(int)sStack_8e,*(undefined2 *)(*(int *)dVar4 + 0x68),
                   *(undefined2 *)(*(int *)dVar4 + 0x6a),uVar9,auStack_ac,puStack_28[2],
                   auStack_c8[0]);
    }
    sub_080003F0();
  }
  iVar21 = sub_080020F4();
  iVar23 = DWORD_080ab018 + 0x30;
  puVar18 = (uint *)(iVar21 * 0x14c + iVar23);
  *puVar18 = *puVar18 & 0xfffffffe;
  sub_08058688(0xd);
  dVar4 = DWORD_080ab01c;
  sub_08097658(*(undefined4 *)DWORD_080ab01c,*(undefined4 *)DWORD_080ab020,auStack_fc,puStack_28,
               *puStack_24,*(undefined2 *)DWORD_080ab024,iStack_5c);
  iVar21 = sub_080020F4();
  if (((*(uint *)(iVar21 * 0x14c + iVar23) & 0x2000) == 0) &&
     (*(short *)(*(int *)dVar4 + 0x5a) != 0)) {
    uVar14 = sub_0801E46C(*(undefined4 *)DWORD_080ab028,iStack_8c);
    uStack_60 = 0x1d;
    do {
      iVar21 = *(int *)DWORD_080ab020;
      *(int *)(iVar21 + 0x18) = *(int *)(iVar21 + 0x18) + -0x20;
      sub_0806171C(iVar21,uVar14);
      sub_080003F0();
      uVar13 = uStack_60 * 0x10000 + DWORD_080ab02c;
      uStack_60 = uVar13 >> 0x10;
    } while ((int)uVar13 >> 0x10 != -1);
    sub_0801E4CC(*(undefined4 *)DWORD_080ab028,uVar14);
  }
  uStack_60 = 0x6f;
  do {
    sub_080003F0();
    uVar13 = uStack_60 * 0x10000 + DWORD_080ab02c;
    uStack_60 = uVar13 >> 0x10;
  } while ((int)uVar13 >> 0x10 != -1);
  sub_08067C18();
  while (iVar21 = sub_08067C08(), iVar21 == 0) {
    sub_080003F0();
  }
  sub_08067BF8();
  sub_08056E24();
  return in_lr;
}


