
undefined4 sub_08006BB4(void)

{
  undefined4 in_lr;
  
  m4aSoundMode();
  return in_lr;
}


