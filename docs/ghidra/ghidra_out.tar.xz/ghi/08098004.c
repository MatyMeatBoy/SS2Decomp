
undefined1 sub_08098004(void)

{
  return *(undefined1 *)DWORD_0809800c;
}


