
undefined8 sub_0805B618(void)

{
  dword dVar1;
  dword dVar2;
  int iVar3;
  dword dVar4;
  uint uVar5;
  uint uVar6;
  undefined4 in_lr;
  
  dVar1 = DWORD_0805b670;
  iVar3 = *(int *)DWORD_0805b670;
  uVar6 = 0;
  dVar4 = 0;
  uVar5 = DWORD_0805b674;
  dVar2 = DWORD_0805b674;
  do {
    if ((*(ushort *)(iVar3 + 10) & 1) != 0) {
      uVar6 = uVar6 + 1;
      if (*(ushort *)(iVar3 + 0xc) < uVar5) {
        uVar5 = (uint)*(ushort *)(iVar3 + 0xc);
        dVar2 = dVar4;
      }
    }
    dVar4 = dVar4 + 1;
    iVar3 = iVar3 + 0x20;
  } while (dVar4 < 0x10);
  if (0xf < uVar6) {
    *(undefined2 *)(dVar2 * 0x20 + *(int *)DWORD_0805b670 + 10) = 0;
  }
  iVar3 = *(int *)dVar1;
  uVar5 = 0;
  do {
    if ((*(ushort *)(iVar3 + 10) & 3) == 0) goto LAB_0805b682;
    uVar5 = uVar5 + 1;
    iVar3 = iVar3 + 0x20;
  } while (uVar5 < 0x10);
  iVar3 = 0;
LAB_0805b682:
  return CONCAT44(in_lr,iVar3);
}


