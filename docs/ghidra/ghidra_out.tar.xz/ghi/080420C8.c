
undefined4 sub_080420C8(void)

{
  short sVar1;
  dword dVar2;
  short sVar3;
  int iVar4;
  byte *pbVar5;
  undefined4 uVar6;
  undefined4 in_lr;
  undefined1 auStack_38 [4];
  undefined1 auStack_34 [4];
  undefined1 auStack_30 [4];
  undefined1 auStack_2c [4];
  undefined1 *puStack_28;
  undefined1 *puStack_24;
  
  iVar4 = sub_080020F4();
  iVar4 = iVar4 * 0x14c + DWORD_08042104;
  *(uint *)(iVar4 + 0x30) = *(uint *)(iVar4 + 0x30) | 1;
  sub_0800D0F4();
  iVar4 = sub_080020F4();
  if (iVar4 == 1) {
    uVar6 = 0x84;
  }
  else if (iVar4 < 2) {
    if (iVar4 != 0) goto LAB_08042138;
    uVar6 = 0x6c;
  }
  else {
    if (iVar4 != 2) {
      if (iVar4 == 3) {
        sub_08028AAC(0,0x9c,0x80,0);
      }
      goto LAB_08042138;
    }
    uVar6 = 0x54;
  }
  sub_08028AAC(0,uVar6,0x80,0);
LAB_08042138:
  sub_080290E4(0,4);
  iVar4 = sub_080020F4();
  iVar4 = iVar4 * 0x14c + DWORD_08042170;
  *(uint *)(iVar4 + 0x30) = *(uint *)(iVar4 + 0x30) & 0xfffffffd;
  sub_08067D74();
  sVar3 = 2;
  puStack_28 = auStack_30;
  puStack_24 = auStack_2c;
  do {
    sub_080003F0();
    iVar4 = sub_080021A8();
    if (iVar4 != 0) break;
    sVar3 = sVar3 + -1;
  } while (sVar3 != 0);
  iVar4 = sub_0800CC98();
  if (iVar4 == 0) {
    iVar4 = sub_0801AB24();
    if (iVar4 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar4 < 2) {
      if (iVar4 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar4 == 2) {
      sub_0801AB90(6);
    }
    while (iVar4 = sub_0801AAE0(), iVar4 == 0) {
      sub_080003F0();
    }
  }
  dVar2 = DWORD_0804223c;
  sVar3 = *(short *)(DWORD_08042238 + 0x80);
  sVar1 = *(short *)(DWORD_08042238 + 0x82);
  iVar4 = 0;
  do {
    sub_080659F4(auStack_38,(int)sVar3,0,iVar4);
    sub_080659F4(auStack_34,(int)sVar1,(int)dVar2 >> 0x10,iVar4);
    sub_0800BB80((int)auStack_38._0_2_,(int)auStack_34._0_2_);
    sub_080003F0();
    iVar4 = iVar4 + 10;
  } while (iVar4 < 0x401);
  iVar4 = sub_0800CE30();
  if (iVar4 == 0) {
    pbVar5 = (byte *)(*(int *)DWORD_0804225c + 0x1b8);
  }
  else {
    pbVar5 = (byte *)(*(int *)DWORD_08042240 + 0x1c4);
  }
  if ((int)(uint)*pbVar5 >> 7 == 0) {
    while (iVar4 = sub_0805F184(), iVar4 != 0) {
      sub_080003F0();
    }
    while (iVar4 = sub_0805EF90(), iVar4 != 0) {
      sub_080003F0();
    }
    uVar6 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_080422e8);
    while (iVar4 = sub_0805EEFC(uVar6), iVar4 == 0) {
      iVar4 = sub_0800CDF8();
      if (iVar4 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
  }
  else {
    while (iVar4 = sub_0805F184(), iVar4 != 0) {
      sub_080003F0();
    }
    while (iVar4 = sub_0805EF90(), iVar4 != 0) {
      sub_080003F0();
    }
    uVar6 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08042294);
    while (iVar4 = sub_0805EEFC(uVar6), iVar4 == 0) {
      iVar4 = sub_0800CDF8();
      if (iVar4 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
  }
  sVar3 = *(short *)(DWORD_08042388 + 0x80);
  sVar1 = *(short *)(DWORD_08042388 + 0x82);
  iVar4 = 0;
  do {
    sub_080659F4(puStack_28,(int)sVar3,0,iVar4);
    sub_080659F4(puStack_24,(int)sVar1,0,iVar4);
    sub_0800BB80((int)auStack_30._0_2_,(int)auStack_2c._0_2_);
    sub_080003F0();
    iVar4 = iVar4 + 0x22;
  } while (iVar4 < 0x401);
  iVar4 = sub_080020F4();
  iVar4 = iVar4 * 0x14c + DWORD_0804238c;
  *(uint *)(iVar4 + 0x30) = *(uint *)(iVar4 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


