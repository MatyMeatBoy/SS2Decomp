
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_0801ACB8(void)

{
  dword dVar1;
  undefined1 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined2 *puVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint uVar8;
  int iVar9;
  undefined4 in_lr;
  undefined2 uStack_40;
  undefined2 uStack_3e;
  undefined4 uStack_3c;
  undefined1 uStack_38;
  short *psStack_30;
  short *psStack_2c;
  short *psStack_28;
  undefined2 *puStack_24;
  
  iVar9 = *(int *)DWORD_0801ad08;
  iVar3 = sub_080020F4();
  iVar3 = iVar3 * 0x14c + DWORD_0801ad0c;
  puVar4 = (undefined4 *)((uint)*(ushort *)(iVar9 + 10) * 0x20 + DWORD_0801ad10);
  uVar6 = puVar4[1];
  uVar7 = puVar4[2];
  *(undefined4 *)(iVar9 + 0x10) = *puVar4;
  *(undefined4 *)(iVar9 + 0x14) = uVar6;
  *(undefined4 *)(iVar9 + 0x18) = uVar7;
  uVar6 = puVar4[4];
  uVar7 = puVar4[5];
  *(undefined4 *)(iVar9 + 0x1c) = puVar4[3];
  *(undefined4 *)(iVar9 + 0x20) = uVar6;
  *(undefined4 *)(iVar9 + 0x24) = uVar7;
  uVar6 = puVar4[7];
  *(undefined4 *)(iVar9 + 0x28) = puVar4[6];
  *(undefined4 *)(iVar9 + 0x2c) = uVar6;
  uVar2 = sub_0801DE60(puVar4 + 8,iVar9 + 0x30);
  uVar6 = _UNK_0801b130;
  switch(uVar2) {
  case 0:
    sub_0805D064(_UNK_0801ad80,0);
    sub_0805D064(_UNK_0801ad84,1);
    sub_0805D064(_UNK_0801ad88,2);
    sub_0807BEA0(4,0,_UNK_0801ad8c);
    sub_0807BEA0(2,0,_UNK_0801ad90);
    sub_0807BEA0(3,0,_UNK_0801ad94);
    sub_0807BEA0(5,0,_UNK_0801ad98);
    uVar6 = _UNK_0801ad9c;
    break;
  case 1:
    sub_0805D064(_UNK_0801aeac,0);
    sub_0805D064(_UNK_0801aeb0,1);
    sub_0805D064(_UNK_0801aeb4,2);
    sub_0807BEA0(4,0,_UNK_0801aeb8);
    sub_0807BEA0(2,0,_UNK_0801aebc);
    sub_0807BEA0(3,0,_UNK_0801aec0);
    sub_0807BEA0(5,0,_UNK_0801aec4);
    uVar6 = _UNK_0801aec8;
    break;
  case 2:
    sub_0805D064(_UNK_0801ae48,0);
    sub_0805D064(_UNK_0801ae4c,1);
    sub_0805D064(_UNK_0801ae50,2);
    sub_0807BEA0(4,0,_UNK_0801ae54);
    sub_0807BEA0(2,0,_UNK_0801ae58);
    sub_0807BEA0(3,0,_UNK_0801ae5c);
    sub_0807BEA0(5,0,_UNK_0801ae60);
    uVar6 = _UNK_0801ae64;
    break;
  case 3:
    sub_0805D064(_UNK_0801ade4,0);
    sub_0805D064(_UNK_0801ade8,1);
    sub_0805D064(_UNK_0801adec,2);
    sub_0807BEA0(4,0,_UNK_0801adf0);
    sub_0807BEA0(2,0,_UNK_0801adf4);
    sub_0807BEA0(3,0,_UNK_0801adf8);
    sub_0807BEA0(5,0,_UNK_0801adfc);
    uVar6 = _UNK_0801ae00;
    break;
  case 4:
    sub_0805D064(_UNK_0801af10,0);
    sub_0805D064(_UNK_0801af14,1);
    sub_0805D064(_UNK_0801af18,2);
    sub_0807BEA0(4,0,_UNK_0801af1c);
    sub_0807BEA0(2,0,_UNK_0801af20);
    sub_0807BEA0(3,0,_UNK_0801af24);
    sub_0807BEA0(5,0,_UNK_0801af28);
    uVar6 = _UNK_0801af2c;
    break;
  case 5:
    sub_0805D064(_UNK_0801afd8,0);
    sub_0805D064(_UNK_0801afdc,1);
    sub_0805D064(_UNK_0801afe0,2);
    sub_0807BEA0(4,0,_UNK_0801afe4);
    sub_0807BEA0(2,0,_UNK_0801afe8);
    sub_0807BEA0(3,0,_UNK_0801afec);
    sub_0807BEA0(5,0,_UNK_0801aff0);
    uVar6 = _UNK_0801aff4;
    break;
  case 6:
    sub_0805D064(_UNK_0801af74,0);
    sub_0805D064(_UNK_0801af78,1);
    sub_0805D064(_UNK_0801af7c,2);
    sub_0807BEA0(4,0,_UNK_0801af80);
    sub_0807BEA0(2,0,_UNK_0801af84);
    sub_0807BEA0(3,0,_UNK_0801af88);
    sub_0807BEA0(5,0,_UNK_0801af8c);
    uVar6 = _UNK_0801af90;
    break;
  case 7:
    sub_0805D064(_UNK_0801b044,0);
    sub_0805D064(_UNK_0801b048,1);
    sub_0805D064(_UNK_0801b04c,2);
    sub_0807BEA0(4,0,_UNK_0801b050);
    sub_0807BEA0(2,0,_UNK_0801b054);
    sub_0807BEA0(3,0,_UNK_0801b058);
    sub_0807BEA0(5,0,_UNK_0801b05c);
    uVar6 = _UNK_0801b060;
    break;
  case 8:
    sub_0805D064(_UNK_0801b130,0);
    sub_0805D064(uVar6,1);
    sub_0805D064(uVar6,2);
    sub_0807BEA0(4,0,_UNK_0801b134);
    sub_0807BEA0(2,0,_UNK_0801b138);
    sub_0807BEA0(3,0,_UNK_0801b13c);
    sub_0807BEA0(5,0,_UNK_0801b140);
    sub_0807BEA0(6,0,_UNK_0801b144);
  default:
    goto LAB_0801b0b0;
  }
  sub_0807BEA0(6,0,uVar6);
LAB_0801b0b0:
  sub_0805AD78(0);
  sub_0805D094();
  sub_0805D0E8();
  sub_0805D13C();
  sub_0805D190();
  sub_0805D1E0();
  dVar1 = DWORD_0801b148;
  uVar8 = 0;
  puStack_24 = (undefined2 *)(iVar9 + 0x68);
  psStack_30 = (short *)(iVar3 + 0xc2);
  psStack_2c = (short *)(iVar3 + 0xc4);
  psStack_28 = (short *)(iVar3 + 0x62);
  do {
    puVar5 = (undefined2 *)(uVar8 * 4 + dVar1);
    uStack_3e = puVar5[1];
    uStack_40 = *puVar5;
    uStack_3c = 0;
    uStack_38 = 0;
    sub_0805CFF8(uVar8,&uStack_40);
    uVar8 = uVar8 + 1 & 0xff;
  } while (uVar8 < 5);
  sub_0805CFF8(0x18,DWORD_0801b14c);
  uVar6 = sub_0802A9B0();
  switch(uVar6) {
  case 0:
    *(short *)(iVar9 + 0x12) = *(short *)(iVar9 + 0x12) + 5;
    break;
  case 1:
    *(short *)(iVar9 + 0x24) = *(short *)(iVar9 + 0x24) + 0x1e;
    break;
  case 2:
    uStack_40 = 6;
    uStack_3e = 0x5e;
    goto code_r0x0801b1fe;
  case 3:
    uStack_40 = 5;
    uStack_3e = 0x21;
    goto code_r0x0801b1fe;
  case 4:
    *(short *)(iVar9 + 0x10) = *(short *)(iVar9 + 0x10) + 5;
    break;
  case 5:
    *(short *)(iVar9 + 0x26) = *(short *)(iVar9 + 0x26) + 0x1e;
    break;
  case 6:
    *(short *)(iVar9 + 0x16) = *(short *)(iVar9 + 0x16) + 5;
    break;
  case 7:
    *(short *)(iVar9 + 0x2e) = *(short *)(iVar9 + 0x2e) + 0x1e;
    break;
  case 8:
    uStack_40 = 4;
    uStack_3e = 0x95;
    goto code_r0x0801b1fe;
  case 9:
    *(short *)(iVar9 + 0x2a) = *(short *)(iVar9 + 0x2a) + 0x1e;
    break;
  case 10:
    *(short *)(iVar9 + 0x2c) = *(short *)(iVar9 + 0x2c) + 0x1e;
    break;
  case 0xb:
    uStack_40 = 6;
    uStack_3e = 0x5f;
code_r0x0801b1fe:
    uStack_38 = 0;
    uStack_3c = 0;
    sub_0805AB20();
    break;
  case 0xc:
    *(short *)(iVar9 + 0x14) = *(short *)(iVar9 + 0x14) + 5;
    *(short *)(iVar9 + 0x28) = *(short *)(iVar9 + 0x28) + 0x1e;
  }
  *puStack_24 = 0;
  sub_0801E024(iVar3);
  if (*(short *)(iVar3 + 0x60) < *psStack_30) {
    *psStack_30 = *(short *)(iVar3 + 0x60);
  }
  if (*psStack_28 < *psStack_2c) {
    *psStack_2c = *psStack_28;
  }
  return in_lr;
}


