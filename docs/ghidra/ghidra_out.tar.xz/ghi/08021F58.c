
undefined4 sub_08021F58(int param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  uVar4 = 0;
  uVar1 = *(uint *)DWORD_08021fd4 & 1;
  while( true ) {
    if (uVar1 == 0) {
      if (uVar4 < 0x20) {
        iVar3 = *(int *)DWORD_08021fd8 + uVar4 * 0x28;
        *(dword *)(iVar3 + 0xc) = DWORD_08021fdc;
        iVar2 = sub_08001494(0x400);
        *(int *)(iVar3 + 0x20) = iVar2;
        if (iVar2 != 0) {
          *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
          *(undefined4 *)(iVar3 + 8) = 0x46;
          *(undefined4 *)(iVar3 + 0x24) = 0;
          sub_08000274(iVar3,param_1 >> 8 | (param_2 >> 8) << 0x10,uVar4);
          *(uint *)DWORD_08021fd4 = *(uint *)DWORD_08021fd4 | 1 << (uVar4 & 0xff);
        }
      }
      return in_lr;
    }
    uVar4 = uVar4 + 1;
    if (0x1f < uVar4) break;
    uVar1 = *(uint *)DWORD_08021fd4 & 1 << (uVar4 & 0xff);
  }
  return in_lr;
}


