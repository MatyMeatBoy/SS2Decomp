
undefined4 sub_0809D7E4(void)

{
  dword dVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  dVar1 = DWORD_0809d80c;
  uVar2 = sub_08001494(0x50);
  *(undefined4 *)dVar1 = uVar2;
  uVar4 = 0;
  iVar3 = 0;
  do {
    *(undefined4 *)(iVar3 + *(int *)dVar1 + 8) = 0;
    iVar3 = iVar3 + 0x28;
    uVar4 = uVar4 + 1;
  } while (uVar4 < 2);
  return in_lr;
}


