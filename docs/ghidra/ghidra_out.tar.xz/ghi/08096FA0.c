
undefined4 sub_08096FA0(undefined1 param_1)

{
  bool bVar1;
  dword dVar2;
  undefined1 uVar3;
  int iVar4;
  uint uVar5;
  uint unaff_r10;
  undefined4 in_lr;
  undefined4 auStack_60 [2];
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined1 uStack_44;
  undefined1 uStack_43;
  undefined2 uStack_2c;
  undefined2 uStack_2a;
  short sStack_28;
  short sStack_26;
  uint uStack_24;
  
  sub_08065158(auStack_60,DWORD_080970bc,8,0xffffffff,1);
  uStack_44 = 7;
  uStack_43 = 8;
  uStack_2a = 0;
  uStack_2c = 0;
  uStack_24 = 0;
  sub_0805865C(DWORD_080970c0);
  dVar2 = DWORD_080970c4;
  do {
    do {
      iVar4 = sub_0800CD8C();
      if (iVar4 == 0) {
        uVar5 = sub_08065370(auStack_60,param_1,&uStack_2c,&uStack_2a,0);
        unaff_r10 = uVar5 & 0xffff;
      }
      iVar4 = sub_0800CCCC();
      if ((((iVar4 == 0) && (iVar4 = sub_0800CC98(), iVar4 == 0)) &&
          (iVar4 = sub_0800CD8C(), iVar4 == 0)) && (iVar4 = sub_0800CD34(), iVar4 == 0)) {
        sub_08000AF0(0x17,uStack_54,2);
        uVar3 = sub_0800BC44(*(int *)dVar2 >> 8,*(int *)(dVar2 + 4) >> 8,0);
        sub_0800BC08((*(int *)dVar2 << 8) >> 0x10,(*(int *)(dVar2 + 4) << 8) >> 0x10,&sStack_28,
                     &sStack_26,0,0);
        iVar4 = sub_08007870((int)sStack_28,0,param_1,uStack_2c,uVar3,&uStack_44,uStack_58,
                             auStack_60[0]);
        *(int *)(iVar4 + 0xc) = (int)sStack_26;
      }
      sub_080003F0();
    } while (unaff_r10 == 0);
    bVar1 = 0x3b < uStack_24;
    uStack_24 = uStack_24 + 1 & 0xffff;
  } while (bVar1);
  *(undefined4 *)(*(int *)DWORD_080970c8 + 8) = 0;
  return in_lr;
}


