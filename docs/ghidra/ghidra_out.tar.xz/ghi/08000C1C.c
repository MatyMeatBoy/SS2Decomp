
void sub_08000C1C(void)

{
  dword dVar1;
  dword dVar2;
  undefined1 auStack_4 [4];
  
  dVar1 = DWORD_08000c44;
  *(undefined1 **)DWORD_08000c44 = auStack_4;
  dVar2 = DWORD_08000c48;
  *(dword *)(dVar1 + 4) = DWORD_08000c48;
  *(dword *)(dVar1 + 8) = DWORD_08000c4c;
  *(undefined2 *)(dVar2 + 0x14) = 0x100;
  *(undefined2 *)(dVar2 + 0x10) = 0x100;
  *(undefined2 *)(dVar2 + 0x24) = 0x100;
  *(undefined2 *)(dVar2 + 0x20) = 0x100;
  return;
}


