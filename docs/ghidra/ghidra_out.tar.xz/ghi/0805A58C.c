
undefined8 sub_0805A58C(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_lr;
  
  iVar2 = *(int *)DWORD_0805a5a0 + DWORD_0805a5a4;
  uVar3 = 0;
  iVar1 = param_1;
  while( true ) {
    if (0x1d < uVar3) goto LAB_0805a600;
    iVar1 = sub_08000470(iVar2);
    if (iVar1 == 0) break;
    uVar3 = uVar3 + 1;
    iVar2 = iVar2 + 0x28;
  }
  *(ushort *)(*(int *)DWORD_0805a5cc + 4) = *(ushort *)(*(int *)DWORD_0805a5cc + 4) | 0x80;
  while( true ) {
    iVar1 = sub_08001494(0x400);
    *(int *)(iVar2 + 0x20) = iVar1;
    if (iVar1 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar2 + 8) = 0x3c;
  *(undefined4 *)(iVar2 + 0xc) = param_2;
  *(int *)(iVar2 + 0x10) = iVar1 + 0x3fc;
  *(dword *)(iVar2 + 0x24) = DWORD_0805a608;
  sub_08000274(iVar2,param_1);
  iVar1 = iVar2;
LAB_0805a600:
  return CONCAT44(in_lr,iVar1);
}


