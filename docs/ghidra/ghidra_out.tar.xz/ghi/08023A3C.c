
undefined4 sub_08023A3C(int *param_1,uint param_2)

{
  ushort uVar1;
  dword dVar2;
  char cVar3;
  bool bVar4;
  ushort uVar5;
  uint uVar6;
  int iVar7;
  ushort *puVar8;
  int *piVar9;
  byte *pbVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  undefined4 in_lr;
  byte abStack_64 [4];
  byte abStack_60 [2];
  undefined2 auStack_5e [23];
  int *piStack_30;
  int iStack_2c;
  uint uStack_28;
  int *piStack_24;
  
  pbVar10 = abStack_64;
  uVar6 = param_2 & 0xffff;
  uStack_28 = 0;
  iStack_2c = 0;
  uVar13 = 0;
  piStack_30 = param_1;
  do {
    dVar2 = DWORD_08023b1c;
    if ((short)param_1[2] != 0) {
      uStack_28 = uStack_28 + 1;
      iVar7 = *(int *)DWORD_08023b1c;
      *(undefined4 *)pbVar10 = *(undefined4 *)(iVar7 + DWORD_08023b20 + uVar6 * 4);
      *(undefined2 *)((int)pbVar10 + 6) = *(undefined2 *)(iVar7 + 8);
      *(char *)((int)pbVar10 + 5) = (char)uVar6;
      iVar11 = (uVar13 & 0xff) + (param_2 & 0xff) * 5;
      if ((*(char *)(iVar7 + 0x1c8 + iVar11) != '\x03') &&
         (piStack_24 = param_1, iVar7 = sub_08002204(), param_1 = piStack_24, iVar7 != 0)) {
        *(undefined1 *)(*(int *)dVar2 + 0x1c8 + iVar11) = 1;
      }
    }
    pbVar10 = (byte *)((int)pbVar10 + 8);
    param_1 = param_1 + 2;
    uVar13 = uVar13 + 1;
  } while (uVar13 < 5);
  uVar13 = 0;
  if (uStack_28 != 0) {
    pbVar10 = abStack_60;
    do {
      *pbVar10 = (byte)uVar13;
      cVar3 = sub_080008C8();
      if (cVar3 == -0x80) {
        *pbVar10 = *pbVar10 | 0x80;
      }
      pbVar10 = pbVar10 + 8;
      uVar13 = uVar13 + 1;
    } while (uVar13 < uStack_28);
  }
  iVar7 = *(int *)DWORD_08023b1c;
  uVar5 = *(short *)(iVar7 + 8) + 5;
  *(ushort *)(iVar7 + 8) = uVar5;
  if (0xfa < uVar5) {
    *(undefined2 *)(iVar7 + 8) = 9;
  }
  do {
    if (**(short **)DWORD_08023db0 != 0xb) {
LAB_08023e66:
      do {
        sub_080003F0();
        iVar7 = sub_08056E90();
        if (iVar7 != 0) break;
        if ((*(uint *)DWORD_08023de4 & 1) == (param_2 & 1)) {
          uVar5 = *(ushort *)(piStack_30 + 1);
          uVar1 = *(ushort *)((int)piStack_30 + 6);
          uVar13 = sub_08002164();
          bVar4 = false;
          iVar7 = sub_08019FA8();
          if (iVar7 == 0) goto LAB_08023e66;
          uVar12 = 0;
          if (uVar13 != 0) {
            do {
              iVar7 = uVar12 * 0x14c + DWORD_08023e5c;
              puVar8 = *(ushort **)(iVar7 + 0x148);
              if (((puVar8[2] & 0x20) == 0) && ((*(uint *)(iVar7 + 0x30) & 0x2000) == 0)) {
                iVar7 = (int)(short)*piStack_30 - (uint)(*puVar8 >> 7);
                if (iVar7 < 0) {
                  iVar7 = -iVar7;
                }
                if (iVar7 < (int)(uint)uVar5) {
                  iVar7 = (int)*(short *)((int)piStack_30 + 2) - (((uint)puVar8[1] << 0x14) >> 0x17)
                  ;
                  if (iVar7 < 0) {
                    iVar7 = -iVar7;
                  }
                  if (iVar7 < (int)(uint)uVar1) {
                    bVar4 = true;
                    break;
                  }
                }
              }
              uVar12 = uVar12 + 1;
            } while (uVar12 < uVar13);
          }
        }
        else {
          bVar4 = false;
        }
      } while (!bVar4);
    }
    iVar7 = sub_08056E90();
    if (iVar7 != 0) break;
    if ((short)piStack_30[0xc] == 0) {
      while( true ) {
        while ((iVar7 = sub_08019FA8(), iVar7 == 0 && (iVar7 = sub_08056E90(), iVar7 == 0))) {
          sub_080003F0();
        }
        iVar7 = sub_08056E90();
        if ((iVar7 == 0) && (uVar13 = 0, uStack_28 != 0)) {
          piVar9 = (int *)DWORD_08023bc8;
          do {
            iVar7 = (uVar13 & 0xff) + (param_2 & 0xff) * 5;
            if (((*(char *)(*piVar9 + 0x1c8 + iVar7) == '\x01') &&
                (piStack_24 = piVar9, iVar11 = sub_0806603C(abStack_60 + uVar13 * 8 + -4),
                piVar9 = piStack_24, iVar11 != 0)) &&
               (iVar11 = sub_08002204(), piVar9 = piStack_24, iVar11 != 0)) {
              *(undefined1 *)(*piStack_24 + 0x1c8 + iVar7) = 2;
            }
            uVar13 = uVar13 + 1;
          } while (uVar13 < uStack_28);
        }
        iVar7 = sub_08056E90();
        if (iVar7 != 0) break;
        uVar13 = 0;
        while (*(char *)(*(int *)DWORD_08023c1c + 0x1c8 + (uVar13 & 0xff) + (param_2 & 0xff) * 5) !=
               '\x02') {
          uVar13 = uVar13 + 1;
          if (4 < uVar13) goto LAB_08023c26;
        }
        sub_080003F0();
      }
      while (iVar7 = sub_08067C28(*(int *)DWORD_08023be8 + uVar6 * 4 + DWORD_08023be4), iVar7 == 0)
      {
        sub_080003F0();
      }
LAB_08023c26:
      uVar13 = 0;
      do {
        cVar3 = *(char *)(*(int *)DWORD_08023c68 + 0x1c8 + (uVar13 & 0xff) + (param_2 & 0xff) * 5);
        if ((cVar3 == '\x02') || (cVar3 == '\x01')) {
          iStack_2c = 0;
          goto LAB_08023d96;
        }
        uVar13 = uVar13 + 1;
      } while (uVar13 < 5);
      iStack_2c = 1;
    }
    else if (((short)piStack_30[0xc] == 1) && (uVar13 = 0, uStack_28 != 0)) {
      do {
        while ((iVar7 = sub_08019FA8(), iVar7 == 0 && (iVar7 = sub_08056E90(), iVar7 == 0))) {
          sub_080003F0();
        }
        iVar7 = sub_08056E90();
        if ((iVar7 == 0) &&
           (*(char *)(*(int *)DWORD_08023cd4 + 0x1c8 + (uVar13 & 0xff) + (param_2 & 0xff) * 5) !=
            '\x03')) {
          while ((iVar7 = sub_0806603C(abStack_60 + uVar13 * 8 + -4), iVar7 == 0 &&
                 (iVar7 = sub_08056E90(), iVar7 == 0))) {
            sub_080003F0();
          }
          iVar7 = sub_08056E90();
          if (iVar7 == 0) {
            iVar7 = sub_08002204();
            if (iVar7 != 0) {
              *(undefined1 *)
               (*(int *)DWORD_08023d28 + 0x1c8 + (uVar13 & 0xff) + (param_2 & 0xff) * 5) = 2;
            }
          }
        }
        dVar2 = DWORD_08023d28;
        while (iVar7 = sub_08056E90(), iVar7 == 0) {
          cVar3 = *(char *)(*(int *)dVar2 + 0x1c8 + (uVar13 & 0xff) + (param_2 & 0xff) * 5);
          if (cVar3 == '\x01') {
            iStack_2c = 0;
            uVar13 = uStack_28;
            goto LAB_08023d8c;
          }
          if (cVar3 == '\x03') {
            iStack_2c = 1;
            goto LAB_08023d8c;
          }
          sub_080003F0();
        }
        while (iVar7 = sub_08067C28(*(int *)dVar2 + uVar6 * 4 + DWORD_08023dac), uVar13 = uStack_28,
              iVar7 == 0) {
          sub_080003F0();
        }
LAB_08023d8c:
        uVar13 = uVar13 + 1;
      } while (uVar13 < uStack_28);
    }
LAB_08023d96:
    sub_080003F0();
  } while (iStack_2c != 1);
  dVar2 = DWORD_08023eb8;
  iVar7 = *(int *)DWORD_08023eb8;
  uVar5 = *(short *)(iVar7 + 10) - 1;
  *(ushort *)(iVar7 + 10) = uVar5;
  if ((uVar5 & 0x8000) != 0) {
    *(undefined2 *)(iVar7 + 10) = 0;
  }
  if ((((*(short *)(*(int *)dVar2 + 10) == 0) && (iVar7 = sub_08056E50(), iVar7 == 0)) &&
      (iVar7 = sub_08056FF8(), iVar7 == 0)) && (**(short **)dVar2 != 0xb)) {
    while (iVar7 = sub_08067EC8(), iVar7 == 0) {
      sub_080003F0();
    }
  }
  return in_lr;
}


