
undefined4 sub_0802D2C8(void)

{
  dword dVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  undefined4 in_lr;
  
  uVar2 = sub_080289C0(0x2c,0x79,0x186);
  dVar1 = DWORD_0802d2e8;
  iVar5 = *(int *)DWORD_0802d2ec + DWORD_0802d2f0;
  for (uVar6 = 0; uVar6 < 0x1e; uVar6 = uVar6 + 1) {
    iVar3 = sub_08000470(iVar5);
    if (iVar3 == 0) goto LAB_0802d30c;
    iVar5 = iVar5 + 0x28;
  }
LAB_0802d336:
  iVar5 = sub_080289C0(0x15,0x138,0x1a6);
  piVar4 = (int *)(*(int *)DWORD_0802d4f0 + DWORD_0802d4f4);
  uVar6 = 0;
  do {
    if (*piVar4 == iVar5) goto LAB_0802d366;
    uVar6 = uVar6 + 1;
    piVar4 = piVar4 + 0x1c;
  } while (uVar6 < 0xf);
  sub_080003F0();
  piVar4 = (int *)0x0;
LAB_0802d366:
  if (piVar4 != (int *)0x0) {
    *(undefined2 *)(piVar4 + 6) = 8;
    *(undefined2 *)((int)piVar4 + 0x1a) = 4;
    piVar4[0xf] = piVar4[0xf] | 0x10;
  }
  dVar1 = DWORD_0802d4f8;
  piVar4 = (int *)(*(int *)DWORD_0802d4f0 + DWORD_0802d4f4);
  uVar6 = 0;
  do {
    if (*piVar4 == iVar5) goto LAB_0802d39c;
    uVar6 = uVar6 + 1;
    piVar4 = piVar4 + 0x1c;
  } while (uVar6 < 0xf);
  sub_080003F0();
  piVar4 = (int *)0x0;
LAB_0802d39c:
  if (piVar4 != (int *)0x0) {
    piVar4[0x11] = dVar1;
  }
  iVar5 = sub_080289C0(DWORD_0802d4fc,0xa3,DWORD_0802d500);
  piVar4 = (int *)(*(int *)DWORD_0802d4f0 + DWORD_0802d4f4);
  uVar6 = 0;
  do {
    if (*piVar4 == iVar5) goto LAB_0802d3ce;
    uVar6 = uVar6 + 1;
    piVar4 = piVar4 + 0x1c;
  } while (uVar6 < 0xf);
  sub_080003F0();
  piVar4 = (int *)0x0;
LAB_0802d3ce:
  if (piVar4 != (int *)0x0) {
    *(undefined2 *)(piVar4 + 6) = 8;
    *(undefined2 *)((int)piVar4 + 0x1a) = 4;
    piVar4[0xf] = piVar4[0xf] | 0x10;
  }
  dVar1 = DWORD_0802d504;
  piVar4 = (int *)(*(int *)DWORD_0802d4f0 + DWORD_0802d4f4);
  uVar6 = 0;
  do {
    if (*piVar4 == iVar5) goto LAB_0802d404;
    uVar6 = uVar6 + 1;
    piVar4 = piVar4 + 0x1c;
  } while (uVar6 < 0xf);
  sub_080003F0();
  piVar4 = (int *)0x0;
LAB_0802d404:
  if (piVar4 != (int *)0x0) {
    piVar4[0x11] = dVar1;
  }
  iVar5 = sub_080289C0(0x47,0x5a,0x1a6);
  piVar4 = (int *)(*(int *)DWORD_0802d4f0 + DWORD_0802d4f4);
  uVar6 = 0;
  do {
    if (*piVar4 == iVar5) goto LAB_0802d436;
    uVar6 = uVar6 + 1;
    piVar4 = piVar4 + 0x1c;
  } while (uVar6 < 0xf);
  sub_080003F0();
  piVar4 = (int *)0x0;
LAB_0802d436:
  if (piVar4 != (int *)0x0) {
    *(undefined2 *)(piVar4 + 6) = 8;
    *(undefined2 *)((int)piVar4 + 0x1a) = 4;
    piVar4[0xf] = piVar4[0xf] | 0x10;
  }
  dVar1 = DWORD_0802d508;
  piVar4 = (int *)(*(int *)DWORD_0802d4f0 + DWORD_0802d4f4);
  uVar6 = 0;
  do {
    if (*piVar4 == iVar5) goto LAB_0802d46a;
    uVar6 = uVar6 + 1;
    piVar4 = piVar4 + 0x1c;
  } while (uVar6 < 0xf);
  sub_080003F0();
  piVar4 = (int *)0x0;
LAB_0802d46a:
  if (piVar4 != (int *)0x0) {
    piVar4[0x11] = dVar1;
  }
  iVar5 = sub_080289C0(DWORD_0802d50c,0x39,DWORD_0802d510);
  piVar4 = (int *)(*(int *)DWORD_0802d4f0 + DWORD_0802d4f4);
  uVar6 = 0;
  do {
    if (*piVar4 == iVar5) goto LAB_0802d49a;
    uVar6 = uVar6 + 1;
    piVar4 = piVar4 + 0x1c;
  } while (uVar6 < 0xf);
  sub_080003F0();
  piVar4 = (int *)0x0;
LAB_0802d49a:
  if (piVar4 != (int *)0x0) {
    *(undefined2 *)(piVar4 + 6) = 8;
    *(undefined2 *)((int)piVar4 + 0x1a) = 4;
    piVar4[0xf] = piVar4[0xf] | 0x10;
  }
  dVar1 = DWORD_0802d514;
  piVar4 = (int *)(*(int *)DWORD_0802d4f0 + DWORD_0802d4f4);
  uVar6 = 0;
  do {
    if (*piVar4 == iVar5) goto LAB_0802d4ce;
    uVar6 = uVar6 + 1;
    piVar4 = piVar4 + 0x1c;
  } while (uVar6 < 0xf);
  sub_080003F0();
  piVar4 = (int *)0x0;
LAB_0802d4ce:
  if (piVar4 != (int *)0x0) {
    piVar4[0x11] = dVar1;
  }
  iVar5 = sub_0800CC98();
  if (iVar5 == 0) {
    iVar5 = sub_0801AB24();
    if (iVar5 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar5 < 2) {
      if (iVar5 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar5 == 2) {
      sub_0801AB90(6);
    }
    while (iVar5 = sub_0801AAE0(), iVar5 == 0) {
      sub_080003F0();
    }
  }
  return in_lr;
LAB_0802d30c:
  while( true ) {
    iVar3 = sub_08001494(0x400);
    *(int *)(iVar5 + 0x20) = iVar3;
    if (iVar3 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar5 + 8) = 0x3c;
  *(dword *)(iVar5 + 0xc) = dVar1;
  *(int *)(iVar5 + 0x10) = iVar3 + 0x3fc;
  *(undefined4 *)(iVar5 + 0x24) = 0;
  sub_08000274(iVar5,uVar2);
  goto LAB_0802d336;
}


