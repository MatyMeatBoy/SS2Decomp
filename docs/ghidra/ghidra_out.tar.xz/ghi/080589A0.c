
undefined4 sub_080589A0(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 in_lr;
  
  iVar1 = sub_0800CE30();
  if (iVar1 == 0) {
    iVar1 = *(int *)DWORD_080589d4 + 0xd0;
  }
  else {
    iVar1 = *(int *)DWORD_080589bc + 0x120;
  }
  *(undefined4 *)(iVar1 + param_1 * 4) = param_2;
  return in_lr;
}


