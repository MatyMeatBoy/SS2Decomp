
undefined4 sub_08090E38(void)

{
  short sVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  dword dVar5;
  undefined4 *puVar6;
  uint uVar7;
  int unaff_r9;
  undefined4 in_lr;
  undefined4 uStack_28;
  
  dVar5 = DWORD_08090e7c;
  puVar2 = (undefined4 *)sub_08001494(0x44);
  *(undefined4 **)dVar5 = puVar2;
  sVar1 = sub_0800086C();
  sVar1 = __modsi3((int)sVar1,3);
  uVar3 = (uint)sVar1;
  if ((int)uVar3 < 0) {
    uVar3 = -uVar3;
  }
  uVar3 = uVar3 & 0xff;
  dVar5 = DWORD_08090ea8;
  if (uVar3 != 1) {
    if (1 < uVar3) {
      if (uVar3 == 2) {
        sub_08065158(puVar2,DWORD_08090efc,0,0xffffffff,0);
      }
      goto LAB_08090ebe;
    }
    dVar5 = DWORD_08090e90;
    if (uVar3 != 0) goto LAB_08090ebe;
  }
  sub_08065158(puVar2,dVar5,0,0xffffffff,0);
LAB_08090ebe:
  *(undefined1 *)(puVar2 + 7) = 0;
  *(undefined2 *)(puVar2 + 0xf) = 10;
  puVar6 = puVar2 + 0x10;
  *(undefined2 *)puVar6 = 0;
  *(undefined2 *)((int)puVar2 + 0x3e) = 0;
  puVar2[0xd] = 0x10000;
  puVar2[0xe] = 0x5800;
  uStack_28 = 1;
  sVar1 = 0;
  uVar7 = 0;
  if (*(int *)DWORD_08090f00 != 0) {
    do {
      if (uVar7 == 1) {
        if (unaff_r9 != 0) {
          dVar5 = DWORD_08090fd0;
          if (uVar3 == 1) {
LAB_08090fc4:
            sub_08065158(puVar2,dVar5,0,0xffffffff,0);
          }
          else if (uVar3 < 2) {
            dVar5 = DWORD_08090fb8;
            if (uVar3 == 0) goto LAB_08090fc4;
          }
          else if (uVar3 == 2) {
            sub_08065158(puVar2,DWORD_08090ffc,0,0xffffffff,0);
          }
          uStack_28 = 1;
          *(undefined2 *)(puVar2 + 0xf) = 10;
          *(undefined2 *)puVar6 = 0;
          *(undefined2 *)((int)puVar2 + 0x3e) = 0;
          uVar7 = 2;
        }
      }
      else if (uVar7 < 2) {
        if ((uVar7 == 0) &&
           (iVar4 = puVar2[0xd] + DWORD_08090f34, puVar2[0xd] = iVar4, iVar4 < 0x8001)) {
          dVar5 = DWORD_08090f60;
          if (uVar3 == 1) {
LAB_08090f52:
            sub_08065158(puVar2,dVar5,0,0xffffffff,0);
          }
          else if (uVar3 < 2) {
            dVar5 = DWORD_08090f48;
            if (uVar3 == 0) goto LAB_08090f52;
          }
          else if (uVar3 == 2) {
            sub_08065158(puVar2,DWORD_08090f90,0,0xffffffff,0);
          }
          uStack_28 = 0;
          *(undefined1 *)(puVar2 + 7) = 0;
          *(undefined2 *)(puVar2 + 0xf) = 10;
          *(undefined2 *)puVar6 = 0;
          *(undefined2 *)((int)puVar2 + 0x3e) = 0;
          uVar7 = 1;
        }
      }
      else if (uVar7 == 2) {
        iVar4 = puVar2[0xd] + DWORD_08091018;
        puVar2[0xd] = iVar4;
        if (iVar4 <= (int)DWORD_0809101c) {
          sVar1 = 0;
          uVar7 = 6;
        }
      }
      else if ((uVar7 == 6) && (sVar1 = sVar1 + 1, sVar1 == 0x3d)) {
        uVar7 = 0xff;
      }
      sub_08000AF0(0x10,puVar2[3],1);
      unaff_r9 = sub_08065370(puVar2,*(undefined2 *)(puVar2 + 0xf),(int)puVar2 + 0x3e,puVar6,
                              uStack_28);
      sub_08007870((int)puVar2[0xd] >> 8,(int)puVar2[0xe] >> 8,*(undefined2 *)(puVar2 + 0xf),
                   *(undefined2 *)((int)puVar2 + 0x3e),0,puVar2 + 7,puVar2[2],*puVar2);
      sub_080003F0();
      dVar5 = DWORD_080910a4;
    } while ((uVar7 != 0xff) && (*(int *)DWORD_080910a4 != 0));
    if (*(int *)DWORD_080910a4 != 0) {
      sub_08001538();
      *(undefined4 *)dVar5 = 0;
    }
  }
  return in_lr;
}


