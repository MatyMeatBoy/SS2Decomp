
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_080B0288(byte *param_1)

{
  bool bVar1;
  dword dVar2;
  dword dVar3;
  byte bVar4;
  undefined1 uVar5;
  char cVar6;
  undefined2 uVar7;
  short sVar8;
  int iVar9;
  undefined4 uVar10;
  ushort uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint *puVar15;
  byte *pbVar16;
  int iVar17;
  undefined4 *unaff_r9;
  undefined4 in_lr;
  undefined4 auStack_f0 [13];
  undefined4 auStack_bc [13];
  undefined4 auStack_88 [2];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined1 auStack_6c [24];
  short sStack_54;
  short sStack_52;
  byte *pbStack_50;
  int iStack_4c;
  uint uStack_48;
  int iStack_44;
  dword dStack_40;
  undefined4 uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  int iStack_2c;
  byte *pbStack_28;
  byte *pbStack_24;
  
  *(byte **)DWORD_080b040c = param_1;
  pbStack_50 = param_1 + 0x204;
  sub_0801623C(param_1,DWORD_080b0410,0);
  sub_08019F60(pbStack_50);
  sub_0801A0A4(param_1);
  sub_08065158(auStack_f0,DWORD_080b0414,5,0xffffffff,0);
  sub_08065158(auStack_bc,DWORD_080b0418,5,0xffffffff,0);
  sub_08065158(auStack_88,DWORD_080b041c,5,0xffffffff,0);
  sVar8 = *(short *)(pbStack_50 + 6);
  *(short *)(param_1 + 0x1d6) = sVar8 * 3;
  *(short *)(param_1 + 0x5c) = sVar8 * 3;
  sVar8 = *(short *)(pbStack_50 + 4);
  *(short *)(param_1 + 0x1d4) = sVar8 * 0x14;
  *(short *)(param_1 + 0x5e) = sVar8 * 0x14;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  iStack_44 = 0;
  dStack_40 = DWORD_080b0420;
  uStack_38 = 0;
  uStack_34 = 0;
  param_1[DWORD_080b0424] = 2;
  param_1[0x1fe] = 2;
  pbVar16 = pbStack_50;
  pbVar16[0x28] = 0xb3;
  pbVar16[0x29] = 0;
  iVar9 = sub_08007290(0xb00b3);
  uStack_48 = (uint)*(byte *)(iVar9 + 0x9b);
  pbVar16[0x24] = 2;
  pbVar16[0x25] = 0;
  param_1[DWORD_080b0428] = 0;
  param_1[0x50] = 1;
  dVar2 = DWORD_080b042c;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  param_1[0x53] = 0;
  uVar12 = 0;
  pbVar16 = param_1 + 0x6c;
  pbStack_24 = param_1 + 0x6a;
  pbStack_28 = param_1 + 0x68;
  do {
    uVar14 = 0;
    do {
      *(undefined4 *)((short)uVar14 * 4 + ((int)(uVar12 * 0x10000) >> 0x10) * 0x14c + dVar2) = 0;
      uVar13 = (int)(short)uVar14 + 1;
      uVar14 = uVar13 & 0xffff;
    } while ((int)(uVar13 * 0x10000) >> 0x10 < 5);
    uVar14 = uVar12 * 0x10000 + 0x10000;
    uVar12 = uVar14 >> 0x10;
  } while ((int)uVar14 >> 0x10 < 4);
  pbVar16[0] = 0;
  pbVar16[1] = 0;
  pbStack_24[0] = 0;
  pbStack_24[1] = 0;
  pbStack_28[0] = 0;
  pbStack_28[1] = 0;
  uVar11 = 0;
  sub_08098044();
  sub_08097FE4();
  sub_08097A4C();
  param_1[0x1fc] = param_1[0x1fc] & 0xf0 | *param_1 & 0xf;
  *(undefined2 *)(param_1 + DWORD_080b0430) = *(undefined2 *)(param_1 + 2);
  param_1[0x200] = 0xff;
  iStack_2c = 0;
  sub_08067C18();
  while (iVar9 = sub_08067C08(), iVar9 == 0) {
    sub_080003F0();
  }
  sub_08067BF8();
  do {
    iVar9 = sub_0800CB78();
    if ((iVar9 != 0) || (iVar9 = sub_08056E90(), iVar9 != 0)) break;
    if ((*(short *)(param_1 + 0xc) == 10) && (uStack_38 == 0)) {
      uStack_38 = 8;
    }
    iVar9 = sub_08058DB0();
    if (iVar9 == 0) {
      sub_0801C8F0(*(undefined4 *)DWORD_080b0484);
      switch(param_1[DWORD_080b0488]) {
      case 1:
        param_1[0xc] = 0;
        param_1[0xd] = 0;
        iVar9 = sub_08067C08();
        if (iVar9 != 0) {
          param_1[_UNK_080b04c8] = param_1[0x1fe];
          sub_08067BF8();
        }
        break;
      case 2:
        iStack_44 = 0;
        iVar9 = sub_08056F78();
        if (iVar9 != 0) {
          bVar4 = 3;
code_r0x080b057c:
          param_1[0x1fe] = bVar4;
          param_1[_UNK_080b058c] = 1;
          sub_08067C18();
        }
        break;
      case 3:
        iStack_44 = 1;
        param_1[0xc] = 1;
        param_1[0xd] = 0;
        iVar9 = sub_08096594(0);
        uVar12 = param_1[0x1fc] & 0xf | iVar9 << 4;
        param_1[0x1fc] = (byte)uVar12;
        cVar6 = sub_08097A74(param_1,((uVar12 << 0x18) >> 0x1c) * 0x14c + _UNK_080b053c,0x140,0x1c);
        if (cVar6 == '\0') {
          param_1[0x1fe] = 4;
          param_1[_UNK_080b0540] = 1;
          sub_08067C18();
        }
        break;
      case 4:
        iStack_44 = 2;
        param_1[0xc] = 2;
        param_1[0xd] = 0;
        if ((*(short *)pbStack_24 == 2) && (*(short *)pbVar16 == 0)) {
          sub_08058CC4(uStack_48);
        }
        if (*(short *)(param_1 + 0x6e) != 0) {
          *(int *)(param_1 + 0x50) = *(int *)(param_1 + 0x50) + 1;
          bVar4 = 5;
          goto code_r0x080b057c;
        }
        break;
      case 5:
        iStack_44 = 0;
        param_1[0xc] = 0;
        param_1[0xd] = 0;
        bVar1 = 0x3c < uVar11;
        uVar11 = uVar11 + 1;
        if (bVar1) {
          uVar11 = 0;
          sub_08097A38(0);
          param_1[_UNK_080b05d4] = 1;
          param_1[0x1fe] = 3;
          sub_08067C18();
        }
      }
    }
    if (iStack_44 == 1) {
      unaff_r9 = auStack_f0;
      *(short *)pbStack_28 = *(short *)(param_1 + 8) + 8;
      uStack_3c = 1;
    }
    else if (iStack_44 < 2) {
      if (iStack_44 == 0) {
        unaff_r9 = auStack_f0;
        *(undefined2 *)pbStack_28 = *(undefined2 *)(param_1 + 8);
        uStack_3c = 1;
      }
    }
    else if (iStack_44 == 2) {
      unaff_r9 = auStack_bc;
      *(undefined2 *)pbStack_28 = *(undefined2 *)(param_1 + 8);
      uStack_3c = 0;
    }
    iVar9 = *(int *)DWORD_080b0658;
    if (dStack_40 != *(ushort *)(iVar9 + 0x68)) {
      dStack_40 = (uint)*(ushort *)(iVar9 + 0x68);
      *(undefined2 *)(iVar9 + 0x6c) = 0;
      *(undefined2 *)(iVar9 + 0x6a) = 0;
    }
    *(undefined1 *)(unaff_r9 + 7) = 5;
    sub_08000AF0(0x15,unaff_r9[3],1);
    uVar12 = sub_08098004();
    if ((uVar12 & 1) == 0) {
      uVar5 = sub_0800BC44(*(int *)(param_1 + 0x14) >> 8,*(int *)(param_1 + 0x18) >> 8,0);
    }
    else {
      uVar5 = sub_08097FF8();
    }
    iVar9 = sub_0800CD8C();
    if (iVar9 == 0) {
      uVar7 = sub_08065370(unaff_r9,*(undefined2 *)pbStack_28,pbStack_24,pbVar16,uStack_3c);
      *(undefined2 *)(param_1 + 0x6e) = uVar7;
    }
    sub_0800BC08((*(int *)(param_1 + 0x14) << 8) >> 0x10,(*(int *)(param_1 + 0x18) << 8) >> 0x10,
                 &sStack_54,&sStack_52,0,0);
    if (uStack_38 == 0) {
      iVar9 = sub_0800CCCC();
      if (((iVar9 == 0) && (iVar9 = sub_0800CC98(), iVar9 == 0)) &&
         (iVar9 = sub_0800CD34(), iVar9 == 0)) {
        sub_08007870((int)sStack_54,(int)sStack_52,*(undefined2 *)pbStack_28,
                     *(undefined2 *)pbStack_24,uVar5,unaff_r9 + 7,unaff_r9[2],*unaff_r9);
      }
    }
    else {
      uVar12 = uStack_38 - 1 & 0xffff;
      uVar14 = uStack_38 & 1;
      uStack_38 = uVar12;
      if (((uVar14 != 0) && (iVar9 = sub_0800CCCC(), iVar9 == 0)) &&
         ((iVar9 = sub_0800CC98(), iVar9 == 0 && (iVar9 = sub_0800CD34(), iVar9 == 0)))) {
        sub_08007870((int)sStack_54,(int)sStack_52,*(undefined2 *)pbStack_28,
                     *(undefined2 *)pbStack_24,uVar5,unaff_r9 + 7,unaff_r9[2],*unaff_r9);
      }
    }
    iVar9 = *(int *)(param_1 + 0x4c);
    if ((iVar9 != 0) && (iStack_4c != iVar9)) {
      uStack_34 = 10;
      uStack_30 = 0;
      iStack_4c = iVar9;
    }
    if (uStack_34 == 0) {
      iStack_4c = 0;
      param_1[0x4c] = 0;
      param_1[0x4d] = 0;
      param_1[0x4e] = 0;
      param_1[0x4f] = 0;
    }
    else {
      iVar9 = sub_0800CC98();
      if (((iVar9 == 0) && (iVar9 = sub_0800CCCC(), iVar9 == 0)) &&
         (iVar9 = sub_0800CD34(), iVar9 == 0)) {
        sub_0801A120(param_1,iStack_4c,(int)(short)uStack_30);
      }
      if ((uStack_34 & 2) != 0) {
        uStack_30 = uStack_30 * 0x10000 + DWORD_080b07ac >> 0x10;
      }
      uStack_34 = uStack_34 - 1 & 0xffff;
    }
    sVar8 = sub_08019CE8(param_1);
    if (sVar8 != 0) {
      iStack_2c = 1;
    }
    sub_08020680(param_1);
    sub_080003F0();
  } while (iStack_2c == 0);
  iVar9 = sub_080020F4();
  puVar15 = (uint *)(iVar9 * 0x14c + DWORD_080b093c + 0x30);
  *puVar15 = *puVar15 | 1;
  dVar2 = DWORD_080b0940;
  auStack_6c[0] = 5;
  iVar9 = *(int *)DWORD_080b0940;
  *(undefined2 *)(iVar9 + 0x6c) = 0;
  *(undefined2 *)(iVar9 + 0x6a) = 0;
  *(undefined2 *)(iVar9 + 0x68) = 0;
  uStack_30 = 0;
  uStack_34 = 10;
  do {
    iVar9 = sub_080020F4();
    puVar15 = (uint *)(iVar9 * 0x14c + DWORD_080b093c + 0x30);
    *puVar15 = *puVar15 | 1;
    iVar9 = sub_0800CCCC();
    if (((iVar9 == 0) && (iVar9 = sub_0800CC98(), iVar9 == 0)) &&
       (iVar9 = sub_0800CD34(), iVar9 == 0)) {
      sub_08000AF0(0x15,uStack_7c,1);
      uVar5 = sub_0800BC44(*(int *)(*(int *)dVar2 + 0x14) >> 8,*(int *)(*(int *)dVar2 + 0x18) >> 8,0
                          );
      iVar9 = *(int *)dVar2;
      uVar7 = sub_08065370(auStack_88,*(undefined2 *)(iVar9 + 0x68),iVar9 + 0x6a,iVar9 + 0x6c,1);
      iVar9 = *(int *)dVar2;
      *(undefined2 *)(iVar9 + 0x6e) = uVar7;
      sub_0800BC08((*(int *)(iVar9 + 0x14) << 8) >> 0x10,(*(int *)(iVar9 + 0x18) << 8) >> 0x10,
                   &sStack_54,&sStack_52,0,0);
      sub_08007870((int)sStack_54,(int)sStack_52,*(undefined2 *)(*(int *)dVar2 + 0x68),
                   *(undefined2 *)(*(int *)dVar2 + 0x6a),uVar5,auStack_6c,uStack_80,auStack_88[0]);
      sub_0801A120(param_1,iStack_4c,(int)(short)uStack_30);
    }
    if ((uStack_34 & 2) != 0) {
      uStack_30 = uStack_30 * 0x10000 + DWORD_080b0944 >> 0x10;
    }
    sub_080003F0();
    uStack_34 = uStack_34 - 1 & 0xffff;
  } while (uStack_34 != DWORD_080b0948);
  sub_080683CC();
  dVar2 = DWORD_080b0940;
  sub_08067CA8(*(undefined2 *)(*(int *)DWORD_080b0940 + 2));
  sub_08068330(DWORD_080b094c);
  while (iVar9 = sub_080682B8(DWORD_080b0a34), iVar9 == 0) {
    iVar9 = sub_080020F4();
    puVar15 = (uint *)(iVar9 * 0x14c + DWORD_080b0a30);
    *puVar15 = *puVar15 | 1;
    iVar9 = sub_0800CCCC();
    if (((iVar9 == 0) && (iVar9 = sub_0800CC98(), iVar9 == 0)) &&
       ((iVar9 = sub_0800CD8C(), iVar9 == 0 && (iVar9 = sub_0800CD34(), iVar9 == 0)))) {
      sub_08000AF0(0x15,uStack_7c,1);
      uVar5 = sub_0800BC44(*(int *)(*(int *)dVar2 + 0x14) >> 8,*(int *)(*(int *)dVar2 + 0x18) >> 8,0
                          );
      iVar9 = *(int *)dVar2;
      uVar7 = sub_08065370(auStack_88,*(undefined2 *)(iVar9 + 0x68),iVar9 + 0x6a,iVar9 + 0x6c,1);
      iVar9 = *(int *)dVar2;
      *(undefined2 *)(iVar9 + 0x6e) = uVar7;
      sub_0800BC08((*(int *)(iVar9 + 0x14) << 8) >> 0x10,(*(int *)(iVar9 + 0x18) << 8) >> 0x10,
                   &sStack_54,&sStack_52,0,0);
      sub_08007870((int)sStack_54,(int)sStack_52,*(undefined2 *)(*(int *)dVar2 + 0x68),
                   *(undefined2 *)(*(int *)dVar2 + 0x6a),uVar5,auStack_6c,uStack_80,auStack_88[0]);
    }
    sub_080003F0();
  }
  sub_08065E38(DWORD_080b0a34);
  dVar2 = DWORD_080b0a38;
  while (iVar9 = sub_08058DB0(), iVar9 != 0) {
    iVar9 = sub_080020F4();
    puVar15 = (uint *)(iVar9 * 0x14c + DWORD_080b0b4c);
    *puVar15 = *puVar15 | 1;
    iVar9 = sub_0800CCCC();
    if ((((iVar9 == 0) && (iVar9 = sub_0800CC98(), iVar9 == 0)) &&
        (iVar9 = sub_0800CD8C(), iVar9 == 0)) && (iVar9 = sub_0800CD34(), iVar9 == 0)) {
      sub_08000AF0(0x15,uStack_7c,1);
      uVar5 = sub_0800BC44(*(int *)(*(int *)dVar2 + 0x14) >> 8,*(int *)(*(int *)dVar2 + 0x18) >> 8,0
                          );
      iVar9 = *(int *)dVar2;
      uVar7 = sub_08065370(auStack_88,*(undefined2 *)(iVar9 + 0x68),iVar9 + 0x6a,iVar9 + 0x6c,1);
      iVar9 = *(int *)dVar2;
      *(undefined2 *)(iVar9 + 0x6e) = uVar7;
      sub_0800BC08((*(int *)(iVar9 + 0x14) << 8) >> 0x10,(*(int *)(iVar9 + 0x18) << 8) >> 0x10,
                   &sStack_54,&sStack_52,0,0);
      sub_08007870((int)sStack_54,(int)sStack_52,*(undefined2 *)(*(int *)dVar2 + 0x68),
                   *(undefined2 *)(*(int *)dVar2 + 0x6a),uVar5,auStack_6c,uStack_80,auStack_88[0]);
    }
    sub_080003F0();
  }
  sub_080586B4(0);
  iVar9 = sub_080020F4();
  puVar15 = (uint *)(iVar9 * 0x14c + DWORD_080b0b50 + 0x30);
  *puVar15 = *puVar15 | 1;
  iVar9 = sub_0805A318();
  if (iVar9 == 0) {
    uVar10 = sub_0805DF38(1,0xe,0x19,2,0x3c,DWORD_080b0b84);
    iVar9 = *(int *)DWORD_080b0b88;
  }
  else {
    uVar10 = sub_0805DF38(1,0xe,0x19,2,0x3c,DWORD_080b0b54);
    iVar9 = *(int *)DWORD_080b0b58;
  }
  *(undefined4 *)(iVar9 + 0x720) = uVar10;
  dVar2 = DWORD_080b0b8c;
  while (iVar9 = sub_0805EEFC(*(undefined4 *)(*(int *)DWORD_080b0cd8 + 0x720)),
        dVar3 = DWORD_080b0cdc, iVar9 == 0) {
    iVar9 = sub_080020F4();
    puVar15 = (uint *)(iVar9 * 0x14c + DWORD_080b0cd4 + 0x30);
    *puVar15 = *puVar15 | 1;
    iVar9 = sub_0800CCCC();
    if (((iVar9 == 0) && (iVar9 = sub_0800CC98(), iVar9 == 0)) &&
       ((iVar9 = sub_0800CD8C(), iVar9 == 0 && (iVar9 = sub_0800CD34(), iVar9 == 0)))) {
      sub_08000AF0(0x15,uStack_7c,1);
      uVar5 = sub_0800BC44(*(int *)(*(int *)dVar2 + 0x14) >> 8,*(int *)(*(int *)dVar2 + 0x18) >> 8,0
                          );
      iVar9 = *(int *)dVar2;
      uVar7 = sub_08065370(auStack_88,*(undefined2 *)(iVar9 + 0x68),iVar9 + 0x6a,iVar9 + 0x6c,1);
      iVar9 = *(int *)dVar2;
      *(undefined2 *)(iVar9 + 0x6e) = uVar7;
      sub_0800BC08((*(int *)(iVar9 + 0x14) << 8) >> 0x10,(*(int *)(iVar9 + 0x18) << 8) >> 0x10,
                   &sStack_54,&sStack_52,0,0);
      sub_08007870((int)sStack_54,(int)sStack_52,*(undefined2 *)(*(int *)dVar2 + 0x68),
                   *(undefined2 *)(*(int *)dVar2 + 0x6a),uVar5,auStack_6c,uStack_80,auStack_88[0]);
    }
    sub_080003F0();
  }
  auStack_6c[0] = 5;
  iVar9 = *(int *)DWORD_080b0cdc;
  *(undefined2 *)(iVar9 + 0x68) = 0;
  *(undefined2 *)(iVar9 + 0x6c) = 0;
  *(undefined2 *)(iVar9 + 0x6a) = 0;
  bVar4 = 100;
  do {
    iVar9 = sub_080020F4();
    puVar15 = (uint *)(iVar9 * 0x14c + DWORD_080b0cd4 + 0x30);
    *puVar15 = *puVar15 | 1;
    iVar9 = sub_0800CCCC();
    if (((iVar9 == 0) && (iVar9 = sub_0800CC98(), iVar9 == 0)) &&
       ((iVar9 = sub_0800CD8C(), iVar9 == 0 && (iVar9 = sub_0800CD34(), iVar9 == 0)))) {
      if (bVar4 < 0x50) {
        if (bVar4 < 0x3c) {
          iVar9 = *(int *)dVar3;
          uVar11 = 0x12;
        }
        else {
          if ((bVar4 & 2) == 0) goto LAB_080b0d06;
          iVar9 = *(int *)dVar3;
          uVar11 = *(ushort *)(iVar9 + 0x68);
          if (uVar11 < 8) {
            uVar11 = uVar11 + 1;
            *(ushort *)(iVar9 + 0x68) = uVar11;
          }
          else {
            uVar11 = 8;
          }
        }
        *(ushort *)(iVar9 + 0x68) = uVar11;
      }
LAB_080b0d06:
      sub_08000AF0(0x15,uStack_7c,1);
      uVar5 = sub_0800BC44(*(int *)(*(int *)dVar3 + 0x14) >> 8,*(int *)(*(int *)dVar3 + 0x18) >> 8,0
                          );
      iVar9 = *(int *)dVar3;
      uVar7 = sub_08065370(auStack_88,*(undefined2 *)(iVar9 + 0x68),iVar9 + 0x6a,iVar9 + 0x6c,1);
      iVar9 = *(int *)dVar3;
      *(undefined2 *)(iVar9 + 0x6e) = uVar7;
      sub_0800BC08((*(int *)(iVar9 + 0x14) << 8) >> 0x10,(*(int *)(iVar9 + 0x18) << 8) >> 0x10,
                   &sStack_54,&sStack_52,0,0);
      sub_08007870((int)sStack_54,(int)sStack_52,*(undefined2 *)pbStack_28,*(undefined2 *)pbStack_24
                   ,uVar5,auStack_6c,uStack_80,auStack_88[0]);
    }
    sub_080003F0();
    dVar2 = DWORD_080b0f60;
    bVar4 = bVar4 - 1;
    if (bVar4 == 0xff) {
      iVar9 = *(int *)DWORD_080b0f60;
      *(undefined2 *)(iVar9 + 0x68) = 0x12;
      *(undefined2 *)(iVar9 + 0x6c) = 0;
      *(undefined2 *)(iVar9 + 0x6a) = 0;
      uVar12 = 0;
      sub_08098088(*(undefined4 *)(param_1 + 0x14),*(undefined4 *)(param_1 + 0x18),1);
      do {
        iVar9 = sub_080020F4();
        puVar15 = (uint *)(iVar9 * 0x14c + DWORD_080b0f64 + 0x30);
        *puVar15 = *puVar15 | 1;
        iVar9 = sub_0800CCCC();
        if ((((iVar9 == 0) && (iVar9 = sub_0800CC98(), iVar9 == 0)) &&
            (iVar9 = sub_0800CD8C(), iVar9 == 0)) && (iVar9 = sub_0800CD34(), iVar9 == 0)) {
          uVar12 = ((uVar12 + 1) * 0x1000000 & 0xf000000) >> 0x18;
          sub_08009088(0,0,uVar12,0);
          sub_08000AF0(0x15,uStack_7c,1);
          uVar5 = sub_0800BC44(*(int *)(*(int *)dVar2 + 0x14) >> 8,
                               *(int *)(*(int *)dVar2 + 0x18) >> 8,0);
          iVar9 = *(int *)dVar2;
          uVar7 = sub_08065370(auStack_88,*(undefined2 *)(iVar9 + 0x68),iVar9 + 0x6a,iVar9 + 0x6c,1)
          ;
          iVar9 = *(int *)dVar2;
          *(undefined2 *)(iVar9 + 0x6e) = uVar7;
          sub_0800BC08((*(int *)(iVar9 + 0x14) << 8) >> 0x10,(*(int *)(iVar9 + 0x18) << 8) >> 0x10,
                       &sStack_54,&sStack_52,0,0);
          sub_08007974((int)sStack_54,(int)sStack_52,*(undefined2 *)pbStack_28,
                       *(undefined2 *)pbStack_24,uVar5,1,0,auStack_6c,uStack_80,auStack_88[0]);
        }
        sub_080003F0();
        cVar6 = sub_080980F0();
      } while (cVar6 == '\0');
      sub_08009088(0,0,0,0);
      sub_08098060();
      iVar9 = sub_080020F4();
      iVar17 = DWORD_080b0f64 + 0x30;
      puVar15 = (uint *)(iVar9 * 0x14c + iVar17);
      *puVar15 = *puVar15 & 0xfffffffe;
      iVar9 = sub_080020F4();
      if (((*(uint *)(iVar9 * 0x14c + iVar17) & 0x2000) == 0) &&
         (*(short *)(*(int *)DWORD_080b0f60 + 0x5a) != 0)) {
        uVar10 = sub_0801E46C(*(undefined4 *)DWORD_080b0f68,pbStack_50);
        uStack_30 = 0x1d;
        do {
          iVar9 = *(int *)DWORD_080b0f60;
          *(int *)(iVar9 + 0x18) = *(int *)(iVar9 + 0x18) + -0x20;
          sub_0806171C(iVar9,uVar10);
          sub_080003F0();
          uVar12 = uStack_30 * 0x10000 + DWORD_080b0f6c;
          uStack_30 = uVar12 >> 0x10;
        } while ((int)uVar12 >> 0x10 != -1);
        sub_0801E4CC(*(undefined4 *)DWORD_080b0f68,uVar10);
      }
      sub_08056E24();
      return in_lr;
    }
  } while( true );
}


