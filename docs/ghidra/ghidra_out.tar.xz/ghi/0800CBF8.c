
void sub_0800CBF8(uint param_1)

{
  *(uint *)DWORD_0800cc10 = param_1 & 0xffff;
  *(uint *)DWORD_0800cc14 = *(uint *)DWORD_0800cc14 | 0x8000;
  return;
}


