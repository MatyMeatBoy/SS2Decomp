
undefined4 sub_08091E94(void)

{
  dword dVar1;
  short sVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  dVar1 = DWORD_08091ecc;
  iVar3 = sub_08001494(0x110);
  *(int *)dVar1 = iVar3;
  sVar2 = 0;
  uVar4 = 0;
  if (iVar3 != 0) {
    do {
      if (uVar4 == 1) {
        uVar4 = 2;
      }
      else if (uVar4 < 2) {
        if (uVar4 == 0) {
          uVar4 = 1;
        }
      }
      else if (uVar4 == 2) {
        uVar4 = 6;
      }
      else if ((uVar4 == 6) && (sVar2 = sVar2 + 1, sVar2 == 0x3d)) {
        uVar4 = 0xff;
      }
      sub_080003F0();
      dVar1 = DWORD_08091f1c;
    } while ((uVar4 != 0xff) && (*(int *)DWORD_08091f1c != 0));
    if (*(int *)DWORD_08091f1c != 0) {
      sub_08001538();
      *(undefined4 *)dVar1 = 0;
    }
  }
  return in_lr;
}


