
undefined4 SampleFreqSet(uint param_1)

{
  dword dVar1;
  undefined1 uVar2;
  short sVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  undefined4 in_lr;
  
  iVar6 = *(int *)DWORD_080b7690;
  *(char *)(iVar6 + 8) = (char)((param_1 & 0xf0000) >> 0x10);
  uVar7 = (uint)*(ushort *)((((param_1 & 0xf0000) >> 0x10) - 1) * 2 + DWORD_080b7694);
  *(uint *)(iVar6 + 0x10) = uVar7;
  uVar2 = __divsi3(0x630,uVar7);
  *(undefined1 *)(iVar6 + 0xb) = uVar2;
  uVar4 = __divsi3(uVar7 * DWORD_080b7698 + DWORD_080b769c,DWORD_080b76a0);
  *(undefined4 *)(iVar6 + 0x14) = uVar4;
  iVar5 = __divsi3(0x1000000);
  *(int *)(iVar6 + 0x18) = iVar5 + 1 >> 1;
  *(undefined2 *)DWORD_080b76a4 = 0;
  dVar1 = DWORD_080b76a8;
  sVar3 = __divsi3(DWORD_080b76ac,uVar7);
  *(short *)dVar1 = -sVar3;
  m4aSoundVSyncOn();
  do {
  } while (*(char *)DWORD_080b76b0 == -0x61);
  do {
  } while (*(char *)DWORD_080b76b0 != -0x61);
  *(undefined2 *)DWORD_080b76a4 = 0x80;
  return in_lr;
}


