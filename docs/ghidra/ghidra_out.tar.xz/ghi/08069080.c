
undefined4
sub_08069080(short *param_1,uint param_2,int param_3,undefined4 param_4,uint param_5,int param_6)

{
  byte bVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  byte *unaff_r10;
  undefined4 in_lr;
  undefined4 uStack_28;
  uint uStack_24;
  
  uVar2 = sub_080008C8();
  iVar3 = __umodsi3(uVar2,100);
  if (param_6 == 1) {
    iVar4 = (param_3 * 10 + 5) * (100 - *param_1);
    uVar2 = 0x19;
  }
  else {
    if (param_6 != 4) {
      return in_lr;
    }
    iVar4 = (param_3 * 10 + 5) * (100 - param_1[3]);
    uVar2 = 0x32;
  }
  iVar4 = __udivsi3(iVar4,uVar2);
  uVar5 = sub_080020F4();
  if ((param_5 == uVar5) || ((iVar6 = sub_0800CF80(), iVar6 != 0 && (param_5 < 4)))) {
    iVar4 = __divsi3(iVar4 * *(char *)(param_5 * 0x14c + DWORD_0806913c + 0x73),100);
  }
  if (iVar3 < iVar4) {
    uStack_28 = uStack_28 & DWORD_08069140 | (uint)(param_6 << 0x18) >> 0x10;
  }
  uVar5 = uStack_28 >> 8 & 0xff;
  if (uVar5 == 1) {
    uVar2 = sub_080008C8();
    iVar3 = __umodsi3(uVar2,100);
    iVar3 = iVar3 + 0x1c2;
  }
  else {
    if (uVar5 != 4) {
      return in_lr;
    }
    uVar2 = sub_080008C8();
    iVar3 = __umodsi3(uVar2,100);
    iVar3 = iVar3 + 700;
  }
  uVar5 = __divsi3(iVar3 * (param_2 & 0xffff),1000);
  if (param_5 < 4) {
    unaff_r10 = (byte *)(param_5 * 0x14c + DWORD_08069190);
    bVar1 = *unaff_r10;
  }
  else {
    iVar3 = *(int *)DWORD_0806920c + param_5 * 0x2e0 + DWORD_08069210;
    if (*(char *)(iVar3 + DWORD_08069214) == '\x03') {
      return in_lr;
    }
    bVar1 = *(byte *)(iVar3 + 2);
  }
  uStack_28 = uStack_28 & DWORD_08069218 | (uint)bVar1;
  uStack_24 = uStack_24 & DWORD_0806921c | uVar5 & 0xffff;
  sub_08067D28(&uStack_28);
  uVar7 = sub_080020F4();
  if ((param_5 == uVar7) && (iVar3 = sub_0800CF80(), iVar3 == 0)) {
    sub_08069224(uStack_28._1_1_,uVar5 & 0xffff,*(int *)DWORD_08069220 + 0x24);
    *(int *)(unaff_r10 + 0xe0) = param_6;
  }
  return in_lr;
}


