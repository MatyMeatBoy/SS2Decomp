
undefined4 sub_08058B74(uint param_1,uint param_2,uint param_3)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  *(uint *)DWORD_08058bac = param_1 & 0xffff;
  if ((*(uint *)DWORD_08058bb0 & 0x20) == 0) {
    sub_08006CB4(param_1 & 0xffff);
  }
  dVar1 = DWORD_08058bb4;
  iVar3 = *(int *)DWORD_08058bb8 + DWORD_08058bbc;
  uVar4 = 0;
  while( true ) {
    if (0x1d < uVar4) {
      return in_lr;
    }
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) break;
    uVar4 = uVar4 + 1;
    iVar3 = iVar3 + 0x28;
  }
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,((param_2 & 0xffff) - 1) * 0x10000 | param_3 & 0xffff);
  return in_lr;
}


