
undefined8 sub_08067F94(uint param_1,int param_2,int param_3)

{
  dword dVar1;
  uint uVar2;
  undefined1 *puVar3;
  undefined4 in_lr;
  
  dVar1 = DWORD_08067fd0;
  uVar2 = *(uint *)DWORD_08067fd0;
  if (uVar2 < 0x32) {
    puVar3 = (undefined1 *)(*(int *)DWORD_08067fd4 + uVar2 * 0x88);
    *(undefined4 *)(puVar3 + 4) = 1;
    *puVar3 = 0x9e;
    *(uint *)(puVar3 + 8) = param_3 << 0x10 | param_2 << 8 | param_1;
    puVar3[1] = 1;
    *(int *)dVar1 = *(int *)dVar1 + 1;
  }
  return CONCAT44(in_lr,(uint)(uVar2 < 0x32));
}


