
undefined4 sub_080140AC(int param_1)

{
  short sVar1;
  undefined2 uVar2;
  ushort uVar3;
  int iVar4;
  uint uVar5;
  short *psVar6;
  ushort *puVar7;
  undefined4 in_lr;
  
  psVar6 = (short *)(param_1 + 200);
  if (*psVar6 != 0) {
    uVar2 = sub_0800CCCC();
    sub_08013E90((int)*(short *)(param_1 + 0xcc),param_1 + 0x8c,*(undefined2 *)(param_1 + 0xca),
                 uVar2,0);
    *psVar6 = *psVar6 + -1;
  }
  psVar6 = (short *)(param_1 + 0xce);
  if (*psVar6 == 0) {
    return in_lr;
  }
  uVar2 = sub_0800CCCC();
  puVar7 = (ushort *)(param_1 + 0xd2);
  sub_08013E90((int)(short)*puVar7,param_1 + 0x8c,*(undefined2 *)(param_1 + 0xd0),uVar2,0);
  sVar1 = *psVar6;
  *psVar6 = sVar1 + -1;
  if ((short)(sVar1 + -1) == 0) {
    iVar4 = (int)*(short *)(param_1 + 0xd4);
    if (iVar4 != 0) {
      uVar5 = iVar4 / 2;
      *psVar6 = (short)uVar5;
      if (3 < (uVar5 & 0xffff)) {
        *psVar6 = 4;
      }
      *(short *)(param_1 + 0xd4) = 0;
      uVar3 = 0x200;
      goto LAB_08014164;
    }
  }
  else if (*(short *)(param_1 + 0xd4) != 0) {
    return in_lr;
  }
  uVar3 = *puVar7;
  *puVar7 = (short)uVar3 >> 1;
  if (0x3f < (int)((uint)uVar3 << 0x10) >> 0x11) {
    return in_lr;
  }
  uVar3 = 0x40;
LAB_08014164:
  *puVar7 = uVar3;
  return in_lr;
}


