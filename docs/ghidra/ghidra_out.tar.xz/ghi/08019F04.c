
undefined4 sub_08019F04(void)

{
  dword dVar1;
  dword dVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  *(undefined2 *)(*(int *)DWORD_08019f50 + 0x5a) = 1;
  dVar2 = DWORD_08019f5c;
  dVar1 = DWORD_08019f58;
  iVar3 = *(int *)DWORD_08019f54;
  uVar4 = 0;
  do {
    if (((*(uint *)dVar1 & 1 << (uVar4 & 0xff)) != 0) && ((*(ushort *)(iVar3 + 0x7a) & 4) != 0)) {
      *(undefined1 *)(iVar3 + dVar2) = 1;
    }
    uVar4 = uVar4 + 1;
    iVar3 = iVar3 + 0x2e0;
  } while (uVar4 < 5);
  return in_lr;
}


