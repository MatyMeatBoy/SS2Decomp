
undefined8 sub_08079FD0(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar4 = iVar1 * 0x14c + DWORD_0807a00c;
  iVar1 = 7;
  uVar3 = 0x80000;
  while( true ) {
    iVar2 = sub_0806898C(param_1,iVar1);
    iVar2 = (iVar2 + -1) * 0x10000 >> 0x10;
    if ((-1 < iVar2) && (iVar2 <= *(short *)(iVar4 + 0xc2))) break;
    uVar3 = uVar3 + DWORD_0807a024;
    iVar1 = iVar1 + -1;
    if (iVar1 < 1) {
      uVar3 = 0;
LAB_0807a01c:
      return CONCAT44(in_lr,uVar3);
    }
  }
  uVar3 = uVar3 >> 0x10;
  goto LAB_0807a01c;
}


