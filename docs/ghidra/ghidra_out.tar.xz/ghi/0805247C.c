
undefined4 sub_0805247C(void)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  byte *pbVar5;
  uint uVar6;
  undefined4 in_lr;
  undefined1 auStack_2c [12];
  dword dStack_20;
  undefined4 uStack_1c;
  
  iVar2 = sub_0800CE30();
  piVar4 = (int *)DWORD_080524b8;
  dVar1 = DWORD_08052498;
  if (iVar2 == 0) {
    *(undefined1 *)(*(int *)DWORD_080524b8 + DWORD_080524bc) = 0;
  }
  else {
    *(undefined1 *)(*(int *)DWORD_08052498 + DWORD_0805249c) = 0;
    piVar4 = (int *)dVar1;
  }
  dVar1 = DWORD_080524c0;
  iVar2 = *piVar4 + DWORD_080524c4;
  for (uVar6 = 0; uVar6 < 0x1e; uVar6 = uVar6 + 1) {
    iVar3 = sub_08000470(iVar2);
    if (iVar3 == 0) goto LAB_080524e0;
    iVar2 = iVar2 + 0x28;
  }
LAB_0805250a:
  dVar1 = DWORD_08052518;
  iVar2 = *(int *)DWORD_0805251c + DWORD_08052520;
  for (uVar6 = 0; uVar6 < 0x1e; uVar6 = uVar6 + 1) {
    iVar3 = sub_08000470(iVar2);
    if (iVar3 == 0) goto LAB_0805253c;
    iVar2 = iVar2 + 0x28;
  }
LAB_08052566:
  dVar1 = DWORD_08052574;
  iVar2 = *(int *)DWORD_08052578 + DWORD_0805257c;
  for (uVar6 = 0; uVar6 < 0x1e; uVar6 = uVar6 + 1) {
    iVar3 = sub_08000470(iVar2);
    if (iVar3 == 0) goto LAB_08052598;
    iVar2 = iVar2 + 0x28;
  }
LAB_080525c2:
  iVar2 = sub_0800CE30();
  dVar1 = DWORD_08052614;
  if (iVar2 == 0) {
    pbVar5 = (byte *)(*(int *)DWORD_08052600 + 0x1b8);
    piVar4 = (int *)DWORD_08052600;
  }
  else {
    pbVar5 = (byte *)(*(int *)DWORD_080525d8 + 0x1c4);
    piVar4 = (int *)DWORD_080525d8;
  }
  if (((int)(uint)*pbVar5 >> 4 & 1U) == 0) {
    iVar2 = *piVar4 + DWORD_08052618;
    for (uVar6 = 0; uVar6 < 0x1e; uVar6 = uVar6 + 1) {
      iVar3 = sub_08000470(iVar2);
      if (iVar3 == 0) {
        dStack_20 = dVar1;
        uStack_1c = 0;
        *(undefined4 *)(iVar2 + 8) = 0x3c;
        iVar3 = sub_08001494(0x400);
        *(int *)(iVar2 + 0x20) = iVar3;
        *(dword *)(iVar2 + 0xc) = DWORD_08052680;
        *(int *)(iVar2 + 0x10) = iVar3 + 0x3fc;
        *(undefined4 *)(iVar2 + 0x24) = 0;
        sub_08000274(iVar2,auStack_2c,9);
        sub_080003F0();
        sub_080003F0();
        break;
      }
      iVar2 = iVar2 + 0x28;
    }
  }
  else {
    sub_08028AAC(9,DWORD_08052604,DWORD_08052604,0);
  }
  iVar2 = sub_0800CC98();
  if (iVar2 == 0) {
    iVar2 = sub_0801AB24();
    if (iVar2 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar2 < 2) {
      if (iVar2 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar2 == 2) {
      sub_0801AB90(6);
    }
    while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
      sub_080003F0();
    }
  }
  return in_lr;
LAB_080524e0:
  while( true ) {
    iVar3 = sub_08001494(0x400);
    *(int *)(iVar2 + 0x20) = iVar3;
    if (iVar3 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar2 + 8) = 0x3c;
  *(dword *)(iVar2 + 0xc) = dVar1;
  *(int *)(iVar2 + 0x10) = iVar3 + 0x3fc;
  *(undefined4 *)(iVar2 + 0x24) = 0;
  sub_08000274(iVar2,3);
  goto LAB_0805250a;
LAB_0805253c:
  while( true ) {
    iVar3 = sub_08001494(0x400);
    *(int *)(iVar2 + 0x20) = iVar3;
    if (iVar3 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar2 + 8) = 0x3c;
  *(dword *)(iVar2 + 0xc) = dVar1;
  *(int *)(iVar2 + 0x10) = iVar3 + 0x3fc;
  *(undefined4 *)(iVar2 + 0x24) = 0;
  sub_08000274(iVar2,4);
  goto LAB_08052566;
LAB_08052598:
  while( true ) {
    iVar3 = sub_08001494(0x400);
    *(int *)(iVar2 + 0x20) = iVar3;
    if (iVar3 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar2 + 8) = 0x3c;
  *(dword *)(iVar2 + 0xc) = dVar1;
  *(int *)(iVar2 + 0x10) = iVar3 + 0x3fc;
  *(undefined4 *)(iVar2 + 0x24) = 0;
  sub_08000274(iVar2,5);
  goto LAB_080525c2;
}


