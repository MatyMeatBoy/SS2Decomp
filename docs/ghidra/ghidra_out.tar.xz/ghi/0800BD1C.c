
bool sub_0800BD1C(void)

{
  return *(ushort *)((uint)*(ushort *)(DWORD_0800bd40 + 0x8c) * 0x74 + DWORD_0800bd3c) - 1 ==
         (uint)*(ushort *)(DWORD_0800bd40 + 0x90);
}


