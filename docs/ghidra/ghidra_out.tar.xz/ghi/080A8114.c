
undefined4 sub_080A8114(void)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  undefined4 in_lr;
  
  dVar1 = DWORD_080a815c;
  iVar2 = sub_08000470(*(undefined4 *)DWORD_080a815c);
  if ((iVar2 != 0) || (*(int *)(*(int *)dVar1 + 8) == 0)) {
    *(undefined4 *)(*(int *)dVar1 + 8) = 0x44;
    iVar2 = sub_08001494(0x200);
    iVar3 = *(int *)dVar1;
    *(int *)(iVar3 + 0x20) = iVar2;
    *(int *)(iVar3 + 0x10) = iVar2 + 0x1fc;
    *(dword *)(iVar3 + 0xc) = DWORD_080a8160;
    *(undefined4 *)(iVar3 + 0x24) = 0;
    sub_08000274(iVar3,0,0);
  }
  return in_lr;
}


