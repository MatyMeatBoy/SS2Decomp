
void sub_08097FE4(void)

{
  *(undefined1 *)DWORD_08097ff0 = 0;
  *(undefined1 *)DWORD_08097ff4 = 0;
  return;
}


