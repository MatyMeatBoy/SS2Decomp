
undefined8 sub_0805AD18(void)

{
  ushort uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 in_lr;
  
  iVar2 = sub_080020F4();
  iVar2 = iVar2 * 0x14c + DWORD_0805ad40;
  if (*(short *)(iVar2 + 0xc) == *(short *)(iVar2 + 100)) {
    iVar2 = *(int *)DWORD_0805ad60 + (uint)*(ushort *)(*(int *)DWORD_0805ad60 + 0x68) * 0x10;
    if (*(char *)(iVar2 + 0x79) == '\0') {
      uVar3 = 0;
      goto LAB_0805ad74;
    }
    uVar1 = *(ushort *)(iVar2 + 0x72);
  }
  else {
    uVar1 = *(ushort *)(*(int *)(iVar2 + 0x138) + 0x28);
  }
  uVar3 = sub_08007290(uVar1 | 0xb0000);
LAB_0805ad74:
  return CONCAT44(in_lr,uVar3);
}


