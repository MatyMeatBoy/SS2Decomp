
void sub_08097D30(undefined2 param_1,undefined2 param_2)

{
  dword dVar1;
  
  dVar1 = DWORD_08097d38;
  *(undefined2 *)DWORD_08097d38 = param_1;
  *(undefined2 *)(dVar1 + 2) = param_2;
  return;
}


