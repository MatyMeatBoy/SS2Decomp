
undefined4 sub_080904A4(void)

{
  ushort uVar1;
  undefined1 *puVar2;
  dword dVar3;
  dword dVar4;
  int iVar5;
  uint uVar6;
  byte bVar7;
  bool bVar8;
  uint unaff_r10;
  undefined4 in_lr;
  undefined4 auStack_cc [2];
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined1 auStack_b0 [24];
  undefined2 uStack_98;
  undefined2 uStack_96;
  undefined2 uStack_94;
  undefined2 uStack_92;
  short sStack_90;
  undefined2 uStack_8c;
  undefined2 uStack_8a;
  undefined2 uStack_88;
  undefined2 uStack_86;
  undefined2 auStack_84 [2];
  undefined2 uStack_80;
  undefined2 uStack_7e;
  undefined2 uStack_7c;
  undefined2 uStack_7a;
  undefined2 auStack_78 [2];
  undefined2 uStack_74;
  undefined2 uStack_72;
  undefined2 uStack_70;
  undefined2 uStack_6e;
  undefined2 uStack_6c;
  undefined2 uStack_68;
  undefined2 uStack_66;
  undefined2 uStack_64;
  undefined2 uStack_62;
  short sStack_60;
  undefined1 auStack_5c [12];
  uint uStack_50;
  dword dStack_4c;
  dword dStack_48;
  uint uStack_44;
  uint uStack_40;
  int iStack_3c;
  uint uStack_38;
  int iStack_34;
  undefined2 *puStack_30;
  undefined1 *puStack_2c;
  undefined2 *puStack_28;
  undefined2 *puStack_24;
  
  sub_0801A6D4(1);
  uVar6 = 0;
  sub_08000A34(1,0,0,0,0);
  sub_080009F8(0xf00,0,0);
  sub_08000990(0,0);
  sub_080009C0(0x1100,0,0);
  uStack_50 = uStack_50 & DWORD_08090674 | DWORD_08090678;
  sub_08000AA8(0,&uStack_50);
  sub_080921E4(0,0x18);
  sub_08065158(auStack_cc,DWORD_0809067c,8,0xffffffff,1);
  auStack_b0[0] = 8;
  uStack_92 = 1;
  uStack_6e = 1;
  uStack_62 = 0;
  uStack_7a = 0;
  uStack_86 = 0;
  uStack_98 = 2;
  uStack_74 = 0;
  uStack_68 = 0;
  uStack_80 = 0;
  uStack_8c = 0;
  uStack_94 = 6;
  uStack_70 = 0;
  uStack_64 = 0;
  uStack_7c = 0;
  uStack_88 = 0;
  uStack_96 = 7;
  uStack_72 = 0;
  uStack_66 = 0;
  uStack_7e = 0;
  uStack_8a = 0;
  sStack_90 = 8;
  uStack_6c = 0;
  sStack_60 = 0;
  auStack_78[0] = 0;
  auStack_84[0] = 0;
  puStack_2c = auStack_b0;
  puStack_28 = auStack_84;
  puStack_24 = auStack_78;
  do {
    auStack_5c[uVar6] = 0;
    uVar6 = uVar6 + 1 & 0xff;
  } while (uVar6 < 0xc);
  sub_08092124();
  sub_08000940();
  sub_0801AB50(6);
  dStack_48 = 0;
  dStack_4c = 0;
  bVar7 = 0;
  uStack_40 = 0;
  uStack_44 = 0;
  bVar8 = false;
  uStack_38 = 0;
  iStack_3c = 0;
  iStack_34 = 1;
  puStack_30 = &uStack_8c;
  do {
    if ((*(ushort *)DWORD_08090680 & 1) != 0) {
      sub_08000AF0(0x18,uStack_c0,1);
      uStack_66 = sub_08065370(auStack_cc,uStack_96,&uStack_8a,&uStack_7e,uStack_72);
      sub_08007870(0xd3,0x83,uStack_96,uStack_8a,0,puStack_2c,uStack_c4,auStack_cc[0]);
    }
    if ((*(ushort *)DWORD_08090680 & 2) != 0) {
      sub_08000AF0(0x18,uStack_c0,1);
      uStack_64 = sub_08065370(auStack_cc,uStack_94,&uStack_88,&uStack_7c,uStack_70);
      sub_08007870(0xc1,0x83,uStack_94,uStack_88,0,puStack_2c,uStack_c4,auStack_cc[0]);
    }
    uVar1 = *(ushort *)DWORD_08090680;
    if ((uVar1 & 0xf0) != 0) {
      if ((uVar1 & 0x40) == 0) {
        if ((uVar1 & 0x80) == 0) {
          if ((uVar1 & 0x10) == 0) {
            uStack_98 = 5;
          }
          else {
            uStack_98 = 4;
          }
        }
        else {
          uStack_98 = 3;
        }
      }
      else {
        uStack_98 = 2;
      }
      sub_08000AF0(0x18,uStack_c0,1);
      uStack_68 = sub_08065370(auStack_cc,uStack_98,puStack_30,&uStack_80,uStack_74);
      sub_08007870(0x30,0x7d,uStack_98,*puStack_30,0,puStack_2c,uStack_c4,auStack_cc[0]);
    }
    if (iStack_3c == 0) {
      sub_08000AF0(0x18,uStack_c0,1);
      uStack_62 = sub_08065370(auStack_cc,uStack_92,&uStack_86,&uStack_7a,uStack_6e);
      sub_08007870(0x7b,0x7e,uStack_92,uStack_86,iStack_3c,puStack_2c,uStack_c4,auStack_cc[0]);
    }
    sub_08000AF0(0x18,uStack_c0,1);
    sStack_60 = sub_08065370(auStack_cc,sStack_90,puStack_28,puStack_24,uStack_6c);
    sub_08007870(199,0x74,sStack_90,auStack_84[0],0,puStack_2c,uStack_c4,auStack_cc[0]);
    if ((sStack_60 != 0) && (sStack_90 == 9)) {
      sStack_90 = 0xb;
      uStack_6c = 1;
      sStack_60 = 0;
      auStack_78[0] = 0;
      auStack_84[0] = 0;
    }
    if ((bVar8) && (*(int *)DWORD_08090800 == 0)) {
      sub_08092190();
    }
    dVar4 = DWORD_08090974;
    dVar3 = dStack_48;
    if ((*(ushort *)DWORD_08090804 & 8) == 0) {
      if (((*(ushort *)DWORD_0809084c & 0x30) == 0) || (iStack_3c == 0)) {
        if (((*(ushort *)DWORD_0809084c & 0x40) == 0) || ((iStack_3c == 0 || (bVar7 != 0)))) {
          if (((*(ushort *)DWORD_0809084c & 0x80) == 0) || ((iStack_3c == 0 || (bVar7 != 0)))) {
            if ((((*(ushort *)DWORD_08090804 & 1) == 0) || (iStack_3c == 0)) || (bVar7 != 0)) {
              if ((*(ushort *)DWORD_08090804 & 2) != 0) {
                bVar7 = 0;
                if (iStack_3c == 0) {
                  if (!bVar8) {
                    iStack_34 = 0;
                  }
                }
                else {
                  if (bVar8) {
                    m4aSongNumStop(*(undefined2 *)(uStack_44 * 2 + DWORD_080909d0));
                    bVar8 = false;
                    sStack_90 = 0xb;
                    uStack_6c = 1;
                    sStack_60 = 0;
                    auStack_78[0] = 0;
                    auStack_84[0] = 0;
                  }
                  m4aSongNumStop(*(undefined2 *)(dStack_4c * 2 + DWORD_080909d4));
                  dVar3 = dStack_48;
                }
              }
            }
            else if (uStack_38 == 0) {
              if (bVar8) {
                m4aSongNumStop(*(undefined2 *)(uStack_44 * 2 + DWORD_08090914));
              }
              else {
                sStack_90 = 10;
                uStack_6c = 1;
                sStack_60 = 0;
                auStack_78[0] = 0;
                auStack_84[0] = 0;
              }
              bVar8 = true;
              uStack_44 = uStack_40;
              m4aSongNumStart(*(undefined2 *)(uStack_40 * 2 + DWORD_08090950));
              dVar3 = dStack_48;
            }
            else {
              m4aSongNumStop(*(undefined2 *)(dStack_4c * 2 + DWORD_08090974));
              dStack_4c = dStack_48;
              m4aSongNumStart(*(undefined2 *)(dStack_48 * 2 + dVar4));
              dVar3 = dStack_48;
            }
          }
          else if (uStack_38 == 0) {
            if (uStack_40 != 0x24) {
              uStack_40 = uStack_40 + 1;
              goto LAB_080908b6;
            }
            uStack_40 = 0;
          }
          else {
            if (dStack_48 != DWORD_080908d4) {
              uVar6 = dStack_48 + 1;
              goto LAB_080908ce;
            }
            dVar3 = 0;
          }
        }
        else if (uStack_38 == 0) {
          if (uStack_40 == 0) {
            uStack_40 = 0x24;
          }
          else {
            uStack_40 = uStack_40 - 1;
LAB_080908b6:
            uStack_40 = uStack_40 & 0xffff;
          }
        }
        else {
          dVar3 = DWORD_0809088c;
          if (dStack_48 != 0) {
            uVar6 = dStack_48 - 1;
LAB_080908ce:
            dVar3 = uVar6 & 0xffff;
          }
        }
      }
      else {
        uStack_38 = uStack_38 ^ 1;
        bVar7 = 0x3c;
      }
    }
    else if (!bVar8) {
      if (iStack_3c == 0) {
        iStack_3c = 1;
        bVar7 = 0x3c;
        sStack_90 = 9;
        uStack_6c = 0;
        sStack_60 = 0;
        auStack_78[0] = 0;
        auStack_84[0] = 0;
      }
      else {
        iStack_3c = 0;
        bVar7 = 0;
        sStack_90 = 8;
        uStack_6c = 0;
        sStack_60 = 0;
        auStack_78[0] = 0;
        puStack_30[4] = 0;
        uStack_92 = 1;
        uStack_6e = 1;
        uStack_62 = 0;
        uStack_7a = 0;
        puStack_30[3] = 0;
        dVar3 = dStack_48;
      }
    }
    dStack_48 = dVar3;
    uVar6 = (unaff_r10 & DWORD_08090a24 | 0x4c) & DWORD_08090a28;
    unaff_r10 = uVar6 | 0x740000;
    if (iStack_3c != 0) {
      if (bVar7 == 0) {
        sub_08091F9C(*(undefined4 *)(uStack_38 * 4 + *(int *)DWORD_08090a84 * 8 + DWORD_08090a80),
                     auStack_5c);
        if (uStack_38 == 0) {
          sub_08091F20(uStack_40 + 1 & 0xffff,auStack_5c);
        }
        else {
          sub_08091F20(dStack_48 + 1 & 0xffff,auStack_5c);
        }
      }
      else {
        dVar4 = DWORD_08090a4c;
        if ((bVar7 & 3) != 0) {
          dVar4 = *(dword *)(uStack_38 * 4 + *(int *)DWORD_08090a30 * 8 + DWORD_08090a2c);
        }
        sub_08091F9C(dVar4,auStack_5c);
        sub_0801A764(auStack_5c,uVar6 & 0xffff,unaff_r10 >> 0x10);
        bVar7 = bVar7 - 1;
      }
      sub_0801A764(auStack_5c,uVar6 & 0xffff,unaff_r10 >> 0x10);
    }
    uVar6 = 0;
    do {
      auStack_5c[uVar6] = 0;
      uVar6 = uVar6 + 1 & 0xff;
    } while (uVar6 < 0xc);
    sub_080003F0();
    if (iStack_34 == 0) {
      sub_0801AA8C(0x3c);
      puVar2 = puStack_2c;
      while (iVar5 = sub_0801AAE0(), dVar4 = DWORD_08090b80, iVar5 == 0) {
        sub_08000AF0(0x18,uStack_c0,1);
        sub_08065370(auStack_cc,uStack_92,&uStack_86,&uStack_7a,uStack_6e);
        sub_08007870(0x7b,0x7e,uStack_92,uStack_86,0,puVar2,uStack_c4,auStack_cc[0]);
        sub_08000AF0(0x18,uStack_c0,1);
        sub_08065370(auStack_cc,sStack_90,puStack_28,puStack_24,uStack_6c);
        sub_08007870(199,0x74,sStack_90,auStack_84[0],0,puVar2,uStack_c4,auStack_cc[0]);
        sub_080003F0();
      }
      if (*(int *)DWORD_08090b80 != 0) {
        sub_08001538();
        *(undefined4 *)dVar4 = 0;
      }
      sub_0801A6D4(0);
      sub_08000968();
      sub_08000420(0x14);
      return in_lr;
    }
  } while( true );
}


