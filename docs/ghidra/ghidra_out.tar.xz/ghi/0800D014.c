
void sub_0800D014(void)

{
  *(uint *)DWORD_0800d020 = *(uint *)DWORD_0800d020 & DWORD_0800d024;
  return;
}


