
undefined4 sub_080590B4(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_080590e0;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) | 1;
  sub_0800D0F4();
  sub_0802949C(param_1,0);
  while (iVar1 = sub_0805F184(), iVar1 != 0) {
    sub_080003F0();
  }
  while (iVar1 = sub_0805EF90(), iVar1 != 0) {
    sub_080003F0();
  }
  uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08059118);
  do {
    iVar1 = sub_0805EEFC(uVar2);
    if (iVar1 != 0) {
LAB_08059136:
      sub_08029788(param_1);
      iVar1 = sub_080020F4();
      iVar1 = iVar1 * 0x14c + DWORD_08059164;
      *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & 0xfffffffe;
      sub_0800D108();
      return in_lr;
    }
    iVar1 = sub_0800CDF8();
    if (iVar1 != 0) {
      sub_0805EFBC();
      goto LAB_08059136;
    }
    sub_080003F0();
  } while( true );
}


