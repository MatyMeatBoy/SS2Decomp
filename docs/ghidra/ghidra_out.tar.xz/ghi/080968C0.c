
undefined4 sub_080968C0(void)

{
  dword dVar1;
  dword dVar2;
  short sVar3;
  short sVar4;
  short sVar5;
  short sVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined4 in_lr;
  
  dVar2 = DWORD_080969c4;
  dVar1 = DWORD_080969c0;
  sVar3 = sub_08090434((int)*(short *)((*(byte *)(DWORD_080969c4 + 0xd) + 0x40) * 2 + DWORD_080969c0
                                      ),0x100);
  sVar4 = sub_08090434((int)*(short *)((uint)*(byte *)(dVar2 + 0xd) * 2 + dVar1),0x100);
  sVar5 = sub_08090434(-(int)*(short *)((uint)*(byte *)(dVar2 + 0xd) * 2 + dVar1),0x100);
  sVar6 = sub_08090434((int)*(short *)((*(byte *)(dVar2 + 0xd) + 0x40) * 2 + dVar1),0x100);
  iVar9 = (0x78 - ((int)(((uint)*(ushort *)(dVar2 + 8) + (uint)*(ushort *)(dVar2 + 4)) * 0x10000) >>
                  0x10)) * 0x100 + sVar3 * -0x78 + sVar4 * -0x50;
  iVar8 = (0x78 - ((int)(((uint)*(ushort *)(dVar2 + 10) + (uint)*(ushort *)(dVar2 + 6)) * 0x10000)
                  >> 0x10)) * 0x100 + sVar5 * -0x78 + sVar6 * -0x50;
  iVar7 = sub_0800CCCC();
  if ((((iVar7 == 0) && (iVar7 = sub_0800CC98(), iVar7 == 0)) &&
      (iVar7 = sub_0800CD8C(), iVar7 == 0)) &&
     (iVar7 = sub_0800CD34(), dVar1 = DWORD_080969c8, iVar7 == 0)) {
    *(short *)(DWORD_080969c8 + 0x10) = sVar3;
    *(short *)(dVar1 + 0x12) = sVar4;
    *(short *)(dVar1 + 0x14) = sVar5;
    *(short *)(dVar1 + 0x16) = sVar6;
    *(short *)(dVar1 + 0x18) = (short)iVar9;
    *(short *)(dVar1 + 0x1c) = (short)iVar8;
    *(short *)(dVar1 + 0x1a) = (short)((uint)iVar9 >> 0x10);
    *(short *)(dVar1 + 0x1e) = (short)((uint)iVar8 >> 0x10);
  }
  return in_lr;
}


