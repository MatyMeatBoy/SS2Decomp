
undefined4 sub_08001130(void)

{
  undefined4 in_lr;
  
  if (*(int *)DWORD_08001150 != 0) {
    _call_via_r0();
  }
  *(undefined2 *)DWORD_08001154 = 4;
  *(ushort *)DWORD_08001158 = *(ushort *)DWORD_08001158 | 4;
  return in_lr;
}


