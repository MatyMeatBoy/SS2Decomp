
undefined8 sub_0806898C(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  short sVar3;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_080689f0;
  if (param_2 != 0) {
    iVar2 = (int)*(short *)((param_2 + -1) * 2 + param_1 * 0x18 + DWORD_080689f4 + 6) +
            *(char *)(iVar1 + 0x6c) * 10;
    sVar3 = (short)iVar2;
    if (iVar2 * 0x10000 < 0) {
      sVar3 = 0;
    }
    if (-1 < (int)*(short *)(iVar1 + 0xc2) - (int)sVar3) {
      iVar1 = (sVar3 + 1) * 0x10000 >> 0x10;
      goto LAB_080689fa;
    }
  }
  iVar1 = 0;
LAB_080689fa:
  return CONCAT44(in_lr,iVar1);
}


