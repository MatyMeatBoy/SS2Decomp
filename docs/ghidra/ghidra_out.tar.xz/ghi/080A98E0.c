
undefined8 sub_080A98E0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  undefined4 in_lr;
  
  iVar1 = sub_080A9910();
  iVar2 = sub_080A9910(param_1,param_2,param_4);
  return CONCAT44(in_lr,(uint)(iVar1 != iVar2));
}


