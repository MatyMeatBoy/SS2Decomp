
undefined4 sub_0802A7DC(void)

{
  dword dVar1;
  short sVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 in_lr;
  
  sub_0801AC24(10);
  sVar2 = 0xc;
  do {
    sub_080003F0();
    iVar3 = sub_080021A8();
    if (iVar3 != 0) break;
    sVar2 = sVar2 + -1;
  } while (sVar2 != 0);
  iVar3 = sub_080020F4();
  iVar3 = iVar3 * 0x14c + DWORD_0802a868;
  *(uint *)(iVar3 + 0x30) = *(uint *)(iVar3 + 0x30) | 1;
  sub_0800D0F4();
  if ((*(uint *)DWORD_0802a86c & 0x20) == 0) {
    sub_08006D08(0x180);
  }
  *(ushort *)(*(int *)DWORD_0802a870 + 4) = *(ushort *)(*(int *)DWORD_0802a870 + 4) | 0x200;
  sub_0805DC1C(4,2,0x12,10);
  sub_0802A590(0,0x17);
  dVar1 = DWORD_0802a874;
  *(short *)(DWORD_0802a874 + 0x38) = (short)DWORD_0802a878;
  *(short *)(dVar1 + 0x3a) = (short)DWORD_0802a87c;
  *(short *)(dVar1 + 0x32) = (short)DWORD_0802a880;
  *(short *)(dVar1 + 0x36) = (short)DWORD_0802a884;
  sVar2 = 1;
  do {
    sub_080003F0();
    iVar3 = sub_080021A8();
    if (iVar3 != 0) break;
    sVar2 = sVar2 + -1;
  } while (sVar2 != 0);
  sub_080009C0(0,0x4000,1);
  sub_0801AB90(10);
  sVar2 = 0xc;
  do {
    sub_080003F0();
    iVar3 = sub_080021A8();
    if (iVar3 != 0) break;
    sVar2 = sVar2 + -1;
  } while (sVar2 != 0);
  sub_0802A644(DWORD_0802a8f8);
  sub_0802A644(DWORD_0802a8fc);
  sub_0802A644(DWORD_0802a900);
  sub_0802A644(DWORD_0802a904);
  dVar1 = DWORD_0802a908;
  sub_08006C30(0x1e);
  *(undefined4 *)dVar1 = 0;
  sub_0801AA8C(0x1e);
  while (iVar3 = sub_0801AAE0(), iVar3 == 0) {
    sub_080003F0();
  }
  sub_080009F8(0,0x4000,1);
  iVar3 = *(int *)DWORD_0802a984 + DWORD_0802a988;
  uVar5 = 0;
  do {
    iVar4 = sub_08000470(iVar3 + 0x48);
    if (iVar4 != 0) {
      sub_080003A8(iVar3 + 0x48);
    }
    uVar5 = uVar5 + 1;
    iVar3 = iVar3 + 0x70;
  } while (uVar5 < 0xf);
  sub_0800D108();
  sub_0800D0F4();
  iVar3 = sub_080020F4();
  dVar1 = DWORD_0802a98c;
  iVar3 = iVar3 * 0x14c + DWORD_0802a98c;
  *(uint *)(iVar3 + 0x30) = *(uint *)(iVar3 + 0x30) | 2;
  sub_08067D74();
  iVar3 = sub_080020F4();
  *(undefined4 *)(iVar3 * 0x14c + dVar1 + 0x8c) = 0x12c00;
  sVar2 = 10;
  do {
    sub_080003F0();
    iVar3 = sub_080021A8();
    if (iVar3 != 0) break;
    sVar2 = sVar2 + -1;
  } while (sVar2 != 0);
  sub_0808899C();
  return in_lr;
}


