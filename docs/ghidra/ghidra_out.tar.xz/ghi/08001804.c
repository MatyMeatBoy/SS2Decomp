
undefined8 sub_08001804(undefined4 param_1,undefined4 param_2)

{
  byte bVar1;
  dword dVar2;
  dword dVar3;
  uint uVar4;
  uint uVar5;
  uint unaff_r8;
  undefined4 in_lr;
  
  dVar3 = DWORD_080018a0;
  dVar2 = DWORD_08001824;
  bVar1 = *(byte *)(DWORD_08001824 + 1);
  if (bVar1 == 1) {
LAB_0800188c:
    if (*(char *)(DWORD_080018ac + 2) != '\0') {
      if (*(byte *)(DWORD_080018ac + 10) < 8) {
        *(byte *)(DWORD_080018ac + 10) = *(byte *)(DWORD_080018ac + 10) + 1;
      }
      else {
        *(undefined1 *)(DWORD_080018ac + 1) = 2;
      }
    }
  }
  else {
    if (bVar1 < 2) {
      if (bVar1 != 0) goto LAB_080018c0;
      unaff_r8 = *(uint *)DWORD_080018a0;
      if ((unaff_r8 & 0x30) == 0) {
        if ((unaff_r8 & 0x88) != 8) goto LAB_080018c0;
        if (((unaff_r8 & 4) == 0) && (*(int *)(DWORD_08001824 + 0x14) == -1)) {
          sub_08000EF4();
          sub_08000FD4(0x80);
          sub_08000F64(0x40);
          sub_08000F2C();
          *(byte *)(dVar3 + 1) = *(byte *)(dVar3 + 1) & 0xbf;
          dVar3 = DWORD_080018a4;
          *(undefined2 *)DWORD_080018a4 = 0xc0;
          *(dword *)(dVar3 - 0xf6) = DWORD_080018a8;
          *(undefined1 *)dVar2 = 8;
        }
      }
      *(undefined1 *)(DWORD_080018ac + 1) = 1;
      goto LAB_0800188c;
    }
    if (bVar1 != 2) goto LAB_080018c0;
  }
  sub_08001990(param_2);
  sub_0800191C(param_1);
LAB_080018c0:
  dVar2 = DWORD_080018dc;
  *(char *)(DWORD_080018dc + 0xb) = *(char *)(DWORD_080018dc + 0xb) + '\x01';
  uVar5 = (uint)*(byte *)(dVar2 + 2) << 8;
  if (*(char *)dVar2 == '\b') {
    uVar5 = uVar5 | 0x80;
  }
  uVar5 = uVar5 | *(byte *)(dVar2 + 3);
  if (*(char *)(dVar2 + 9) != '\0') {
    uVar5 = uVar5 | 0x1000;
  }
  uVar4 = (uint)(*(byte *)(dVar2 + 10) >> 3) << 0xf;
  if (3 < (unaff_r8 << 0x1a) >> 0x1e) {
    uVar4 = uVar4 | 0x2000;
  }
  return CONCAT44(in_lr,uVar4 | uVar5);
}


