
undefined4 sub_08061B88(void)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  undefined4 unaff_r7;
  undefined4 in_lr;
  uint uStack_18;
  
  sub_0800CDD0();
  uVar6 = 0;
  do {
    iVar2 = sub_080021A8();
    if (iVar2 != 0) {
      return in_lr;
    }
    sub_080003F0();
    uVar6 = uVar6 + 1;
  } while (uVar6 < 100);
  sub_080021D4();
  while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
    iVar2 = sub_080021A8();
    if (iVar2 != 0) {
      return in_lr;
    }
    sub_080003F0();
  }
  iVar2 = sub_0801AC78();
  if (iVar2 != 0) {
    sub_0801ABE8(6);
    while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
      iVar2 = sub_080021A8();
      if (iVar2 != 0) {
        return in_lr;
      }
      sub_080003F0();
    }
  }
  *(undefined2 *)(DWORD_08061ca8 + 0x3a) = 0;
  sub_0800CCEC();
  *(uint *)(DWORD_08061cac + 0x9c) = *(uint *)(DWORD_08061cac + 0x9c) | 0xc;
  dVar1 = DWORD_08061cb0;
  iVar2 = sub_08000470(DWORD_08061cb0);
  if (iVar2 != 0) {
    sub_080003A8(dVar1);
  }
  dVar1 = DWORD_08061cb4;
  iVar2 = sub_08000470(DWORD_08061cb4);
  if (iVar2 != 0) {
    sub_080003A8(dVar1);
  }
  dVar1 = DWORD_08061cb8;
  iVar2 = sub_08000470(DWORD_08061cb8);
  if (iVar2 != 0) {
    sub_080003A8(dVar1);
  }
  uVar6 = 0;
  iVar2 = 0;
  do {
    iVar5 = iVar2 + DWORD_08061cbc;
    iVar3 = sub_08000470(iVar5);
    if (iVar3 != 0) {
      sub_080003A8(iVar5);
    }
    iVar2 = iVar2 + 0x28;
    uVar6 = uVar6 + 1;
  } while (uVar6 < 5);
  sub_0805DE98();
  dVar1 = DWORD_08061cc0;
  iVar2 = sub_08000470(DWORD_08061cc0);
  if (iVar2 != 0) {
    sub_080003A8(dVar1);
  }
  iVar3 = dVar1 + 0x28;
  iVar2 = sub_08000470(iVar3);
  if (iVar2 != 0) {
    sub_080003A8(iVar3);
  }
  dVar1 = DWORD_08061cc4;
  iVar2 = sub_08000470(DWORD_08061cc4);
  if (iVar2 != 0) {
    sub_080003A8(dVar1);
  }
  iVar3 = dVar1 + 0x28;
  iVar2 = sub_08000470(iVar3);
  if (iVar2 != 0) {
    sub_080003A8(iVar3);
  }
  iVar2 = 0;
  for (uVar6 = 0; uVar4 = sub_08002164(), uVar6 < uVar4; uVar6 = uVar6 + 1) {
    iVar5 = iVar2 + DWORD_08061d9c;
    iVar3 = sub_08000470(iVar5);
    if (iVar3 != 0) {
      sub_080003A8(iVar5);
    }
    iVar2 = iVar2 + 0x28;
  }
  iVar2 = sub_080021A8();
  if (iVar2 == 0) {
    sub_080003F0();
    iVar2 = sub_080021A8();
    if (iVar2 == 0) {
      sub_080003F0();
      iVar2 = sub_080021A8();
      if (iVar2 == 0) {
        sub_080003F0();
        iVar2 = sub_080021A8();
        if (iVar2 == 0) {
          sub_080003F0();
          iVar2 = sub_080021A8();
          if (iVar2 == 0) {
            sub_080003F0();
            iVar2 = sub_080021A8();
            if (iVar2 == 0) {
              sub_080003F0();
              iVar2 = sub_080021A8();
              if (iVar2 == 0) {
                sub_080003F0();
                iVar2 = sub_080021A8();
                if (iVar2 == 0) {
                  sub_080003F0();
                  iVar2 = sub_080021A8();
                  if (iVar2 == 0) {
                    sub_080009F8(0x7f00,0,0);
                    sub_080009C0(0x1100,0,1);
                    uStack_18 = uStack_18 & DWORD_08061da0 | DWORD_08061da4;
                    sub_08000AA8(0,&uStack_18);
                    dVar1 = DWORD_08061da8;
                    *(undefined2 *)(DWORD_08061da8 + 4) = 0;
                    *(undefined2 *)(dVar1 + 6) = 0;
                    sub_0805F07C();
                    sub_0801AB50(6);
                    while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
                      sub_080003F0();
                    }
                    do {
                      sub_080003F0();
                      iVar2 = sub_0805EEFC(unaff_r7);
                    } while (iVar2 == 0);
                    sub_08006DAC();
                    uVar6 = 0;
                    do {
                      sub_080003F0();
                      uVar6 = uVar6 + 1;
                    } while (uVar6 < 0x3c);
                    while( true ) {
                      sub_08006C14();
                      iVar2 = sub_0807A124();
                      if (iVar2 == 0) break;
                      sub_08006BF8();
                      do {
                        sub_080003F0();
                        iVar2 = sub_0805EEFC(unaff_r7);
                      } while (iVar2 == 0);
                    }
                    do {
                      sub_080003F0();
                      iVar2 = sub_0805EEFC(unaff_r7);
                    } while (iVar2 == 0);
                    sub_0801ABE8(10);
                    while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
                      sub_080003F0();
                    }
                    sub_0800CBAC();
                    sub_0800CDE4();
                    sub_0801AA8C(6);
                    while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
                      sub_080003F0();
                    }
                    SoftReset(0);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return in_lr;
}


