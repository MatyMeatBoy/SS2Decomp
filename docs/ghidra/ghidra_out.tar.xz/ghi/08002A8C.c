
bool sub_08002A8C(void)

{
  return *(int *)DWORD_08002a9c == 2;
}


