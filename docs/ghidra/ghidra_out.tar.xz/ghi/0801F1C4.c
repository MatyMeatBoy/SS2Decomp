
undefined4 sub_0801F1C4(int *param_1,int param_2,uint param_3)

{
  dword dVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_lr;
  undefined4 uStack_1c;
  uint uStack_18;
  
  *(undefined2 *)(param_2 + 0xc) = 10;
  dVar1 = DWORD_0801f2b8;
  uStack_18 = uStack_18 & DWORD_0801f2b4 | param_3 & 0xffff;
  uStack_1c = uStack_1c & DWORD_0801f2b4 + 0xff & DWORD_0801f2b8 | 0x20000;
  iVar2 = ArcTan2((*(int *)(param_2 + 0x14) - *param_1) * 0x100 >> 0x10,
                  (*(int *)(param_2 + 0x18) - param_1[1]) * 0x100 >> 0x10);
  uVar3 = (uStack_1c & DWORD_0801f2c0 |
          (uint)*(byte *)(((uint)(iVar2 << 0x10) >> 0x1c) + DWORD_0801f2bc) << 0x18) &
          DWORD_0801f2c4;
  uStack_1c = uVar3 | *(byte *)(param_2 + 2);
  *(short *)(param_2 + 0x4a) = (short)uStack_18 + *(short *)(param_2 + 0x4a);
  *(uint *)(param_2 + 0x4c) = uStack_18 & 0xffff;
  *(ushort *)(param_2 + 0x62) = (ushort)(uVar3 >> 8) & 0xff;
  *(ushort *)(param_2 + 0x7c) = (ushort)(byte)(uVar3 >> 0x10);
  if (((uStack_1c << 8) >> 0x18 & 0x80) != 0) {
    uStack_1c = uStack_1c & dVar1;
  }
  if (*(int *)(param_2 + 0x210) == 0xff) {
    uStack_1c = uStack_1c & dVar1;
  }
  sub_0801F2CC(param_2,&uStack_1c);
  *(short *)(param_2 + 0x7e) = (short)uStack_1c._3_1_;
  *(undefined2 *)(param_2 + 0x58) = 100;
  iVar2 = sub_080020F4();
  *(ushort *)(param_2 + 0x5a) =
       (ushort)(1 << (*(ushort *)(iVar2 * 0x14c + DWORD_0801f2c8) & 0xff)) |
       *(ushort *)(param_2 + 0x5a);
  sub_080660EC(&uStack_1c);
  return in_lr;
}


