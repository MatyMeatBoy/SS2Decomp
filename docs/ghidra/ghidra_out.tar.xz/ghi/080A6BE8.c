
/* WARNING: Type propagation algorithm not settling */

undefined4 sub_080A6BE8(uint param_1)

{
  byte bVar1;
  char cVar2;
  char cVar3;
  ushort uVar4;
  short sVar5;
  int iVar6;
  undefined4 uVar7;
  int *piVar8;
  short *psVar9;
  dword dVar10;
  ushort *puVar11;
  dword dVar12;
  int *piVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  undefined4 in_lr;
  undefined4 auStack_c4 [2];
  undefined4 uStack_bc;
  int iStack_b8;
  undefined1 auStack_a8 [24];
  int aiStack_90 [3];
  undefined2 auStack_84 [2];
  char acStack_80 [64];
  short sStack_40;
  short sStack_3e;
  uint uStack_3c;
  int iStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  uint uStack_28;
  int *piStack_24;
  
  dVar12 = DWORD_080a6c78;
  dVar10 = DWORD_080a6c70;
  uStack_3c = param_1 & 0xffff;
  iStack_38 = *(int *)DWORD_080a6c70 + 0x204;
  sub_08065158(auStack_c4,DWORD_080a6c74,*(undefined2 *)DWORD_080a6c78,0xffffffff,1);
  auStack_a8[0] = (undefined1)*(undefined2 *)dVar12;
  iVar6 = sub_0800CE30();
  cVar3 = '\x10';
  if (iVar6 == 1) {
    cVar3 = '\b';
  }
  uVar15 = 0;
  piStack_24 = aiStack_90;
  piStack_2c = aiStack_90 + 2;
  piStack_30 = aiStack_90 + 1;
  do {
    cVar2 = (char)uVar15;
    if (uStack_3c == 0) {
      piVar8 = piStack_24 + uVar15 * 5;
      acStack_80[uVar15 * 0x14] = cVar2 + '\x01';
      *piVar8 = *(int *)(*(int *)dVar10 + 0x14) + DWORD_080a6d04;
    }
    else {
      piVar8 = piStack_24 + uVar15 * 5;
      acStack_80[uVar15 * 0x14] = cVar2 + '\x04';
      *piVar8 = *(int *)(*(int *)dVar10 + 0x14) + 0x800;
      cVar2 = '\x03' - cVar2;
    }
    *(char *)((int)piVar8 + 0x13) = cVar3 * cVar2;
    acStack_80[uVar15 * 0x14 + 1] = '\0';
    piStack_2c[uVar15 * 5] = 0x80;
    piStack_30[uVar15 * 5] = *(int *)(*(int *)dVar10 + 0x18);
    auStack_84[uVar15 * 10 + 1] = 0;
    auStack_84[uVar15 * 10] = 0;
    acStack_80[uVar15 * 0x14 + 2] = '\0';
    uVar15 = uVar15 + 1 & 0xff;
  } while (uVar15 < 4);
  uVar15 = 0xf0;
  do {
    uVar16 = 0;
    uStack_28 = uVar15 - 1;
    do {
      dVar12 = DWORD_080a6d90;
      dVar10 = DWORD_080a6d8c;
      cVar3 = *(char *)((int)piStack_24 + uVar16 * 0x14 + 0x13);
      if (cVar3 == '\0') {
        bVar1 = *(byte *)((int)piStack_24 + uVar16 * 0x14 + 0x11);
        *(byte *)((int)piStack_24 + uVar16 * 0x14 + 0x11) = bVar1 + 1;
        if (8 < bVar1) {
          *(undefined1 *)((int)piStack_24 + uVar16 * 0x14 + 0x11) = 0;
          if (uStack_3c == 0) {
            if ((char)piStack_24[uVar16 * 5 + 4] == '\0') {
              cVar3 = '\a';
            }
            else {
              cVar3 = (char)piStack_24[uVar16 * 5 + 4] + -1;
              *(char *)(piStack_24 + uVar16 * 5 + 4) = cVar3;
            }
          }
          else if ((char)piStack_24[uVar16 * 5 + 4] == '\a') {
            cVar3 = '\0';
          }
          else {
            cVar3 = (char)piStack_24[uVar16 * 5 + 4] + '\x01';
            *(char *)(piStack_24 + uVar16 * 5 + 4) = cVar3;
          }
          *(char *)(piStack_24 + uVar16 * 5 + 4) = cVar3;
        }
        if (((char)piStack_24[uVar16 * 5 + 4] == '\0') ||
           ((char)piStack_24[uVar16 * 5 + 4] == '\x04')) {
          piVar8 = piStack_30 + uVar16 * 5;
          iVar6 = __divsi3((int)*(short *)((uint)*(ushort *)
                                                  ((uint)*(byte *)(piStack_24 + uVar16 * 5 + 4) * 2
                                                  + DWORD_080a6d90) * 2 + DWORD_080a6d8c) *
                           piStack_2c[uVar16 * 5],0x130);
          *piVar8 = *piVar8 + iVar6;
        }
        else {
          iVar6 = (int)*(short *)((uint)*(ushort *)
                                         ((uint)*(byte *)(piStack_24 + uVar16 * 5 + 4) * 2 +
                                         DWORD_080a7044) * 2 + DWORD_080a7040) *
                  piStack_2c[uVar16 * 5];
          if (iVar6 < 0) {
            iVar6 = iVar6 + 0xff;
          }
          piStack_30[uVar16 * 5] = piStack_30[uVar16 * 5] + (iVar6 >> 8);
          dVar10 = DWORD_080a7040;
          dVar12 = DWORD_080a7044;
        }
        piVar13 = piStack_24 + uVar16 * 5;
        piVar8 = piStack_2c + uVar16 * 5;
        iVar6 = *piVar8 * (int)*(short *)((*(ushort *)((uint)*(byte *)(piVar13 + 4) * 2 + dVar12) +
                                          0x40) * 2 + dVar10);
        if (iVar6 < 0) {
          iVar6 = iVar6 + 0xff;
        }
        *piVar13 = *piVar13 + (iVar6 >> 8);
        *piVar8 = (*piVar8 + 0x20) - uVar16;
      }
      else {
        cVar3 = cVar3 + -1;
        *(char *)((int)piStack_24 + uVar16 * 0x14 + 0x13) = cVar3;
        if (cVar3 == '\0') {
          sub_0805865C(0x1a2);
        }
      }
      iVar6 = sub_0800CCCC();
      if ((((iVar6 == 0) && (iVar6 = sub_0800CC98(), iVar6 == 0)) &&
          (iVar6 = sub_0800CD8C(), iVar6 == 0)) && (iVar6 = sub_0800CD34(), iVar6 == 0)) {
        sub_08000AF0(*(ushort *)DWORD_080a7048 + 0x10,
                     iStack_b8 + (uint)*(ushort *)(iStack_38 + 0xd6) * 0x20,1);
        piVar8 = piStack_24 + uVar16 * 5;
        sub_0800BC08((*piVar8 << 8) >> 0x10,(piStack_30[uVar16 * 5] << 8) >> 0x10,&sStack_40,
                     &sStack_3e,0,0);
        sub_08065370(auStack_c4,*(byte *)(piVar8 + 4) + 5,piVar8 + 3,(int)piVar8 + 0xe,1);
        sub_08007870((int)sStack_40,(int)sStack_3e,*(byte *)(piVar8 + 4) + 5,(short)piVar8[3],0,
                     auStack_a8,uStack_bc,auStack_c4[0]);
      }
      piStack_34 = piStack_24 + uVar16 * 5;
      if (*(char *)((int)piStack_34 + 0x12) == '\0') {
        iVar6 = sub_080020F4();
        dVar10 = DWORD_080a704c;
        iVar14 = *piStack_34;
        uVar7 = *(undefined4 *)(iVar6 * 0x14c + DWORD_080a704c + 0x8c);
        iVar6 = sub_080020F4();
        iVar14 = (int)(short)((short)((uint)iVar14 >> 8) - (short)((uint)uVar7 >> 8));
        iVar6 = (((piStack_30[uVar16 * 5] >> 8) + 0xc) -
                (*(int *)(iVar6 * 0x14c + dVar10 + 0x90) >> 8)) * 0x10000 >> 0x10;
        uVar4 = Sqrt(iVar14 * iVar14 + iVar6 * iVar6);
        if ((((uVar4 < 0x10) && (iVar6 = sub_0800CDF8(), iVar6 == 0)) &&
            ((iVar6 = sub_0800CD8C(), iVar6 == 0 &&
             ((iVar6 = sub_0800CCCC(), dVar12 = DWORD_080a7050, iVar6 == 0 &&
              (*(short *)(*(int *)DWORD_080a7050 + 0xc) != 0xb)))))) &&
           ((iVar6 = sub_080020F4(), (*(uint *)(iVar6 * 0x14c + dVar10 + 0x30) & 0x2000) == 0 &&
            ((((iVar6 = sub_080020F4(), *(char *)(iVar6 * 0x14c + dVar10 + 0x68) != '\0' &&
               (iVar6 = sub_080020F4(), *(short *)(iVar6 * 0x14c + dVar10 + 0x20) != 0xe)) &&
              (iVar6 = sub_080020F4(), *(short *)(iVar6 * 0x14c + dVar10 + 0x20) != 0xb)) &&
             (iVar6 = sub_080020F4(), *(short *)(iVar6 * 0x14c + dVar10 + 0x20) != 0xc)))))) {
          iVar6 = sub_080020F4();
          if (*(int *)((uint)**(ushort **)dVar12 * 4 + iVar6 * 0x14c + dVar10 + 0xe4) !=
              *(int *)(*(ushort **)dVar12 + 0x28)) {
            iVar6 = sub_080020F4();
            *(undefined2 *)(iVar6 * 0x14c + dVar10 + 0x20) = 10;
            iVar6 = sub_080020F4();
            *(short *)(iVar6 * 0x14c + dVar10 + 0xb0) = (short)DWORD_080a7054;
            iVar6 = sub_080020F4();
            uVar7 = *(undefined4 *)dVar12;
            iVar14 = sub_080020F4();
            sVar5 = sub_0801ED8C(uVar7,iVar14 * 0x14c + dVar10);
            psVar9 = (short *)(iVar6 * 0x14c + dVar10 + 0x88);
            *psVar9 = sVar5 + *psVar9;
            iVar6 = sub_080020F4();
            puVar11 = *(ushort **)dVar12;
            iVar14 = *(int *)(puVar11 + 0x28);
            *(int *)((uint)*puVar11 * 4 + iVar6 * 0x14c + dVar10 + 0xe4) = iVar14;
            *(int *)(puVar11 + 0x28) = iVar14 + 1;
            *(undefined1 *)((int)piStack_34 + 0x12) = 1;
          }
        }
      }
      uVar16 = uVar16 + 1 & 0xff;
    } while (uVar16 < 4);
    sub_080003F0();
    uVar15 = uStack_28 & 0xffff;
  } while (uVar15 != DWORD_080a7058);
  iVar6 = sub_0800048C();
  *(undefined4 *)(iVar6 + 8) = 0;
  return in_lr;
}


