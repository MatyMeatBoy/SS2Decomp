
undefined4 sub_08054CE8(void)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  dVar1 = DWORD_08054cf8;
  iVar3 = *(int *)DWORD_08054cfc + DWORD_08054d00;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08054d1c;
    iVar3 = iVar3 + 0x28;
  }
LAB_08054d46:
  dVar1 = DWORD_08054d54;
  iVar3 = *(int *)DWORD_08054d58 + DWORD_08054d5c;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08054d78;
    iVar3 = iVar3 + 0x28;
  }
LAB_08054da2:
  dVar1 = DWORD_08054db0;
  iVar3 = *(int *)DWORD_08054db4 + DWORD_08054db8;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08054dd4;
    iVar3 = iVar3 + 0x28;
  }
LAB_08054dfe:
  dVar1 = DWORD_08054e0c;
  iVar3 = *(int *)DWORD_08054e10 + DWORD_08054e14;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08054e30;
    iVar3 = iVar3 + 0x28;
  }
LAB_08054e5a:
  dVar1 = DWORD_08054e68;
  iVar3 = *(int *)DWORD_08054e6c + DWORD_08054e70;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08054e8c;
    iVar3 = iVar3 + 0x28;
  }
LAB_08054eb6:
  dVar1 = DWORD_08054ec4;
  iVar3 = *(int *)DWORD_08054ec8 + DWORD_08054ecc;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08054ee8;
    iVar3 = iVar3 + 0x28;
  }
LAB_08054f12:
  dVar1 = DWORD_08054f20;
  iVar3 = *(int *)DWORD_08054f24 + DWORD_08054f28;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08054f44;
    iVar3 = iVar3 + 0x28;
  }
LAB_08054f6e:
  iVar3 = sub_0800CC98();
  if (iVar3 == 0) {
    iVar3 = sub_0801AB24();
    if (iVar3 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar3 < 2) {
      if (iVar3 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar3 == 2) {
      sub_0801AB90(6);
    }
    while (iVar3 = sub_0801AAE0(), iVar3 == 0) {
      sub_080003F0();
    }
  }
  return in_lr;
LAB_08054d1c:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x1e);
  goto LAB_08054d46;
LAB_08054d78:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x1f);
  goto LAB_08054da2;
LAB_08054dd4:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x20);
  goto LAB_08054dfe;
LAB_08054e30:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x21);
  goto LAB_08054e5a;
LAB_08054e8c:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x22);
  goto LAB_08054eb6;
LAB_08054ee8:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x23);
  goto LAB_08054f12;
LAB_08054f44:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0x24);
  goto LAB_08054f6e;
}


