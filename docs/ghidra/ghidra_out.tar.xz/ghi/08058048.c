
undefined4 sub_08058048(int param_1,int param_2,int param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_lr;
  undefined2 uStack_1c;
  undefined2 uStack_1a;
  undefined4 auStack_18 [3];
  
  uStack_1c = (undefined2)param_3;
  uVar1 = param_4;
  if (param_3 != 10) {
    uStack_1a = (undefined2)param_4;
    uVar3 = 0;
    do {
      *(undefined1 *)((int)auStack_18 + uVar3) = 0;
      uVar3 = uVar3 + 1;
      uVar1 = auStack_18[0];
    } while (uVar3 < 0xc);
  }
  while (auStack_18[0] = uVar1, iVar2 = sub_08067B9C(param_1 << 8,param_2 * 0x100,&uStack_1c),
        iVar2 == 0) {
    sub_080003F0();
    uVar1 = auStack_18[0];
  }
  return in_lr;
}


