
void ld_r3_tp_adr_i(undefined4 param_1,int param_2)

{
  *(int *)(param_2 + 0x40) = *(int *)(param_2 + 0x40) + 1;
  return;
}


