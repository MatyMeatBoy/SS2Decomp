
undefined4 ClearChain(undefined4 param_1)

{
  undefined4 in_lr;
  
  _call_via_r1(param_1,*(undefined4 *)DWORD_080b7530);
  return in_lr;
}


