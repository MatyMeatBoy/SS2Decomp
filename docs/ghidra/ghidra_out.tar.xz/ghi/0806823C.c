
undefined8
sub_0806823C(uint param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  dword dVar1;
  int iVar2;
  undefined4 uVar3;
  undefined1 *puVar4;
  undefined4 in_lr;
  
  dVar1 = DWORD_08068290;
  if ((*(uint *)DWORD_08068290 < 0x32) && (iVar2 = sub_0800CFF0(), iVar2 == 0)) {
    puVar4 = (undefined1 *)(*(int *)DWORD_08068294 + *(int *)dVar1 * 0x88);
    *(undefined4 *)(puVar4 + 4) = 1;
    *puVar4 = 0xaa;
    *(uint *)(puVar4 + 8) = param_2 << 0x10 | param_1;
    *(undefined4 *)(puVar4 + 0xc) = param_3;
    *(undefined4 *)(puVar4 + 0x10) = param_4;
    *(undefined4 *)(puVar4 + 0x14) = param_5;
    puVar4[1] = 2;
    *(int *)dVar1 = *(int *)dVar1 + 1;
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  return CONCAT44(in_lr,uVar3);
}


