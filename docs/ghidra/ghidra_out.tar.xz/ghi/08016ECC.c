
undefined4 sub_08016ECC(int param_1)

{
  dword dVar1;
  dword dVar2;
  uint uVar3;
  int iVar4;
  uint *puVar5;
  uint uVar6;
  uint uVar7;
  undefined4 in_lr;
  
  dVar2 = DWORD_08016f18;
  dVar1 = DWORD_08016f14;
  uVar3 = param_1 * 0x10000 + DWORD_08016f10 >> 0x10;
  uVar7 = 1 << (uVar3 & 0xff);
  uVar6 = *(uint *)DWORD_08016f14;
  if ((uVar6 & uVar7) != 0) {
    iVar4 = uVar3 * 0xc;
    puVar5 = (uint *)(iVar4 + DWORD_08016f18 + 8);
    if (*puVar5 < 2) {
      *(undefined4 *)(iVar4 + DWORD_08016f18) = 0;
      *(undefined4 *)(iVar4 + dVar2 + 4) = 0;
      *puVar5 = 0;
      *(uint *)dVar1 = uVar6 & ~uVar7;
    }
    else {
      *puVar5 = *puVar5 - 1;
    }
  }
  return in_lr;
}


