
undefined4 sub_08082960(int param_1)

{
  ushort uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uVar5;
  ushort *puVar6;
  undefined1 *puVar7;
  ushort *puVar8;
  int iVar9;
  uint uVar10;
  undefined4 in_lr;
  undefined2 uStack_4c;
  undefined2 uStack_4a;
  undefined4 uStack_48;
  undefined1 uStack_44;
  undefined1 uStack_3c;
  undefined1 auStack_3b [39];
  
  if (param_1 != 0) {
    iVar2 = sub_08007290(DWORD_08082a38);
    uVar3 = sub_0801A638(iVar2 + 2);
    sub_0801A3D0(iVar2 + 2,0xf - (uVar3 >> 1) & 0xffff,3);
    uVar3 = 0;
    uVar1 = *(ushort *)(param_1 + *(int *)DWORD_08082a3c * 0x3e);
    uStack_3c = (undefined1)uVar1;
    puVar7 = &uStack_3c;
    while ((uVar1 & 0xff) != 0) {
      uVar3 = uVar3 + 1;
      puVar7 = puVar7 + 1;
      if (0x1e < uVar3) break;
      uVar1 = *(ushort *)(param_1 + (*(int *)DWORD_08082a3c * 0x1f + uVar3) * 2);
      *puVar7 = (char)uVar1;
    }
    *puVar7 = 0xfd;
    uVar3 = sub_0801A638(&uStack_3c);
    sub_0801A3D0(&uStack_3c,0xf - (uVar3 >> 1) & 0xffff,0x12);
    iVar2 = 0;
    uVar3 = 0;
    puVar8 = (ushort *)(param_1 + 0x136);
    do {
      if ((*puVar8 & 0x8000) == 0) {
        iVar2 = iVar2 + 1;
      }
      puVar8 = puVar8 + 1;
      uVar3 = uVar3 + 1;
    } while (uVar3 < 6);
    uStack_48 = 0;
    uStack_44 = 0;
    iVar9 = 0;
    uVar3 = 0;
    do {
      if ((*(ushort *)(param_1 + 0x136 + uVar3 * 2) & 0x8000) == 0) {
        switch(uVar3) {
        case 0:
          uStack_4c = 2;
          break;
        case 1:
          uStack_4c = 4;
          break;
        case 2:
          uStack_4c = 3;
          break;
        case 3:
          uStack_4c = 5;
          break;
        case 4:
          uStack_4c = 6;
          break;
        case 5:
          uStack_4c = 7;
        }
        uStack_4a = *(undefined2 *)(param_1 + 0x136 + uVar3 * 2);
        sub_0805FC80(iVar9 * 0x10 + 0x80 + iVar2 * -8,
                     0x38 - *(int *)(*(int *)DWORD_08082b08 + 0x74 + uVar3 * 8),&uStack_4c,0);
        iVar9 = iVar9 + 1;
      }
      uVar3 = uVar3 + 1;
    } while (uVar3 < 6);
    puVar8 = (ushort *)(param_1 + 0x144);
    uVar10 = 0;
    uVar3 = 0;
    puVar6 = puVar8;
    if (puVar8 != (ushort *)0x0) {
      do {
        if ((*puVar6 != 0) && (*puVar6 != 0x29)) {
          uVar10 = uVar10 + 1;
        }
        uVar3 = uVar3 + 1;
      } while ((uVar3 < 3) && (puVar6 = puVar6 + 2, puVar8 != (ushort *)0x0));
      uVar3 = 0;
      do {
        if (puVar8 == (ushort *)0x0) {
          return in_lr;
        }
        if ((*puVar8 != 0) && (*puVar8 != 0x29)) {
          if ((puVar8[1] & 0x8000) == 0) {
            uVar4 = (uint)*puVar8 * 2 + DWORD_08082b30;
          }
          else {
            uVar4 = (uint)*puVar8 * 2 + 0x2c4;
          }
          uVar5 = sub_08007290(uVar4 | 0x140000);
          if (uVar10 == 2) {
            uVar4 = (uint)(short)puVar8[1];
            if ((int)uVar4 < 0) {
              uVar4 = -uVar4;
            }
            sub_08081518(0xf,uVar3 * 0x20000 + 0xa0000 >> 0x10,uVar5,uVar4 & 0xffff,1);
          }
          else if (uVar10 < 3) {
            if (uVar10 == 1) {
              uVar4 = (uint)(short)puVar8[1];
              if ((int)uVar4 < 0) {
                uVar4 = -uVar4;
              }
              sub_08081518(0xf,0xb,uVar5,uVar4 & 0xffff,1);
            }
          }
          else if (uVar10 == 3) {
            uVar4 = (uint)(short)puVar8[1];
            if ((int)uVar4 < 0) {
              uVar4 = -uVar4;
            }
            sub_08081518(0xf,uVar3 * 0x20000 + 0x90000 >> 0x10,uVar5,uVar4 & 0xffff,1);
          }
        }
        puVar8 = puVar8 + 2;
        uVar3 = uVar3 + 1;
      } while (uVar3 < 3);
    }
  }
  return in_lr;
}


