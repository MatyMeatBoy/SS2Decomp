
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_080226A4(void)

{
  ushort uVar1;
  dword dVar2;
  undefined1 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined2 *puVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 uVar9;
  ushort *puVar10;
  undefined4 uVar11;
  uint uVar12;
  int unaff_r8;
  undefined4 in_lr;
  undefined2 uStack_24;
  undefined2 uStack_22;
  
  uVar4 = sub_080653CC();
  iVar5 = sub_080020F4();
  dVar2 = DWORD_0802271c;
  puVar6 = *(undefined2 **)DWORD_0802271c;
  *puVar6 = 0;
  puVar6[1] = 0;
  puVar6[4] = 9;
  *(undefined4 *)(puVar6 + 0x1c) = 0;
  *(undefined4 *)(puVar6 + 0x24) = 0;
  *(dword *)(puVar6 + 0x26) = DWORD_08022720;
  puVar6[0x1b] = 0;
  puVar6[2] = 1;
  *(undefined4 *)(puVar6 + 0x22) = 0;
  *(undefined4 *)(puVar6 + 0x2a) = 0;
  *(undefined4 *)(puVar6 + 0x36) = 0;
  *(undefined4 *)DWORD_08022724 = 0;
  uStack_22 = 0;
  uStack_24 = 0;
  uVar12 = 0;
  iVar8 = 0;
  do {
    *(undefined4 *)(*(int *)dVar2 + 0x7e0 + iVar8) = 0;
    iVar8 = iVar8 + 0x70;
    uVar12 = uVar12 + 1;
  } while (uVar12 < 0xf);
  uVar12 = 0;
  puVar7 = (undefined4 *)DWORD_08022728;
  do {
    puVar7[2] = 0;
    puVar7[1] = 0;
    *puVar7 = 0;
    puVar7 = puVar7 + 3;
    uVar12 = uVar12 + 1;
  } while (uVar12 < 3);
  while (iVar8 = sub_08067C18(), iVar8 == 0) {
    sub_080003F0();
  }
  while (iVar8 = sub_08067C08(), iVar8 == 0) {
    iVar8 = sub_0800CB9C();
    if (iVar8 != 0) {
      sub_08065370(uVar4,0x21,&uStack_24,&uStack_22,1);
      sub_08065230(uVar4,0x78,100,0x21,uStack_24);
    }
    sub_080003F0();
  }
  sub_08067BF8();
  iVar8 = sub_08002204();
  if (iVar8 != 0) {
    sub_08066624();
  }
  sub_08057624(5);
  while (iVar8 = sub_08067C18(), iVar8 == 0) {
    sub_080003F0();
  }
  while (iVar8 = sub_08067C08(), iVar8 == 0) {
    sub_080003F0();
  }
  sub_08067BF8();
  iVar8 = sub_0800CB9C();
  if (iVar8 == 0) {
    memcpy(*(int *)DWORD_08022828 + 0x70,*(undefined4 *)DWORD_0802282c,DWORD_08022830);
  }
  else {
    iVar8 = sub_08057AE8(7);
    if (iVar8 != 0) {
      sub_08057A5C(0x15);
    }
    sub_08057AE8(0x15);
    sub_0805C7B8();
    dVar2 = DWORD_080227ec;
    uVar12 = 0;
    do {
      iVar8 = *(int *)dVar2 + uVar12 * 0x20;
      *(undefined2 *)(iVar8 + 0x1e6) = 0;
      *(undefined2 *)(iVar8 + 0x1e8) = 0;
      uVar12 = uVar12 + 1;
    } while (uVar12 < 0x10);
  }
  iVar8 = *(int *)DWORD_08022828;
  *(undefined2 *)(iVar8 + 0x14a) = *(undefined2 *)(*(int *)DWORD_0802282c + 0xda);
  uVar12 = *(uint *)(iVar8 + 0x70);
  if (uVar12 < 5) {
                    /* WARNING: Could not recover jumptable at 0x08022824. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar4 = (**(code **)(uVar12 * 4 + DWORD_08022834))();
    return uVar4;
  }
  do {
    iVar8 = sub_0800CB78();
    if (iVar8 != 0) {
      return in_lr;
    }
    for (puVar10 = *(ushort **)(*(int *)DWORD_08022c1c + DWORD_08022c20); *puVar10 != 0;
        puVar10 = puVar10 + 0x92) {
      uVar1 = *puVar10;
      if (uVar1 != 2) {
        if (uVar1 < 3) {
          if (uVar1 == 1) {
LAB_08022c38:
            iVar8 = sub_0800CCCC();
            dVar2 = DWORD_08022c90;
            if (iVar8 == 0) {
              sub_0805A4A0(*puVar10);
              unaff_r8 = _call_via_r4(puVar10);
            }
            else {
              iVar8 = sub_08056E90();
              if ((iVar8 == 0) || (*(dword *)(*(int *)dVar2 + 0x40) == DWORD_08022c94)) {
                unaff_r8 = _call_via_r4(puVar10);
              }
              else {
                sub_080277E0(puVar10);
              }
              if (unaff_r8 != 0) {
                sub_080570DC(0);
              }
            }
          }
        }
        else if (uVar1 == 7) goto LAB_08022c38;
      }
    }
    iVar8 = sub_0800BA6C();
    if ((iVar8 != 0) && ((iVar8 = sub_0800CDC0(), iVar8 == 0 || (*(int *)DWORD_08022d10 != 0)))) {
      uVar11 = *(undefined4 *)(iVar5 * 0x14c + DWORD_08022d14 + 0x8c);
      uVar9 = *(undefined4 *)(iVar5 * 0x14c + DWORD_08022d14 + 0x90);
      uVar4 = sub_0800CCCC();
      uVar3 = sub_0800BCA0(uVar11,uVar9,uVar4);
      switch(uVar3) {
      case 2:
        iVar8 = sub_08000440(_UNK_08022d5c);
        if (iVar8 != 0) {
          sub_0800A03C();
        }
        if ((*(short *)(_UNK_08022d60 + 0xa0) == 2) && (*(short *)(_UNK_08022d60 + 0xa8) == 0)) {
          uVar4 = 0;
          uVar9 = 0x3c;
code_r0x08022d8c:
          sub_08029A7C(uVar4,uVar9,0);
        }
        break;
      case 3:
        iVar8 = sub_08000440(_UNK_08022d94);
        if (iVar8 != 0) {
          sub_0800A03C();
        }
        if ((*(short *)(_UNK_08022d98 + 0xa0) == 2) && (*(short *)(_UNK_08022d98 + 0xa8) == 0)) {
          uVar4 = 6;
          uVar9 = 0x2d;
          goto code_r0x08022d8c;
        }
        break;
      case 4:
        iVar8 = sub_08000440(_UNK_08022dcc);
        if (iVar8 != 0) {
          sub_0800A03C();
        }
        if (((*(short *)(_UNK_08022dd0 + 0xa0) == 0) || (*(short *)(_UNK_08022dd0 + 0xa0) == 2)) &&
           (*(short *)(_UNK_08022dd0 + 0xa8) == 0)) {
          uVar4 = 10;
code_r0x08022dfc:
          sub_08029CEC(1,uVar4,0);
        }
        break;
      case 5:
        iVar8 = sub_08000440(_UNK_08022e04);
        if (iVar8 != 0) {
          sub_0800A03C();
        }
        if ((*(short *)(_UNK_08022e08 + 0xa0) == 0) && (*(short *)(_UNK_08022e08 + 0xa8) == 0)) {
          uVar4 = 8;
          goto code_r0x08022dfc;
        }
        break;
      case 6:
        iVar8 = sub_08000440(_UNK_08022e58);
        if (iVar8 != 0) {
          sub_0800A03C();
        }
        if ((*(short *)(_UNK_08022e5c + 0xa0) == 2) && (*(short *)(_UNK_08022e5c + 0xa8) == 0)) {
          sub_08029CEC(1,6,0);
        }
      }
    }
    sub_080003F0();
  } while( true );
}


