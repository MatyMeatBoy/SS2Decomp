
undefined4 sub_08019F60(short *param_1)

{
  dword dVar1;
  short sVar2;
  uint uVar3;
  undefined4 in_lr;
  
  uVar3 = sub_08002164();
  dVar1 = DWORD_08019fa4;
  sVar2 = __udivsi3((int)param_1[3] * *(int *)(uVar3 * 0xc + DWORD_08019fa4),100);
  param_1[3] = sVar2;
  if (1 < uVar3) {
    sVar2 = __udivsi3((*param_1 + 2) * *(int *)(uVar3 * 0xc + dVar1 + 4),100);
    *param_1 = sVar2;
  }
  return in_lr;
}


