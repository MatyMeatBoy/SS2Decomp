
undefined4 sub_0800BBA8(uint param_1,undefined2 param_2,undefined2 param_3)

{
  int iVar1;
  undefined4 in_lr;
  
  iVar1 = sub_0800CCCC();
  if (iVar1 == 0) {
    iVar1 = (param_1 & 0xffff) * 0x18 + DWORD_0800bbd4;
    *(undefined2 *)(iVar1 + 8) = param_2;
    *(undefined2 *)(iVar1 + 10) = param_3;
  }
  return in_lr;
}


