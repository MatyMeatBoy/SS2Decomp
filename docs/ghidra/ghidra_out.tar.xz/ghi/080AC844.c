
/* WARNING: Possible PIC construction at 0x080ac8b8: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x080ac8bc) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_080AC844(ushort *param_1)

{
  bool bVar1;
  uint *puVar2;
  dword dVar3;
  dword dVar4;
  dword dVar5;
  char *pcVar6;
  byte bVar7;
  undefined1 uVar8;
  char cVar9;
  ushort uVar10;
  short sVar11;
  int iVar12;
  uint uVar13;
  undefined4 uVar14;
  uint uVar15;
  byte *pbVar16;
  int iVar17;
  uint uVar18;
  ushort *puVar19;
  undefined4 in_lr;
  short sStack_50;
  short sStack_4e;
  ushort *puStack_4c;
  int iStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  int iStack_30;
  ushort *puStack_2c;
  ushort *puStack_28;
  ushort *puStack_24;
  
  *puRam080ac8bc = param_1;
  puStack_4c = param_1 + 0x102;
  sub_0801623C(param_1,uRam080ac8c0,0);
  sub_08019F60(puStack_4c);
  sub_0801A0A4(param_1);
  puVar19 = puRam080ac8c4;
  uVar10 = sub_08016E04(param_1[0x16c],*(undefined2 *)((int)param_1 + iRam080ac8c8));
  *puVar19 = uVar10;
  puVar2 = puRam080ac8d0;
  uVar13 = uRam080ac8cc;
  while (uVar10 == uVar13) {
    param_1[6] = 0xb;
    iVar12 = sub_0800CB78();
    if ((iVar12 != 0) || (iVar12 = sub_08056E90(), iVar12 != 0)) {
      *puVar2 = *puVar2 & ~(1 << (*param_1 & 0xff));
      return in_lr;
    }
    sub_080003F0();
    uVar13 = (uint)*(ushort *)DWORD_080aca58;
  }
  sub_08065158(DWORD_080aca5c,DWORD_080aca60,*(undefined2 *)DWORD_080aca58,0xffffffff,1);
  uVar10 = puStack_4c[3];
  param_1[0xeb] = uVar10 * 3;
  param_1[0x2e] = uVar10 * 3;
  uVar10 = puStack_4c[2];
  param_1[0xea] = uVar10 * 0x14;
  param_1[0x2f] = uVar10 * 0x14;
  puStack_24 = param_1 + 0x36;
  *puStack_24 = 0;
  puStack_28 = param_1 + 0x35;
  *puStack_28 = 0;
  puStack_2c = param_1 + 0x34;
  *puStack_2c = 0;
  param_1[6] = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  param_1[0x28] = 1;
  dVar5 = DWORD_080aca6c;
  dVar4 = DWORD_080aca68;
  dVar3 = DWORD_080aca64;
  param_1[0x29] = 0;
  uVar13 = 0;
  do {
    uVar18 = 0;
    do {
      *(undefined4 *)((short)uVar18 * 4 + (short)uVar13 * 0x14c + dVar5) = 0;
      uVar15 = (int)(short)uVar18 + 1;
      uVar18 = uVar15 & 0xffff;
    } while ((int)(uVar15 * 0x10000) >> 0x10 < 5);
    uVar18 = uVar13 * 0x10000 + 0x10000;
    uVar13 = uVar18 >> 0x10;
  } while ((int)uVar18 >> 0x10 < 4);
  *(int *)dVar3 = *(int *)(param_1 + 10) >> 8;
  *(int *)(dVar3 + 4) = (*(int *)(param_1 + 0xc) >> 8) + 0x10;
  *(undefined1 *)dVar4 = 0;
  uVar13 = 1;
  do {
    iVar17 = (int)(short)uVar13;
    iVar12 = (iVar17 + -1) * 8;
    *(undefined4 *)(iVar17 * 8 + dVar3) = *(undefined4 *)(iVar12 + dVar3);
    *(int *)(iVar17 * 8 + dVar3 + 4) = *(int *)(iVar12 + dVar3 + 4) + -0x10;
    *(undefined1 *)(iVar17 + dVar4) = 0;
    uVar13 = iVar17 + 1U & 0xffff;
  } while ((int)((iVar17 + 1U) * 0x10000) >> 0x10 < 5);
  sub_080AE0B8();
  sub_080AE11C(0);
  sub_080AE11C(1);
  sub_080AE11C(2);
  sub_080AE11C(3);
  sub_08097FE4();
  sub_08097A4C();
  param_1[4] = 1;
  *(byte *)((int)param_1 + DWORD_080aca70) = 2;
  *(byte *)(param_1 + 0xff) = 2;
  uStack_38 = 0;
  *(undefined1 *)DWORD_080aca74 = 0;
  *(undefined1 *)DWORD_080aca78 = 0;
  uStack_34 = 0;
  *(byte *)(param_1 + 0xfe) = (byte)param_1[0xfe] & 0xf0 | (byte)*param_1 & 0xf;
  *(ushort *)((int)param_1 + DWORD_080aca7c) = param_1[1];
  *(byte *)(param_1 + 0x100) = 0xff;
  iStack_30 = 0;
  param_1[4] = 1;
  sub_08067C18();
  while (iVar12 = sub_08067C08(), iVar12 == 0) {
    sub_080003F0();
  }
  sub_08067BF8();
  do {
    iVar12 = sub_0800CB78();
    if ((iVar12 != 0) || (iVar12 = sub_08056E90(), iVar12 != 0)) break;
    if (*(int *)DWORD_080acaa4 == 1) {
      sub_0801A0A4(param_1);
    }
    else {
      sub_0801A0B0(param_1);
    }
    if ((param_1[6] == 10) && (uStack_44 == 0)) {
      *(undefined1 *)DWORD_080acaf8 = 1;
      uStack_44 = 8;
    }
    iVar12 = sub_08058DB0();
    puVar19 = puStack_4c + 0x6b;
    if (iVar12 != 0) goto LAB_080ace16;
    sub_0801C8F0(param_1);
    switch(*(byte *)((int)param_1 + DWORD_080acafc)) {
    case 1:
      param_1[6] = 0;
      iVar12 = sub_08067C08();
      puVar19 = puStack_4c + 0x6b;
      if (iVar12 != 0) {
        *(byte *)((int)param_1 + _UNK_080acb5c) = (byte)param_1[0xff];
        sub_08067BF8();
      }
      break;
    case 2:
      iVar12 = sub_08056F78();
      puVar19 = puStack_4c + 0x6b;
      if (iVar12 == 0) break;
      *(byte *)(param_1 + 0xff) = 5;
      pbVar16 = (byte *)((int)param_1 + _UNK_080acb88);
      goto code_r0x080acd8e;
    case 5:
      param_1[6] = 2;
      pcVar6 = _UNK_080acc20;
      if (*_UNK_080acc20 == '\0') {
        sVar11 = sub_08095B04(param_1,0x240);
        if (sVar11 != 0) {
          if (*_UNK_080acc50 < 6) {
            *_UNK_080acc50 = *_UNK_080acc50 + 1;
          }
          else {
            *_UNK_080acc50 = 0;
            iVar12 = *_UNK_080acc8c;
            if (iVar12 != 1) {
              iVar12 = 0x5a;
            }
            *pcVar6 = (char)iVar12;
          }
        }
        puVar19 = puStack_4c + 0x6b;
        bVar1 = 0x3c < uStack_38;
        uStack_38 = uStack_38 + 1 & 0xff;
        if (bVar1) {
          uStack_38 = 0;
          sub_0805865C(0xe9);
        }
      }
      else {
        cVar9 = *_UNK_080acc20 + -1;
        *_UNK_080acc20 = cVar9;
        iVar17 = _UNK_080acc2c;
        iVar12 = _UNK_080acc28;
        puVar19 = puStack_4c + 0x6b;
        if (cVar9 == '\0') {
          uVar13 = 0;
          uVar18 = 1;
          do {
            if ((1 << ((int)(short)uVar18 & 0xffU) & *_UNK_080acc24) != 0) {
              uVar13 = uVar13 * 0x10000 + 0x10000 >> 0x10;
            }
            uVar15 = (int)(short)uVar18 + 1;
            uVar18 = uVar15 & 0xffff;
          } while ((int)(uVar15 * 0x10000) >> 0x10 < 5);
          if (uVar13 != 0) {
            uVar13 = 0;
            do {
              *(undefined1 *)(*(int *)((short)uVar13 * 4 + iVar12) + iVar17) = 8;
              uVar18 = (int)(short)uVar13 + 1;
              uVar13 = uVar18 & 0xffff;
            } while ((int)(uVar18 * 0x10000) >> 0x10 < 4);
          }
          *pcVar6 = '\0';
          *(byte *)(param_1 + 0xff) = 8;
          pbVar16 = (byte *)((int)param_1 + _UNK_080acc2c);
          goto code_r0x080acd8e;
        }
      }
      break;
    case 8:
      uVar13 = 0;
      uVar18 = 1;
      puVar19 = puStack_4c + 0x6b;
      do {
        if ((1 << ((int)(short)uVar18 & 0xffU) & *_UNK_080acd00) != 0) {
          uVar13 = uVar13 * 0x10000 + 0x10000 >> 0x10;
        }
        uVar15 = (int)(short)uVar18 + 1;
        uVar18 = uVar15 & 0xffff;
      } while ((int)(uVar15 * 0x10000) >> 0x10 < 5);
      iVar12 = (int)(short)uVar13;
      if (iVar12 == 0) {
code_r0x080acd80:
        bVar7 = 5;
      }
      else {
        uVar13 = 0;
        if (0 < iVar12) {
          do {
            if (*(char *)((short)uVar13 + _UNK_080acd04) != '\x01') goto LAB_080ace16;
            uVar18 = (int)(short)uVar13 + 1;
            uVar13 = uVar18 & 0xffff;
          } while ((int)(uVar18 * 0x10000) >> 0x10 < iVar12);
        }
        bVar7 = 9;
      }
      goto code_r0x080acd88;
    case 9:
      uVar13 = 0;
      uVar18 = 1;
      puVar19 = puStack_4c + 0x6b;
      do {
        if ((1 << ((int)(short)uVar18 & 0xffU) & *_UNK_080acd78) != 0) {
          uVar13 = uVar13 * 0x10000 + 0x10000 >> 0x10;
        }
        uVar15 = (int)(short)uVar18 + 1;
        uVar18 = uVar15 & 0xffff;
      } while ((int)(uVar15 * 0x10000) >> 0x10 < 5);
      iVar12 = (int)(short)uVar13;
      if (iVar12 == 0) goto code_r0x080acd80;
      uVar13 = 0;
      if (0 < iVar12) {
        do {
          if (*(char *)((short)uVar13 + _UNK_080acd7c) != '\x02') goto LAB_080ace16;
          uVar18 = (int)(short)uVar13 + 1;
          uVar13 = uVar18 & 0xffff;
        } while ((int)(uVar18 * 0x10000) >> 0x10 < iVar12);
      }
      bVar7 = 10;
code_r0x080acd88:
      puVar19 = puStack_4c + 0x6b;
      *(byte *)(param_1 + 0xff) = bVar7;
      pbVar16 = (byte *)((int)param_1 + _UNK_080acd98);
code_r0x080acd8e:
      *pbVar16 = 1;
      sub_08067C18();
      break;
    case 10:
      uVar13 = 0;
      uVar18 = 1;
      puVar19 = puStack_4c + 0x6b;
      do {
        if ((1 << ((int)(short)uVar18 & 0xffU) & *_UNK_080ace44) != 0) {
          uVar13 = uVar13 * 0x10000 + 0x10000 >> 0x10;
        }
        uVar15 = (int)(short)uVar18 + 1;
        uVar18 = uVar15 & 0xffff;
      } while ((int)(uVar15 * 0x10000) >> 0x10 < 5);
      iVar12 = (int)(short)uVar13;
      if ((iVar12 != 0) && (uVar13 = 0, 0 < iVar12)) {
        do {
          if (*(char *)((short)uVar13 + _UNK_080ace48) != '\0') goto LAB_080ace16;
          uVar18 = (int)(short)uVar13 + 1;
          uVar13 = uVar18 & 0xffff;
        } while ((int)(uVar18 * 0x10000) >> 0x10 < iVar12);
      }
      *(byte *)(param_1 + 0xff) = 5;
      *(byte *)((int)param_1 + _UNK_080ace4c) = 1;
      sub_08067C18();
    }
LAB_080ace16:
    *puStack_2c = param_1[4];
    dVar3 = DWORD_080ace50;
    *(int *)DWORD_080ace50 = *(int *)(param_1 + 10) >> 8;
    *(int *)(dVar3 + 4) = *(int *)(param_1 + 0xc) >> 8;
    *(char *)DWORD_080ace54 = (char)param_1[4];
    switch(param_1[4]) {
    default:
      goto LAB_080acec4;
    case 1:
      iVar12 = *(int *)dVar3 + 4;
      goto code_r0x080acebc;
    case 2:
      *(int *)dVar3 = *(int *)dVar3 + 0xe;
      iVar12 = *(int *)(dVar3 + 4) + 8;
      break;
    case 3:
      *(int *)dVar3 = *(int *)dVar3 + 0xe;
      iVar12 = *(int *)(dVar3 + 4) + 0x10;
      break;
    case 4:
      iVar12 = *(int *)(dVar3 + 4) + 0x10;
      break;
    case 5:
      *(int *)dVar3 = *(int *)dVar3 + -0xe;
      iVar12 = *(int *)(dVar3 + 4) + 0x10;
      break;
    case 6:
      *(int *)dVar3 = *(int *)dVar3 + -0xe;
      iVar12 = *(int *)(dVar3 + 4) + 8;
      break;
    case 7:
      iVar12 = *(int *)dVar3 + -4;
code_r0x080acebc:
      *(int *)dVar3 = iVar12;
      iVar12 = *(int *)(dVar3 + 4) + 4;
    }
    *(int *)(dVar3 + 4) = iVar12;
LAB_080acec4:
    sub_08000AF0(*(ushort *)DWORD_080acef0 + 0x10,
                 *(int *)(DWORD_080acef4 + 0xc) + (uint)*puVar19 * 0x20,1);
    uVar13 = sub_08098004();
    if ((uVar13 & 1) == 0) {
      uVar8 = sub_0800BC44(*(int *)DWORD_080acfb4 >> 8,*(int *)(DWORD_080acfb4 + 4) >> 8,0);
    }
    else {
      uVar8 = sub_08097FF8();
    }
    dVar3 = DWORD_080acfb8;
    *(char *)(DWORD_080acfb8 + 0x1c) = (char)*(undefined2 *)DWORD_080acfbc;
    iVar12 = sub_0800CD8C();
    if (iVar12 == 0) {
      uVar10 = sub_08065370(dVar3,*puStack_2c,puStack_28,puStack_24,1);
      param_1[0x37] = uVar10;
    }
    sub_0800BC08((*(int *)(param_1 + 10) << 8) >> 0x10,(*(int *)(param_1 + 0xc) << 8) >> 0x10,
                 &sStack_50,&sStack_4e,0,0);
    if (uStack_44 == 0) {
      iVar12 = sub_0800CCCC();
      if (((iVar12 == 0) && (iVar12 = sub_0800CC98(), iVar12 == 0)) &&
         (iVar12 = sub_0800CD34(), iVar12 == 0)) {
        sub_08007870((int)sStack_50,(int)sStack_4e,*puStack_2c,*puStack_28,uVar8,dVar3 + 0x1c,
                     *(undefined4 *)(dVar3 + 8),*(undefined4 *)dVar3);
      }
    }
    else {
      uVar13 = uStack_44 - 1 & 0xffff;
      uVar18 = uStack_44 & 1;
      uStack_44 = uVar13;
      if (((uVar18 != 0) && (iVar12 = sub_0800CCCC(), iVar12 == 0)) &&
         ((iVar12 = sub_0800CC98(), iVar12 == 0 && (iVar12 = sub_0800CD34(), iVar12 == 0)))) {
        sub_08007870((int)sStack_50,(int)sStack_4e,*puStack_2c,*puStack_28,uVar8,dVar3 + 0x1c,
                     *(undefined4 *)(dVar3 + 8),*(undefined4 *)dVar3);
      }
    }
    if (uStack_34 == 0) {
      cVar9 = sub_080ADE30(param_1);
      if (cVar9 != '\0') {
        uStack_34 = 0x1e;
      }
    }
    else {
      uStack_34 = uStack_34 - 1 & 0xff;
    }
    iVar12 = *(int *)(param_1 + 0x26);
    if ((iVar12 != 0) && (iStack_48 != iVar12)) {
      uStack_40 = 10;
      uStack_3c = 0;
      iStack_48 = iVar12;
    }
    if (uStack_40 == 0) {
      iStack_48 = 0;
      param_1[0x26] = 0;
      param_1[0x27] = 0;
    }
    else {
      iVar12 = sub_0800CC98();
      if (((iVar12 == 0) && (iVar12 = sub_0800CCCC(), iVar12 == 0)) &&
         (iVar12 = sub_0800CD34(), iVar12 == 0)) {
        sub_0801A120(param_1,iStack_48,(int)(short)uStack_3c);
      }
      if ((uStack_40 & 2) != 0) {
        uStack_3c = uStack_3c * 0x10000 + DWORD_080ad084 >> 0x10;
      }
      uStack_40 = uStack_40 - 1 & 0xffff;
    }
    sVar11 = sub_08019CE8(param_1);
    if (sVar11 != 0) {
      iStack_30 = 1;
    }
    sub_080003F0();
  } while (iStack_30 == 0);
  *(undefined4 *)DWORD_080ad1e4 = 0;
  sub_080AE0E4();
  uStack_3c = 0;
  uStack_40 = 10;
  do {
    iVar12 = sub_0800CCCC();
    if (((iVar12 == 0) && (iVar12 = sub_0800CC98(), iVar12 == 0)) &&
       (iVar12 = sub_0800CD34(), dVar4 = DWORD_080ad1ec, dVar3 = DWORD_080ad1e8, iVar12 == 0)) {
      *(char *)(DWORD_080ad1e8 + 0x1c) = (char)*(undefined2 *)DWORD_080ad1ec;
      sub_08000AF0(*(ushort *)dVar4 + 0x10,*(int *)(dVar3 + 0xc) + (uint)puStack_4c[0x6b] * 0x20,1);
      uVar8 = sub_0800BC44(*(int *)DWORD_080ad1f0 >> 8,*(int *)(DWORD_080ad1f0 + 4) >> 8,0);
      uVar10 = sub_08065370(dVar3,*puStack_2c,puStack_28,puStack_24,1);
      param_1[0x37] = uVar10;
      sub_0800BC08((*(int *)(param_1 + 10) << 8) >> 0x10,(*(int *)(param_1 + 0xc) << 8) >> 0x10,
                   &sStack_50,&sStack_4e,0,0);
      if ((uStack_40 & 1) != 0) {
        sub_08007870((int)sStack_50,(int)sStack_4e,*puStack_2c,*puStack_28,uVar8,dVar3 + 0x1c,
                     *(undefined4 *)(dVar3 + 8),*(undefined4 *)dVar3);
      }
      sub_0801A120(param_1,iStack_48,(int)(short)uStack_3c);
    }
    if ((uStack_40 & 2) != 0) {
      uStack_3c = uStack_3c * 0x10000 + DWORD_080ad1f4 >> 0x10;
    }
    sub_080003F0();
    uStack_40 = uStack_40 - 1 & 0xffff;
  } while (uStack_40 != DWORD_080ad1f8);
  sub_080683CC();
  sub_08067CA8(param_1[1]);
  sub_08068330(DWORD_080ad1fc);
  uVar13 = uStack_44 & 1;
  while (iVar12 = sub_080682B8(DWORD_080ad2e8), iVar12 == 0) {
    iVar12 = sub_0800CCCC();
    if (((iVar12 == 0) && (iVar12 = sub_0800CC98(), iVar12 == 0)) &&
       ((iVar12 = sub_0800CD8C(), iVar12 == 0 &&
        (iVar12 = sub_0800CD34(), dVar4 = DWORD_080ad2e0, dVar3 = DWORD_080ad2dc, iVar12 == 0)))) {
      *(char *)(DWORD_080ad2dc + 0x1c) = (char)*(undefined2 *)DWORD_080ad2e0;
      sub_08000AF0(*(ushort *)dVar4 + 0x10,*(int *)(dVar3 + 0xc) + (uint)puStack_4c[0x6b] * 0x20,1);
      uVar8 = sub_0800BC44(*(int *)DWORD_080ad2e4 >> 8,*(int *)(DWORD_080ad2e4 + 4) >> 8,0);
      uVar10 = sub_08065370(dVar3,*puStack_2c,puStack_28,puStack_24,1);
      param_1[0x37] = uVar10;
      sub_0800BC08((*(int *)(param_1 + 10) << 8) >> 0x10,(*(int *)(param_1 + 0xc) << 8) >> 0x10,
                   &sStack_50,&sStack_4e,0,0);
      if (uVar13 != 0) {
        sub_08007870((int)sStack_50,(int)sStack_4e,*puStack_2c,*puStack_28,uVar8,dVar3 + 0x1c,
                     *(undefined4 *)(dVar3 + 8),*(undefined4 *)dVar3);
      }
    }
    sub_080003F0();
  }
  sub_08065E38(DWORD_080ad2e8);
  uVar13 = uStack_44 & 1;
  while (iVar12 = sub_08058DB0(), iVar12 != 0) {
    iVar12 = sub_0800CCCC();
    if ((((iVar12 == 0) && (iVar12 = sub_0800CC98(), iVar12 == 0)) &&
        (iVar12 = sub_0800CD8C(), iVar12 == 0)) &&
       (iVar12 = sub_0800CD34(), dVar4 = DWORD_080ad518, dVar3 = DWORD_080ad514, iVar12 == 0)) {
      *(char *)(DWORD_080ad514 + 0x1c) = (char)*(undefined2 *)DWORD_080ad518;
      sub_08000AF0(*(ushort *)dVar4 + 0x10,*(int *)(dVar3 + 0xc) + (uint)puStack_4c[0x6b] * 0x20,1);
      uVar8 = sub_0800BC44(*(int *)DWORD_080ad51c >> 8,*(int *)(DWORD_080ad51c + 4) >> 8,0);
      uVar10 = sub_08065370(dVar3,*puStack_2c,puStack_28,puStack_24,1);
      param_1[0x37] = uVar10;
      sub_0800BC08((*(int *)(param_1 + 10) << 8) >> 0x10,(*(int *)(param_1 + 0xc) << 8) >> 0x10,
                   &sStack_50,&sStack_4e,0,0);
      if (uVar13 != 0) {
        sub_08007870((int)sStack_50,(int)sStack_4e,*puStack_2c,*puStack_28,uVar8,dVar3 + 0x1c,
                     *(undefined4 *)(dVar3 + 8),*(undefined4 *)dVar3);
      }
    }
    sub_080003F0();
  }
  sub_080586B4(0);
  uStack_44 = 0x14;
  do {
    iVar12 = sub_0800CCCC();
    if (((iVar12 == 0) && (iVar12 = sub_0800CC98(), iVar12 == 0)) &&
       (iVar12 = sub_0800CD34(), dVar4 = DWORD_080ad518, dVar3 = DWORD_080ad514, iVar12 == 0)) {
      *(char *)(DWORD_080ad514 + 0x1c) = (char)*(undefined2 *)DWORD_080ad518;
      sub_08000AF0(*(ushort *)dVar4 + 0x10,*(int *)(dVar3 + 0xc) + (uint)puStack_4c[0x6b] * 0x20,1);
      uVar8 = sub_0800BC44(*(int *)DWORD_080ad51c >> 8,*(int *)(DWORD_080ad51c + 4) >> 8,0);
      uVar10 = sub_08065370(dVar3,*puStack_2c,puStack_28,puStack_24,1);
      param_1[0x37] = uVar10;
      sub_0800BC08((*(int *)(param_1 + 10) << 8) >> 0x10,(*(int *)(param_1 + 0xc) << 8) >> 0x10,
                   &sStack_50,&sStack_4e,0,0);
      if ((uStack_44 & 1) != 0) {
        sub_08007870((int)sStack_50,(int)sStack_4e,*puStack_2c,*puStack_28,uVar8,dVar3 + 0x1c,
                     *(undefined4 *)(dVar3 + 8),*(undefined4 *)dVar3);
      }
    }
    sub_080003F0();
    uStack_44 = uStack_44 - 1 & 0xffff;
  } while (uStack_44 != DWORD_080ad520);
  iVar12 = sub_080020F4();
  if (((*(uint *)(iVar12 * 0x14c + DWORD_080ad524 + 0x30) & 0x2000) == 0) &&
     (*(short *)(*(int *)DWORD_080ad528 + 0x5a) != 0)) {
    uVar14 = sub_0801E46C(*(undefined4 *)DWORD_080ad52c,puStack_4c);
    uStack_3c = 0x1d;
    do {
      iVar12 = *(int *)DWORD_080ad528;
      *(int *)(iVar12 + 0x18) = *(int *)(iVar12 + 0x18) + -0x20;
      sub_0806171C(iVar12,uVar14);
      sub_080003F0();
      uVar13 = uStack_3c * 0x10000 + DWORD_080ad530;
      uStack_3c = uVar13 >> 0x10;
    } while ((int)uVar13 >> 0x10 != -1);
    sub_0801E4CC(*(undefined4 *)DWORD_080ad52c,uVar14);
  }
  sub_08056E24();
  return in_lr;
}


