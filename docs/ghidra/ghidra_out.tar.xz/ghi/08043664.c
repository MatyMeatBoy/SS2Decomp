
undefined4 sub_08043664(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_08043698;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) | 1;
  sub_0800D0F4();
  iVar1 = sub_0800CE30();
  if (iVar1 == 0) {
    iVar1 = *(int *)DWORD_080436c4;
    iVar3 = 0x1ba;
  }
  else {
    iVar1 = *(int *)DWORD_0804369c;
    iVar3 = 0x1c6;
  }
  if (((int)(uint)*(byte *)(iVar1 + iVar3) >> 4 & 1U) == 0) {
    iVar1 = sub_080020F4();
    if (iVar1 == 0) {
      while (iVar1 = sub_0805F184(), iVar1 != 0) {
        sub_080003F0();
      }
      uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,DWORD_080436f0);
      while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
        sub_080003F0();
      }
      iVar1 = sub_0805EF14(uVar2);
      if (iVar1 == 0) {
        while (iVar1 = sub_0805F184(), iVar1 != 0) {
          sub_080003F0();
        }
        while (iVar1 = sub_0805EF90(), iVar1 != 0) {
          sub_080003F0();
        }
        uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_080437b4);
        while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
          iVar1 = sub_0800CDF8();
          if (iVar1 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
      }
      else {
        sub_08068070(DWORD_08043718,0x1c);
        while (iVar1 = sub_0805F184(), iVar1 != 0) {
          sub_080003F0();
        }
        while (iVar1 = sub_0805EF90(), iVar1 != 0) {
          sub_080003F0();
        }
        uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08043750);
        while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
          iVar1 = sub_0800CDF8();
          if (iVar1 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
        sub_08068820(DWORD_0804377c,param_1,0);
      }
    }
    else {
      while (iVar1 = sub_0805F184(), iVar1 != 0) {
        sub_080003F0();
      }
      while (iVar1 = sub_0805EF90(), iVar1 != 0) {
        sub_080003F0();
      }
      uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08043808);
      while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
        iVar1 = sub_0800CDF8();
        if (iVar1 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
    }
  }
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_0804384c;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


