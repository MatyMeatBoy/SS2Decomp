
undefined4 sub_080542C4(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  dword dVar3;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_080542f4;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) | 1;
  sub_0800D0F4();
  iVar1 = sub_0800CE30();
  if (iVar1 == 0) {
    iVar1 = *(int *)DWORD_08054324;
    dVar3 = DWORD_08054328;
  }
  else {
    iVar1 = *(int *)DWORD_080542f8;
    dVar3 = DWORD_080542fc;
  }
  if (((int)(uint)*(byte *)(iVar1 + dVar3) >> 1 & 1U) == 0) {
    iVar1 = sub_0800CE30();
    if (iVar1 == 0) {
      iVar1 = *(int *)DWORD_08054344;
      dVar3 = DWORD_08054348;
    }
    else {
      iVar1 = *(int *)DWORD_08054324;
      dVar3 = DWORD_0805432c;
    }
    *(byte *)(iVar1 + dVar3) = *(byte *)(iVar1 + dVar3) | 2;
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_08054380);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      sub_080003F0();
    }
    sub_080290E4(param_1,0);
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_080543d0);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      sub_080003F0();
    }
    sub_08028AAC(2,0x138,200,0);
    sub_08028AAC(1,DWORD_08054424,DWORD_08054424,0);
    iVar1 = sub_080020F4();
    iVar1 = iVar1 * 0x14c + DWORD_08054428;
    *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & 0xfffffffe;
    sub_0800D108();
  }
  return in_lr;
}


