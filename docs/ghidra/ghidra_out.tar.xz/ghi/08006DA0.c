
undefined4 sub_08006DA0(void)

{
  undefined4 in_lr;
  
  m4aMPlayStop();
  return in_lr;
}


