
undefined4 sub_080012F8(void)

{
  dword dVar1;
  dword dVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  undefined4 in_lr;
  
  dVar1 = DWORD_08001334;
  uVar3 = sub_08001494(0x12c0);
  *(undefined4 *)dVar1 = uVar3;
  dVar2 = DWORD_08001338;
  uVar6 = 0;
  iVar5 = 0;
  do {
    puVar4 = (undefined4 *)(iVar5 + *(int *)dVar1);
    *puVar4 = 0;
    puVar4[1] = 0;
    puVar4[2] = 0;
    iVar5 = iVar5 + 0xc;
    uVar6 = uVar6 + 1;
  } while (uVar6 <= dVar2);
  *(undefined4 *)DWORD_0800133c = 0;
  *(undefined4 *)DWORD_08001340 = 0;
  *(undefined4 *)DWORD_08001344 = 0;
  return in_lr;
}


