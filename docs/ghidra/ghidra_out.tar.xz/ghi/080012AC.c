
undefined4 sub_080012AC(void)

{
  undefined4 in_lr;
  
  _call_via_r0(*(undefined4 *)DWORD_080012cc);
  *(undefined2 *)DWORD_080012d0 = 0x100;
  *(ushort *)DWORD_080012d4 = *(ushort *)DWORD_080012d4 | 0x100;
  return in_lr;
}


