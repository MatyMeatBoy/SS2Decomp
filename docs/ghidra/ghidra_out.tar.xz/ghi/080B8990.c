
void VerifyFlashSectorNBytes(uint param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  undefined2 *puVar2;
  undefined2 *puVar3;
  uint uVar4;
  undefined2 uStack_110;
  
  puVar2 = &uStack_110;
  uVar4 = param_1 & 0xffff;
  if (**(int **)DWORD_080b89d8 == 0x20000) {
    SwitchFlashBank((param_1 << 0x10) >> 0x14 & 0xff);
    uVar4 = param_1 & 0xf;
  }
  *(ushort *)DWORD_080b89dc = *(ushort *)DWORD_080b89dc & (ushort)DWORD_080b89e0 | 3;
  puVar3 = (undefined2 *)(DWORD_080b89e4 & 0xfffffffe);
  for (uVar1 = (DWORD_080b89e8 - DWORD_080b89e4) * 0x8000; uVar1 >> 0x10 != 0;
      uVar1 = ((uVar1 >> 0x10) - 1) * 0x10000) {
    *puVar2 = *puVar3;
    puVar3 = puVar3 + 1;
    puVar2 = puVar2 + 1;
  }
  _call_via_r3(param_2,(uVar4 << *(sbyte *)(*(int *)DWORD_080b8a24 + 8)) + 0xe000000,param_3,
               (int)&uStack_110 + 1);
  return;
}


