
void sub_08034488(undefined4 param_1)

{
  dword dVar1;
  short sVar2;
  int iVar3;
  byte *pbVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  
  iVar3 = sub_0800CE30();
  if (iVar3 == 0) {
    pbVar4 = (byte *)(*(int *)DWORD_0803454c + DWORD_08034550);
  }
  else {
    pbVar4 = (byte *)(*(int *)DWORD_080344a4 + DWORD_080344a8);
  }
  uVar9 = (int)(uint)*pbVar4 >> 5 & 1;
  if (uVar9 == 0) {
    do {
      sub_0802939C(param_1,0);
      sVar2 = 400;
      do {
        sub_080003F0();
        iVar3 = sub_080021A8();
        if (iVar3 != 0) break;
        sVar2 = sVar2 + -1;
      } while (sVar2 != 0);
      sub_0802939C(param_1,1);
      sVar2 = 400;
      do {
        sub_080003F0();
        iVar3 = sub_080021A8();
        if (iVar3 != 0) break;
        sVar2 = sVar2 + -1;
      } while (sVar2 != 0);
      sub_0802939C(param_1,8);
      sub_08028AAC(param_1,0xf3,0xe9,0x3c);
      sub_0802939C(param_1,2);
      sVar2 = 0x1e;
      do {
        sub_080003F0();
        iVar3 = sub_080021A8();
        if (iVar3 != 0) break;
        sVar2 = sVar2 + -1;
      } while (sVar2 != 0);
      sub_0802939C(param_1,3);
      sVar2 = 0x78;
      do {
        sub_080003F0();
        iVar3 = sub_080021A8();
        if (iVar3 != 0) break;
        sVar2 = sVar2 + -1;
      } while (sVar2 != 0);
      sub_0802939C(param_1,2);
      sVar2 = 0x1e;
      do {
        sub_080003F0();
        iVar3 = sub_080021A8();
        if (iVar3 != 0) break;
        sVar2 = sVar2 + -1;
      } while (sVar2 != 0);
      sub_0802939C(param_1,7);
      sub_08028AAC(param_1,0xda,0xe9,0x3c);
    } while( true );
  }
  iVar3 = sub_080289C0(6,0x138,0xfa);
  piVar7 = (int *)(*(int *)DWORD_0803454c + DWORD_08034554);
  uVar8 = 0;
  do {
    if (*piVar7 == iVar3) goto LAB_080344f6;
    uVar8 = uVar8 + 1;
    piVar7 = piVar7 + 0x1c;
  } while (uVar8 < 0xf);
  sub_080003F0();
  piVar7 = (int *)0x0;
LAB_080344f6:
  if (piVar7 != (int *)0x0) {
    *(undefined2 *)(piVar7 + 6) = 8;
    *(undefined2 *)((int)piVar7 + 0x1a) = 4;
    piVar7[0xf] = piVar7[0xf] | 0x10;
  }
  dVar1 = DWORD_08034558;
  piVar7 = (int *)(*(int *)DWORD_0803454c + DWORD_08034554);
  uVar8 = 0;
  do {
    if (*piVar7 == iVar3) goto LAB_0803452a;
    uVar8 = uVar8 + 1;
    piVar7 = piVar7 + 0x1c;
  } while (uVar8 < 0xf);
  sub_080003F0();
  piVar7 = (int *)0x0;
LAB_0803452a:
  if (piVar7 != (int *)0x0) {
    piVar7[0x11] = dVar1;
  }
  sub_0802939C(iVar3,0xb);
  do {
    sub_0802939C(param_1,0);
    sVar2 = 400;
    do {
      sub_080003F0();
      iVar5 = sub_080021A8();
      if (iVar5 != 0) break;
      sVar2 = sVar2 + -1;
    } while (sVar2 != 0);
    sub_0802939C(param_1,1);
    sVar2 = 400;
    do {
      sub_080003F0();
      iVar5 = sub_080021A8();
      if (iVar5 != 0) break;
      sVar2 = sVar2 + -1;
    } while (sVar2 != 0);
    sub_0802939C(param_1,8);
    sub_08028AAC(param_1,0xf3,0xe9,0x3c);
    sub_0802939C(param_1,2);
    sVar2 = 0x1e;
    do {
      sub_080003F0();
      iVar5 = sub_080021A8();
      if (iVar5 != 0) break;
      sVar2 = sVar2 + -1;
    } while (sVar2 != 0);
    sub_0802939C(param_1,3);
    sVar2 = 0x78;
    do {
      sub_080003F0();
      iVar5 = sub_080021A8();
      if (iVar5 != 0) break;
      sVar2 = sVar2 + -1;
    } while (sVar2 != 0);
    sub_0802939C(param_1,2);
    sVar2 = 0x1e;
    do {
      sub_080003F0();
      iVar5 = sub_080021A8();
      if (iVar5 != 0) break;
      sVar2 = sVar2 + -1;
    } while (sVar2 != 0);
    sub_0802939C(param_1,7);
    sub_08028AAC(param_1,0xda,0xe9,0x3c);
    sub_0802939C(param_1,0);
    sVar2 = 200;
    do {
      sub_080003F0();
      iVar5 = sub_080021A8();
      if (iVar5 != 0) break;
      sVar2 = sVar2 + -1;
    } while (sVar2 != 0);
    sub_0802939C(param_1,4);
    sVar2 = 0x1e;
    do {
      sub_080003F0();
      iVar5 = sub_080021A8();
      if (iVar5 != 0) break;
      sVar2 = sVar2 + -1;
    } while (sVar2 != 0);
    sub_0802939C(param_1,0);
    sVar2 = 0x50;
    do {
      sub_080003F0();
      iVar5 = sub_080021A8();
      if (iVar5 != 0) break;
      sVar2 = sVar2 + -1;
    } while (sVar2 != 0);
    sub_0802939C(param_1,4);
    sVar2 = 100;
    do {
      sub_080003F0();
      iVar5 = sub_080021A8();
      if (iVar5 != 0) break;
      sVar2 = sVar2 + -1;
    } while (sVar2 != 0);
    sub_08029174(param_1,5);
    sVar2 = 0xd;
    do {
      sub_080003F0();
      iVar5 = sub_080021A8();
      if (iVar5 != 0) break;
      sVar2 = sVar2 + -1;
    } while (sVar2 != 0);
    if ((uVar9 & 3) == 0) {
      iVar5 = sub_080289C0(DWORD_0803477c,0xe2,0xe9);
      sub_08028AAC(iVar5,0x15e,0xf0,0x3c);
      if ((*(uint *)DWORD_08034780 & 0x20) == 0) {
        sub_08006D08(0x35);
      }
      sVar2 = 2;
      do {
        sub_080003F0();
        iVar6 = sub_080021A8();
        if (iVar6 != 0) break;
        sVar2 = sVar2 + -1;
      } while (sVar2 != 0);
      sub_08028D98(iVar5,0xfffffffd,0xfffffffc,2);
      sub_08028D98(iVar5,0xfffffffd,0xfffffffe,2);
      sub_08028D98(iVar5,0xfffffffd,0xffffffff,2);
      sub_08028D98(iVar5,0xfffffffd,0,2);
      sub_08028D98(iVar5,0xfffffffd,1,2);
      sub_08028D98(iVar5,0xfffffffd,2,2);
      sub_08028D98(iVar5,0xfffffffd,4,2);
      piVar7 = (int *)(*(int *)DWORD_08034820 + DWORD_08034824);
      uVar8 = 0;
      do {
        if (*piVar7 == iVar5) goto LAB_08034812;
        uVar8 = uVar8 + 1;
        piVar7 = piVar7 + 0x1c;
      } while (uVar8 < 0xf);
      sub_080003F0();
      piVar7 = (int *)0x0;
LAB_08034812:
      if (piVar7 != (int *)0x0) {
        *(undefined2 *)((int)piVar7 + 0x36) = 4;
      }
    }
    else {
      iVar5 = sub_080289C0(DWORD_08034720,0xe2,0xe9);
      sub_08028AAC(iVar5,0x144,0xf0,0x32);
      piVar7 = (int *)(*(int *)DWORD_08034724 + DWORD_08034728);
      uVar8 = 0;
      do {
        if (*piVar7 == iVar5) goto LAB_0803470c;
        uVar8 = uVar8 + 1;
        piVar7 = piVar7 + 0x1c;
      } while (uVar8 < 0xf);
      sub_080003F0();
      piVar7 = (int *)0x0;
LAB_0803470c:
      if (piVar7 != (int *)0x0) {
        *(undefined2 *)((int)piVar7 + 0x36) = 4;
      }
      sub_0802926C(iVar3,10);
      sVar2 = 0x1e;
      do {
        sub_080003F0();
        iVar5 = sub_080021A8();
        if (iVar5 != 0) break;
        sVar2 = sVar2 + -1;
      } while (sVar2 != 0);
      sub_0802939C(iVar3,0xb);
    }
    uVar9 = uVar9 + 1;
  } while( true );
}


