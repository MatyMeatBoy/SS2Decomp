
undefined4 sub_0805DC1C(ushort param_1,ushort param_2,uint param_3,uint param_4)

{
  short sVar1;
  ushort uVar2;
  short sVar3;
  short sVar4;
  short sVar5;
  dword dVar6;
  dword dVar7;
  dword dVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  uint uVar17;
  int iVar18;
  uint uVar19;
  int iVar20;
  undefined4 in_lr;
  
  param_3 = param_3 & 0xff;
  param_4 = param_4 & 0xff;
  uVar13 = 0;
  do {
    if (((int)(uint)*(byte *)DWORD_0805dc9c >> uVar13 & 1U) == 0) goto LAB_0805dc56;
    uVar13 = uVar13 + 1 & 0xff;
  } while (uVar13 < 4);
  uVar13 = 0xff;
LAB_0805dc56:
  if (uVar13 != 0xff) {
    iVar9 = *(int *)DWORD_0805dca0 + uVar13 * 0x34;
    *(undefined1 *)(iVar9 + 0x30) = 1;
    dVar6 = DWORD_0805dca4;
    *(undefined2 *)DWORD_0805dca4 = 0;
    *(undefined2 *)(dVar6 + 2) = 0;
    *(ushort *)(iVar9 + 0x28) = (param_1 & 0xff) + (short)(param_3 >> 1) + 1;
    *(ushort *)(iVar9 + 0x2a) = (param_2 & 0xff) + (short)(param_4 >> 1) + 1;
    if (param_3 == 0) {
      uVar13 = 1;
    }
    else {
      uVar13 = 0x1c;
      if (param_3 < 0x1d) {
        uVar13 = param_3;
      }
    }
    *(short *)(iVar9 + 0x2c) = (short)uVar13;
    if (param_4 == 0) {
      uVar13 = 1;
    }
    else {
      uVar13 = 0x12;
      if (param_4 < 0x13) {
        uVar13 = param_4;
      }
    }
    *(short *)(iVar9 + 0x2e) = (short)uVar13;
    uVar2 = *(ushort *)(iVar9 + 0x2c) >> 1;
    uVar13 = (uint)uVar2;
    if (0x1e < *(ushort *)(iVar9 + 0x28) + uVar13) {
      *(ushort *)(iVar9 + 0x28) = 0x1e - uVar2;
    }
    if ((*(ushort *)(iVar9 + 0x28) - uVar13 & 0x80) != 0) {
      *(ushort *)(iVar9 + 0x28) = uVar2;
    }
    uVar2 = *(ushort *)(iVar9 + 0x2e) >> 1;
    uVar17 = (uint)uVar2;
    if (0x14 < *(ushort *)(iVar9 + 0x2a) + uVar17) {
      *(ushort *)(iVar9 + 0x2a) = 0x1e - uVar2;
    }
    if ((*(ushort *)(iVar9 + 0x2a) - uVar17 & 0x80) != 0) {
      *(ushort *)(iVar9 + 0x2a) = uVar2;
    }
    dVar6 = DWORD_0805de2c;
    uVar10 = *(ushort *)(iVar9 + 0x28) - uVar13 & 0xffff;
    uVar13 = (*(ushort *)(iVar9 + 0x28) + uVar13 & 0xffff) + (*(ushort *)(iVar9 + 0x2c) & 1);
    uVar16 = uVar13 & 0xffff;
    uVar11 = *(ushort *)(iVar9 + 0x2a) - uVar17;
    uVar12 = uVar11 & 0xffff;
    uVar17 = (*(ushort *)(iVar9 + 0x2a) + uVar17 & 0xffff) + (*(ushort *)(iVar9 + 0x2e) & 1);
    uVar19 = uVar17 & 0xffff;
    iVar14 = (uVar10 - 1) * 2;
    iVar20 = (uVar12 - 1) * 0x40;
    sVar1 = (short)DWORD_0805de30;
    *(short *)(iVar14 + iVar20 + DWORD_0805de2c) = sVar1;
    iVar18 = (uVar19 + 1) * 0x40;
    *(short *)(iVar14 + iVar18 + dVar6) = (short)DWORD_0805de34;
    iVar14 = (uVar16 + 1) * 2;
    *(short *)(iVar14 + iVar20 + dVar6) = sVar1 + 2;
    sVar1 = (short)DWORD_0805de38;
    *(short *)(iVar14 + iVar18 + dVar6) = sVar1;
    dVar7 = DWORD_0805de3c;
    if (uVar10 <= uVar16) {
      uVar15 = uVar10;
      do {
        *(short *)(uVar15 * 2 + iVar20 + dVar6) = sVar1 + -7;
        *(short *)(uVar15 * 2 + iVar18 + dVar6) = (short)dVar7;
        uVar15 = uVar15 + 1 & 0xffff;
      } while (uVar15 <= uVar16);
    }
    dVar8 = DWORD_0805de44;
    dVar7 = DWORD_0805de40;
    dVar6 = DWORD_0805de2c;
    sVar5 = (short)uVar11 + -1;
    sVar1 = (short)uVar13 + 2;
    sVar4 = (short)uVar17 + 2;
    if (uVar12 <= uVar19) {
      do {
        *(short *)((uVar10 - 1) * 2 + uVar12 * 0x40 + dVar6) = (short)dVar7;
        *(short *)((uVar16 + 1) * 2 + uVar12 * 0x40 + dVar6) = (short)dVar8;
        uVar12 = uVar12 + 1 & 0xffff;
      } while (uVar12 <= uVar19);
    }
    dVar7 = DWORD_0805de94;
    dVar6 = DWORD_0805de48;
    sVar3 = (short)(uVar10 - 1);
    if (*(char *)(iVar9 + 0x31) == '\0') {
      *(ushort *)(DWORD_0805de48 + 0x32) = (sVar3 * 8 + 3) * 0x100 | sVar1 * 8 - 3U;
      *(ushort *)(dVar6 + 0x36) = (sVar5 * 8 + 3) * 0x100 | sVar4 * 8 - 3U;
    }
    else {
      *(ushort *)(DWORD_0805de94 + 0x30) = (sVar3 * 8 + 3) * 0x100 | sVar1 * 8 - 3U;
      *(ushort *)(dVar7 + 0x34) = (sVar5 * 8 + 3) * 0x100 | sVar4 * 8 - 3U;
    }
    sub_0801A664(~(uint)(*(ushort *)(iVar9 + 0x2e) >> 1) + (uint)*(ushort *)(iVar9 + 0x2a),
                 *(ushort *)(iVar9 + 0x2e) + 3);
  }
  return in_lr;
}


