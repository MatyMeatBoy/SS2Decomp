
undefined4 sub_08001B04(undefined2 param_1)

{
  undefined4 in_lr;
  
  ReadFlash(param_1);
  return in_lr;
}


