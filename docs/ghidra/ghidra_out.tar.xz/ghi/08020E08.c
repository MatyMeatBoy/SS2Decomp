
undefined4 sub_08020E08(uint param_1,uint param_2)

{
  undefined1 uVar1;
  short sVar2;
  int iVar3;
  ushort *puVar4;
  uint uVar5;
  uint uVar6;
  undefined4 in_lr;
  undefined4 auStack_5c [2];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined1 uStack_40;
  undefined1 uStack_3f;
  undefined2 uStack_28;
  undefined2 uStack_26;
  short sStack_24;
  short sStack_22;
  
  sub_08065158(auStack_5c,DWORD_08020e5c,1,0xffffffff,0);
  sub_08000AF0(0x17,uStack_50,2);
  uStack_40 = 7;
  uStack_3f = 8;
  uStack_28 = 0;
  uStack_26 = 0;
  sVar2 = 0;
  iVar3 = sub_0800CCCC();
  if (iVar3 == 0) {
    sub_0805865C(0x180);
  }
  while ((iVar3 = sub_0800CB78(), iVar3 == 0 && (sVar2 == 0))) {
    sVar2 = sub_08065370(auStack_5c,8,&uStack_28,&uStack_26,0);
    iVar3 = sub_0800CC98();
    if ((iVar3 == 0) &&
       ((iVar3 = sub_0800CD8C(), iVar3 == 0 && (iVar3 = sub_0800CCCC(), iVar3 == 0)))) {
      if (param_1 < 4) {
        puVar4 = *(ushort **)(param_1 * 0x14c + DWORD_08020eb4);
        uVar5 = (uint)(*puVar4 >> 4);
        uVar6 = puVar4[1] & 0xfff;
      }
      else {
        iVar3 = param_1 * 0x2e0 + *(int *)DWORD_08020f64 + DWORD_08020f68;
        uVar5 = *(int *)(iVar3 + 0x14) >> 8;
        uVar6 = *(int *)(iVar3 + 0x18) >> 8;
      }
      sub_0800BC08((int)(short)uVar5,(int)(short)uVar6,&sStack_24,&sStack_22,0x10,0);
      uVar1 = sub_0800BC44(uVar5,uVar6,0);
      if ((*(uint *)DWORD_08020f6c & 1) == (param_2 & 1)) {
        sub_08007870((int)sStack_24,sStack_22 + 1,8,uStack_28,uVar1,&uStack_40,uStack_54,
                     auStack_5c[0]);
      }
    }
    sub_080003F0();
  }
  *(uint *)DWORD_08020f70 = *(uint *)DWORD_08020f70 & ~(1 << (param_2 & 0xff));
  return in_lr;
}


