
ulonglong sub_0807A028(undefined2 param_1)

{
  undefined4 uVar1;
  undefined4 in_lr;
  
  uVar1 = sub_08073EE8(param_1,DWORD_0807a03c);
  return CONCAT44(in_lr,uVar1) & 0xffffffff0000ffff;
}


