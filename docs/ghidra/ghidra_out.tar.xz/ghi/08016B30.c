
undefined8 sub_08016B30(int param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  ushort *puVar3;
  uint uVar4;
  uint *puVar5;
  int iVar6;
  uint *puVar7;
  int iVar8;
  uint *puVar9;
  ushort *puVar10;
  dword *pdVar11;
  uint uVar12;
  int iVar13;
  uint uVar14;
  undefined4 in_lr;
  dword dStack_4c;
  uint auStack_48 [7];
  uint *puStack_2c;
  int iStack_28;
  int iStack_24;
  
  pdVar11 = &dStack_4c;
  puStack_2c = param_2;
  uVar1 = sub_08002164();
  iStack_28 = *(int *)(param_1 + 0x14) >> 8;
  iStack_24 = *(int *)(param_1 + 0x18) >> 8;
  uVar14 = 0;
  if (uVar1 != 0) {
    iVar13 = 0;
    puVar10 = (ushort *)DWORD_08016c68;
    do {
      *pdVar11 = DWORD_08016c6c;
      if ((((*(uint *)(puVar10 + 0x18) & 0x2000) == 0) &&
          (((puVar10[0x32] < 10 ||
            (((int)(uint)*(ushort *)(param_1 + 0x5a) >> (*puVar10 & 0xff) & 1U) != 0)) &&
           (puVar10[0x32] != 9)))) && ((*(uint *)(puVar10 + 0x18) & DWORD_08016c70) == 0)) {
        puVar3 = *(ushort **)(puVar10 + 0xa4);
        if (((*puVar3 & 0xf) != 0xb) && ((puVar3[2] & 0x20) == 0)) {
          iVar6 = iStack_28 - (uint)(*puVar3 >> 4);
          iVar8 = iStack_24 - (puVar3[1] & 0xfff);
          *pdVar11 = iVar6 * iVar6 + iVar8 * iVar8;
        }
        *(uint *)((int)auStack_48 + iVar13) = uVar14;
      }
      pdVar11 = pdVar11 + 2;
      iVar13 = iVar13 + 8;
      uVar14 = uVar14 + 1;
      puVar10 = puVar10 + 0xa6;
    } while (uVar14 < uVar1);
  }
  uVar14 = 0;
  if (uVar1 != 0) {
    do {
      uVar12 = uVar14 + 1;
      if (uVar12 < uVar1) {
        puVar9 = auStack_48 + uVar14 * 2 + -1;
        puVar7 = auStack_48 + uVar14 * 2;
        puVar5 = auStack_48 + uVar12 * 2 + -1;
        uVar14 = uVar12;
        do {
          if ((int)*puVar5 < (int)*puVar9) {
            uVar2 = *puVar5 ^ *puVar9;
            *puVar9 = uVar2;
            uVar2 = *puVar5 ^ uVar2;
            *puVar5 = uVar2;
            *puVar9 = *puVar9 ^ uVar2;
            uVar4 = *puVar7;
            uVar2 = puVar5[1];
            *puVar7 = uVar4 ^ uVar2;
            uVar2 = puVar5[1] ^ uVar4 ^ uVar2;
            puVar5[1] = uVar2;
            *puVar7 = *puVar7 ^ uVar2;
          }
          puVar5 = puVar5 + 2;
          uVar14 = uVar14 + 1;
        } while (uVar14 < uVar1);
      }
      uVar14 = uVar12;
    } while (uVar12 < uVar1);
  }
  uVar1 = Sqrt(dStack_4c);
  if ((int)*puStack_2c < (int)(uVar1 & 0xffff)) {
    auStack_48[0] = 10;
  }
  else {
    *puStack_2c = uVar1 & 0xffff;
  }
  return CONCAT44(in_lr,auStack_48[0]);
}


