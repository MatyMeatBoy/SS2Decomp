
void sub_08057CAC(int param_1)

{
  int iVar1;
  
  iVar1 = sub_0800CE30();
  if (iVar1 == 0) {
    *(uint *)(*(int *)DWORD_08057ccc + 0x78) =
         *(uint *)(*(int *)DWORD_08057ccc + 0x78) & ~(1 << (param_1 - 1U & 0xff));
  }
  else {
    *(uint *)(*(int *)DWORD_08057ce8 + 0x80) =
         *(uint *)(*(int *)DWORD_08057ce8 + 0x80) & ~(1 << (param_1 - 1U & 0xff));
  }
  return;
}


