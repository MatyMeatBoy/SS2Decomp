
undefined4 sub_080587F0(void)

{
  undefined4 in_lr;
  
  sub_08015D98();
  return in_lr;
}


