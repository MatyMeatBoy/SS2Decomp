
undefined4 sub_08050454(void)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  undefined1 auStack_2c [12];
  dword dStack_20;
  undefined4 uStack_1c;
  
  dVar1 = DWORD_08050474;
  if ((*(uint *)(*(int *)DWORD_08050470 + 0x38) & 2) == 0) {
    iVar3 = *(int *)DWORD_08050470 + DWORD_08050478;
    for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
      iVar2 = sub_08000470(iVar3);
      if (iVar2 == 0) {
        dStack_20 = dVar1;
        uStack_1c = 0;
        *(undefined4 *)(iVar3 + 8) = 0x3c;
        iVar2 = sub_08001494(0x400);
        *(int *)(iVar3 + 0x20) = iVar2;
        *(dword *)(iVar3 + 0xc) = DWORD_080504c8;
        *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
        *(undefined4 *)(iVar3 + 0x24) = 0;
        sub_08000274(iVar3,auStack_2c,6);
        sub_080003F0();
        sub_080003F0();
        break;
      }
      iVar3 = iVar3 + 0x28;
    }
  }
  else {
    sub_08028AAC(7,0x378,0xa0,0);
  }
  iVar3 = sub_0800CC98();
  if (iVar3 == 0) {
    iVar3 = sub_0801AB24();
    if (iVar3 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar3 < 2) {
      if (iVar3 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar3 == 2) {
      sub_0801AB90(6);
    }
    while (iVar3 = sub_0801AAE0(), iVar3 == 0) {
      sub_080003F0();
    }
  }
  return in_lr;
}


