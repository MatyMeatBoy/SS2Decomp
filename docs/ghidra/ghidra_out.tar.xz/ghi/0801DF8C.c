
undefined8 sub_0801DF8C(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_0801dfdc;
  if ((*(uint *)(iVar1 + 0x30) & 0x100000) == 0) {
    uVar2 = 0;
    if ((((*(short *)(iVar1 + 0x20) == 0xb) || (*(ushort *)(iVar1 + 0xc4) == 0)) ||
        ((int)(((uint)*(ushort *)(iVar1 + 0xc4) - (uint)*(ushort *)(iVar1 + 0x88)) * 0x10000) < 1))
       || ((*(uint *)(iVar1 + 0x30) & 0x2000) != 0)) {
      uVar2 = 1;
    }
  }
  else {
    uVar2 = 0;
  }
  return CONCAT44(in_lr,uVar2);
}


