
undefined4 sub_08054514(void)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  undefined4 in_lr;
  
  iVar1 = sub_080289C0(0x24,0x138,0xb0);
  iVar2 = sub_080289C0(DWORD_08054594,0x138,200);
  sub_08028D98(iVar1,0,0xffffff38,200);
  piVar3 = (int *)(*(int *)DWORD_08054598 + DWORD_0805459c);
  uVar4 = 0;
  do {
    if (*piVar3 == iVar1) goto LAB_0805455e;
    uVar4 = uVar4 + 1;
    piVar3 = piVar3 + 0x1c;
  } while (uVar4 < 0xf);
  sub_080003F0();
  piVar3 = (int *)0x0;
LAB_0805455e:
  if (piVar3 != (int *)0x0) {
    *(undefined2 *)((int)piVar3 + 0x36) = 4;
  }
  piVar3 = (int *)(*(int *)DWORD_08054598 + DWORD_0805459c);
  uVar4 = 0;
  do {
    if (*piVar3 == iVar2) goto LAB_08054584;
    uVar4 = uVar4 + 1;
    piVar3 = piVar3 + 0x1c;
  } while (uVar4 < 0xf);
  sub_080003F0();
  piVar3 = (int *)0x0;
LAB_08054584:
  if (piVar3 != (int *)0x0) {
    *(undefined2 *)((int)piVar3 + 0x36) = 4;
  }
  return in_lr;
}


