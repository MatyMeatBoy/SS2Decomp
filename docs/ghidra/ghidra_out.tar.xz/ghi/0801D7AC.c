
undefined4 sub_0801D7AC(uint param_1,uint param_2,uint param_3,short param_4)

{
  ushort uVar1;
  bool bVar2;
  dword dVar3;
  short sVar4;
  short *psVar5;
  int iVar6;
  uint uVar7;
  short *psVar8;
  uint uVar9;
  undefined4 in_lr;
  undefined2 auStack_24 [2];
  int iStack_20;
  
  dVar3 = DWORD_0801d7dc;
  iVar6 = param_1 * 0x14c + DWORD_0801d7dc;
  uVar1 = *(ushort *)(iVar6 + 0xc);
  sVar4 = (short)param_1;
  if (uVar1 == 2) {
    if (param_3 != 7) {
      return in_lr;
    }
    if (*(char *)(param_2 * 0x14c + DWORD_0801d7dc + 0x68) != *(char *)(iVar6 + 0x68)) {
      return in_lr;
    }
    bVar2 = false;
    psVar8 = *(short **)(param_2 * 0x14c + DWORD_0801d7dc + 0x34);
    uVar9 = 0;
    if (((*psVar8 != -2) || (psVar8[2] != 7)) || ((ushort)psVar8[1] != param_1)) {
      do {
        psVar5 = psVar8;
        uVar9 = uVar9 + 1;
        psVar8 = psVar5 + 0x14;
        if (7 < uVar9) goto LAB_0801d8fc;
      } while (((*psVar8 != -2) || (psVar5[0x16] != 7)) || ((ushort)psVar5[0x15] != param_1));
      psVar5[0x17] = param_4;
      bVar2 = true;
LAB_0801d8fc:
      if (bVar2) {
        return in_lr;
      }
      psVar8 = *(short **)(param_2 * 0x14c + dVar3 + 0x34);
      uVar9 = 0;
      do {
        if (*psVar8 == -1) {
          psVar8[1] = sVar4;
          *psVar8 = (short)DWORD_0801db08;
          psVar8[2] = 7;
          psVar8[3] = param_4;
          return in_lr;
        }
        uVar9 = uVar9 + 1;
        psVar8 = psVar8 + 0x14;
      } while (uVar9 < 8);
      return in_lr;
    }
  }
  else if (uVar1 < 3) {
    if (uVar1 != 0) {
      return in_lr;
    }
    if (*(char *)(param_2 * 0x14c + DWORD_0801d7dc + 0x68) != *(char *)(iVar6 + 0x68)) {
      return in_lr;
    }
    if (param_3 != 7) {
      return in_lr;
    }
    if (param_1 == param_2) {
      return in_lr;
    }
    bVar2 = false;
    psVar8 = *(short **)(param_2 * 0x14c + DWORD_0801d7dc + 0x34);
    uVar9 = 0;
    if (((*psVar8 != -2) || (psVar8[2] != 7)) || ((ushort)psVar8[1] != param_1)) {
      do {
        psVar5 = psVar8;
        uVar9 = uVar9 + 1;
        psVar8 = psVar5 + 0x14;
        if (7 < uVar9) goto LAB_0801d860;
      } while (((*psVar8 != -2) || (psVar5[0x16] != 7)) || ((ushort)psVar5[0x15] != param_1));
      psVar5[0x17] = param_4;
      bVar2 = true;
LAB_0801d860:
      if (bVar2) {
        return in_lr;
      }
      psVar8 = *(short **)(param_2 * 0x14c + dVar3 + 0x34);
      uVar9 = 0;
      while (*psVar8 != -1) {
        uVar9 = uVar9 + 1;
        psVar8 = psVar8 + 0x14;
        if (7 < uVar9) {
          return in_lr;
        }
      }
      psVar8[1] = sVar4;
      *psVar8 = (short)DWORD_0801daf4;
      sVar4 = 7;
LAB_0801db28:
      psVar8[2] = sVar4;
      psVar8[3] = param_4;
      return in_lr;
    }
  }
  else {
    if (uVar1 != 3) {
      if (uVar1 != 5) {
        return in_lr;
      }
      if (param_3 != 7) {
        return in_lr;
      }
      bVar2 = false;
      if (*(char *)(param_2 * 0x14c + DWORD_0801d7dc + 0x68) != *(char *)(iVar6 + 0x68)) {
        return in_lr;
      }
      psVar8 = *(short **)(param_2 * 0x14c + DWORD_0801d7dc + 0x34);
      uVar9 = 0;
      if (((*psVar8 == -2) && (psVar8[2] == 7)) && ((ushort)psVar8[1] == param_1)) {
        psVar8[3] = param_4;
        return in_lr;
      }
      do {
        psVar5 = psVar8;
        uVar9 = uVar9 + 1;
        psVar8 = psVar5 + 0x14;
        if (7 < uVar9) goto LAB_0801d99c;
      } while (((*psVar8 != -2) || (psVar5[0x16] != 7)) || ((ushort)psVar5[0x15] != param_1));
      psVar5[0x17] = param_4;
      bVar2 = true;
LAB_0801d99c:
      if (bVar2) {
        return in_lr;
      }
      psVar8 = *(short **)(param_2 * 0x14c + dVar3 + 0x34);
      uVar9 = 0;
      do {
        if (*psVar8 == -1) {
          psVar8[1] = sVar4;
          *psVar8 = (short)DWORD_0801db1c;
          psVar8[2] = 7;
          psVar8[3] = param_4;
          return in_lr;
        }
        uVar9 = uVar9 + 1;
        psVar8 = psVar8 + 0x14;
      } while (uVar9 < 8);
      return in_lr;
    }
    if ((param_3 & 0xff) == 4) {
      uVar9 = param_3 >> 8 & 0xff;
      if (3 < uVar9) {
        uVar7 = 0;
        iVar6 = 0;
        while (((*(uint *)DWORD_0801da9c & 1 << (uVar7 & 0xff)) == 0 ||
               (uVar9 != *(ushort *)(iVar6 + *(int *)DWORD_0801daa0 + 2)))) {
          iVar6 = iVar6 + 0x2e0;
          uVar7 = uVar7 + 1;
          if (4 < uVar7) {
            return in_lr;
          }
        }
        psVar8 = (short *)(iVar6 + *(int *)DWORD_0801daa0 + 0x8c);
        uVar9 = 0;
        iStack_20 = -1;
        do {
          if (*psVar8 == iStack_20) {
            auStack_24[0] = 0;
            CpuSet(auStack_24,psVar8,DWORD_0801daa4);
            psVar8[1] = sVar4;
            *psVar8 = 0x78;
            psVar8[2] = 4;
            psVar8[3] = param_4;
          }
          uVar9 = uVar9 + 1;
          psVar8 = psVar8 + 0x14;
        } while (uVar9 < 8);
        return in_lr;
      }
      if (*(char *)(param_2 * 0x14c + DWORD_0801d7dc + 0x68) == *(char *)(iVar6 + 0x68)) {
        return in_lr;
      }
      psVar8 = *(short **)(uVar9 * 0x14c + DWORD_0801d7dc + 0x34);
      uVar9 = 0;
      do {
        if (*psVar8 == -1) {
          auStack_24[0] = 0;
          CpuSet(auStack_24,psVar8,DWORD_0801da3c);
          psVar8[1] = sVar4;
          *psVar8 = 0x78;
          psVar8[2] = 4;
          psVar8[3] = param_4;
        }
        uVar9 = uVar9 + 1;
        psVar8 = psVar8 + 0x14;
      } while (uVar9 < 8);
      return in_lr;
    }
    if ((param_3 & 0xff) != 6) {
      return in_lr;
    }
    bVar2 = false;
    psVar8 = *(short **)(param_2 * 0x14c + DWORD_0801d7dc + 0x34);
    uVar9 = 0;
    if (((*psVar8 != -2) || (psVar8[2] != 6)) || ((ushort)psVar8[1] != param_1)) {
      do {
        psVar5 = psVar8;
        uVar9 = uVar9 + 1;
        psVar8 = psVar5 + 0x14;
        if (7 < uVar9) goto LAB_0801db5a;
      } while (((*psVar8 != -2) || (psVar5[0x16] != 6)) || ((ushort)psVar5[0x15] != param_1));
      psVar5[0x17] = param_4;
      bVar2 = true;
LAB_0801db5a:
      if (bVar2) {
        return in_lr;
      }
      psVar8 = *(short **)(param_2 * 0x14c + dVar3 + 0x34);
      uVar9 = 0;
      while (*psVar8 != -1) {
        uVar9 = uVar9 + 1;
        psVar8 = psVar8 + 0x14;
        if (7 < uVar9) {
          return in_lr;
        }
      }
      psVar8[1] = sVar4;
      *psVar8 = (short)DWORD_0801db30;
      sVar4 = 6;
      goto LAB_0801db28;
    }
  }
  psVar8[3] = param_4;
  return in_lr;
}


