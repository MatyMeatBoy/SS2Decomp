
undefined8 sub_0805CDF8(void)

{
  ushort *puVar1;
  undefined4 uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  short *psVar8;
  int *piVar9;
  int iVar10;
  uint uVar11;
  int iVar12;
  short *psVar13;
  uint uVar14;
  undefined4 in_lr;
  int aiStack_40 [4];
  ushort uStack_30;
  undefined2 uStack_2e;
  uint uStack_2c;
  undefined1 uStack_28;
  
  piVar6 = aiStack_40;
  piVar9 = aiStack_40;
  uVar11 = 0;
  do {
    piVar7 = *(int **)DWORD_0805cf28;
    iVar12 = 0;
    *piVar6 = 0;
    uVar14 = 0;
    do {
      if (*(short *)((int)piVar7 + 10) != 0) {
        iVar4 = uVar11 * 0x10;
        uVar5 = (*piVar7 << 5) >> 0x10;
        if ((((*(uint *)(iVar4 + DWORD_0805cf2c) <= uVar5) &&
             (uVar3 = (piVar7[1] << 5) >> 0x10, *(uint *)(iVar4 + DWORD_0805cf2c + 4) <= uVar3)) &&
            (uVar5 <= *(uint *)(iVar4 + DWORD_0805cf2c + 8))) &&
           (uVar3 <= *(uint *)(iVar4 + DWORD_0805cf2c + 0xc))) {
          iVar12 = iVar12 + 1;
          *piVar6 = (int)piVar7;
        }
      }
      uVar14 = uVar14 + 1;
      piVar7 = piVar7 + 8;
    } while (uVar14 < 0x10);
    if (iVar12 != 1) goto LAB_0805cf8e;
    piVar6 = piVar6 + 1;
    uVar11 = uVar11 + 1;
  } while (uVar11 < 4);
  if (*(short *)DWORD_0805cf30 != 0) {
    iVar12 = 0;
    psVar13 = (short *)DWORD_0805cf30;
    do {
      iVar10 = 0;
      uVar11 = 0;
      psVar8 = (short *)(iVar12 + DWORD_0805cf30);
      piVar6 = aiStack_40;
      iVar4 = iVar12;
      do {
        if ((*(short *)(*piVar6 + 0x10) == *psVar8) &&
           (*(short *)(*piVar6 + 0x12) == *(short *)(iVar4 + DWORD_0805cf30 + 2))) {
          iVar10 = iVar10 + 1;
        }
        psVar8 = psVar8 + 2;
        iVar4 = iVar4 + 4;
        piVar6 = piVar6 + 1;
        uVar11 = uVar11 + 1;
      } while (uVar11 < 4);
      if (iVar10 == 4) {
        uVar11 = 0;
        do {
          sub_08021EC8(*(undefined4 *)*piVar9,((undefined4 *)*piVar9)[1],2);
          sub_08058768(*(int *)*piVar9 >> 8,((int *)*piVar9)[1] >> 8,0);
          sub_08057624(2);
          iVar4 = *piVar9;
          piVar9 = piVar9 + 1;
          *(undefined2 *)(iVar4 + 10) = 0;
          sub_08057624(10);
          uVar11 = uVar11 + 1;
        } while (uVar11 < 4);
        puVar1 = (ushort *)(DWORD_0805cf30 + 0x10 + iVar12);
        if (*puVar1 == 10) {
          uStack_2c = (uint)*(ushort *)(DWORD_0805cf30 + 0x12 + iVar12);
          uStack_30 = 10;
        }
        else {
          uStack_2c = 0;
          uStack_30 = *puVar1;
          uStack_2e = *(undefined2 *)(DWORD_0805cf30 + 0x12 + iVar12);
          if ((uStack_30 < 6) && (1 < uStack_30)) {
            uStack_28 = 0;
            uStack_2c = 0;
          }
        }
        iVar12 = sub_08002204();
        if (iVar12 != 0) {
          sub_08066490(0xf700,0x6e00,&uStack_30);
        }
        sub_08021EC8(0xf700,0x6e00,6);
        uVar2 = 1;
        goto LAB_0805cf90;
      }
      psVar13 = psVar13 + 10;
      iVar12 = iVar12 + 0x14;
    } while (*psVar13 != 0);
  }
LAB_0805cf8e:
  uVar2 = 0;
LAB_0805cf90:
  return CONCAT44(in_lr,uVar2);
}


