
/* WARNING: Removing unreachable block (ram,0x080024b4) */

undefined4 sub_0800232C(void)

{
  dword dVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 in_lr;
  undefined1 auStack_48 [52];
  uint uStack_14;
  
  iVar2 = sub_0801AB24();
  if (iVar2 == 0) {
    sub_08000A34(1,0,0,0,0);
    sub_080009F8(0xf00,0,0);
    sub_080009C0(0x200,0,0);
    uStack_14 = uStack_14 & DWORD_080023a0 | DWORD_080023a4;
    sub_08000AA8(0,&uStack_14);
    uStack_14 = CONCAT22(uStack_14._2_2_,(short)DWORD_080023a8);
    sub_08000AA8(1,&uStack_14);
    sub_0800BCDC(0,1,0x6000000,0,0x10);
    sub_08000940();
    sub_0801AB90(0x14);
  }
  else {
    sub_08000A34(1,0,0,0,1);
    sub_080009F8(0xf00,0,1);
    sub_080009C0(0x200,0,1);
    uStack_14._0_2_ = (undefined2)DWORD_08002418;
    sub_08000AA8(0,&uStack_14);
    uStack_14 = CONCAT22(uStack_14._2_2_,(short)DWORD_0800241c);
    sub_08000AA8(1,&uStack_14);
    sub_0800BCDC(0,1,0x6000000,0,0x10);
    dVar1 = DWORD_08002420;
    *(undefined2 *)(DWORD_08002420 + 4) = 0;
    *(undefined2 *)(dVar1 + 6) = 0;
    iVar2 = sub_0801AB24();
    if (iVar2 == 2) {
      sub_0801AB90(6);
    }
    else {
      sub_0801AB50(6);
    }
  }
  while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
    sub_080920A0();
    sub_080003F0();
  }
  uVar4 = 0;
  do {
    sub_080920A0();
    sub_080003F0();
    uVar4 = uVar4 + 1;
  } while (uVar4 < 0xb4);
  sub_0801AA8C(0x1e);
  while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
    sub_080920A0();
    sub_080003F0();
  }
  sub_0800BCDC(0x4a,1,0x6000000,0,0x10);
  sub_08065158(auStack_48,DWORD_0800249c,0,1,0);
  sub_080009C0(0x1200,0,1);
  sub_0801AA34(6);
  while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
    sub_080003F0();
  }
  if ((*(ushort *)DWORD_08002624 & 1) == 0) {
                    /* WARNING: Could not recover jumptable at 0x080024be. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar3 = (**(code **)DWORD_080024c0)();
    return uVar3;
  }
  sub_08006D08(0xf);
  sub_0801AA8C(0x3c);
  while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
    sub_080003F0();
  }
  *(uint *)DWORD_08002650 = (uint)*(ushort *)DWORD_08002654;
  sub_080003F0();
  sub_08000420(0x14);
  return in_lr;
}


