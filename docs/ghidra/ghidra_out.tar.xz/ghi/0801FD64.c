
undefined4 sub_0801FD64(int param_1)

{
  byte bVar1;
  short sVar2;
  undefined4 in_lr;
  
  if ((*(int *)(param_1 + 0x10c) != *(int *)(param_1 + 0xdc)) && (*(char *)(param_1 + 0x68) != '\0')
     ) {
    bVar1 = *(byte *)(param_1 + 0x69);
    if (((bVar1 & 0x80) == 0) && (bVar1 != 0)) {
      sVar2 = __divsi3((int)*(short *)(param_1 + 0x62) * (uint)*(byte *)(param_1 + 0x69),100);
      if (sVar2 == 0) {
        sVar2 = 1;
      }
      *(short *)(param_1 + 0x8a) = sVar2 + *(short *)(param_1 + 0x8a);
      *(int *)(param_1 + 0x10c) = *(int *)(param_1 + 0xdc);
      *(uint *)(param_1 + 0xe0) = bVar1 & 0x80;
    }
  }
  return in_lr;
}


