
void sub_0809EDFC(void)

{
  ushort uVar1;
  
  uVar1 = *(ushort *)DWORD_0809ee2c;
  while ((uVar1 & 2) == 0) {
    uVar1 = *(ushort *)DWORD_0809ee2c;
  }
  if (8 < *(byte *)DWORD_0809ee30) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0809ee28. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)((uint)*(byte *)DWORD_0809ee30 * 4 + DWORD_0809ee34))();
  return;
}


