
undefined4 sub_080746A4(uint param_1,uint param_2)

{
  short sVar1;
  int iVar2;
  int unaff_r9;
  undefined4 in_lr;
  undefined4 auStack_68 [2];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined1 uStack_4c;
  undefined1 uStack_4b;
  short sStack_34;
  short sStack_32;
  undefined2 uStack_30;
  undefined2 uStack_2e;
  uint uStack_2c;
  int iStack_28;
  int iStack_24;
  
  uStack_30 = 0;
  uStack_2e = 0;
  uStack_2c = param_2;
  sub_08065158(auStack_68,DWORD_080746f4,8,0xffffffff,0);
  uStack_4c = 7;
  uStack_4b = 8;
  if (param_1 < 4) {
    iStack_28 = param_1 * 0x14c + DWORD_080746f8;
  }
  else {
    unaff_r9 = *(int *)DWORD_0807474c + param_1 * 0x2e0 + DWORD_08074750;
  }
  iStack_24 = param_1 << 2;
  do {
    if (param_1 < 4) {
      sub_0800BC08(**(ushort **)(iStack_28 + 0x148) >> 4,
                   (*(ushort **)(iStack_28 + 0x148))[1] & 0xfff,&sStack_34,&sStack_32,0x30,0);
    }
    else {
      sub_0800BC08((*(int *)(unaff_r9 + 0x14) << 8) >> 0x10,(*(int *)(unaff_r9 + 0x18) << 8) >> 0x10
                   ,&sStack_34,&sStack_32,0x30,0);
    }
    sVar1 = sub_08065370(auStack_68,0x12,&uStack_30,&uStack_2e,0);
    iVar2 = sub_0800CC98();
    if (((iVar2 == 0) && (iVar2 = sub_0800CD8C(), iVar2 == 0)) &&
       (iVar2 = sub_0800CCCC(), iVar2 == 0)) {
      if ((*(uint *)DWORD_08074810 & 1) == 0) {
        sub_08000AF0(0x17,uStack_5c,2);
      }
      sub_08007870((int)sStack_34,sStack_32 + 1,0x12,uStack_30,1,&uStack_4c,uStack_60,auStack_68[0])
      ;
    }
    sub_080003F0();
  } while (sVar1 == 0);
  *(uint *)(iStack_24 + DWORD_08074814) =
       *(uint *)(iStack_24 + DWORD_08074814) & ~(1 << (uStack_2c & 0xff));
  return in_lr;
}


