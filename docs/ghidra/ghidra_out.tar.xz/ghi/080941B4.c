
void sub_080941B4(void)

{
  dword dVar1;
  dword dVar2;
  short sVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  byte bVar9;
  undefined4 uVar10;
  uint uVar11;
  int iStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  
  uVar8 = 0;
  bVar9 = 0;
  uStack_24 = 0;
  uVar11 = 0;
  iStack_2c = 0;
  iStack_30 = 0;
  uVar10 = 6;
  uStack_28 = 10;
  sVar3 = sub_0800086C();
  sVar3 = __modsi3((int)sVar3,0x14);
  dVar2 = DWORD_08094214;
  dVar1 = DWORD_08094210;
  iVar4 = (int)sVar3;
  if (iVar4 < 0) {
    iVar4 = -iVar4;
  }
  uVar7 = iVar4 + 10U & 0xffff;
  do {
    if (bVar9 == 1) {
      uVar10 = 0x16;
      uStack_28 = 10;
      *(undefined1 *)dVar1 = 1;
      iVar4 = uVar8 * -0x10000;
      uVar8 = uVar8 * 0x10000 + 0x10000 >> 0x10;
      if (uVar7 * 0x10000 + iVar4 == 0) {
        iVar4 = sub_0800086C();
        iVar5 = (iVar4 << 0x10) >> 0x10;
        iVar4 = (iVar5 + (iVar5 - ((iVar4 << 0x10) >> 0x1f) >> 1) * -2) * 0x10000 >> 0x10;
        if (iVar4 < 0) {
          iVar4 = -iVar4;
        }
        uVar7 = iVar4 + 2U & 0xffff;
        bVar9 = 2;
        uVar8 = 0;
      }
    }
    else if (bVar9 < 2) {
      if (bVar9 == 0) {
        uVar10 = 6;
        uStack_28 = 10;
        *(undefined1 *)dVar1 = 0;
        if ((*(char *)DWORD_0809427c != '\0') &&
           (iVar5 = uVar8 * 0x10000, iVar4 = uVar8 * -0x10000,
           uVar8 = uVar8 * 0x10000 + 0x10000 >> 0x10,
           (int)(uVar7 * 0x10000 + iVar4) < 0 != SBORROW4(uVar7 * 0x10000,iVar5))) {
          sVar3 = sub_0800086C();
          iVar5 = (int)sVar3;
          iVar4 = iVar5;
          if (iVar5 < 0) {
            iVar4 = iVar5 + 3;
          }
          iVar4 = (iVar5 + (iVar4 >> 2) * -4) * 0x10000 >> 0x10;
          if (iVar4 < 0) {
            iVar4 = -iVar4;
          }
          uVar7 = iVar4 + 2U & 0xffff;
          bVar9 = 1;
          uVar8 = 0;
        }
      }
    }
    else if (bVar9 == 2) {
      uVar10 = 0x16;
      uStack_28 = 0x1a;
      *(undefined1 *)dVar1 = 1;
      if (*(char *)DWORD_080942f4 == '\0') {
        iVar4 = uVar8 * -0x10000;
        uVar8 = uVar8 * 0x10000 + 0x10000 >> 0x10;
        if (uVar7 * 0x10000 + iVar4 == 0) {
          sVar3 = sub_0800086C();
          iVar5 = (int)sVar3;
          iVar4 = iVar5;
          if (iVar5 < 0) {
            iVar4 = iVar5 + 3;
          }
          iVar4 = (iVar5 + (iVar4 >> 2) * -4) * 0x10000 >> 0x10;
          if (iVar4 < 0) {
            iVar4 = -iVar4;
          }
          uVar7 = iVar4 + 2U & 0xffff;
          bVar9 = 3;
          uVar8 = 0;
        }
      }
      else {
        uVar6 = uVar8 * 0x10000 + 0x10000;
        uVar8 = uVar6 >> 0x10;
        if ((int)uVar6 >> 0x10 == 0xd) {
          *(undefined1 *)DWORD_080942f4 = 2;
        }
      }
    }
    else if (bVar9 == 3) {
      uVar10 = 6;
      uStack_28 = 0x1a;
      *(undefined1 *)dVar1 = 1;
      iVar4 = uVar8 * -0x10000;
      uVar8 = uVar8 * 0x10000 + 0x10000 >> 0x10;
      if (uVar7 * 0x10000 + iVar4 == 0) {
        sVar3 = sub_0800086C();
        sVar3 = __modsi3((int)sVar3,0x14);
        iVar4 = (int)sVar3;
        if (iVar4 < 0) {
          iVar4 = -iVar4;
        }
        uVar7 = iVar4 + 10U & 0xffff;
        bVar9 = 0;
        uVar8 = 0;
      }
    }
    sub_0800903C(1,0x32,1,uVar10,uStack_28,0);
    iStack_30 = iStack_30 + -0x200;
    *(short *)dVar2 = (short)((uint)iStack_30 >> 8);
    *(short *)(dVar2 + 2) = (short)(*(short *)(uVar11 * 2 + DWORD_080943f4) * 3 >> 6) + 0xc;
    uVar11 = uVar11 + 2 & 0xff;
    iStack_2c = iStack_2c + -0x44;
    *(short *)(dVar2 + 4) = (short)((uint)iStack_2c >> 8);
    *(short *)(dVar2 + 6) = 0xc - (short)(*(short *)(uStack_24 * 2 + DWORD_080943f4) * 3 >> 7);
    uStack_24 = uStack_24 + 1 & 0xff;
    sub_080003F0();
  } while( true );
}


