
undefined8 sub_0805AC08(short *param_1)

{
  dword dVar1;
  dword dVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  undefined2 *puVar7;
  short *psVar8;
  int iVar9;
  ushort *puVar10;
  int iVar11;
  dword dVar12;
  undefined4 in_lr;
  
  dVar1 = DWORD_0805ac20;
  if (*param_1 == 10) {
    iVar6 = -1;
    do {
      iVar11 = iVar6;
      if (iVar6 < 0) {
        iVar11 = 0;
      }
      iVar4 = *(int *)dVar1;
      psVar8 = (short *)(iVar4 + iVar11 * 0x10 + 0x2e0);
      dVar12 = 0xffffffff;
      uVar5 = (uint)*(ushort *)(iVar4 + 0x6a);
      iVar4 = uVar5 * 0xf;
      iVar9 = iVar11;
      if ((int)(iVar11 + uVar5 * -0xf) < 0 != SBORROW4(iVar11,iVar4)) {
        do {
          if (((*psVar8 == 10) && (dVar2 = *(dword *)(psVar8 + 2), (int)dVar12 < (int)dVar2)) &&
             (dVar2 != DWORD_0805acec)) {
            iVar9 = iVar11;
            dVar12 = dVar2;
          }
          iVar11 = iVar11 + 1;
          psVar8 = psVar8 + 8;
        } while (iVar11 < iVar4);
      }
      if ((int)dVar12 < 0) {
        iVar9 = -1;
      }
      if ((iVar6 == iVar9) || (iVar9 < 0)) break;
      iVar6 = *(int *)dVar1;
      puVar10 = (ushort *)(iVar6 + 0x6a);
      if (0x18 < (uint)*puVar10 * 0xf) break;
      puVar7 = (undefined2 *)(iVar6 + iVar9 * 0x10 + 0x2e0);
      *puVar7 = 10;
      uVar5 = *(int *)(puVar7 + 2) + *(int *)(param_1 + 2);
      if (uVar5 <= DWORD_0805acec) {
        *(uint *)(puVar7 + 2) = uVar5;
        goto LAB_0805ad0a;
      }
      *(dword *)(puVar7 + 2) = DWORD_0805acec;
      *(uint *)(param_1 + 2) = uVar5 + DWORD_0805acf0;
      uVar5 = (uint)*puVar10;
      iVar6 = iVar9;
    } while ((int)(iVar9 + uVar5 * -0xf) < 0 != SBORROW4(iVar9,uVar5 * 0xf));
  }
  uVar5 = 0;
  psVar8 = (short *)(*(int *)DWORD_0805acf4 + 0x2e0);
  do {
    if (*psVar8 == 0) goto LAB_0805acde;
    psVar8 = psVar8 + 8;
    uVar5 = uVar5 + 1;
  } while (uVar5 < 0x19);
  uVar5 = 0xffffffff;
LAB_0805acde:
  if (uVar5 == 0xffffffff) {
    uVar3 = 0;
  }
  else {
    sub_0805D028(uVar5 & 0xff,param_1);
LAB_0805ad0a:
    uVar3 = 1;
  }
  return CONCAT44(in_lr,uVar3);
}


