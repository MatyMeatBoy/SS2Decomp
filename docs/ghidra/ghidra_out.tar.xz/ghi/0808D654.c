
undefined4 sub_0808D654(ushort *param_1)

{
  ushort uVar1;
  undefined1 uVar2;
  ushort uVar3;
  short sVar4;
  int iVar5;
  ushort *puVar6;
  undefined4 in_lr;
  undefined4 auStack_9c [2];
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined1 auStack_80 [76];
  short sStack_34;
  short sStack_32;
  uint uStack_30;
  int iStack_2c;
  int iStack_28;
  uint uStack_24;
  
  sub_0801623C(param_1,DWORD_0808d6d4,3);
  param_1[1] = *param_1 + param_1[1];
  sub_08019F60(param_1 + 0x102);
  param_1[0x36] = 0;
  puVar6 = param_1 + 0x35;
  *puVar6 = 0;
  param_1[0x34] = 0;
  param_1[0xeb] = param_1[0x105] * 3;
  param_1[0x2e] = param_1[0x105] * 3;
  param_1[0xea] = param_1[0x104] * 0x14;
  param_1[0x2f] = param_1[0x104] * 0x14;
  param_1[6] = 0;
  uVar3 = 0;
  iStack_28 = 0;
  uStack_24 = DWORD_0808d6d8;
  iStack_2c = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  while ((iVar5 = sub_0800CB78(), iVar5 == 0 && (iVar5 = sub_08056E90(), iVar5 == 0))) {
    sub_0801C8F0(param_1);
    uVar1 = param_1[6];
    if (uVar1 == 0) {
      sub_08065158(auStack_9c,DWORD_0808d710,5,0xffffffff,0);
      param_1[0x34] = 0;
    }
    else if (uVar1 == 10) {
      if (iStack_28 == 0) {
        iStack_28 = 1;
        uVar3 = 8;
      }
    }
    else if ((uVar1 == 0xb) && (iStack_28 == 0)) {
      iStack_28 = 1;
      uVar3 = 0x14;
      sub_080586D0(2);
    }
    uVar2 = sub_0800BC44(*(int *)(param_1 + 10) >> 8,*(int *)(param_1 + 0xc) >> 8,0);
    auStack_80[0] = 5;
    sub_0800BC08((*(int *)(param_1 + 10) << 8) >> 0x10,(*(int *)(param_1 + 0xc) << 8) >> 0x10,
                 &sStack_34,&sStack_32,0x30,0);
    if (iStack_28 == 0) {
      iVar5 = sub_0800CCCC();
      if ((((iVar5 == 0) && (iVar5 = sub_0800CC98(), iVar5 == 0)) &&
          (iVar5 = sub_0800CD8C(), iVar5 == 0)) && (iVar5 = sub_0800CD34(), iVar5 == 0)) {
        sub_08007870((int)sStack_34,(int)sStack_32,param_1[0x34],*puVar6,uVar2,auStack_80,uStack_94,
                     auStack_9c[0]);
      }
    }
    else {
      if ((((uVar3 & 1) != 0) && (iVar5 = sub_0800CCCC(), iVar5 == 0)) &&
         ((iVar5 = sub_0800CC98(), iVar5 == 0 &&
          ((iVar5 = sub_0800CD8C(), iVar5 == 0 && (iVar5 = sub_0800CD34(), iVar5 == 0)))))) {
        sub_08007870((int)sStack_34,(int)sStack_32,param_1[0x34],*puVar6,uVar2,auStack_80,uStack_94,
                     auStack_9c[0]);
      }
      uVar3 = uVar3 - 1;
      if (uVar3 == 0) {
        if (param_1[6] == 0xb) break;
        param_1[6] = 0;
        sub_08019CE8(param_1);
        iStack_28 = 0;
        iVar5 = __divsi3((short)param_1[0x2e] * 100,(int)(short)param_1[0xeb]);
        if (iVar5 < 10) {
          *puVar6 = 7;
        }
        else if (iVar5 < 0xf) {
          *puVar6 = 6;
        }
        else if (iVar5 < 0x14) {
          *puVar6 = 5;
        }
        else if (iVar5 < 0x1e) {
          *puVar6 = 4;
        }
        else if (iVar5 < 0x32) {
          *puVar6 = 3;
        }
        else if (iVar5 < 0x46) {
          *puVar6 = 2;
        }
        else if (iVar5 < 0x5a) {
          *puVar6 = 1;
        }
        else {
          *puVar6 = 0;
        }
      }
    }
    if ((*(int *)(param_1 + 0x26) != 0) && (iStack_2c != *(int *)(param_1 + 0x26))) {
      sVar4 = sub_08019CE8(param_1);
      if (sVar4 != 0) {
        uVar3 = 10;
      }
      iStack_2c = *(int *)(param_1 + 0x26);
      uStack_24 = 10;
      uStack_30 = 0;
    }
    if ((uStack_24 & 0x8000) == 0) {
      if (iStack_2c == 0) {
        uStack_24 = DWORD_0808d8e4;
      }
      else {
        uStack_24 = uStack_24 - 1 & 0xffff;
        iVar5 = sub_0800CC98();
        if (((iVar5 == 0) && (iVar5 = sub_0800CCCC(), iVar5 == 0)) &&
           (iVar5 = sub_0800CD34(), iVar5 == 0)) {
          sub_0801A120(param_1,iStack_2c,(int)(short)uStack_30);
        }
        if ((uStack_24 & 2) != 0) {
          uStack_30 = uStack_30 * 0x10000 + DWORD_0808d928 >> 0x10;
        }
      }
    }
    else {
      uStack_24 = DWORD_0808d9a0;
      iStack_2c = 0;
      param_1[0x26] = 0;
      param_1[0x27] = 0;
    }
    iVar5 = sub_0800CCCC();
    if ((iVar5 == 0) && ((*(uint *)DWORD_0808d9a4 & 1) == (*param_1 & 1))) {
      sub_08000AF0(0x15,uStack_90,1);
    }
    sub_080003F0();
  }
  sub_0809D558();
  sub_0805865C(0xe8);
  *(uint *)DWORD_0808d9a8 = *(uint *)DWORD_0808d9a8 & ~(1 << (*param_1 & 0xff));
  sub_08016ECC(5);
  return in_lr;
}


