
undefined4 sub_08058790(void)

{
  short sVar1;
  int iVar2;
  undefined4 in_lr;
  
  sub_0800CF90();
  sVar1 = 1;
  do {
    sub_080003F0();
    iVar2 = sub_080021A8();
    if (iVar2 != 0) break;
    sVar1 = sVar1 + -1;
  } while (sVar1 != 0);
  sub_0801A664(0,2);
  sVar1 = 1;
  do {
    sub_080003F0();
    iVar2 = sub_080021A8();
    if (iVar2 != 0) {
      return in_lr;
    }
    sVar1 = sVar1 + -1;
  } while (sVar1 != 0);
  return in_lr;
}


