
undefined4 sub_08046F28(uint param_1)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  dword dVar4;
  int iVar5;
  byte *pbVar6;
  undefined4 uVar7;
  int iVar8;
  uint uVar9;
  short *psVar10;
  uint *puVar11;
  short *psVar12;
  undefined4 in_lr;
  undefined2 uStack_38;
  undefined2 uStack_36;
  undefined1 auStack_34 [28];
  
  iVar5 = sub_080020F4();
  dVar4 = DWORD_08046f6c;
  iVar5 = iVar5 * 0x14c + DWORD_08046f6c;
  *(uint *)(iVar5 + 0x30) = *(uint *)(iVar5 + 0x30) | 1;
  sub_0800D0F4();
  iVar5 = sub_080020F4();
  if ((int)DWORD_08046f70 < *(int *)(iVar5 * 0x14c + dVar4 + 0x8c) >> 8) {
    sub_08029174(param_1,6);
  }
  else {
    sub_08029174(param_1,2);
  }
  iVar5 = sub_0800CE30();
  if (iVar5 == 0) {
    pbVar6 = (byte *)(*(int *)DWORD_08046fbc + DWORD_08046fc0);
  }
  else {
    pbVar6 = (byte *)(*(int *)DWORD_08046f90 + DWORD_08046f94);
  }
  bVar1 = *pbVar6;
  iVar5 = sub_0800CE30();
  if (iVar5 == 0) {
    pbVar6 = (byte *)(*(int *)DWORD_08046fec + DWORD_08046ff0);
  }
  else {
    pbVar6 = (byte *)(*(int *)DWORD_08046fbc + DWORD_08046fc4);
  }
  bVar2 = *pbVar6;
  iVar5 = sub_0800CE30();
  if (iVar5 == 0) {
    pbVar6 = (byte *)(*(int *)DWORD_0804701c + DWORD_08047020);
  }
  else {
    pbVar6 = (byte *)(*(int *)DWORD_08046fec + DWORD_08046ff4);
  }
  bVar3 = *pbVar6;
  iVar5 = sub_0800CE30();
  if (iVar5 == 0) {
    pbVar6 = (byte *)(*(int *)DWORD_0804704c + DWORD_08047050);
  }
  else {
    pbVar6 = (byte *)(*(int *)DWORD_0804701c + DWORD_08047024);
  }
  uVar9 = (int)(uint)*pbVar6 >> 5 & 1;
  if (((((int)(uint)bVar1 >> 2 & 1U) == 0) || (((int)(uint)bVar2 >> 3 & 1U) == 0)) ||
     (((int)(uint)bVar3 >> 4 & 1U) == 0)) {
    if (uVar9 != 0) {
      while (iVar5 = sub_0805F184(), iVar5 != 0) {
        sub_080003F0();
      }
      while (iVar5 = sub_0805EF90(), iVar5 != 0) {
        sub_080003F0();
      }
      uVar7 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_080470e4);
      while (iVar5 = sub_0805EEFC(uVar7), iVar5 == 0) {
        iVar5 = sub_0800CDF8();
        if (iVar5 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
      goto LAB_0804743e;
    }
  }
  else if (uVar9 != 0) {
    while (iVar5 = sub_0805F184(), iVar5 != 0) {
      sub_080003F0();
    }
    while (iVar5 = sub_0805EF90(), iVar5 != 0) {
      sub_080003F0();
    }
    uVar7 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08047088);
    while (iVar5 = sub_0805EEFC(uVar7), iVar5 == 0) {
      iVar5 = sub_0800CDF8();
      if (iVar5 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
    goto LAB_0804743e;
  }
  while (iVar5 = sub_0805F184(), iVar5 != 0) {
    sub_080003F0();
  }
  while (iVar5 = sub_0805EF90(), iVar5 != 0) {
    sub_080003F0();
  }
  uVar7 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08047140);
  while (iVar5 = sub_0805EEFC(uVar7), iVar5 == 0) {
    iVar5 = sub_0800CDF8();
    if (iVar5 != 0) {
      sub_0805EFBC();
      break;
    }
    sub_080003F0();
  }
  iVar5 = 0;
  uVar9 = 0;
  psVar10 = (short *)(*(int *)DWORD_080471cc + 0x150);
  do {
    if ((*psVar10 == 2) && (psVar10[1] == 0x38)) {
      iVar5 = iVar5 + 1;
    }
    psVar10 = psVar10 + 8;
    uVar9 = uVar9 + 1;
  } while (uVar9 < 0x19);
  iVar8 = sub_080020F4();
  if ((iVar5 != 0) && (iVar8 == 0)) {
    if (param_1 < 0x100001) {
      if (param_1 == 0) {
        iVar5 = sub_080020F4();
        *(undefined2 *)(iVar5 * 0x14c + DWORD_08047218 + 0x11e) = 3;
      }
      else if (param_1 - 1 < 5) {
        sub_08019EB8(*(undefined2 *)(*(int *)DWORD_080471fc + (param_1 - 1) * 0x2e0 + 2),3);
      }
    }
    else {
      puVar11 = (uint *)(*(int *)DWORD_080471d0 + DWORD_080471d4);
      uVar9 = 0;
      do {
        if (*puVar11 == param_1) goto LAB_080471c0;
        uVar9 = uVar9 + 1;
        puVar11 = puVar11 + 0x1c;
      } while (uVar9 < 0xf);
      sub_080003F0();
      puVar11 = (uint *)0x0;
LAB_080471c0:
      if (puVar11 != (uint *)0x0) {
        *(undefined2 *)((int)puVar11 + 0x42) = 3;
      }
    }
    while (iVar5 = sub_0805F184(), iVar5 != 0) {
      sub_080003F0();
    }
    uVar7 = sub_0805DF38(1,0xf,2,0,0xfffffffe,DWORD_08047244);
    while (iVar5 = sub_0805EEFC(uVar7), iVar5 == 0) {
      sub_080003F0();
    }
    iVar5 = sub_0805EF14(uVar7);
    if (iVar5 == 0) {
      while (iVar5 = sub_0805F184(), iVar5 != 0) {
        sub_080003F0();
      }
      while (iVar5 = sub_0805EF90(), iVar5 != 0) {
        sub_080003F0();
      }
      uVar7 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08047420);
      while (iVar5 = sub_0805EEFC(uVar7), iVar5 == 0) {
        iVar5 = sub_0800CDF8();
        if (iVar5 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
    }
    else {
      while (iVar5 = sub_0805F184(), iVar5 != 0) {
        sub_080003F0();
      }
      while (iVar5 = sub_0805EF90(), iVar5 != 0) {
        sub_080003F0();
      }
      uVar7 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_080472a0);
      while (iVar5 = sub_0805EEFC(uVar7), iVar5 == 0) {
        iVar5 = sub_0800CDF8();
        if (iVar5 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
      dVar4 = DWORD_08047338;
      iVar5 = 1;
      uVar9 = 0;
      do {
        iVar8 = *(int *)dVar4 + uVar9 * 0x10;
        psVar10 = (short *)(iVar8 + 0x150);
        if ((*psVar10 == 2) && (psVar12 = (short *)(iVar8 + 0x152), *psVar12 == 0x38)) {
          iVar5 = iVar5 + -1;
          *psVar10 = 0;
          *psVar12 = 0;
          if (iVar5 == 0) break;
        }
        uVar9 = uVar9 + 1;
      } while (uVar9 < 0x19);
      uStack_38 = 1;
      uStack_36 = 0x1e;
      uVar9 = 0;
      do {
        auStack_34[uVar9] = 0;
        uVar9 = uVar9 + 1;
      } while (uVar9 < 0xc);
      iVar5 = 0;
      do {
        sub_0805AB20(&uStack_38);
        iVar5 = iVar5 + 1;
      } while (iVar5 == 0);
      sub_08068070(DWORD_0804733c,0x25);
      if ((*(uint *)DWORD_08047340 & 0x20) == 0) {
        sub_08006D08(0x33);
      }
      while (iVar5 = sub_0805F184(), iVar5 != 0) {
        sub_080003F0();
      }
      while (iVar5 = sub_0805EF90(), iVar5 != 0) {
        sub_080003F0();
      }
      uVar7 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08047378);
      while (iVar5 = sub_0805EEFC(uVar7), iVar5 == 0) {
        iVar5 = sub_0800CDF8();
        if (iVar5 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
      while (iVar5 = sub_0805F184(), iVar5 != 0) {
        sub_080003F0();
      }
      while (iVar5 = sub_0805EF90(), iVar5 != 0) {
        sub_080003F0();
      }
      uVar7 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_080473cc);
      while (iVar5 = sub_0805EEFC(uVar7), iVar5 == 0) {
        iVar5 = sub_0800CDF8();
        if (iVar5 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
    }
  }
LAB_0804743e:
  sub_0802939C(param_1,0);
  iVar5 = sub_080020F4();
  iVar5 = iVar5 * 0x14c + DWORD_08047470;
  *(uint *)(iVar5 + 0x30) = *(uint *)(iVar5 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


