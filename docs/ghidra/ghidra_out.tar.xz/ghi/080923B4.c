
undefined4 sub_080923B4(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 in_lr;
  
  iVar1 = (param_1 << 0x18) >> 0x16;
  iVar2 = (param_2 << 0x10) >> 0x18;
  _call_via_r2(iVar2,(int)(char)param_2,*(undefined4 *)(iVar1 + DWORD_080923f0));
  _call_via_r2(iVar2,(int)(char)param_2,*(undefined4 *)(iVar1 + DWORD_080923f4));
  sub_08000420(DWORD_080923f8);
  return in_lr;
}


