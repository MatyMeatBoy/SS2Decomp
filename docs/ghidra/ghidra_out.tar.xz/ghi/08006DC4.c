
undefined4 sub_08006DC4(undefined4 param_1,undefined2 param_2)

{
  undefined4 in_lr;
  
  m4aMPlayFadeOut(param_1,param_2);
  return in_lr;
}


