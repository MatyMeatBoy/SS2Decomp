
undefined4 sub_08052D0C(void)

{
  short sVar1;
  short sVar2;
  int iVar3;
  dword dVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 in_lr;
  undefined1 auStack_38 [4];
  undefined1 auStack_34 [4];
  undefined1 auStack_30 [4];
  undefined1 auStack_2c [4];
  undefined1 *puStack_28;
  undefined1 *puStack_24;
  
  iVar3 = sub_080020F4();
  iVar3 = iVar3 * 0x14c + DWORD_08052d44;
  *(uint *)(iVar3 + 0x30) = *(uint *)(iVar3 + 0x30) | 1;
  sub_0800D0F4();
  iVar3 = sub_08002164();
  if (iVar3 == 1) {
    uVar5 = 0xa0;
    uVar6 = 0xd8;
  }
  else {
    iVar3 = sub_080020F4();
    if (iVar3 == 1) {
      uVar5 = 0xae;
    }
    else {
      if (iVar3 < 2) {
        if (iVar3 != 0) goto LAB_08052d8c;
        uVar5 = 0xa0;
        uVar6 = 0xd0;
        goto LAB_08052d78;
      }
      if (iVar3 != 2) {
        if (iVar3 == 3) {
          sub_08028AAC(0,0xa0,0xdc,0);
        }
        goto LAB_08052d8c;
      }
      uVar5 = 0x94;
    }
    uVar6 = 0xd6;
  }
LAB_08052d78:
  sub_08028AAC(0,uVar5,uVar6,0);
LAB_08052d8c:
  sub_080290E4(0,5);
  sVar2 = 1;
  puStack_28 = auStack_30;
  puStack_24 = auStack_2c;
  do {
    sub_080003F0();
    iVar3 = sub_080021A8();
    if (iVar3 != 0) break;
    sVar2 = sVar2 + -1;
  } while (sVar2 != 0);
  iVar3 = sub_0800CC98();
  if (iVar3 == 0) {
    iVar3 = sub_0801AB24();
    if (iVar3 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar3 < 2) {
      if (iVar3 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar3 == 2) {
      sub_0801AB90(6);
    }
    while (iVar3 = sub_0801AAE0(), iVar3 == 0) {
      sub_080003F0();
    }
  }
  *(undefined4 *)DWORD_08052e1c = 0xd9;
  if ((*(uint *)DWORD_08052e20 & 0x20) == 0) {
    sub_08006CB4(0xd9);
  }
  sVar2 = 0x14;
  do {
    sub_080003F0();
    iVar3 = sub_080021A8();
    dVar4 = DWORD_08052ea8;
    if (iVar3 != 0) break;
    sVar2 = sVar2 + -1;
  } while (sVar2 != 0);
  sVar2 = *(short *)(DWORD_08052ea4 + 0x80);
  sVar1 = *(short *)(DWORD_08052ea4 + 0x82);
  iVar3 = 0;
  do {
    sub_080659F4(auStack_38,(int)sVar2,0xa0,iVar3);
    sub_080659F4(auStack_34,(int)sVar1,(int)dVar4 >> 0x10,iVar3);
    sub_0800BB80((int)auStack_38._0_2_,(int)auStack_34._0_2_);
    sub_080003F0();
    iVar3 = iVar3 + 0x11;
  } while (iVar3 < 0x401);
  if ((*(uint *)(*(int *)DWORD_08052eac + 0x38) & 1) == 0) {
    while (iVar3 = sub_0805F184(), iVar3 != 0) {
      sub_080003F0();
    }
    while (iVar3 = sub_0805EF90(), dVar4 = DWORD_08052ed4, iVar3 != 0) {
      sub_080003F0();
    }
  }
  else {
    while (iVar3 = sub_0805F184(), iVar3 != 0) {
      sub_080003F0();
    }
    while (iVar3 = sub_0805EF90(), dVar4 = DWORD_08052f18, iVar3 != 0) {
      sub_080003F0();
    }
  }
  uVar5 = sub_0805DF38(1,0xf,2,0,0x2d,dVar4);
  *(uint *)(*(int *)DWORD_08052f1c + 0x38) = *(uint *)(*(int *)DWORD_08052f1c + 0x38) | 1;
  while (iVar3 = sub_0805EEFC(uVar5), iVar3 == 0) {
    sub_080003F0();
  }
  sVar2 = *(short *)(DWORD_08052fd4 + 0x80);
  sVar1 = *(short *)(DWORD_08052fd4 + 0x82);
  iVar3 = 0;
  do {
    sub_080659F4(puStack_28,(int)sVar2,0,iVar3);
    sub_080659F4(puStack_24,(int)sVar1,0,iVar3);
    sub_0800BB80((int)auStack_30._0_2_,(int)auStack_2c._0_2_);
    sub_080003F0();
    iVar3 = iVar3 + 0x22;
  } while (iVar3 < 0x401);
  *(undefined4 *)DWORD_08052fd8 = 0xb;
  if ((*(uint *)DWORD_08052fdc & 0x20) == 0) {
    sub_08006CB4(0xb);
  }
  *(ushort *)(*(int *)DWORD_08052fe0 + 4) = *(ushort *)(*(int *)DWORD_08052fe0 + 4) | 0x20;
  iVar3 = sub_080020F4();
  iVar3 = iVar3 * 0x14c + DWORD_08052fe4;
  *(uint *)(iVar3 + 0x30) = *(uint *)(iVar3 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


