
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_08026CD0(undefined2 param_1,uint param_2,short param_3)

{
  int iVar1;
  undefined2 *puVar2;
  undefined4 *puVar3;
  undefined4 in_lr;
  
  param_2 = param_2 & 0xffff;
  if (param_3 == 0) {
    sub_0800BB40();
    sub_0805768C();
  }
  else if (param_3 == 1) {
    sub_080576C4();
    sub_0800BB40();
    sub_08057624(5);
  }
  switch(param_1) {
  case 0:
    sub_0800CCDC();
    iVar1 = *_UNK_08026d90;
    *(undefined4 *)(iVar1 + _UNK_08026d94) = *(undefined4 *)(param_2 * 4 + _UNK_08026d98);
    *(undefined2 *)(iVar1 + 0x36) = 0;
    goto LAB_0802701a;
  case 1:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026dac + _UNK_08026db0);
    iVar1 = _UNK_08026db4;
    break;
  case 2:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026dc8 + _UNK_08026dcc);
    iVar1 = _UNK_08026dd0;
    break;
  case 3:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026de4 + _UNK_08026de8);
    iVar1 = _UNK_08026dec;
    break;
  case 4:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026e00 + _UNK_08026e04);
    iVar1 = _UNK_08026e08;
    break;
  case 5:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026e1c + _UNK_08026e20);
    iVar1 = _UNK_08026e24;
    break;
  case 6:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026e38 + _UNK_08026e3c);
    iVar1 = _UNK_08026e40;
    break;
  case 7:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026e54 + _UNK_08026e58);
    iVar1 = _UNK_08026e5c;
    break;
  case 8:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026e70 + _UNK_08026e74);
    iVar1 = _UNK_08026e78;
    break;
  case 9:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026e8c + _UNK_08026e90);
    iVar1 = _UNK_08026e94;
    break;
  case 10:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026ea8 + _UNK_08026eac);
    iVar1 = _UNK_08026eb0;
    break;
  case 0xb:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026ec4 + _UNK_08026ec8);
    iVar1 = _UNK_08026ecc;
    break;
  case 0xc:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026ee0 + _UNK_08026ee4);
    iVar1 = _UNK_08026ee8;
    break;
  case 0xd:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026efc + _UNK_08026f00);
    iVar1 = _UNK_08026f04;
    break;
  case 0xe:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026f18 + _UNK_08026f1c);
    iVar1 = _UNK_08026f20;
    break;
  case 0xf:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026f34 + _UNK_08026f38);
    iVar1 = _UNK_08026f3c;
    break;
  case 0x10:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026f50 + _UNK_08026f54);
    iVar1 = _UNK_08026f58;
    break;
  case 0x11:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026f6c + _UNK_08026f70);
    iVar1 = _UNK_08026f74;
    break;
  case 0x12:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026f88 + _UNK_08026f8c);
    iVar1 = _UNK_08026f90;
    break;
  case 0x13:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026fa4 + _UNK_08026fa8);
    iVar1 = _UNK_08026fac;
    break;
  case 0x14:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026fc0 + _UNK_08026fc4);
    iVar1 = _UNK_08026fc8;
    break;
  case 0x15:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026fdc + _UNK_08026fe0);
    iVar1 = _UNK_08026fe4;
    break;
  case 0x16:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*_UNK_08026ff8 + _UNK_08026ffc);
    iVar1 = _UNK_08027000;
    break;
  case 0x17:
    sub_0800CCEC();
    puVar3 = (undefined4 *)(*(int *)DWORD_08027040 + _UNK_08027044);
    iVar1 = _UNK_08027048;
    break;
  default:
    goto LAB_0802701a;
  }
  *puVar3 = *(undefined4 *)(param_2 * 4 + iVar1);
LAB_0802701a:
  iVar1 = sub_0800CF10();
  sub_080570DC(iVar1 == 0);
  puVar2 = *(undefined2 **)DWORD_08027040;
  puVar2[8] = 0;
  *(uint *)(puVar2 + 0x20) = param_2;
  *puVar2 = param_1;
  return in_lr;
}


