
undefined4 sub_08059418(undefined4 param_1)

{
  int iVar1;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_08059454;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) | 1;
  sub_0800D0F4();
  sub_0802949C(param_1,0);
  iVar1 = sub_0800CE30();
  if (iVar1 == 0) {
    sub_080445E8(2,param_1);
  }
  else {
    sub_080445E8(3,param_1);
  }
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_08059484;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


