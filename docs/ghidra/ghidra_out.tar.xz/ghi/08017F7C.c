
undefined8 sub_08017F7C(undefined4 param_1)

{
  uint uVar1;
  int iVar2;
  ushort *puVar3;
  dword dVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 in_lr;
  int iStack_2c;
  uint uStack_28;
  dword dStack_24;
  uint uStack_20;
  
  dStack_24 = DWORD_08018014;
  uStack_20 = (uStack_20 & DWORD_0801800c | 0x20) & DWORD_08018010 | 0x200000;
  uVar6 = 0;
  uVar1 = sub_08002164();
  uVar5 = 0;
  dVar4 = DWORD_08018018;
  if (uVar1 != 0) {
    do {
      puVar3 = *(ushort **)(dVar4 + 0x148);
      if ((puVar3[2] & 0x20) == 0) {
        iStack_2c = (uint)(*puVar3 >> 4) << 8;
        uStack_28 = ((uint)*(ushort *)(*(int *)(dVar4 + 0x148) + 2) << 0x14) >> 0xc;
        iVar2 = sub_08021FE0(&iStack_2c,param_1,&dStack_24,&uStack_20);
        if (iVar2 != 0) {
          uVar6 = 1;
        }
      }
      uVar5 = uVar5 + 1;
      dVar4 = dVar4 + 0x14c;
    } while (uVar5 < uVar1);
  }
  return CONCAT44(in_lr,uVar6);
}


