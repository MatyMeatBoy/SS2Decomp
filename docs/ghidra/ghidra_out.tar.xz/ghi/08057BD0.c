
void sub_08057BD0(int param_1)

{
  int iVar1;
  
  iVar1 = sub_0800CE30();
  if (iVar1 == 0) {
    *(uint *)(*(int *)DWORD_08057bf0 + 0x74) =
         *(uint *)(*(int *)DWORD_08057bf0 + 0x74) | 1 << (param_1 - 1U & 0xff);
  }
  else {
    *(uint *)(*(int *)DWORD_08057c08 + 0x7c) =
         *(uint *)(*(int *)DWORD_08057c08 + 0x7c) | 1 << (param_1 - 1U & 0xff);
  }
  return;
}


