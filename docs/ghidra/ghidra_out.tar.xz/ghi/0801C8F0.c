
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_0801C8F0(ushort *param_1)

{
  byte bVar1;
  ushort uVar2;
  short sVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  ushort *puVar7;
  int iVar8;
  ushort *puVar9;
  uint uVar10;
  undefined4 in_lr;
  int iStack_24;
  uint uStack_20;
  dword dStack_1c;
  dword dStack_18;
  
  iVar4 = sub_08007290(param_1[0x116] | 0xb0000);
  puVar9 = param_1 + 0xe6;
  sub_0801B264(iVar4 + 0xb0,param_1 + 0x102,puVar9);
  bVar1 = *(byte *)(iVar4 + 0x9c);
  *puVar9 = (ushort)bVar1;
  *puVar9 = (ushort)bVar1 + param_1[0x102];
  param_1[0xe7] = param_1[0x107];
  param_1[0x31] = 0;
  if ((*(byte *)((int)param_1 + DWORD_0801c994) & 2) != 0) {
    param_1[0x31] = 8;
  }
  if (*(char *)((int)param_1 + DWORD_0801c998) != '\x03') {
    puVar9 = param_1 + 0x46;
    uVar10 = 0;
    do {
      if (((short)*puVar9 < 0) && (*puVar9 != 0xfffe)) goto LAB_0801cbfe;
      if (puVar9[1] < 4) {
        iVar8 = (uint)puVar9[1] * 0x14c;
        iVar4 = iVar8 + DWORD_0801c99c;
        uVar2 = *(ushort *)(iVar4 + 0xc);
        if (uVar2 == 5) {
          iVar4 = sub_0800CDC0();
          if ((iVar4 == 0) && (puVar9[2] == 6)) {
            puVar7 = param_1 + 0x31;
            uVar2 = 9;
            goto LAB_0801cbea;
          }
        }
        else if (uVar2 < 6) {
          if (uVar2 == 3) {
            if (puVar9[2] == 4) {
              sVar3 = *(short *)(iVar4 + 0x10);
              if (sVar3 == 2) {
                sVar3 = puVar9[3] << 3;
LAB_0801c9d8:
                param_1[0xe7] = param_1[0xe7] - sVar3;
              }
              else if (sVar3 == 4) {
                sVar3 = puVar9[3] * 0xc;
                goto LAB_0801c9d8;
              }
              puVar7 = param_1 + 0xe7;
              if ((short)*puVar7 < 0) {
                uVar2 = 0;
                goto LAB_0801cbea;
              }
            }
            else if (puVar9[2] == 6) {
              piVar6 = (int *)(iVar8 + DWORD_0801c99c + 0x148);
              iStack_24 = (uint)(*(ushort *)*piVar6 >> 4) << 8;
              uStack_20 = ((uint)*(ushort *)(*piVar6 + 2) << 0x14) >> 0xc;
              dStack_1c = DWORD_0801ca48;
              dStack_18 = DWORD_0801ca4c;
              iVar4 = sub_08021FE0(&iStack_24,param_1 + 10,&dStack_1c,&dStack_18);
              if (iVar4 != 0) {
                puVar7 = param_1 + 0xe6;
                iVar4 = (uint)*puVar7 + (uint)puVar9[3] * -4;
                *puVar7 = (ushort)iVar4;
                if (iVar4 * 0x10000 < 0) {
                  *puVar7 = 0;
                }
              }
            }
          }
        }
        else if (((uVar2 == 7) && (puVar9[2] == 4)) &&
                ((iVar4 = sub_0800CDC0(), iVar4 != 0 ||
                 (*(undefined1 *)((int)param_1 + DWORD_0801ca90) = 1, param_1[6] == 10)))) {
          *puVar9 = (ushort)DWORD_0801ca94;
        }
        goto LAB_0801cbec;
      }
      switch(puVar9[2]) {
      case 1:
        if (((*puVar9 == 0) &&
            (puVar7 = param_1 + 0x25, 0 < (int)((int)(short)param_1[0x2e] - (uint)*puVar7))) &&
           ((param_1[6] != 0xb && (param_1[0x33] == 0)))) {
          sub_08021DC4(*param_1 + 4);
          *puVar7 = puVar9[3] + *puVar7;
          *(uint *)(param_1 + 0x26) = (uint)puVar9[3];
        }
        break;
      case 2:
        puVar7 = param_1 + 0x31;
        uVar2 = 9;
        goto LAB_0801cbea;
      case 3:
        param_1[0x31] = 10;
        *(undefined1 *)((int)param_1 + _UNK_0801caf0) = 1;
        *(undefined1 *)((int)param_1 + _UNK_0801caf4) = 0;
        break;
      case 4:
        if ((((*puVar9 == 0) &&
             (puVar7 = param_1 + 0x25, 0 < (int)((int)(short)param_1[0x2e] - (uint)*puVar7))) &&
            (param_1[6] != 0xb)) && (param_1[0x33] == 0)) {
          sub_08022180(*param_1 + 4);
          *puVar7 = puVar9[3] + *puVar7;
          *(uint *)(param_1 + 0x26) = (uint)puVar9[3];
          puVar7 = param_1 + 0x31;
          uVar2 = 0xb;
          goto LAB_0801cbea;
        }
        break;
      case 5:
        param_1[0x31] = 0xc;
        uVar2 = *(short *)(*(int *)(param_1 + 0x16e) + 2) >> 1;
        puVar7 = (ushort *)((int)param_1 + _UNK_0801cb14);
LAB_0801cbea:
        *puVar7 = uVar2;
        break;
      case 6:
        param_1[0x31] = 0xd;
        uVar2 = *puVar9;
        goto code_r0x0801cb32;
      case 7:
        param_1[0x31] = 0xd;
        uVar2 = *puVar9;
code_r0x0801cb32:
        sVar3 = __modsi3((int)(short)uVar2,0x3c);
        if (sVar3 == 0) {
          uVar5 = __divsi3((*(int *)(puVar9 + 0xc) * 10 + 100) * (uint)puVar9[3],100);
          *(undefined4 *)(param_1 + 0x26) = uVar5;
          param_1[0x25] = param_1[0x25] + (short)uVar5;
        }
      }
LAB_0801cbec:
      if (*puVar9 != 0xfffe) {
        *puVar9 = *puVar9 - 1;
      }
LAB_0801cbfe:
      uVar10 = uVar10 + 1;
      puVar9 = puVar9 + 0x14;
    } while (uVar10 < 8);
  }
  return in_lr;
}


