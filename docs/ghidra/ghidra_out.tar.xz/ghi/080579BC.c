
undefined4 sub_080579BC(void)

{
  int iVar1;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  *(undefined2 *)(iVar1 * 0x14c + DWORD_080579d4 + 0x20) = 0;
  return in_lr;
}


