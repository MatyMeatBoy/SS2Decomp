
/* WARNING: Removing unreachable block (ram,0x08079a50) */

undefined4 sub_08079948(uint *param_1)

{
  undefined1 uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined1 unaff_r8;
  undefined4 in_lr;
  bool bVar6;
  undefined4 auStack_84 [2];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined1 uStack_68;
  undefined1 uStack_67;
  short sStack_50;
  short sStack_4e;
  undefined2 uStack_4c;
  undefined2 uStack_4a;
  uint uStack_48;
  uint uStack_44;
  dword dStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  dword dStack_30;
  uint uStack_2c;
  int iStack_28;
  int iStack_24;
  
  uStack_2c = sub_080020F4();
  uStack_48 = param_1[2];
  uStack_44 = param_1[5];
  uStack_38 = *param_1;
  uStack_34 = param_1[1];
  uStack_4a = 0;
  uStack_4c = 0;
  dStack_40 = DWORD_08079b90;
  dStack_30 = DWORD_08079b94;
  sub_08065158(auStack_84,DWORD_08079b98,0,0x80000000,0);
  iVar2 = sub_0800CCCC();
  if ((iVar2 == 0) && (iVar2 = sub_0800CD34(), iVar2 == 0)) {
    sub_0805865C(0x35);
  }
  iStack_24 = uStack_38 << 2;
  iVar2 = 4;
  do {
    iVar3 = sub_0800CC98();
    if (((iVar3 == 0) && (iVar3 = sub_0800CD8C(), iVar3 == 0)) &&
       (iVar3 = sub_0800CCCC(), iVar3 == 0)) {
      sub_08007870((int)sStack_50,(int)sStack_4e,8,uStack_4c,unaff_r8,&uStack_68,uStack_7c,
                   auStack_84[0]);
    }
    sub_080003F0();
    bVar6 = iVar2 != 0;
    iVar2 = iVar2 + -1;
  } while (bVar6);
  sub_08065158(auStack_84,DWORD_08079b9c,0,0x80000000,0);
  sub_08000AF0(0x17,uStack_78,2);
  uStack_68 = 7;
  uStack_67 = 8;
  iVar2 = sub_0800CCCC();
  if ((iVar2 == 0) && (iVar2 = sub_0800CD34(), iVar2 == 0)) {
    sub_0805865C(0x17a);
  }
  iVar2 = 0xb3;
  do {
    if (uStack_2c == uStack_38) {
LAB_08079a78:
      sub_0801FB14(&uStack_48,&dStack_40,10);
      uVar5 = 0;
      iStack_28 = iVar2 + -1;
      do {
        if ((((*(uint *)DWORD_08079ba0 & 1 << (uVar5 & 0xff)) != 0) &&
            (iVar3 = *(int *)DWORD_08079ba4 + uVar5 * 0x2e0, *(char *)(iVar3 + 0x1dc) != '\0')) &&
           (*(dword *)(iVar3 + 0x54) != dStack_30)) {
          uStack_3c = (uStack_3c & DWORD_08079ba8 | (uint)*(byte *)(iVar3 + 0x22e)) & DWORD_08079bb0
                      | (uint)*(byte *)(iVar3 + DWORD_08079bac) << 0x10;
          iVar4 = sub_08021FE0(&uStack_48,iVar3 + 0x14,&dStack_40,&uStack_3c);
          if (iVar4 != 0) {
            sub_0801F1C4(&uStack_48,iVar3,10);
            *(dword *)(iVar3 + 0x54) = dStack_30;
          }
        }
        uVar5 = uVar5 + 1 & 0xffff;
      } while (uVar5 < 5);
    }
    else {
      iVar3 = sub_08002204();
      iStack_28 = iVar2 + -1;
      if ((iVar3 != 0) && (3 < uStack_38)) goto LAB_08079a78;
    }
    iVar3 = sub_080020F4();
    iVar3 = iVar3 * 0x14c + DWORD_08079bb4;
    if (((*(short *)(iVar3 + 0x20) != 0xe) && (*(char *)(iVar3 + 0x68) != '\0')) &&
       ((*(dword *)(iVar3 + 0x108) != dStack_30 &&
        ((*(short *)(iVar3 + 0x20) != 0xb && ((*(uint *)(iVar3 + 0x30) & 0x2000) == 0)))))) {
      iVar4 = sub_0800CCCC();
      if ((iVar4 == 0) &&
         ((iVar4 = sub_0800CDF8(), iVar4 == 0 && (iVar4 = sub_0800D1B0(), iVar4 == 0)))) {
        uStack_3c = 0x100010;
        iVar4 = sub_08021FE0(&uStack_48,iVar3 + 0x8c,&dStack_40,&uStack_3c);
        if (iVar4 != 0) {
          sub_08029CEC(1,10,1);
          *(dword *)(iVar3 + 0x108) = dStack_30;
        }
      }
      else {
        iVar4 = sub_0800CDC0();
        if ((iVar4 != 0) && (*(int *)DWORD_08079cb8 != 0)) {
          uStack_3c = 0x100010;
          iVar4 = sub_08021FE0(&uStack_48,iVar3 + 0x8c,&dStack_40,&uStack_3c);
          if (iVar4 != 0) {
            sub_08029CEC(1,10,1);
            *(dword *)(iVar3 + 0x108) = dStack_30;
          }
        }
      }
    }
    if ((*(uint *)DWORD_08079cbc & 0x1f) == 0) {
      dStack_30 = dStack_30 + 1;
    }
    sub_0800BC08((int)(uStack_48 << 8) >> 0x10,(int)(uStack_44 << 8) >> 0x10,&sStack_50,&sStack_4e,
                 0x30,0);
    uVar1 = sub_0800BC44((int)uStack_48 >> 8,(int)uStack_44 >> 8,0);
    sub_08065370(auStack_84,8,&uStack_4c,&uStack_4a,1);
    iVar3 = sub_0800CC98();
    if (((iVar3 == 0) && (iVar3 = sub_0800CD8C(), iVar3 == 0)) &&
       (iVar3 = sub_0800CCCC(), iVar3 == 0)) {
      sub_08007870((int)sStack_50,(int)sStack_4e,8,uStack_4c,uVar1,&uStack_68,uStack_7c,
                   auStack_84[0]);
    }
    sub_080003F0();
    bVar6 = iVar2 == 0;
    iVar2 = iStack_28;
    if (bVar6) {
      *(uint *)(iStack_24 + DWORD_08079cc0) =
           *(uint *)(iStack_24 + DWORD_08079cc0) & ~(1 << (uStack_34 & 0xff));
      return in_lr;
    }
  } while( true );
}


