
undefined4 sub_08022630(void)

{
  dword dVar1;
  dword dVar2;
  int iVar3;
  int iVar4;
  undefined4 in_lr;
  
  dVar1 = DWORD_08022684;
  iVar3 = sub_08001494(DWORD_08022688);
  *(int *)dVar1 = iVar3;
  *(dword *)(iVar3 + 0x17a0) = DWORD_0802268c;
  iVar3 = sub_08001494(0x800);
  dVar2 = DWORD_08022690;
  iVar4 = *(int *)dVar1;
  *(int *)(iVar4 + DWORD_08022690) = iVar3;
  *(dword *)(iVar4 + (dVar2 - 0x10)) = iVar3 + DWORD_08022694;
  *(undefined4 *)(iVar4 + DWORD_08022698) = 0x46;
  *(undefined4 *)(iVar4 + DWORD_0802269c) = 0;
  *(undefined2 *)(iVar4 + 4) = 0;
  *(undefined4 *)(iVar4 + 0x54) = 0;
  sub_08000274(iVar4 + DWORD_080226a0);
  return in_lr;
}


