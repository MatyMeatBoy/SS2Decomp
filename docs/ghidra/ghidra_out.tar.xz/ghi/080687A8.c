
undefined8 sub_080687A8(int param_1)

{
  dword dVar1;
  undefined1 *puVar2;
  uint uVar3;
  undefined4 in_lr;
  
  dVar1 = DWORD_080687d8;
  uVar3 = *(uint *)DWORD_080687d8;
  if (uVar3 < 0x32) {
    puVar2 = (undefined1 *)(*(int *)DWORD_080687dc + uVar3 * 0x88);
    *(undefined4 *)(puVar2 + 4) = 1;
    *puVar2 = 0x9b;
    *(uint *)(puVar2 + 8) = (uint)*(ushort *)(param_1 + 0xc);
    puVar2[1] = 1;
    *(int *)dVar1 = *(int *)dVar1 + 1;
  }
  return CONCAT44(in_lr,(uint)(uVar3 < 0x32));
}


