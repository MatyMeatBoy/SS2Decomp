
undefined4 sub_0800A03C(void)

{
  ushort uVar1;
  dword dVar2;
  dword dVar3;
  undefined4 uVar4;
  int iVar5;
  ushort *puVar6;
  ushort *puVar7;
  ushort *puVar8;
  uint uVar9;
  int iVar10;
  ushort *puVar11;
  undefined4 in_lr;
  
  dVar2 = DWORD_0800a05c;
  if (*(ushort *)(DWORD_0800a05c + 0x8c) < 0xf) {
                    /* WARNING: Could not recover jumptable at 0x0800a058. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar4 = (**(code **)((uint)*(ushort *)(DWORD_0800a05c + 0x8c) * 4 + DWORD_0800a060))();
    return uVar4;
  }
  if ((*(short *)(DWORD_0800a05c + 0x8c) == 3) || (*(short *)(DWORD_0800a05c + 0x8c) == 6)) {
    iVar10 = 1;
  }
  else {
    iVar10 = 0;
  }
  uVar1 = *(ushort *)(DWORD_0800a05c + 0x8c);
  if (uVar1 == 9) {
    if (*(ushort *)(DWORD_0800a05c + 0x90) < 0x10) {
                    /* WARNING: Could not recover jumptable at 0x0800a162. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar4 = (**(code **)((uint)*(ushort *)(DWORD_0800a05c + 0x90) * 4 + DWORD_0800a164))();
      return uVar4;
    }
  }
  else if (uVar1 < 10) {
    if (uVar1 == 0) {
      if (*(short *)(DWORD_0800a05c + 0x90) == 2) {
        return in_lr;
      }
      if (*(short *)(DWORD_0800a05c + 0x90) == 5) {
        return in_lr;
      }
    }
  }
  else if (uVar1 == 10) {
    if (*(ushort *)(DWORD_0800a05c + 0x90) < 0x14) {
                    /* WARNING: Could not recover jumptable at 0x0800a1ba. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar4 = (**(code **)((uint)*(ushort *)(DWORD_0800a05c + 0x90) * 4 + DWORD_0800a1bc))();
      return uVar4;
    }
  }
  else if (uVar1 == 0xd) {
    return in_lr;
  }
  if ((1 < (ushort)(*(short *)(DWORD_0800a05c + 0x8c) - 7U)) || (iVar5 = sub_0800CDC0(), iVar5 == 0)
     ) {
    dVar3 = DWORD_0800a290;
    uVar9 = 0;
    puVar8 = (ushort *)(dVar2 + 0xa0);
    puVar11 = (ushort *)(iVar10 * 2 + DWORD_0800a294);
    do {
      puVar7 = (ushort *)(uVar9 * 2 + (uint)*(ushort *)(dVar2 + 0x8c) * 0x74 + dVar3);
      if (*puVar7 != 0) {
        puVar6 = (ushort *)(uVar9 * 2 + dVar2 + 0xa8);
        uVar1 = *puVar6;
        *puVar6 = uVar1 + 1;
        if (*puVar7 <= uVar1) {
          *puVar6 = 0;
          uVar1 = *puVar8;
          *puVar8 = uVar1 + 1;
          if (*puVar11 <= (ushort)(uVar1 + 1)) {
            *puVar8 = 0;
          }
        }
      }
      puVar8 = puVar8 + 1;
      uVar9 = uVar9 + 1;
    } while (uVar9 < 4);
  }
  return in_lr;
}


