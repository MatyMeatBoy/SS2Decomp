
void sub_0800CCB8(void)

{
  *(uint *)DWORD_0800ccc8 = *(uint *)DWORD_0800ccc8 & 0xfffffffb;
  return;
}


