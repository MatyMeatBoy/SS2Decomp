
undefined4 sub_08075520(int param_1,uint param_2)

{
  undefined1 uVar1;
  short sVar2;
  ushort uVar3;
  int iVar4;
  ushort *puVar5;
  int iVar6;
  undefined4 in_lr;
  undefined4 auStack_68 [2];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined1 uStack_4c;
  undefined1 uStack_4b;
  short sStack_34;
  short sStack_32;
  undefined2 uStack_30;
  undefined2 uStack_2e;
  int iStack_2c;
  uint uStack_28;
  int iStack_24;
  
  uStack_30 = 0;
  uStack_2e = 0;
  iStack_2c = param_1;
  uStack_28 = param_2;
  sub_08065158(auStack_68,DWORD_080756d4,8,0xffffffff,0);
  uStack_4c = 7;
  uStack_4b = 8;
  iVar6 = iStack_2c * 0x14c + DWORD_080756d8;
  if ((**(byte **)(iVar6 + 0x148) & 0xf) == 10) {
    do {
      sub_080003F0();
    } while ((**(byte **)(iVar6 + 0x148) & 0xf) == 10);
  }
  iStack_24 = iStack_2c << 2;
  do {
    puVar5 = *(ushort **)(iVar6 + 0x148);
    sub_0800BC08(*puVar5 >> 4,puVar5[1] & 0xfff,&sStack_34,&sStack_32,0x30,0);
    puVar5 = *(ushort **)(iVar6 + 0x148);
    uVar1 = sub_0800BC44(*puVar5 >> 4,puVar5[1] & 0xfff,((uint)(byte)puVar5[2] << 0x1a) >> 0x1f);
    sVar2 = sub_08065370(auStack_68,8,&uStack_30,&uStack_2e,0);
    iVar4 = sub_0800CC98();
    if (((iVar4 == 0) && (iVar4 = sub_0800CD8C(), iVar4 == 0)) &&
       (iVar4 = sub_0800CCCC(), iVar4 == 0)) {
      if ((*(uint *)DWORD_080756dc & 1) == 0) {
        sub_08000AF0(0x17,uStack_5c,2);
      }
      sub_08007870((int)sStack_34,sStack_32 + 1,8,uStack_30,uVar1,&uStack_4c,uStack_60,auStack_68[0]
                  );
    }
    sub_080003F0();
  } while (sVar2 == 0);
  iVar4 = sub_080020F4();
  if (iStack_2c == iVar4) {
    *(uint *)(iVar6 + 0x30) = *(uint *)(iVar6 + 0x30) | 0x40000;
  }
  iVar4 = sub_080020F4();
  if (iVar4 != iStack_2c) {
    *(uint *)(iVar6 + 0x30) = *(uint *)(iVar6 + 0x30) | 0x80000;
  }
  uVar3 = 0;
  do {
    uVar3 = uVar3 + 1;
    sub_080003F0();
  } while (uVar3 < 0x3c);
  iVar4 = sub_080020F4();
  if (iStack_2c == iVar4) {
    *(uint *)(iVar6 + 0x30) = *(uint *)(iVar6 + 0x30) & DWORD_080756e0;
  }
  iVar4 = sub_080020F4();
  if (iVar4 != iStack_2c) {
    *(uint *)(iVar6 + 0x30) = *(uint *)(iVar6 + 0x30) & DWORD_080756e4;
  }
  *(uint *)(iStack_24 + DWORD_080756e8) =
       *(uint *)(iStack_24 + DWORD_080756e8) & ~(1 << (uStack_28 & 0xff));
  return in_lr;
}


