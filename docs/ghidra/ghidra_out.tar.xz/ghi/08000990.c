
undefined4 sub_08000990(byte param_1,short param_2)

{
  dword dVar1;
  undefined4 in_lr;
  
  dVar1 = DWORD_080009bc;
  *(byte *)DWORD_080009bc = *(byte *)DWORD_080009bc & 0xf8 | param_1 & 7;
  if (param_2 != 0) {
    Ram04000000 = *(undefined2 *)dVar1;
  }
  return in_lr;
}


