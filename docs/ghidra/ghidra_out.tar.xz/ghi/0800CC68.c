
void sub_0800CC68(void)

{
  *(undefined4 *)DWORD_0800cc7c = 0;
  *(uint *)DWORD_0800cc80 = *(uint *)DWORD_0800cc80 & DWORD_0800cc84;
  return;
}


