
undefined8
sub_080076C4(int param_1,int param_2,uint param_3,uint param_4,byte param_5,int param_6,int param_7)

{
  byte bVar1;
  byte bVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  undefined4 *puVar9;
  char *pcVar10;
  uint uVar11;
  uint uVar12;
  undefined4 in_lr;
  
  if ((*(uint *)DWORD_080076fc < 0x81) && ((param_3 & 0xffff) <= (uint)*(ushort *)(param_7 + 2))) {
    iVar3 = *(int *)DWORD_080077f0;
    iVar5 = param_7 + *(int *)(param_7 + 8) + (param_3 & 0xffff) * 0xc;
    iVar5 = *(int *)(param_7 + 4) + param_7 +
            (uint)*(ushort *)(iVar5 + *(int *)(iVar5 + 8) + (param_4 & 0xffff) * 4) * 0xc;
    pcVar10 = (char *)(iVar5 + *(int *)(iVar5 + 8));
    puVar9 = (undefined4 *)(*(uint *)DWORD_080076fc * 8 + DWORD_080077f4);
    uVar11 = 0;
    uVar12 = 0;
    if (*(short *)(iVar5 + 2) != 0) {
      do {
        uVar6 = *(undefined4 *)(pcVar10 + 4);
        *puVar9 = *(undefined4 *)pcVar10;
        puVar9[1] = uVar6;
        iVar8 = *pcVar10 + param_2;
        iVar7 = ((int)((uint)*(ushort *)(pcVar10 + 2) << 0x17) >> 0x17) + param_1;
        bVar2 = (param_5 & 3) << 2;
        bVar1 = *(byte *)((int)puVar9 + 5);
        *(byte *)((int)puVar9 + 5) = bVar1 & 0xf3 | bVar2;
        *(byte *)((int)puVar9 + 5) =
             bVar1 & 3 | bVar2 | *(char *)(param_6 + (uint)(bVar1 >> 4)) << 4;
        if (((0x130 < iVar7 + 0x40U) || (0xa0 < iVar8)) || (iVar8 < -0x40)) {
          *(byte *)((int)puVar9 + 3) = *(byte *)((int)puVar9 + 3) & 0x3f;
          *(byte *)((int)puVar9 + 1) = *(byte *)((int)puVar9 + 1) & 0x3f;
          iVar8 = 0xa0;
        }
        *(ushort *)((int)puVar9 + 2) =
             (ushort)DWORD_080077fc & *(ushort *)((int)puVar9 + 2) |
             (ushort)iVar7 & (ushort)DWORD_080077f8;
        *(char *)puVar9 = (char)iVar8;
        *(ushort *)(puVar9 + 1) =
             (ushort)DWORD_08007804 & *(ushort *)(puVar9 + 1) |
             (short)uVar11 + (short)iVar3 & (ushort)DWORD_08007800;
        if ((byte)pcVar10[1] >> 6 == 0) {
          piVar4 = (int *)((uint)((byte)pcVar10[3] >> 6) * 4 + DWORD_08007860);
        }
        else {
          piVar4 = (int *)((uint)((byte)pcVar10[3] >> 6) * 4 + DWORD_08007808);
        }
        uVar11 = *piVar4 + uVar11 & 0xffff;
        iVar7 = *(int *)DWORD_08007864;
        *(uint *)DWORD_08007864 = iVar7 + 1U;
        if (0x80 < iVar7 + 1U) {
          iVar3 = 0;
          goto LAB_08007850;
        }
        uVar12 = uVar12 + 1;
        puVar9 = puVar9 + 2;
        pcVar10 = pcVar10 + 8;
      } while (uVar12 < *(ushort *)(iVar5 + 2));
    }
    *(uint *)DWORD_08007868 = *(int *)DWORD_08007868 + uVar11;
    iVar3 = *(int *)DWORD_0800786c + iVar3 * 0x20;
  }
  else {
    iVar3 = -1;
  }
LAB_08007850:
  return CONCAT44(in_lr,iVar3);
}


