
undefined4 sub_08056CB4(int param_1)

{
  int iVar1;
  dword dVar2;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  if (iVar1 == 0) {
    iVar1 = sub_0800CE30();
    if (iVar1 == 0) {
      iVar1 = *(int *)DWORD_08056d04;
      dVar2 = DWORD_08056d08;
    }
    else {
      iVar1 = *(int *)DWORD_08056cd0;
      dVar2 = DWORD_08056cd4;
    }
    if (*(byte *)(iVar1 + dVar2) < 8) {
      sub_08068070(DWORD_08056d0c,param_1 + 8);
      iVar1 = sub_0800CE30();
      if (iVar1 == 0) {
        iVar1 = *(int *)DWORD_08056d24;
        dVar2 = DWORD_08056d28;
      }
      else {
        iVar1 = *(int *)DWORD_08056d04;
        dVar2 = DWORD_08056d10;
      }
      *(char *)(iVar1 + dVar2) = (char)(param_1 + 8);
    }
  }
  return in_lr;
}


