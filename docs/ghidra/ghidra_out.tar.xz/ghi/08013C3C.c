
undefined4 sub_08013C3C(int param_1)

{
  ushort uVar1;
  ushort *puVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  iVar3 = *(int *)DWORD_08013cb0;
  uVar4 = 0;
  do {
    if (((*(uint *)DWORD_08013cb4 & 1) == (uVar4 & 1)) &&
       ((*(uint *)DWORD_08013cb8 & 1 << (uVar4 & 0xff)) != 0)) {
      uVar1 = ArcTan2((*(int *)(iVar3 + 0x14) - *(int *)(param_1 + 0x8c)) * 0x100 >> 0x10,
                      (*(int *)(iVar3 + 0x18) - *(int *)(param_1 + 0x90)) * 0x100 >> 0x10);
      if ((uVar1 & 0xfff) < 0x801) {
        uVar1 = uVar1 >> 0xc;
      }
      else {
        uVar1 = (uVar1 >> 0xc) + 1;
      }
      *(ushort *)(param_1 + 0x126 + uVar4 * 2) = uVar1;
      puVar2 = (ushort *)(param_1 + 0x126 + uVar4 * 2);
      *puVar2 = *puVar2 & 0xf;
    }
    uVar4 = uVar4 + 1 & 0xffff;
    iVar3 = iVar3 + 0x2e0;
  } while (uVar4 < 5);
  return in_lr;
}


