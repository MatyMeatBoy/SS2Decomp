
void sub_08059954(uint param_1)

{
  *(uint *)(*(int *)DWORD_08059964 + 0x38) =
       *(uint *)(*(int *)DWORD_08059964 + 0x38) | 1 << (param_1 & 0xff);
  return;
}


