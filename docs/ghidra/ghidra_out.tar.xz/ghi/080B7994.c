
undefined4 FadeOutBody(int param_1)

{
  dword dVar1;
  short sVar2;
  uint uVar3;
  undefined1 *puVar4;
  byte *pbVar5;
  undefined4 in_lr;
  
  if ((*(short *)(param_1 + 0x24) != 0) &&
     (sVar2 = *(short *)(param_1 + 0x26) + -1, *(short *)(param_1 + 0x26) = sVar2,
     dVar1 = DWORD_080b79dc, sVar2 == 0)) {
    uVar3 = *(ushort *)(param_1 + 0x28) - 0x10;
    *(short *)(param_1 + 0x28) = (short)uVar3;
    if ((int)((uVar3 & dVar1) * 0x10000) < 1) {
      uVar3 = (uint)*(byte *)(param_1 + 8);
      puVar4 = *(undefined1 **)(param_1 + 0x2c);
      if (uVar3 != 0) {
        do {
          TrackStop(param_1,puVar4);
          *puVar4 = 0;
          uVar3 = uVar3 - 1;
          puVar4 = puVar4 + 0x50;
        } while (0 < (int)uVar3);
      }
    }
    else {
      *(short *)(param_1 + 0x26) = *(short *)(param_1 + 0x24);
      uVar3 = (uint)*(byte *)(param_1 + 8);
      pbVar5 = *(byte **)(param_1 + 0x2c);
      if (uVar3 != 0) {
        do {
          if ((*pbVar5 & 0x80) != 0) {
            pbVar5[0x13] = (byte)(*(ushort *)(param_1 + 0x28) >> 2);
            *pbVar5 = *pbVar5 | 3;
          }
          uVar3 = uVar3 - 1;
          pbVar5 = pbVar5 + 0x50;
        } while (0 < (int)uVar3);
      }
    }
  }
  return in_lr;
}


