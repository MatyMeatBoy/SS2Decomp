
undefined4 sub_08067AF0(void)

{
  return 1;
}


