
undefined8 sub_08089384(int param_1)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  ushort *puVar5;
  undefined4 in_lr;
  
  if (*(short *)(*(int *)DWORD_08089394 + 0x10) == 0) {
    while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
      sub_080003F0();
    }
    iVar2 = sub_080020F4();
    puVar5 = (ushort *)(param_1 + (uint)*(ushort *)(*(int *)DWORD_0808941c + 0x36) * 0x24 + 4);
    sub_0800CCDC();
    iVar3 = sub_080020F4();
    dVar1 = DWORD_08089420;
    iVar3 = iVar3 * 0x14c;
    *(uint *)(iVar3 + DWORD_08089420 + 0x8c) = (uint)*puVar5 << 8;
    *(uint *)(iVar3 + dVar1 + 0x90) = (uint)puVar5[1] << 8;
    iVar3 = iVar3 + dVar1;
    *(undefined4 *)(iVar3 + 0x94) = *(undefined4 *)(iVar3 + 0x8c);
    *(undefined4 *)(iVar3 + 0x98) = *(undefined4 *)(iVar3 + 0x90);
    iVar3 = iVar2 * 0x14c + dVar1;
    *(undefined4 *)(iVar3 + 0x94) = *(undefined4 *)(iVar3 + 0x8c);
    *(undefined4 *)(iVar3 + 0x98) = *(undefined4 *)(iVar3 + 0x90);
    iVar3 = sub_08057B98(10);
    if (iVar3 == 0) {
      sub_08009930(0,3);
    }
    else {
      sub_08009930(0,0x14);
    }
    while (iVar3 = sub_0800BA6C(), iVar3 == 0) {
      sub_080003F0();
    }
    iVar2 = iVar2 * 0x14c + DWORD_08089474;
    uVar4 = sub_0800CCCC();
    sub_0800AD04(iVar2,iVar2 + 4,uVar4);
    sub_08057328(0,DWORD_08089478);
    sub_08015EF8();
    sub_08015C38();
    iVar2 = *(int *)DWORD_0808947c;
    *(undefined2 *)(iVar2 + 0x10) = 1;
    *(undefined2 *)(iVar2 + 0x1c) = 1;
  }
  else {
    iVar2 = sub_08088B6C(param_1,3);
    if (iVar2 != 0) {
      uVar4 = 1;
      goto LAB_080894fa;
    }
    iVar2 = sub_080020F4();
    if (0x37 < *(int *)(iVar2 * 0x14c + DWORD_080894b8 + 0x90) >> 0xb) {
      sub_08015ED4();
      sub_0801ABE8(3);
      sub_0800BB40();
      while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
        sub_080003F0();
      }
      sub_0800BB40();
      iVar2 = *(int *)DWORD_080894ec;
      *(undefined2 *)(iVar2 + 0x36) = 3;
      *(undefined2 *)(iVar2 + 2) = 0;
      *(undefined4 *)(iVar2 + DWORD_080894f0) = *(undefined4 *)DWORD_080894f4;
      *(undefined2 *)(iVar2 + 0x10) = 0;
      *(undefined2 *)(iVar2 + 0x1c) = 0;
      uVar4 = 1;
      goto LAB_080894fa;
    }
  }
  uVar4 = 0;
LAB_080894fa:
  return CONCAT44(in_lr,uVar4);
}


