
undefined4 sub_0808D0C4(void)

{
  int iVar1;
  uint uVar2;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_0808d110;
  uVar2 = *(uint *)(iVar1 + 0x30);
  while ((uVar2 & 0x4000) == 0) {
    sub_08057624(1);
    uVar2 = *(uint *)(iVar1 + 0x30);
  }
  sub_08057DD0(0x78,0x14a,0x78,0x50,DWORD_0808d114,0);
  return in_lr;
}


