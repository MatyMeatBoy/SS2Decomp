
undefined4 sub_0800B650(uint param_1,int param_2,int param_3,undefined2 param_4,uint param_5)

{
  uint *puVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 in_lr;
  uint *puStack_28;
  uint uStack_24;
  
  uStack_24 = param_5 & 0xffff;
  puVar1 = (uint *)sub_08007290(param_1);
  iVar2 = sub_08007290(*puVar1);
  uVar3 = sub_08007290((ushort)*puVar1 | 0x70000);
  puStack_28 = (uint *)(param_1 & 0x40000000);
  if (puStack_28 == (uint *)0x0) {
    puStack_28 = (uint *)sub_08000BC8(puVar1 + 1,&puStack_28);
  }
  else {
    puStack_28 = puVar1 + 1;
  }
  if ((*(byte *)DWORD_0800b6f4 & 0x80) == 0) {
    if ((*puVar1 & 0x10000000) == 0) {
      uVar4 = 0;
      do {
        sub_08001348(iVar2 + uVar4 * 0x800,param_3 + uVar4 * 0x800,0x800);
        sub_080003F0();
        uVar4 = uVar4 + 1 & 0xffff;
      } while (uVar4 < 0x10);
    }
    else if ((*puVar1 & 0x20000000) == 0) {
      uVar4 = 0;
      do {
        sub_08001348(iVar2 + uVar4 * 0x400,param_3 + uVar4 * 0x400,0x400);
        sub_080003F0();
        uVar4 = uVar4 + 1 & 0xffff;
      } while (uVar4 < 0x10);
    }
    else {
      uVar4 = 0;
      do {
        sub_08001348(iVar2 + uVar4 * 0x400,param_3 + uVar4 * 0x400 + 0x4000,0x400);
        sub_080003F0();
        uVar4 = uVar4 + 1 & 0xffff;
      } while (uVar4 < 0x10);
    }
    sub_08001348(puStack_28,param_2 * 0x800 + 0x6000000,0x800);
    sub_080003F0();
  }
  else {
    if ((*puVar1 & 0x10000000) == 0) {
      CpuFastSet(iVar2,param_3,0x2000);
    }
    else if ((*puVar1 & 0x20000000) == 0) {
      CpuFastSet(iVar2,param_3,0x1000);
    }
    else {
      CpuFastSet(iVar2,param_3 + 0x4000,0x1000);
    }
    CpuFastSet(puStack_28,param_2 * 0x800 + 0x6000000,0x200);
  }
  if ((param_1 & 0x40000000) == 0) {
    sub_08001538(puStack_28);
  }
  sub_08000AF0(param_4,uVar3,uStack_24);
  *(undefined2 *)DWORD_0800b7d8 = 0;
  return in_lr;
}


