
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_0807BEA0(undefined4 param_1,uint param_2,undefined4 *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 in_lr;
  undefined4 *puVar6;
  
  piVar2 = _UNK_0807bfcc;
  piVar1 = _UNK_0807bf44;
  switch(param_1) {
  case 0:
    iVar3 = *_UNK_0807bf18 + param_2 * 0x10;
    uVar4 = param_3[1];
    uVar5 = param_3[2];
    *(undefined4 *)(iVar3 + 0x150) = *param_3;
    *(undefined4 *)(iVar3 + 0x154) = uVar4;
    *(undefined4 *)(iVar3 + 0x158) = uVar5;
    puVar6 = (undefined4 *)(iVar3 + 0x15c);
    goto code_r0x0807c004;
  case 1:
    iVar3 = *_UNK_0807bf44 + param_2 * 0x10;
    uVar4 = param_3[1];
    uVar5 = param_3[2];
    *(undefined4 *)(iVar3 + 0x70) = *param_3;
    *(undefined4 *)(iVar3 + 0x74) = uVar4;
    *(undefined4 *)(iVar3 + 0x78) = uVar5;
    *(undefined4 *)(iVar3 + 0x7c) = param_3[3];
    if (param_2 == *(ushort *)(*piVar1 + 0x68)) {
      sub_0805AD78(param_2);
    }
    break;
  case 2:
    iVar3 = *_UNK_0807bf64;
    uVar4 = param_3[1];
    uVar5 = param_3[2];
    *(undefined4 *)(iVar3 + 0x100) = *param_3;
    *(undefined4 *)(iVar3 + 0x104) = uVar4;
    *(undefined4 *)(iVar3 + 0x108) = uVar5;
    *(undefined4 *)(iVar3 + 0x10c) = param_3[3];
    sub_0805D094();
    break;
  case 3:
    iVar3 = *_UNK_0807bf84;
    uVar4 = param_3[1];
    uVar5 = param_3[2];
    *(undefined4 *)(iVar3 + 0x120) = *param_3;
    *(undefined4 *)(iVar3 + 0x124) = uVar4;
    *(undefined4 *)(iVar3 + 0x128) = uVar5;
    *(undefined4 *)(iVar3 + 300) = param_3[3];
    sub_0805D13C();
    break;
  case 4:
    iVar3 = *_UNK_0807bfa4;
    uVar4 = param_3[1];
    uVar5 = param_3[2];
    *(undefined4 *)(iVar3 + 0x110) = *param_3;
    *(undefined4 *)(iVar3 + 0x114) = uVar4;
    *(undefined4 *)(iVar3 + 0x118) = uVar5;
    *(undefined4 *)(iVar3 + 0x11c) = param_3[3];
    sub_0805D0E8();
    break;
  case 5:
    iVar3 = *_UNK_0807bfcc;
    uVar4 = param_3[1];
    uVar5 = param_3[2];
    *(undefined4 *)(iVar3 + 0x130) = *param_3;
    *(undefined4 *)(iVar3 + 0x134) = uVar4;
    *(undefined4 *)(iVar3 + 0x138) = uVar5;
    *(undefined4 *)(iVar3 + 0x13c) = param_3[3];
    *(undefined2 *)(*piVar2 + 0x136) = 0;
    sub_0805D190();
    break;
  case 6:
    iVar3 = *_UNK_0807bfec;
    uVar4 = param_3[1];
    uVar5 = param_3[2];
    *(undefined4 *)(iVar3 + 0x140) = *param_3;
    *(undefined4 *)(iVar3 + 0x144) = uVar4;
    *(undefined4 *)(iVar3 + 0x148) = uVar5;
    *(undefined4 *)(iVar3 + 0x14c) = param_3[3];
    sub_0805D1E0();
    break;
  case 0xd:
  case 0x10:
    iVar3 = *_UNK_0807c010 + param_2 * 0x10;
    uVar4 = param_3[1];
    uVar5 = param_3[2];
    *(undefined4 *)(iVar3 + 0x104) = *param_3;
    *(undefined4 *)(iVar3 + 0x108) = uVar4;
    *(undefined4 *)(iVar3 + 0x10c) = uVar5;
    puVar6 = (undefined4 *)(iVar3 + 0x110);
code_r0x0807c004:
    *puVar6 = param_3[3];
  }
  return in_lr;
}


