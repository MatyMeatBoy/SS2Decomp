
uint sub_0800D154(void)

{
  return *(uint *)DWORD_0800d160 >> 0x14 & 1;
}


