
undefined4 sub_08006C70(uint param_1)

{
  undefined4 in_lr;
  
  if (((param_1 & 0xffff) <= DWORD_08006c90) && (*(int *)DWORD_08006c94 != 0)) {
    m4aSongNumStart(param_1 & 0xffff);
  }
  return in_lr;
}


