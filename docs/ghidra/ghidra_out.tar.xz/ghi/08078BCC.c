
/* WARNING: Removing unreachable block (ram,0x08078e34) */
/* WARNING: Removing unreachable block (ram,0x08078e6a) */
/* WARNING: Removing unreachable block (ram,0x08078e6c) */
/* WARNING: Removing unreachable block (ram,0x08078e7a) */

undefined4 sub_08078BCC(uint param_1,uint param_2)

{
  bool bVar1;
  short *psVar2;
  ushort uVar3;
  short sVar4;
  undefined4 uVar5;
  ushort *puVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  ushort *puVar10;
  short *psVar11;
  int *piVar12;
  int iVar13;
  int iVar14;
  dword dVar15;
  undefined2 *puVar16;
  short *psVar17;
  uint uVar18;
  uint uVar19;
  undefined4 in_lr;
  int aiStack_108 [4];
  undefined1 auStack_f8 [12];
  undefined4 uStack_ec;
  undefined1 uStack_dc;
  undefined1 uStack_db;
  short asStack_c4 [2];
  short asStack_c0 [2];
  ushort auStack_bc [6];
  int iStack_b0;
  undefined4 uStack_ac;
  dword dStack_a8;
  dword dStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  uint uStack_98;
  uint uStack_94;
  ushort *puStack_90;
  int iStack_8c;
  int iStack_88;
  int iStack_84;
  int iStack_80;
  int iStack_7c;
  int iStack_78;
  uint uStack_74;
  uint uStack_70;
  int iStack_6c;
  uint uStack_68;
  uint uStack_64;
  int iStack_60;
  int iStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  int iStack_4c;
  undefined1 *puStack_48;
  int iStack_44;
  uint uStack_40;
  short *psStack_3c;
  short *psStack_38;
  ushort *puStack_34;
  ushort *puStack_30;
  int *piStack_2c;
  ushort *puStack_28;
  short *psStack_24;
  
  uStack_98 = param_1;
  uStack_94 = param_2;
  uStack_58 = sub_080020F4();
  sub_08065158(auStack_f8,DWORD_08078d94,8,0xffffffff,0);
  dVar15 = DWORD_08078d98;
  uStack_dc = 7;
  uStack_db = 8;
  uVar18 = 0;
  puStack_34 = auStack_bc;
  puStack_30 = auStack_bc + 2;
  piStack_2c = &iStack_b0;
  puVar10 = puStack_34;
  puVar6 = puStack_30;
  do {
    *puVar6 = 0;
    *puVar10 = 0;
    puVar6 = puVar6 + 1;
    puVar10 = puVar10 + 1;
    uVar18 = uVar18 + 1;
  } while (uVar18 < 2);
  puStack_90 = (ushort *)(uStack_98 * 0x14c + DWORD_08078d98);
  uVar18 = sub_08002164();
  uStack_70 = 0;
  iStack_8c = 0;
  iStack_88 = 0;
  iStack_b0 = 0;
  piStack_2c[1] = 0;
  iStack_7c = 0;
  iStack_78 = 0;
  dStack_a8 = DWORD_08078d9c;
  uStack_54 = uStack_98 * 0x3e80000 >> 0x10;
  uStack_50 = 0;
  iStack_60 = 0;
  iStack_4c = 1;
  iVar13 = 0;
  uVar19 = 0;
  iStack_44 = uStack_98 << 2;
  if (uVar18 != 0) {
    puVar10 = puStack_90 + 0x34;
    piVar12 = aiStack_108;
    do {
      iVar9 = uVar19 * 0x14c + dVar15;
      if ((char)*puVar10 == *(char *)(iVar9 + 0x68)) {
        *piVar12 = iVar9;
        puVar6 = *(ushort **)(iVar9 + 0x148);
        if ((((byte)*puVar6 & 0xf) < 2) &&
           ((int)((uint)*(byte *)((int)puVar6 + 5) * 0x20000000) < 0)) {
          iVar13 = iVar13 + 1;
          iStack_8c = iStack_8c + (uint)(*puVar6 >> 4) * 0x100;
          iStack_88 = iStack_88 + (((uint)puVar6[1] << 0x14) >> 0xc);
          iStack_60 = iStack_60 + ((uint)(*(int *)(puVar6 + 2) << 0xd) >> 0x18);
        }
        piVar12 = piVar12 + 1;
        uStack_70 = uStack_70 + 1;
      }
      uVar19 = uVar19 + 1;
    } while (uVar19 < uVar18);
  }
  iStack_8c = __udivsi3(iStack_8c,iVar13);
  uStack_ac = __udivsi3(iStack_88,iVar13);
  iStack_b0 = iStack_8c;
  iStack_6c = 0;
  uStack_68 = 0;
  iStack_5c = 0;
  iStack_88 = uStack_ac;
  sub_0805865C(0x28);
  puStack_28 = puStack_90 + 0x34;
  while( true ) {
    iStack_8c = 0;
    iStack_88 = 0;
    uVar18 = 0;
    uVar19 = 0;
    if ((uStack_70 != 0) && ((*(byte *)(*(int *)(aiStack_108[0] + 0x148) + 4) & 0x20) == 0)) {
      piVar12 = aiStack_108;
      do {
        puVar10 = *(ushort **)(*piVar12 + 0x148);
        if (((byte)*puVar10 & 0xf) < 2) {
          if (((*(uint *)(*piVar12 + 0x30) & 0x2000) == 0) &&
             ((int)((uint)*(byte *)((int)puVar10 + 5) * 0x20000000) < 0)) {
            uVar18 = uVar18 + 1;
            iStack_8c = iStack_8c + (uint)(*puVar10 >> 4) * 0x100;
            iStack_88 = iStack_88 + (((uint)puVar10[1] << 0x14) >> 0xc);
          }
        }
        else {
          uVar18 = 0;
        }
        piVar12 = piVar12 + 1;
        uVar19 = uVar19 + 1;
      } while ((uVar19 < uStack_70) && ((*(byte *)(*(int *)(*piVar12 + 0x148) + 4) & 0x20) == 0));
    }
    if ((uVar18 != uStack_70) ||
       ((iVar13 = sub_0800CCCC(), iVar13 != 0 || (iVar13 = sub_08056E90(), iVar13 != 0)))) break;
    iStack_8c = __udivsi3(iStack_8c,uStack_70);
    iStack_88 = __udivsi3(iStack_88,uStack_70);
    iStack_84 = iStack_8c - iStack_b0;
    iStack_80 = iStack_88 - piStack_2c[1];
    iVar13 = ArcTan2((int)(short)iStack_84,(int)(short)iStack_80);
    uStack_74 = (uint)(iVar13 << 0x10) >> 0x18;
    psStack_3c = asStack_c4;
    psStack_38 = asStack_c0;
    iVar13 = Sqrt(iStack_84 * iStack_84 + iStack_80 * iStack_80);
    if (iVar13 * 0x10000 - DWORD_08078ea0 == 0 || iVar13 * 0x10000 < (int)DWORD_08078ea0) {
      iStack_6c = iStack_6c + -0x10;
      if (iStack_6c < 0) {
        iStack_6c = 0;
      }
    }
    else {
      iStack_6c = iStack_6c + 0x10;
    }
    if (0x800 < iStack_6c) {
      iStack_6c = 0x800;
    }
    iStack_84 = iStack_6c * *(short *)((uStack_74 + 0x40) * 2 + DWORD_08078f38) >> 8;
    iStack_80 = iStack_6c * *(short *)(uStack_74 * 2 + DWORD_08078f38) >> 8;
    iVar13 = __divsi3(iStack_84 - iStack_7c,0x20);
    iStack_7c = iStack_7c + iVar13;
    iVar13 = __divsi3(iStack_80 - iStack_78,0x20);
    iStack_78 = iStack_78 + iVar13;
    iStack_b0 = iStack_b0 + iStack_7c;
    piStack_2c[1] = piStack_2c[1] + iStack_78;
    uStack_74 = (int)uStack_74 >> 4;
    if (uStack_74 < 2) {
      if (iStack_4c != 0) {
        sub_0805865C(DWORD_08078f3c);
        iStack_4c = 0;
      }
    }
    else {
      iStack_4c = 1;
    }
    iVar13 = sub_0800CC98();
    uStack_40 = uStack_50 + 1;
    if (((iVar13 == 0) && (iVar13 = sub_0800CCCC(), iVar13 == 0)) &&
       (iVar13 = sub_0800CD8C(), iVar13 == 0)) {
      uVar18 = 0;
      puStack_48 = auStack_f8;
      puVar10 = puStack_34;
      puVar6 = puStack_30;
      psVar11 = psStack_3c;
      psVar17 = psStack_38;
      do {
        sub_08065370(puStack_48,0,puVar10,puVar6,1);
        sub_0800BC08((int)*psVar11,(int)*psVar17,auStack_bc + 4,auStack_bc + 5,0x30,0);
        sub_08065230(puStack_48,(int)(short)auStack_bc[4],(int)(short)auStack_bc[5],0,*puVar10);
        psVar17 = psVar17 + 1;
        psVar11 = psVar11 + 1;
        puVar6 = puVar6 + 1;
        puVar10 = puVar10 + 1;
        uVar18 = uVar18 + 1;
      } while (uVar18 < 2);
      if ((*(uint *)DWORD_08079020 & 1) == 0) {
        sub_08000AF0(0x17,uStack_ec,2);
      }
    }
    *psStack_3c = (short)((uint)iStack_b0 >> 8);
    *psStack_38 = (short)((uint)piStack_2c[1] >> 8);
    puVar10 = puStack_34;
    if (uStack_68 == 0) {
      *puStack_34 = 0;
      psVar2 = psStack_38;
      uVar18 = 1;
      psStack_24 = psStack_3c;
      psVar11 = psStack_3c;
      psVar17 = psStack_38;
      do {
        puVar10 = puVar10 + 1;
        psVar17 = psVar17 + 1;
        psVar11 = psVar11 + 1;
        *psVar11 = *psStack_24;
        *psVar17 = *psVar2;
        uVar3 = sub_080008C8();
        *puVar10 = uVar3 & 3;
        uVar18 = uVar18 + 1;
      } while (uVar18 < 2);
      uStack_68 = 1;
      dVar15 = DWORD_0807938c;
    }
    else {
      iVar13 = 1;
      psVar11 = psStack_3c;
      psVar17 = psStack_38;
      do {
        psVar11[1] = *psVar11;
        psVar17[1] = *psVar17;
        psVar17 = psVar17 + -1;
        psVar11 = psVar11 + -1;
        iVar13 = iVar13 + -1;
        dVar15 = DWORD_08079024;
      } while (iVar13 != 0);
    }
    iVar13 = uStack_58 * 0x14c + dVar15;
    if ((*(char *)(iVar13 + 0x68) == (char)*puStack_28) &&
       (uStack_64 = uStack_64 + 1, 0x3c < uStack_64)) {
      iStack_5c = iStack_5c + 1;
      uStack_64 = 0;
      psVar11 = (short *)(iVar13 + 0xc2);
      *psVar11 = *psVar11 + (short)iStack_5c * -10;
      if (((int)*psVar11 & 0x8000U) != 0) {
        *psVar11 = 0;
        *(undefined2 *)(iVar13 + 0x134) = 0;
      }
    }
    if (uStack_98 == uStack_58) {
LAB_08079194:
      uVar5 = __udivsi3(uStack_70 * 10 + iStack_60,5);
      sub_0801FB14(piStack_2c,&dStack_a8,uVar5);
      uVar19 = 0;
      iVar13 = 0;
      uVar18 = uStack_98 & 0xff;
      do {
        if ((*(uint *)DWORD_08079398 & 1 << (uVar19 & 0xff)) != 0) {
          puVar16 = (undefined2 *)(*(int *)DWORD_0807939c + iVar13);
          if ((*(char *)(puVar16 + 0xee) != (char)*puStack_28) &&
             (*(char *)(puVar16 + 0xee) != '\0')) {
            dStack_a4 = (dword)CONCAT12(*(undefined1 *)((int)puVar16 + 0x22f),
                                        (ushort)*(byte *)((int)puVar16 + DWORD_080793a0));
            iVar9 = sub_08021FE0(piStack_2c,puVar16 + 10,&dStack_a8,&dStack_a4);
            if (iVar9 != 0) {
              uStack_68 = 0;
              if ((puVar16[6] != 0xb) && (*(uint *)(puVar16 + 0x2a) != uStack_54)) {
                if (((int)(short)puVar16[0x2e] - (uint)(ushort)puVar16[0x25] & 0x8000) == 0) {
                  uVar7 = (int)(short)puVar16[0x2e] ^ (uint)(ushort)puVar16[0x25];
                  uStack_68 = (-uVar7 | uVar7) >> 0x1f;
                }
              }
              if (uStack_68 != 0) {
                puVar16[6] = 10;
                uVar5 = sub_080008C8();
                iVar14 = iStack_5c + iStack_60 + 10;
                iVar9 = __umodsi3(uVar5,0x32);
                uVar7 = __udivsi3(iVar14 * (iVar9 + 100),100);
                uVar8 = uStack_9c & DWORD_080793a4;
                uStack_9c = uVar8 | uVar7 & 0xffff;
                uStack_a0 = (uStack_a0 & DWORD_080793a8 | (uint)*(byte *)(puVar16 + 1)) &
                            DWORD_080793ac & DWORD_080793b0 & DWORD_080793b4;
                *(uint *)(puVar16 + 0x2a) = uStack_54;
                puVar16[0x25] = (short)uStack_9c + puVar16[0x25];
                *(uint *)(puVar16 + 0x26) = uVar8 & 0xffff | uVar7 & 0xffff;
                puVar16[0x31] = (ushort)(uStack_a0 >> 8) & 0xff;
                puVar16[0x3e] = (ushort)(uStack_a0 >> 0x10) & 0xff;
                puVar16[0x3f] = (short)(char)(uStack_a0 >> 0x18);
                puVar16[0x2c] = *puVar16;
                puVar16[0x2d] = (ushort)(1 << uVar18) | puVar16[0x2d];
                sub_080660EC(&uStack_a0);
                sub_0805865C(DWORD_08079394);
              }
            }
          }
        }
        iVar13 = iVar13 + 0x2e0;
        uVar19 = uVar19 + 1;
      } while (uVar19 < 5);
    }
    else {
      iVar13 = uStack_58 * 0x14c + dVar15;
      dStack_a4 = DWORD_08079390;
      if (((*(char *)(iVar13 + 0x68) != (char)*puStack_28) && (*(char *)(iVar13 + 0x68) != '\0')) &&
         (iVar9 = sub_08021FE0(piStack_2c,iVar13 + 0x8c,&dStack_a8,&dStack_a4), iVar9 != 0)) {
        uStack_68 = 0;
        if ((*(short *)(iVar13 + 0x20) != 0xb) &&
           (*(uint *)(iVar13 + 0xf8 + (uint)*puStack_90 * 4) != uStack_54)) {
          if (((int)*(short *)(iVar13 + 0xc4) - (uint)*(ushort *)(iVar13 + 0x88) & 0x8000) == 0) {
            uVar18 = (int)*(short *)(iVar13 + 0xc4) ^ (uint)*(ushort *)(iVar13 + 0x88);
            uStack_68 = (-uVar18 | uVar18) >> 0x1f;
          }
        }
        if (uStack_68 != 0) {
          uVar5 = sub_080008C8();
          iVar14 = iStack_5c + iStack_60 + 10;
          iVar9 = __umodsi3(uVar5,0x32);
          sVar4 = __udivsi3(iVar14 * (iVar9 + 100),100);
          *(short *)(iVar13 + 0x88) = *(short *)(iVar13 + 0x88) + sVar4;
          *(uint *)(iVar13 + 0xf8 + (uint)*puStack_90 * 4) = uStack_54;
          *(undefined2 *)(iVar13 + 0x20) = 10;
          sub_0805865C(DWORD_08079394);
        }
      }
      if (uStack_98 == uStack_58) goto LAB_08079194;
    }
    bVar1 = 0x3c < uStack_50;
    uStack_50 = uStack_40 & 0xffff;
    if (bVar1) {
      uStack_50 = 0;
      uStack_54 = uStack_54 + 1 & 0xffff;
    }
    sub_080003F0();
    iVar13 = sub_0800CB78();
    if (((iVar13 != 0) || (iVar13 = sub_0800CD00(), iVar13 != 0)) ||
       (iVar13 = sub_0800CD8C(), iVar13 != 0)) break;
  }
  iVar13 = uStack_58 * 0x14c + DWORD_0807938c;
  if (*(char *)(iVar13 + 0x68) == (char)*puStack_28) {
    sub_0800CFDC();
    *(undefined2 *)(iVar13 + 0x134) = 0;
  }
  sub_0805867C(DWORD_08079394);
  *(uint *)(iStack_44 + DWORD_080793b8) =
       *(uint *)(iStack_44 + DWORD_080793b8) & ~(1 << (uStack_94 & 0xff));
  return in_lr;
}


