
void sub_080572E4(void)

{
  *(ushort *)(*(int *)DWORD_080572f8 + 4) = *(ushort *)(*(int *)DWORD_080572f8 + 4) | 0x100;
  return;
}


