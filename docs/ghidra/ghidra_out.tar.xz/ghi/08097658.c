
undefined8
sub_08097658(int param_1,int param_2,undefined4 *param_3,undefined4 *param_4,uint param_5,
            uint param_6,uint param_7)

{
  char cVar1;
  undefined1 uVar2;
  ushort uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  ushort uVar8;
  ushort *puVar9;
  int *piVar10;
  undefined4 in_lr;
  undefined2 uStack_b4;
  undefined2 uStack_94;
  short sStack_74;
  short sStack_72;
  undefined4 *puStack_70;
  undefined4 *puStack_6c;
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  int iStack_54;
  short *psStack_50;
  undefined2 *puStack_4c;
  undefined2 *puStack_48;
  undefined2 *puStack_44;
  undefined2 *puStack_40;
  int iStack_3c;
  int iStack_38;
  undefined2 *puStack_34;
  int iStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  short *psStack_24;
  
  puStack_70 = param_3;
  puStack_6c = param_4;
  uStack_68 = param_5 & 0xffff;
  uStack_64 = param_6 & 0xffff;
  uStack_60 = param_7 & 0xff;
  *(char *)(param_3 + 7) = (char)uStack_64;
  *(char *)(param_4 + 7) = (char)uStack_64;
  uVar4 = 0;
  puStack_34 = &uStack_94;
  psStack_24 = &sStack_72;
  do {
    iVar5 = (int)(short)uVar4;
    iVar6 = ((param_5 & 0xffff) * 0x10 + iVar5) * 2;
    piVar10 = (int *)(param_3[3] + iVar6);
    iVar7 = iVar5 * 2;
    puVar9 = &uStack_b4 + iVar5;
    *(byte *)puVar9 = (byte)*puVar9 & 0xe0 | (byte)*piVar10 & 0x1f;
    *puVar9 = (ushort)DWORD_080977dc & *puVar9 | (ushort)(((uint)(*piVar10 << 0x16) >> 0x1b) << 5);
    *(byte *)((int)&uStack_b4 + iVar7 + 1) =
         *(byte *)((int)&uStack_b4 + iVar7 + 1) & 0x83 |
         (byte)(((uint)(*piVar10 << 0x11) >> 0x1b) << 2);
    piVar10 = (int *)(param_4[3] + iVar6);
    puVar9 = &uStack_94 + iVar5;
    *(byte *)puVar9 = (byte)*puVar9 & 0xe0 | (byte)*piVar10 & 0x1f;
    *puVar9 = (ushort)DWORD_080977dc & *puVar9 | (ushort)(((uint)(*piVar10 << 0x16) >> 0x1b) << 5);
    *(byte *)((int)&uStack_94 + iVar7 + 1) =
         *(byte *)((int)&uStack_94 + iVar7 + 1) & 0x83 |
         (byte)(((uint)(*piVar10 << 0x11) >> 0x1b) << 2);
    uVar4 = iVar5 + 1U & 0xffff;
  } while ((int)((iVar5 + 1U) * 0x10000) >> 0x10 < 0x10);
  uStack_58 = 0;
  uStack_5c = 0;
  iStack_54 = 2;
  iStack_30 = uStack_64 + 0x10;
  puStack_44 = (undefined2 *)(param_1 + 0x68);
  puStack_40 = (undefined2 *)(param_1 + 0x6a);
  iStack_3c = param_1 + 0x6c;
  puStack_2c = param_3 + 7;
  iStack_38 = param_2 + 0x6c;
  puStack_28 = param_4 + 7;
  puStack_4c = (undefined2 *)(param_2 + 0x68);
  puStack_48 = (undefined2 *)(param_2 + 0x6a);
  psStack_50 = &sStack_74;
  uVar8 = 0;
  do {
    uStack_5c = ((uStack_5c + 1) * 0x10000 & 0xf0000) >> 0x10;
    uVar4 = uStack_58 + 1 & 0xff;
    if ((uStack_58 & 1) == 0) {
      uStack_58 = uVar4;
      sub_08009088(0,0,0,uStack_5c);
    }
    else {
      uStack_58 = uVar4;
      sub_08009088(0,0,uStack_5c,0);
    }
    if (iStack_54 == 1) {
      sub_08096E20(&uStack_b4,2,uVar8,0x3c);
      uVar3 = uVar8 + 1;
      cVar1 = sub_08096E20(puStack_34,2,uVar3,0x3c);
      if (cVar1 != '\0') {
        uVar3 = 0;
        iStack_54 = 0;
      }
    }
    else {
      uVar3 = uVar8;
      if ((iStack_54 == 2) && (uVar3 = uVar8 + 1, 0x3c < uVar8)) {
        uVar3 = 0;
        iStack_54 = 1;
      }
    }
    sub_08000AF0(iStack_30,&uStack_b4,1);
    sub_08065370(puStack_70,*puStack_44,puStack_40,iStack_3c,1);
    sub_0800BC08((*(int *)(param_1 + 0x14) << 8) >> 0x10,(*(int *)(param_1 + 0x18) << 8) >> 0x10,
                 &sStack_74,psStack_24,0,0);
    uVar2 = sub_0800BC44(*(int *)(param_1 + 0x14) >> 8,*(int *)(param_1 + 0x18) >> 8,0);
    if (uStack_60 == 0) {
      sStack_74 = sStack_74 + 9;
    }
    else {
      sStack_74 = sStack_74 + -9;
    }
    sStack_72 = sStack_72 + 0x15;
    sub_08007974((int)*psStack_50,(int)sStack_72,*puStack_44,*puStack_40,uVar2,1,0,puStack_2c,
                 puStack_70[2],*puStack_70);
    sub_08000AF0(iStack_30,puStack_34,1);
    sub_08065370(puStack_6c,*puStack_4c,puStack_48,iStack_38,1);
    sub_0800BC08((*(int *)(param_2 + 0x14) << 8) >> 0x10,(*(int *)(param_2 + 0x18) << 8) >> 0x10,
                 psStack_50,&sStack_72,0,0);
    uVar2 = sub_0800BC44(*(int *)(param_2 + 0x14) >> 8,*(int *)(param_2 + 0x18) >> 8,0);
    sub_08007974((int)*psStack_50,(int)sStack_72,*puStack_4c,*puStack_48,uVar2,1,0,puStack_28,
                 puStack_6c[2],*puStack_6c);
    sub_08000B38();
    sub_080003F0();
    uVar8 = uVar3;
  } while (iStack_54 != 0);
  sub_08009088(0,0,0,0);
  return CONCAT44(in_lr,1);
}


