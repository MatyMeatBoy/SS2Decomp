
undefined4 sub_080A230C(undefined4 param_1,uint param_2)

{
  dword dVar1;
  dword dVar2;
  char cVar3;
  byte bVar4;
  ushort uVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  ushort *puVar9;
  int iVar10;
  uint uVar11;
  int iVar12;
  byte bVar13;
  undefined4 in_lr;
  undefined4 auStack_88 [2];
  undefined4 uStack_80;
  int iStack_7c;
  undefined1 auStack_6c [24];
  undefined2 uStack_54;
  undefined2 uStack_52;
  short sStack_50;
  short sStack_4e;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  uint uStack_3c;
  int iStack_38;
  uint uStack_34;
  int iStack_30;
  uint uStack_2c;
  int iStack_28;
  undefined2 *puStack_24;
  
  param_2 = param_2 & 0xffff;
  sub_0805865C(0xc2);
  uVar11 = 0;
  puStack_24 = &uStack_52;
  if ((int)(param_2 * -0x14) < 0) {
    do {
      sub_080003F0();
      uVar11 = uVar11 + 1 & 0xffff;
    } while ((int)(uVar11 + param_2 * -0x14) < 0 != SBORROW4(uVar11,param_2 * 0x14));
  }
  dVar1 = DWORD_080a23fc;
  iStack_44 = *(int *)DWORD_080a23fc + 0x204;
  sub_08065158(auStack_88,DWORD_080a2400,*(undefined2 *)DWORD_080a2404,0xffffffff,1);
  cVar3 = sub_08096594(0);
  *(byte *)(*(int *)dVar1 + 0x1fc) = *(byte *)(*(int *)dVar1 + 0x1fc) & 0xf | cVar3 << 4;
  iStack_40 = (uint)(*(byte *)(*(int *)dVar1 + 0x1fc) >> 4) * 0x14c + DWORD_080a2408;
  sub_08097A38(0);
  *puStack_24 = 0;
  uStack_54 = 0;
  uStack_34 = 0;
  iStack_28 = 0;
  iVar6 = *(int *)dVar1;
  uVar11 = (uint)*(ushort *)(*(short *)(iVar6 + 8) * 2 + DWORD_080a2410);
  iVar12 = *(int *)(iVar6 + 0x14) + *(short *)((uVar11 + 0x40) * 2 + DWORD_080a240c) * 0x20;
  iVar6 = *(int *)(iVar6 + 0x18) + *(short *)(uVar11 * 2 + DWORD_080a240c) * 0x20;
  uStack_2c = 0x78;
  iStack_30 = 1;
  bVar13 = 0;
  do {
    if (uStack_2c == 0) {
      if (uStack_34 < 6) {
        bVar4 = bVar13 + 1;
        if (0x14 < bVar13) {
          bVar4 = 0;
          uStack_3c = (uint)(**(ushort **)(iStack_40 + 0x148) >> 4);
          iStack_38 = ((*(ushort **)(iStack_40 + 0x148))[1] & 0xfff) - 0xc;
          sub_08097978(iVar12,iVar6,uStack_3c,iStack_38,&iStack_4c);
          uStack_34 = uStack_34 + 1 & 0xff;
        }
      }
      else {
        bVar4 = bVar13 + 1;
        if (0xb4 < bVar13) {
          iStack_30 = 0;
        }
      }
      iVar12 = iVar12 + iStack_4c + (iStack_4c >> 1);
      iVar6 = iVar6 + iStack_48 + (iStack_48 >> 1);
      iVar8 = sub_080020F4();
      dVar1 = DWORD_080a2584;
      uVar7 = *(undefined4 *)(iVar8 * 0x14c + DWORD_080a2584 + 0x8c);
      iVar8 = sub_080020F4();
      iVar10 = (int)(short)((short)((uint)iVar12 >> 8) - (short)((uint)uVar7 >> 8));
      iVar8 = (((iVar6 >> 8) + 0xc) - (*(int *)(iVar8 * 0x14c + dVar1 + 0x90) >> 8)) * 0x10000 >>
              0x10;
      uVar5 = Sqrt(iVar10 * iVar10 + iVar8 * iVar8);
      if ((((((iStack_28 == 0) && (uVar5 < 0x18)) && (iVar8 = sub_0800CDF8(), iVar8 == 0)) &&
           (((iVar8 = sub_0800CCCC(), iVar8 == 0 &&
             (iVar8 = sub_0800CD8C(), dVar2 = DWORD_080a2588, iVar8 == 0)) &&
            ((*(short *)(*(int *)DWORD_080a2588 + 0xc) != 0xb &&
             ((iVar8 = sub_080020F4(), (*(uint *)(iVar8 * 0x14c + dVar1 + 0x30) & 0x2000) == 0 &&
              (iVar8 = sub_080020F4(), *(char *)(iVar8 * 0x14c + dVar1 + 0x68) != '\0')))))))) &&
          (iVar8 = sub_080020F4(), *(short *)(iVar8 * 0x14c + dVar1 + 0x20) != 0xe)) &&
         (((iVar8 = sub_080020F4(), *(short *)(iVar8 * 0x14c + dVar1 + 0x20) != 0xb &&
           (iVar8 = sub_080020F4(), *(short *)(iVar8 * 0x14c + dVar1 + 0x20) != 0xc)) &&
          (iVar8 = sub_080020F4(),
          *(int *)((uint)**(ushort **)dVar2 * 4 + iVar8 * 0x14c + dVar1 + 0xe4) !=
          *(int *)(*(ushort **)dVar2 + 0x28))))) {
        iVar8 = sub_0800CE30();
        if (iVar8 == 1) {
          sub_08029CEC(0,0x3c,2);
        }
        else {
          sub_08029CEC(0,0x1e,2);
        }
        iVar8 = sub_080020F4();
        *(short *)(iVar8 * 0x14c + DWORD_080a2688 + 0xb0) = (short)DWORD_080a268c;
        iVar8 = sub_080020F4();
        puVar9 = *(ushort **)DWORD_080a2690;
        iVar10 = *(int *)(puVar9 + 0x28);
        *(int *)((uint)*puVar9 * 4 + iVar8 * 0x14c + DWORD_080a2688 + 0xe4) = iVar10;
        *(int *)(puVar9 + 0x28) = iVar10 + 1;
        iStack_28 = 1;
      }
    }
    else {
      uStack_2c = uStack_2c - 1 & 0xff;
      bVar4 = bVar13;
    }
    iVar8 = sub_0800CCCC();
    if (((iVar8 == 0) && (iVar8 = sub_0800CD8C(), iVar8 == 0)) &&
       ((iVar8 = sub_0800CD34(), iVar8 == 0 && (iVar8 = sub_0800CC98(), iVar8 == 0)))) {
      sub_08065370(auStack_88,8,&uStack_54,puStack_24,1);
      dVar1 = DWORD_080a2694;
      sub_08000AF0(*(ushort *)DWORD_080a2694 + 0x10,
                   iStack_7c + (uint)*(ushort *)(iStack_44 + 0xd6) * 0x20,1);
      auStack_6c[0] = (undefined1)*(undefined2 *)dVar1;
      sub_0800BC08((iVar12 << 8) >> 0x10,(iVar6 << 8) >> 0x10,&sStack_50,&sStack_4e,0,0);
      sub_08007870((int)sStack_50,(int)sStack_4e,8,uStack_54,0,auStack_6c,uStack_80,auStack_88[0]);
    }
    sub_080003F0();
    bVar13 = bVar4;
  } while (iStack_30 != 0);
  sub_0805867C(0xc2);
  iVar6 = sub_0800048C();
  *(int *)(iVar6 + 8) = iStack_30;
  sub_080003F0();
  return in_lr;
}


