
undefined4 sub_0801E550(uint param_1,int param_2,uint param_3,short param_4)

{
  short *psVar1;
  uint uVar2;
  undefined4 in_lr;
  
  psVar1 = *(short **)(param_2 * 0x14c + DWORD_0801e590 + 0x34);
  uVar2 = 0;
  do {
    if (((*psVar1 != -1) && ((ushort)psVar1[2] == param_3)) && ((ushort)psVar1[1] == param_1)) {
      psVar1[3] = param_4;
    }
    uVar2 = uVar2 + 1;
    psVar1 = psVar1 + 0x14;
  } while (uVar2 < 8);
  return in_lr;
}


