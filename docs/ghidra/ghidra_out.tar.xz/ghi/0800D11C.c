
uint sub_0800D11C(void)

{
  return *(uint *)DWORD_0800d128 >> 0xb & 1;
}


