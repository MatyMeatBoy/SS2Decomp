
undefined4 sub_0803F210(undefined4 param_1)

{
  short sVar1;
  int iVar2;
  undefined4 in_lr;
  
  sVar1 = 0x14;
  do {
    sub_080003F0();
    iVar2 = sub_080021A8();
    if (iVar2 != 0) break;
    sVar1 = sVar1 + -1;
  } while (sVar1 != 0);
  sub_08029174(param_1,0x10);
  if ((*(uint *)DWORD_0803f24c & 0x20) == 0) {
    sub_08006D08(0x55);
  }
  sVar1 = 10;
  do {
    sub_080003F0();
    iVar2 = sub_080021A8();
    if (iVar2 != 0) break;
    sVar1 = sVar1 + -1;
  } while (sVar1 != 0);
  sub_08029174(param_1,10);
  sVar1 = 0x3a;
  do {
    sub_080003F0();
    iVar2 = sub_080021A8();
    if (iVar2 != 0) break;
    sVar1 = sVar1 + -1;
  } while (sVar1 != 0);
  sub_08029174(param_1,0x10);
  if ((*(uint *)DWORD_0803f2a8 & 0x20) == 0) {
    sub_08006D08(0x55);
  }
  sVar1 = 10;
  do {
    sub_080003F0();
    iVar2 = sub_080021A8();
    if (iVar2 != 0) break;
    sVar1 = sVar1 + -1;
  } while (sVar1 != 0);
  sub_08029174(param_1,10);
  sVar1 = 0x3a;
  do {
    sub_080003F0();
    iVar2 = sub_080021A8();
    if (iVar2 != 0) break;
    sVar1 = sVar1 + -1;
  } while (sVar1 != 0);
  sub_08029174(param_1,0x10);
  if ((*(uint *)DWORD_0803f304 & 0x20) == 0) {
    sub_08006D08(0x55);
  }
  sVar1 = 10;
  do {
    sub_080003F0();
    iVar2 = sub_080021A8();
    if (iVar2 != 0) break;
    sVar1 = sVar1 + -1;
  } while (sVar1 != 0);
  sub_08029174(param_1,10);
  sVar1 = 0x28;
  do {
    sub_080003F0();
    iVar2 = sub_080021A8();
    if (iVar2 != 0) {
      return in_lr;
    }
    sVar1 = sVar1 + -1;
  } while (sVar1 != 0);
  return in_lr;
}


