
void sub_08092094(void)

{
  *(undefined1 *)DWORD_0809209c = 0;
  return;
}


