
undefined2 sub_08058614(void)

{
  return *(undefined2 *)(DWORD_0805861c + 0x90);
}


