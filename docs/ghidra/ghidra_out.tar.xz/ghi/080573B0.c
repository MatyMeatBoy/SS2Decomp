
undefined4 sub_080573B0(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_lr;
  
  iVar2 = *(int *)DWORD_080573c4 + DWORD_080573c8;
  uVar3 = 0;
  while( true ) {
    if (0x1d < uVar3) {
      return in_lr;
    }
    iVar1 = sub_08000470(iVar2);
    if (iVar1 == 0) break;
    uVar3 = uVar3 + 1;
    iVar2 = iVar2 + 0x28;
  }
  while( true ) {
    iVar1 = sub_08001494(0x400);
    *(int *)(iVar2 + 0x20) = iVar1;
    if (iVar1 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar2 + 8) = 0x3c;
  *(undefined4 *)(iVar2 + 0xc) = param_2;
  *(int *)(iVar2 + 0x10) = iVar1 + 0x3fc;
  *(undefined4 *)(iVar2 + 0x24) = 0;
  sub_08000274(iVar2,param_1);
  do {
    sub_080003F0();
    iVar1 = sub_08000470(iVar2);
  } while (iVar1 != 0);
  return in_lr;
}


