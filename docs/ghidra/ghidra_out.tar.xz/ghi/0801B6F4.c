
void sub_0801B6F4(short *param_1,short param_2)

{
  *param_1 = param_2 + *param_1;
  param_1[1] = param_2 + param_1[1];
  param_1[2] = param_2 + param_1[2];
  param_1[3] = param_2 + param_1[3];
  param_1[4] = param_2 + param_1[4];
  param_1[5] = param_2 + param_1[5];
  return;
}


