
undefined8 sub_0806569C(void)

{
  int iVar1;
  undefined4 in_lr;
  
  iVar1 = sub_08000470(DWORD_080656ac);
  return CONCAT44(in_lr,(uint)(iVar1 != 0));
}


