
undefined4 sub_080580EC(void)

{
  undefined4 in_lr;
  
  sub_0807C014();
  return in_lr;
}


