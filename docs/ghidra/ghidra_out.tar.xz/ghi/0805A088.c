
undefined4 sub_0805A088(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  undefined4 in_lr;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  dword dStack_18;
  
  uStack_1c = 0;
  uStack_24 = 0xb700;
  uStack_20 = 0xe100;
  dStack_18 = DWORD_0805a0b8;
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_0805a0bc;
  while (iVar2 = sub_08021FE0(iVar1 + 0x8c,&uStack_24,&uStack_1c,&dStack_18), iVar2 == 0) {
    sub_080003F0();
  }
  sub_08068070(DWORD_0805a0e8,param_1);
  return in_lr;
}


