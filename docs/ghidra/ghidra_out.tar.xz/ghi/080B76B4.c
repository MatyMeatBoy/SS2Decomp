
undefined4 m4aSoundMode(uint param_1)

{
  dword *pdVar1;
  int iVar2;
  dword *pdVar3;
  undefined4 in_lr;
  
  pdVar3 = *(dword **)DWORD_080b7740;
  if (*pdVar3 == DWORD_080b7744) {
    *pdVar3 = *pdVar3 + 1;
    if ((param_1 & 0xff) != 0) {
      *(byte *)((int)pdVar3 + 5) = (byte)param_1 & 0x7f;
    }
    if ((param_1 & 0xf00) != 0) {
      *(char *)((int)pdVar3 + 6) = (char)((param_1 & 0xf00) >> 8);
      iVar2 = 0xc;
      pdVar1 = pdVar3 + 0x14;
      do {
        *(undefined1 *)pdVar1 = 0;
        iVar2 = iVar2 + -1;
        pdVar1 = pdVar1 + 0x10;
      } while (iVar2 != 0);
    }
    if ((param_1 & 0xf000) != 0) {
      *(char *)((int)pdVar3 + 7) = (char)((param_1 & 0xf000) >> 0xc);
    }
    if ((param_1 & 0xb00000) != 0) {
      *(byte *)DWORD_080b7748 = *(byte *)DWORD_080b7748 & 0x3f | (byte)((param_1 & 0x300000) >> 0xe)
      ;
    }
    if ((param_1 & 0xf0000) != 0) {
      m4aSoundVSyncOff();
      SampleFreqSet(param_1 & 0xf0000);
    }
    *pdVar3 = DWORD_080b7744;
  }
  return in_lr;
}


