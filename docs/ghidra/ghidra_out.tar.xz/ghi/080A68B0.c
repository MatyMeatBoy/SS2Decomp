
undefined4 sub_080A68B0(uint param_1)

{
  dword dVar1;
  dword dVar2;
  ushort uVar3;
  short sVar4;
  undefined4 uVar5;
  int iVar6;
  short *psVar7;
  int iVar8;
  int unaff_r9;
  int unaff_r10;
  undefined4 in_lr;
  undefined4 auStack_7c [2];
  undefined4 uStack_74;
  int iStack_70;
  undefined1 auStack_60 [24];
  short sStack_48;
  short sStack_46;
  undefined2 uStack_44;
  undefined2 uStack_42;
  uint uStack_40;
  int iStack_3c;
  int iStack_38;
  uint uStack_34;
  uint uStack_30;
  int iStack_2c;
  short *psStack_28;
  short *psStack_24;
  
  dVar1 = DWORD_080a6954;
  uStack_40 = param_1 & 0xffff;
  iStack_3c = *(int *)DWORD_080a694c + 0x204;
  sub_08065158(auStack_7c,DWORD_080a6950,*(undefined2 *)DWORD_080a6954,0xffffffff,1);
  auStack_60[0] = (undefined1)*(undefined2 *)dVar1;
  iStack_38 = 0x80;
  uStack_34 = 0xf0;
  uStack_30 = 0;
  uStack_42 = 0;
  uStack_44 = 0;
  sub_0805865C(0x1a4);
  iStack_2c = uStack_40 * 0x11;
  psStack_28 = &sStack_48;
  psStack_24 = &sStack_46;
  while( true ) {
    if ((int)uStack_30 < iStack_2c) {
      uStack_30 = uStack_30 + 1 & 0xff;
      unaff_r9 = *(int *)(*(int *)DWORD_080a694c + 0x14);
      unaff_r10 = *(int *)(*(int *)DWORD_080a694c + 0x18);
      if (iStack_2c <= (int)uStack_30) {
        sub_0805865C(0x1a4);
      }
    }
    else {
      if ((uStack_40 & 1) != 0) {
        unaff_r9 = unaff_r9 + 0xc0;
      }
      unaff_r10 = unaff_r10 + iStack_38;
      iStack_38 = iStack_38 + 0x12;
      iVar6 = sub_080020F4();
      dVar1 = DWORD_080a6b90;
      uVar5 = *(undefined4 *)(iVar6 * 0x14c + DWORD_080a6b90 + 0x8c);
      iVar6 = sub_080020F4();
      iVar8 = (int)(short)((short)((uint)unaff_r9 >> 8) - (short)((uint)uVar5 >> 8));
      iVar6 = (((unaff_r10 >> 8) + 0xc) - (*(int *)(iVar6 * 0x14c + dVar1 + 0x90) >> 8)) * 0x10000
              >> 0x10;
      uVar3 = Sqrt(iVar8 * iVar8 + iVar6 * iVar6);
      if (((((uVar3 < 0x10) && (iVar6 = sub_0800CDF8(), iVar6 == 0)) &&
           (iVar6 = sub_0800CD8C(), iVar6 == 0)) &&
          ((((iVar6 = sub_0800CCCC(), dVar2 = DWORD_080a6b94, iVar6 == 0 &&
             (*(short *)(*(int *)DWORD_080a6b94 + 0xc) != 0xb)) &&
            ((iVar6 = sub_080020F4(), (*(uint *)(iVar6 * 0x14c + dVar1 + 0x30) & 0x2000) == 0 &&
             ((iVar6 = sub_080020F4(), *(char *)(iVar6 * 0x14c + dVar1 + 0x68) != '\0' &&
              (iVar6 = sub_080020F4(), *(short *)(iVar6 * 0x14c + dVar1 + 0x20) != 0xe)))))) &&
           (iVar6 = sub_080020F4(), *(short *)(iVar6 * 0x14c + dVar1 + 0x20) != 0xb)))) &&
         ((iVar6 = sub_080020F4(), *(short *)(iVar6 * 0x14c + dVar1 + 0x20) != 0xc &&
          (iVar6 = sub_080020F4(),
          *(int *)((uint)**(ushort **)dVar2 * 4 + iVar6 * 0x14c + DWORD_080a6b98) !=
          *(int *)(*(ushort **)dVar2 + 0x28))))) {
        iVar6 = sub_080020F4();
        *(undefined2 *)(iVar6 * 0x14c + dVar1 + 0x20) = 10;
        iVar6 = sub_080020F4();
        *(short *)(iVar6 * 0x14c + dVar1 + 0xb0) = (short)DWORD_080a6b9c;
        iVar6 = sub_080020F4();
        uVar5 = *(undefined4 *)dVar2;
        iVar8 = sub_080020F4();
        sVar4 = sub_0801ED8C(uVar5,iVar8 * 0x14c + dVar1);
        psVar7 = (short *)(iVar6 * 0x14c + dVar1 + 0x88);
        *psVar7 = sVar4 + *psVar7;
        iVar6 = sub_080020F4();
        *(undefined4 *)((uint)**(ushort **)dVar2 * 4 + iVar6 * 0x14c + DWORD_080a6b98) =
             *(undefined4 *)(*(ushort **)dVar2 + 0x28);
      }
      iVar6 = sub_0800CCCC();
      if ((((iVar6 == 0) && (iVar6 = sub_0800CC98(), iVar6 == 0)) &&
          (iVar6 = sub_0800CD8C(), iVar6 == 0)) && (iVar6 = sub_0800CD34(), iVar6 == 0)) {
        sub_0800BC08((unaff_r9 << 8) >> 0x10,unaff_r10 * 0x100 >> 0x10,psStack_28,psStack_24,0,0);
        sub_08000AF0(*(ushort *)DWORD_080a6ba0 + 0x10,
                     iStack_70 + (uint)*(ushort *)(iStack_3c + 0xd6) * 0x20,1);
        sub_08065370(auStack_7c,2,&uStack_44,&uStack_42,1);
        sub_08007870((int)*psStack_28,(int)*psStack_24,2,uStack_44,0,auStack_60,uStack_74,
                     auStack_7c[0]);
      }
    }
    sub_080003F0();
    iVar6 = sub_0800CED8();
    if (((iVar6 != 0) || (iVar6 = sub_0800CB78(), iVar6 != 0)) ||
       (iVar6 = sub_0800CD00(), iVar6 != 0)) break;
    uStack_34 = uStack_34 - 1 & 0xffff;
    if (uStack_34 == DWORD_080a6be0) {
      sub_080003F0();
      *(int *)(*(int *)DWORD_080a6be4 + 0x50) = *(int *)(*(int *)DWORD_080a6be4 + 0x50) + 1;
      iVar6 = sub_0800048C();
      *(undefined4 *)(iVar6 + 8) = 0;
      return in_lr;
    }
  }
  iVar6 = sub_0800048C();
  *(undefined4 *)(iVar6 + 8) = 0;
  return in_lr;
}


