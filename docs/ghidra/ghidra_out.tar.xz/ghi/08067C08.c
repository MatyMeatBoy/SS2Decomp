
void sub_08067C08(void)

{
  sub_080682B8(DWORD_08067c14);
  return;
}


