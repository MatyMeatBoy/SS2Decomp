
undefined4 sub_0804EABC(void)

{
  byte bVar1;
  dword dVar2;
  dword dVar3;
  short sVar4;
  byte *pbVar5;
  uint uVar6;
  int iVar7;
  int *piVar8;
  int unaff_r7;
  undefined4 in_lr;
  
  dVar2 = DWORD_0804eae0;
  if ((*(uint *)(*(int *)DWORD_0804eae0 + 0x38) & 4) == 0) {
    iVar7 = sub_0800CE30();
    if (iVar7 == 0) {
      pbVar5 = (byte *)(*(int *)dVar2 + DWORD_0804eb08);
    }
    else {
      pbVar5 = (byte *)(*(int *)dVar2 + DWORD_0804eae4);
    }
    bVar1 = *pbVar5;
    iVar7 = sub_0800CE30();
    if (iVar7 == 0) {
      pbVar5 = (byte *)(*(int *)DWORD_0804ebd4 + DWORD_0804ebd8);
    }
    else {
      pbVar5 = (byte *)(*(int *)DWORD_0804eb0c + DWORD_0804eb10);
    }
    if ((((int)(uint)*pbVar5 >> 2 & 1U) == 0) && (((int)(uint)bVar1 >> 1 & 1U) != 0)) {
      sub_08028AAC(1,0x80,0x50,0);
      dVar3 = DWORD_0804ebe0;
      dVar2 = DWORD_0804ebdc;
      uVar6 = *(uint *)DWORD_0804ebe0;
      while ((uVar6 & 1) == 0) {
        sub_080003F0();
        uVar6 = *(uint *)dVar3;
      }
      iVar7 = *(int *)DWORD_0804ebe4;
      *(dword *)(iVar7 + 0x38) = dVar2;
      *(undefined4 *)(iVar7 + 0x3c) = 1;
      *(undefined4 *)(iVar7 + 0x30) = 0;
      *(undefined4 *)(iVar7 + 0x34) = 0;
      unaff_r7 = sub_080289C0(DWORD_0804ebe8,0x80,0x50);
      piVar8 = (int *)(*(int *)DWORD_0804ebd4 + DWORD_0804ebec);
      uVar6 = 0;
      do {
        if (*piVar8 == unaff_r7) goto LAB_0804eb96;
        uVar6 = uVar6 + 1;
        piVar8 = piVar8 + 0x1c;
      } while (uVar6 < 0xf);
      sub_080003F0();
      piVar8 = (int *)0x0;
LAB_0804eb96:
      if (piVar8 != (int *)0x0) {
        *(undefined2 *)(piVar8 + 6) = 8;
        *(undefined2 *)((int)piVar8 + 0x1a) = 4;
        piVar8[0xf] = piVar8[0xf] | 0x10;
      }
      dVar2 = DWORD_0804ebf0;
      piVar8 = (int *)(*(int *)DWORD_0804ebd4 + DWORD_0804ebec);
      uVar6 = 0;
      do {
        if (*piVar8 == unaff_r7) goto LAB_0804ebca;
        uVar6 = uVar6 + 1;
        piVar8 = piVar8 + 0x1c;
      } while (uVar6 < 0xf);
      sub_080003F0();
      piVar8 = (int *)0x0;
LAB_0804ebca:
      if (piVar8 != (int *)0x0) {
        piVar8[0x11] = dVar2;
      }
    }
    else {
      sub_08028AAC(1,DWORD_0804ec24,DWORD_0804ec24,0);
      sub_08068070(DWORD_0804ec28,2);
    }
    iVar7 = sub_0800CC98();
    piVar8 = (int *)DWORD_0804ec5c;
    if (iVar7 == 0) {
      iVar7 = sub_0801AB24();
      if (iVar7 == 1) {
        sub_0801AB50(6);
      }
      else if (iVar7 < 2) {
        if (iVar7 == 0) {
          sub_080576A8();
        }
      }
      else if (iVar7 == 2) {
        sub_0801AB90(6);
      }
      while (iVar7 = sub_0801AAE0(), piVar8 = (int *)DWORD_0804ec5c, iVar7 == 0) {
        sub_080003F0();
      }
    }
    do {
      sVar4 = 1;
      do {
        sub_080003F0();
        iVar7 = sub_080021A8();
        if (iVar7 != 0) break;
        sVar4 = sVar4 + -1;
      } while (sVar4 != 0);
      iVar7 = sub_0800CE30();
      if (iVar7 == 0) {
        pbVar5 = (byte *)(*piVar8 + DWORD_0804ecc4);
      }
      else {
        pbVar5 = (byte *)(*piVar8 + DWORD_0804ec88);
      }
    } while (((int)(uint)*pbVar5 >> 2 & 1U) == 0);
    piVar8 = (int *)(*(int *)DWORD_0804ecc8 + DWORD_0804eccc);
    uVar6 = 0;
    do {
      if (*piVar8 == unaff_r7) goto LAB_0804ecba;
      uVar6 = uVar6 + 1;
      piVar8 = piVar8 + 0x1c;
    } while (uVar6 < 0xf);
    sub_080003F0();
    piVar8 = (int *)0x0;
LAB_0804ecba:
    if (piVar8 != (int *)0x0) {
      *(undefined2 *)((int)piVar8 + 0x36) = 4;
    }
  }
  else {
    iVar7 = sub_0800CC98();
    if (iVar7 == 0) {
      iVar7 = sub_0801AB24();
      if (iVar7 == 1) {
        sub_0801AB50(6);
      }
      else if (iVar7 < 2) {
        if (iVar7 == 0) {
          sub_080576A8();
        }
      }
      else if (iVar7 == 2) {
        sub_0801AB90(6);
      }
      while (iVar7 = sub_0801AAE0(), iVar7 == 0) {
        sub_080003F0();
      }
    }
  }
  return in_lr;
}


