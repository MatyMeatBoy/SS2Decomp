
undefined8 sub_0808EE98(undefined4 param_1)

{
  dword dVar1;
  int iVar2;
  undefined4 uVar3;
  uint *puVar4;
  undefined4 in_lr;
  
  if (*(short *)(*(int *)DWORD_0808eec0 + 0x10) == 0) {
    sub_0800CD9C();
    sub_0802704C(param_1);
    sub_0801674C(DWORD_0808eec4,DWORD_0808eec8);
    sub_0800CD9C();
  }
  else {
    iVar2 = sub_08056E90();
    if (iVar2 != 0) {
      sub_0801ABE8(3);
      sub_0800BB40();
      while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
        sub_080003F0();
      }
      sub_0800BB40();
      sub_0800CDAC();
      iVar2 = sub_080020F4();
      dVar1 = DWORD_0808ef3c;
      puVar4 = (uint *)(iVar2 * 0x14c + DWORD_0808ef3c + 0x30);
      *puVar4 = *puVar4 & 0xfffffffd;
      iVar2 = sub_080020F4();
      *(undefined2 *)(iVar2 * 0x14c + dVar1 + 0x20) = 0;
      iVar2 = *(int *)DWORD_0808ef40;
      *(undefined4 *)(iVar2 + DWORD_0808ef44) =
           *(undefined4 *)(*(int *)(iVar2 + 0x40) * 4 + DWORD_0808ef48);
      *(undefined2 *)(iVar2 + 0x10) = 0;
      uVar3 = 1;
      *(undefined2 *)(iVar2 + 0x30) = 1;
      *(undefined2 *)(iVar2 + 0x24) = 1;
      goto LAB_0808ef4e;
    }
  }
  uVar3 = 0;
LAB_0808ef4e:
  return CONCAT44(in_lr,uVar3);
}


