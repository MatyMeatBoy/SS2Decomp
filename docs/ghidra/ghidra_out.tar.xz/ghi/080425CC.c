
undefined4 sub_080425CC(int param_1)

{
  short sVar1;
  dword dVar2;
  short sVar3;
  int iVar4;
  undefined4 uVar5;
  undefined1 *puVar6;
  int *piVar7;
  uint uVar8;
  undefined4 in_lr;
  undefined1 auStack_3c [4];
  undefined1 auStack_38 [4];
  undefined1 auStack_34 [4];
  undefined1 auStack_30 [4];
  int iStack_2c;
  undefined1 *puStack_28;
  undefined1 *puStack_24;
  
  iStack_2c = param_1;
  iVar4 = sub_080020F4();
  iVar4 = iVar4 * 0x14c + DWORD_0804260c;
  *(uint *)(iVar4 + 0x30) = *(uint *)(iVar4 + 0x30) | 1;
  sub_0800D0F4();
  iVar4 = sub_080020F4();
  if (iVar4 == 1) {
    uVar5 = 0x84;
  }
  else if (iVar4 < 2) {
    if (iVar4 != 0) goto LAB_08042640;
    uVar5 = 0x6c;
  }
  else {
    if (iVar4 != 2) {
      if (iVar4 == 3) {
        sub_08028AAC(0,0x9c,0x80,0);
      }
      goto LAB_08042640;
    }
    uVar5 = 0x54;
  }
  sub_08028AAC(0,uVar5,0x80,0);
LAB_08042640:
  sub_080290E4(0,4);
  iVar4 = sub_080020F4();
  iVar4 = iVar4 * 0x14c + DWORD_08042678;
  *(uint *)(iVar4 + 0x30) = *(uint *)(iVar4 + 0x30) & 0xfffffffd;
  sub_08067D74();
  sVar3 = 2;
  puStack_28 = auStack_34;
  puStack_24 = auStack_30;
  do {
    sub_080003F0();
    iVar4 = sub_080021A8();
    if (iVar4 != 0) break;
    sVar3 = sVar3 + -1;
  } while (sVar3 != 0);
  iVar4 = sub_0800CC98();
  if (iVar4 == 0) {
    iVar4 = sub_0801AB24();
    if (iVar4 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar4 < 2) {
      if (iVar4 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar4 == 2) {
      sub_0801AB90(6);
    }
    while (iVar4 = sub_0801AAE0(), iVar4 == 0) {
      sub_080003F0();
    }
  }
  dVar2 = DWORD_08042738;
  sVar3 = *(short *)(DWORD_08042734 + 0x80);
  sVar1 = *(short *)(DWORD_08042734 + 0x82);
  iVar4 = 0;
  do {
    sub_080659F4(auStack_3c,(int)sVar3,0,iVar4);
    sub_080659F4(auStack_38,(int)sVar1,(int)dVar2 >> 0x10,iVar4);
    sub_0800BB80((int)auStack_3c._0_2_,(int)auStack_38._0_2_);
    sub_080003F0();
    iVar4 = iVar4 + 10;
  } while (iVar4 < 0x401);
  while (iVar4 = sub_0805F184(), iVar4 != 0) {
    sub_080003F0();
  }
  while (iVar4 = sub_0805EF90(), iVar4 != 0) {
    sub_080003F0();
  }
  uVar5 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08042770);
  while (iVar4 = sub_0805EEFC(uVar5), iVar4 == 0) {
    iVar4 = sub_0800CDF8();
    if (iVar4 != 0) {
      sub_0805EFBC();
      break;
    }
    sub_080003F0();
  }
  piVar7 = (int *)(*(int *)DWORD_08042820 + DWORD_08042824);
  uVar8 = 0;
  do {
    if (*piVar7 == iStack_2c) goto LAB_080427ae;
    uVar8 = uVar8 + 1;
    piVar7 = piVar7 + 0x1c;
  } while (uVar8 < 0xf);
  sub_080003F0();
  piVar7 = (int *)0x0;
LAB_080427ae:
  if (piVar7 != (int *)0x0) {
    *(undefined2 *)((int)piVar7 + 0x36) = 4;
  }
  iVar4 = sub_080289C0(DWORD_08042828,0x78,0x52);
  piVar7 = (int *)(*(int *)DWORD_08042820 + DWORD_08042824);
  uVar8 = 0;
  do {
    if (*piVar7 == iVar4) goto LAB_080427e2;
    uVar8 = uVar8 + 1;
    piVar7 = piVar7 + 0x1c;
  } while (uVar8 < 0xf);
  sub_080003F0();
  piVar7 = (int *)0x0;
LAB_080427e2:
  if (piVar7 != (int *)0x0) {
    *(undefined2 *)(piVar7 + 6) = 8;
    *(undefined2 *)((int)piVar7 + 0x1a) = 0x10;
    piVar7[0xf] = piVar7[0xf] | 0x10;
  }
  dVar2 = DWORD_0804282c;
  piVar7 = (int *)(*(int *)DWORD_08042820 + DWORD_08042824);
  uVar8 = 0;
  do {
    if (*piVar7 == iVar4) goto LAB_08042818;
    uVar8 = uVar8 + 1;
    piVar7 = piVar7 + 0x1c;
  } while (uVar8 < 0xf);
  sub_080003F0();
  piVar7 = (int *)0x0;
LAB_08042818:
  if (piVar7 != (int *)0x0) {
    piVar7[0x11] = dVar2;
  }
  while (iVar4 = sub_0805F184(), iVar4 != 0) {
    sub_080003F0();
  }
  while (iVar4 = sub_0805EF90(), iVar4 != 0) {
    sub_080003F0();
  }
  uVar5 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08042864);
  do {
    iVar4 = sub_0805EEFC(uVar5);
    if (iVar4 != 0) {
LAB_08042882:
      sVar3 = *(short *)(DWORD_080428ec + 0x80);
      sVar1 = *(short *)(DWORD_080428ec + 0x82);
      iVar4 = 0;
      do {
        sub_080659F4(puStack_28,(int)sVar3,0,iVar4);
        sub_080659F4(puStack_24,(int)sVar1,0,iVar4);
        sub_0800BB80((int)auStack_34._0_2_,(int)auStack_30._0_2_);
        sub_080003F0();
        iVar4 = iVar4 + 0x22;
      } while (iVar4 < 0x401);
      iVar4 = sub_0800CE30();
      if (iVar4 == 0) {
        puVar6 = (undefined1 *)(*(int *)DWORD_08042930 + 0x1b2);
      }
      else {
        puVar6 = (undefined1 *)(*(int *)DWORD_080428f0 + 0x1be);
      }
      *puVar6 = 2;
      iVar4 = sub_080020F4();
      iVar4 = iVar4 * 0x14c + DWORD_08042934;
      *(uint *)(iVar4 + 0x30) = *(uint *)(iVar4 + 0x30) & 0xfffffffe;
      sub_0800D108();
      return in_lr;
    }
    iVar4 = sub_0800CDF8();
    if (iVar4 != 0) {
      sub_0805EFBC();
      goto LAB_08042882;
    }
    sub_080003F0();
  } while( true );
}


