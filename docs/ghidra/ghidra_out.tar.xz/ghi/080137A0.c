
undefined4 sub_080137A0(int param_1)

{
  dword dVar1;
  dword dVar2;
  dword dVar3;
  uint uVar4;
  int iVar5;
  undefined4 in_lr;
  
  dVar3 = DWORD_0801384c;
  dVar2 = DWORD_08013814;
  dVar1 = DWORD_080137e0;
  if (param_1 == 1) {
    iVar5 = *(int *)DWORD_08013814;
    *(undefined2 *)(iVar5 + 0x110) = 0;
    *(undefined2 *)(iVar5 + 0x112) = 0;
    uVar4 = 0;
    do {
      *(undefined1 *)(*(int *)dVar2 + 0x114 + uVar4) = 0;
      uVar4 = uVar4 + 1;
    } while (uVar4 < 0xc);
  }
  else if (param_1 == 0) {
    iVar5 = *(int *)DWORD_080137e0;
    *(undefined2 *)(iVar5 + 0x100) = 0;
    *(undefined2 *)(iVar5 + 0x102) = 0;
    uVar4 = 0;
    do {
      *(undefined1 *)(*(int *)dVar1 + 0x104 + uVar4) = 0;
      uVar4 = uVar4 + 1;
    } while (uVar4 < 0xc);
  }
  else if (param_1 == 2) {
    iVar5 = *(int *)DWORD_0801384c;
    *(undefined2 *)(iVar5 + 0x120) = 0;
    *(undefined2 *)(iVar5 + 0x122) = 0;
    uVar4 = 0;
    do {
      *(undefined1 *)(*(int *)dVar3 + 0x124 + uVar4) = 0;
      uVar4 = uVar4 + 1;
    } while (uVar4 < 0xc);
  }
  return in_lr;
}


