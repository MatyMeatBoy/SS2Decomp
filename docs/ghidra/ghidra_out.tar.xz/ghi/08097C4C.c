
undefined4 sub_08097C4C(void)

{
  dword dVar1;
  int iVar2;
  undefined4 in_lr;
  
  dVar1 = DWORD_08097c68;
  iVar2 = sub_08001494(0x28);
  *(int *)dVar1 = iVar2;
  if (iVar2 != 0) {
    *(undefined4 *)(iVar2 + 8) = 0;
  }
  return in_lr;
}


