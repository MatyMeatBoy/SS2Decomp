
undefined4 sub_08001BE4(void)

{
  dword dVar1;
  dword dVar2;
  dword dVar3;
  dword dVar4;
  uint *puVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  undefined4 in_lr;
  uint auStack_30 [4];
  
  puVar5 = auStack_30;
  sub_0800170C();
  *(undefined4 *)DWORD_08001c1c = 1;
  *(undefined4 *)DWORD_08001c20 = 0;
  sub_08002298(0x50);
  dVar2 = DWORD_08001c24;
  dVar1 = DWORD_08001c20;
  uVar11 = 0;
  do {
    *puVar5 = 0;
    puVar5 = puVar5 + 1;
    uVar11 = uVar11 + 1;
  } while (uVar11 < 4);
  while ((auStack_30[0] < 0x3c && (sub_080003F0(), (*(uint *)DWORD_08001cf0 & 0x40000000) == 0))) {
    *(undefined4 *)dVar2 = *(undefined4 *)dVar1;
    uVar6 = sub_08001804(DWORD_08001ce8,DWORD_08001cec);
    *(undefined4 *)dVar1 = uVar6;
    sub_08001A50();
    if ((*(uint *)dVar1 & 0xe00) != 0) {
      auStack_30[0] = auStack_30[0] + 1;
    }
  }
  dVar1 = DWORD_08001cf0;
  auStack_30[0] = 0;
  uVar11 = 0;
  *(uint *)DWORD_08001cf0 = *(uint *)DWORD_08001cf0 | 2;
  uVar7 = sub_080020F4();
  dVar2 = DWORD_08001cf4;
  uVar8 = *(uint *)dVar1;
  do {
    if ((uVar8 & 0x40000000) != 0) {
      sub_08001A64();
      *(undefined4 *)DWORD_08001de8 = 0x80000000;
      *(undefined4 *)DWORD_08001dec = 0;
      sub_0800035C();
      return in_lr;
    }
    sub_080003F0();
    *(undefined4 *)DWORD_08001cf8 = *(undefined4 *)dVar2;
    uVar8 = sub_08001804(DWORD_08001ce8,DWORD_08001cec);
    *(uint *)dVar2 = uVar8;
    uVar9 = *(uint *)dVar1;
    uVar10 = uVar9 & 0xffffffef;
    *(uint *)dVar1 = uVar10;
    if ((uVar8 & 0x1000) == 0) {
      uVar11 = 0;
    }
    else {
      uVar11 = uVar11 + 1;
      if ((5 < uVar11) && ((uVar9 & 4) != 0)) {
        *(uint *)dVar1 = uVar10 | 8;
        sub_080003F4(8000);
        *(uint *)dVar1 = *(uint *)dVar1 & 0xfffffff7;
      }
    }
    *(uint *)dVar1 = *(uint *)dVar1 & 0xffffffdf;
    dVar3 = DWORD_08001d24;
    puVar5 = auStack_30;
    for (uVar8 = 0; uVar9 = sub_08002164(), dVar4 = DWORD_08001d74, uVar8 < uVar9; uVar8 = uVar8 + 1
        ) {
      if ((*(uint *)dVar2 & 1 << (uVar8 & 0xff)) == 0) {
        *puVar5 = *puVar5 + 1;
        *(uint *)dVar3 = *(uint *)dVar3 | 0x10;
      }
      else {
        *puVar5 = 0;
      }
      if ((*(int *)DWORD_08001d74 == 0x50) && (0x3c < *puVar5)) {
        *(uint *)dVar3 = *(uint *)dVar3 | 0x20;
      }
      puVar5 = puVar5 + 1;
    }
    puVar5 = auStack_30;
    for (uVar8 = 0; uVar9 = sub_08002164(), uVar8 < uVar9; uVar8 = uVar8 + 1) {
      if ((uVar8 != uVar7) && (*(uint *)dVar4 < *puVar5)) {
        if ((*(uint *)DWORD_08001de8 & 4) != 0) {
          *(uint *)DWORD_08001de8 = *(uint *)DWORD_08001de8 | 8;
          sub_080003F4(8000);
          break;
        }
        *puVar5 = 0;
      }
      puVar5 = puVar5 + 1;
    }
    dVar3 = DWORD_08001de8;
    if ((*(uint *)DWORD_08001de8 & 0x20) != 0) {
      sub_080586B4(0);
    }
    sub_08001A50();
    uVar8 = *(uint *)dVar3;
  } while( true );
}


