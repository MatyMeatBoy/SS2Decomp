
void sub_080021C4(void)

{
  *(uint *)DWORD_080021d0 = *(uint *)DWORD_080021d0 | 4;
  return;
}


