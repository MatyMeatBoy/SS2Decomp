
/* WARNING: Removing unreachable block (ram,0x0800c116) */

undefined4 sub_0800BEC0(void)

{
  byte bVar1;
  ushort uVar2;
  dword dVar3;
  int iVar4;
  uint *puVar5;
  uint uVar6;
  int iVar7;
  undefined2 *puVar8;
  uint *puVar9;
  byte *pbVar10;
  uint uVar11;
  ushort *puVar12;
  char cVar13;
  char cVar14;
  short *psVar15;
  int *piVar16;
  uint *puVar17;
  uint *puVar18;
  undefined2 *puVar19;
  short sVar20;
  int *piVar21;
  uint uVar22;
  uint uVar23;
  undefined4 in_lr;
  undefined1 auStack_178 [12];
  int iStack_16c;
  undefined1 uStack_150;
  undefined1 auStack_144 [68];
  undefined2 auStack_100 [4];
  undefined2 auStack_f8 [24];
  undefined1 auStack_c8 [48];
  uint uStack_98;
  uint auStack_94 [7];
  uint uStack_78;
  uint uStack_74;
  int iStack_70;
  uint uStack_6c;
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  uint uStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined1 *puStack_38;
  uint *puStack_34;
  uint *puStack_30;
  int iStack_2c;
  int iStack_28;
  undefined2 *puStack_24;
  
  puStack_38 = auStack_144;
  puVar8 = auStack_100;
  puStack_34 = &uStack_98;
  puStack_30 = auStack_94;
  while (iVar4 = sub_0801AAE0(), iVar4 == 0) {
    sub_080003F0();
  }
  if ((*(uint *)DWORD_0800bf08 >> 3 & 1) == 0) {
    uStack_74 = (uint)**(ushort **)DWORD_0800c12c;
  }
  else {
    uStack_74 = 0;
  }
  iStack_70 = 0;
  *(uint *)DWORD_0800bf08 = *(uint *)DWORD_0800bf08 | 0x20;
  sub_08068384();
  sub_08065158(auStack_178,DWORD_0800c130,4,0xffffffff,0);
  uStack_150 = 0;
  sub_08000AF0(0x10,iStack_16c + 0x180,1);
  uStack_6c = sub_080020F4();
  uStack_60 = sub_08002164();
  uStack_60 = uStack_60 & 0xffff;
  sub_0801A508();
  sub_080003F0();
  sub_0800BCDC(0x34,1,0x6000000,0,0xf);
  sub_0800B974(0x48,0x1e);
  sub_080009F8(0xf00,0,1);
  sub_080009C0(0x1300,0,1);
  uStack_78 = uStack_78 & DWORD_0800c134 | DWORD_0800c138;
  sub_08000AA8(0,&uStack_78);
  uStack_78 = CONCAT22(uStack_78._2_2_,0x1e00);
  sub_08000AA8(2,&uStack_78);
  iVar4 = sub_08057C34(5);
  if (iVar4 == 0) {
    sub_080009C0(0x400,0,1);
    sub_0800903C(4,2,1,0xe,0xc,0);
  }
  dVar3 = DWORD_0800c13c;
  *(undefined2 *)(DWORD_0800c13c + 8) = 0;
  *(undefined2 *)(dVar3 + 10) = 0;
  *(undefined2 *)(dVar3 + 0xc) = 0;
  *(undefined2 *)(dVar3 + 0xe) = 0;
  *(undefined2 *)(dVar3 + 4) = 0;
  *(undefined2 *)(dVar3 + 6) = 0;
  sub_08065158(puStack_38,DWORD_0800c140,4,0xc,0);
  sub_080003F0();
  sub_080003F0();
  sub_080003F0();
  sub_0801AB50(3);
  uVar23 = 0;
  iVar4 = uStack_74 * 4;
  puVar5 = puStack_30;
  puVar9 = puStack_34;
  do {
    *puVar8 = 0x300;
    *puVar9 = uVar23;
    *puVar5 = 0;
    dVar3 = DWORD_0800c144;
    puVar9 = puVar9 + 2;
    puVar8 = puVar8 + 1;
    puVar5 = puVar5 + 2;
    uVar23 = uVar23 + 1;
  } while (uVar23 < 4);
  pbVar10 = *(byte **)(uStack_6c * 0x14c + DWORD_0800c144 + 0x144);
  *pbVar10 = *pbVar10 & 0xf0;
  uVar23 = 0;
  if (uStack_60 != 0) {
    psVar15 = (short *)(dVar3 + 0xb0);
    do {
      *psVar15 = (short)uVar23 + 0x1b;
      psVar15 = psVar15 + 0xa6;
      uVar23 = uVar23 + 1;
    } while (uVar23 < uStack_60);
  }
  sub_08058688(0x70);
  iStack_5c = (uint)*(ushort *)(iVar4 + DWORD_0800c148) << 8;
  iStack_58 = (uint)*(ushort *)(iVar4 + DWORD_0800c148 + 2) << 8;
  iStack_54 = 0;
  iStack_4c = 0;
  uStack_64 = 0;
  uStack_68 = 0;
  iStack_44 = 0;
  iStack_48 = 0;
  uStack_40 = sub_08057328(0,DWORD_0800c14c);
LAB_0800c0b2:
  do {
    iVar4 = sub_08057C34(5);
    if (iVar4 == 0) {
      uStack_50 = (uStack_50 * 0x10000 + 0x10000 & 0x7f0000) >> 0x10;
      iVar4 = (int)*(short *)(uStack_50 * 2 + DWORD_0800c150);
      if (iVar4 < 0) {
        iVar4 = iVar4 + 0x1f;
      }
      sub_0800903C(4,0x32,1,(iVar4 >> 5) + 8U & 0xffff,0xc,0);
    }
    if (iStack_70 != 0) {
      *(undefined2 *)DWORD_0800c154 = 0;
    }
    iVar4 = sub_0801AAE0();
    if (iVar4 != 0) {
      iVar4 = sub_0805813C(1,0x31);
      if (iVar4 == 0) {
        sub_08057CAC(0x11);
      }
      else {
        uStack_68 = uStack_68 + 1;
      }
      iVar4 = sub_0805813C(1,0x2c);
      if (iVar4 == 0) {
        sub_08057CAC(0x17);
      }
      else {
        uStack_64 = uStack_64 + 1;
      }
      if ((0x28 < uStack_68) && (sub_08057C6C(0x11), iStack_48 == 0)) {
        sub_0805865C(0x3a);
        iStack_48 = 1;
      }
      if ((0x3c < uStack_64) && (sub_08057C6C(0x17), iStack_44 == 0)) {
        sub_0805865C(0x3b);
        iStack_44 = 1;
      }
      uStack_74 = 0xff;
      uVar23 = 0;
      do {
        if (((uVar23 == 0) || (iVar4 = sub_08057C34(uVar23), iVar4 != 0)) &&
           ((uVar23 != 0xe || ((*(uint *)DWORD_0800c230 >> 1 & 1) == 0)))) {
          iVar7 = uVar23 * 4;
          iVar4 = (uint)*(ushort *)(iVar7 + DWORD_0800c234) - (iStack_5c >> 8);
          if (iVar4 < 0) {
            iVar4 = -iVar4;
          }
          if (iVar4 < (int)(uint)*(ushort *)(iVar7 + DWORD_0800c238)) {
            iVar4 = (uint)*(ushort *)(iVar7 + DWORD_0800c234 + 2) - (iStack_58 >> 8);
            if (iVar4 < 0) {
              iVar4 = -iVar4;
            }
            if ((iVar4 < (int)(uint)*(ushort *)(iVar7 + DWORD_0800c238 + 2)) &&
               (uStack_74 = uVar23, iStack_4c == 0)) {
              if (uVar23 < 0xf) {
                sub_0805865C(0x3a);
              }
              else {
                sub_0805865C(0x3b);
              }
              iStack_4c = 1;
            }
          }
        }
        uVar23 = uVar23 + 1;
      } while (uVar23 < 0x18);
      if ((uStack_74 == 0xff) && (iStack_4c != 0)) {
        sub_0805865C(0x3c);
        iStack_4c = 0;
      }
      uVar23 = uStack_74;
      uVar2 = *(ushort *)DWORD_0800c2a8;
      if (((uVar2 & 0x200) == 0) && ((uVar2 & 0x100) == 0)) {
        if ((uVar2 & 1) == 0) {
          if (((uVar2 & 2) != 0) && (iStack_70 != 0)) {
            sub_0805865C(0x10);
            iStack_70 = 0;
          }
        }
        else if (iStack_70 == 0) {
          if (uStack_74 == 0xff) {
            sub_0805865C(0x61);
          }
          else {
            sub_0805865C(0xf);
            iStack_70 = 1;
            if (uVar23 == 0) goto LAB_0800c87e;
          }
        }
      }
    }
    piVar16 = (int *)(uStack_6c * 0x14c + DWORD_0800c320);
    *(ushort *)(*piVar16 + 4) = *(ushort *)(*piVar16 + 4) | 0x3c0;
    if (iStack_70 == 0) {
      *(byte *)(*piVar16 + 7) = *(byte *)(*piVar16 + 7) & 0xf0;
    }
    else {
      *(byte *)(*piVar16 + 7) = *(byte *)(*piVar16 + 7) & 0xf0 | 1;
      *(undefined2 *)DWORD_0800c324 = 0;
      iStack_5c = (uint)*(ushort *)(uStack_74 * 4 + DWORD_0800c328) << 8;
      iStack_58 = (uint)*(ushort *)(uStack_74 * 4 + DWORD_0800c328 + 2) << 8;
    }
    uVar23 = 0;
    if (uStack_60 != 0) {
      piVar21 = (int *)(uStack_6c * 0x14c + DWORD_0800c3c4);
      iStack_2c = DWORD_0800c3c0 + 0xb4;
      iStack_28 = DWORD_0800c3c0 + 0xb2;
      puStack_24 = (undefined2 *)(DWORD_0800c3c0 + 0xb0);
      piStack_3c = (int *)(uStack_6c * 0x14c + DWORD_0800c3c8);
      puVar5 = puStack_34;
      puVar9 = puStack_30;
      piVar16 = (int *)DWORD_0800c3c4;
      puVar12 = (ushort *)DWORD_0800c3c0;
      do {
        *puVar5 = uVar23;
        *puVar9 = 0;
        if (((uint)*(ushort *)(*(int *)(puVar12 + 0xa4) + 4) << 0x16) >> 0x1c == 0xf) {
          if (*puVar12 == uStack_6c) {
            bVar1 = **(byte **)(uStack_6c * 0x14c + DWORD_0800c3c8);
            if ((bVar1 & 0xf) == 0) {
              if ((*(ushort *)DWORD_0800c400 & 0xf0) != 0) {
                pbVar10 = *(byte **)(uStack_6c * 0x14c + DWORD_0800c404);
                *pbVar10 = *pbVar10 & 0xf0 | 1;
              }
              iStack_54 = iStack_54 + -0x80;
              if (iStack_54 < 0) {
                iStack_54 = 0;
              }
            }
            else if ((bVar1 & 0xf) == 1) {
              cVar13 = '\0';
              if ((*(ushort *)DWORD_0800c41c & 0x40) == 0) {
                if ((*(ushort *)DWORD_0800c41c & 0x80) != 0) {
                  cVar13 = '\x01';
                }
              }
              else {
                cVar13 = '\x05';
              }
              if ((*(ushort *)DWORD_0800c41c & 0x20) == 0) {
                cVar14 = cVar13;
                if ((((*(ushort *)DWORD_0800c41c & 0x10) != 0) &&
                    (cVar14 = '\x06', cVar13 != '\x05')) && (cVar14 = '\a', cVar13 == '\x01')) {
                  cVar14 = '\b';
                }
              }
              else {
                cVar14 = '\x04';
                if ((cVar13 != '\x05') && (cVar14 = '\x03', cVar13 == '\x01')) {
                  cVar14 = '\x02';
                }
              }
              if (cVar14 == '\0') {
                pbVar10 = (byte *)*piVar21;
                *pbVar10 = *pbVar10 & 0xf0;
              }
              else {
                iVar4 = *piVar21;
                *(byte *)(iVar4 + 3) = *(byte *)(iVar4 + 3) & 0xf | (cVar14 + -1) * '\x10';
                iStack_54 = iStack_54 + 0x80;
                if ((int)DWORD_0800c488 < iStack_54) {
                  iStack_54 = DWORD_0800c488 + 1;
                }
              }
            }
            uVar22 = (uint)*(ushort *)((uint)(*(byte *)(*piStack_3c + 3) >> 4) * 2 + DWORD_0800c628)
            ;
            iVar4 = iStack_54 * *(short *)(uVar22 * 2 + DWORD_0800c624);
            if (iVar4 < 0) {
              iVar4 = iVar4 + 0xff;
            }
            iStack_58 = iStack_58 + (iVar4 >> 8);
            iVar4 = iStack_54 * *(short *)((uVar22 + 0x40) * 2 + DWORD_0800c624);
            if (iVar4 < 0) {
              iVar4 = iVar4 + 0xff;
            }
            iStack_5c = iStack_5c + (iVar4 >> 8);
            if (iStack_5c >> 8 < 8) {
              iStack_5c = 0x800;
            }
            if (0xe8 < iStack_5c >> 8) {
              iStack_5c = 0xe800;
            }
            if (iStack_58 >> 8 < 8) {
              iStack_58 = 0x800;
            }
            if (0x98 < iStack_58 >> 8) {
              iStack_58 = 0x9800;
            }
            *(ushort *)*piVar16 = *(ushort *)*piVar16 & 0xf | (ushort)((iStack_5c >> 8) << 4);
            *(ushort *)(*piVar16 + 2) =
                 *(ushort *)(*piVar16 + 2) & (ushort)DWORD_0800c62c |
                 (ushort)((uint)(iStack_58 << 0xc) >> 0x14);
            *(uint *)(*piVar16 + 4) =
                 *(uint *)(*piVar16 + 4) & DWORD_0800c630 | (uStack_74 & 0xff) << 0xb;
          }
          sub_08065370(auStack_178,*puStack_24,iStack_28,iStack_2c,1);
          *puVar5 = uVar23;
          *puVar9 = *(ushort *)(piVar16[1] + 2) & 0xfff;
        }
        puVar9 = puVar9 + 2;
        iStack_2c = iStack_2c + 0x14c;
        iStack_28 = iStack_28 + 0x14c;
        puStack_24 = puStack_24 + 0xa6;
        piVar16 = piVar16 + 0x53;
        puVar5 = puVar5 + 2;
        puVar12 = puVar12 + 0xa6;
        uVar23 = uVar23 + 1;
      } while (uVar23 < uStack_60);
    }
    uVar23 = 0;
    puVar5 = puStack_34;
    puVar9 = puStack_30;
    if (uStack_60 != 0) {
      do {
        uVar22 = uVar23 + 1;
        if (uVar22 < uStack_60) {
          puVar17 = puStack_30 + uVar22 * 2;
          puVar18 = puStack_34 + uVar22 * 2;
          do {
            if (*puVar9 < *puVar17) {
              uVar11 = *puVar5;
              uVar6 = *puVar18;
              *puVar5 = uVar11 ^ uVar6;
              uVar6 = *puVar18 ^ uVar11 ^ uVar6;
              *puVar18 = uVar6;
              *puVar5 = *puVar5 ^ uVar6;
              uVar11 = *puVar9;
              uVar6 = *puVar17;
              *puVar9 = uVar11 ^ uVar6;
              uVar6 = *puVar17 ^ uVar11 ^ uVar6;
              *puVar17 = uVar6;
              *puVar9 = *puVar9 ^ uVar6;
            }
            puVar17 = puVar17 + 2;
            puVar18 = puVar18 + 2;
            uVar22 = uVar22 + 1;
          } while (uVar22 < uStack_60);
        }
        uVar23 = uVar23 + 1;
        puVar5 = puVar5 + 2;
        puVar9 = puVar9 + 2;
      } while (uVar23 < uStack_60);
    }
    for (uVar23 = 0; uVar23 < uStack_60; uVar23 = uVar23 + 1) {
      iVar4 = puStack_34[uVar23 * 2] * 0x14c + DWORD_0800c694;
      puVar12 = *(ushort **)(iVar4 + 0x148);
      if (((uint)puVar12[2] << 0x16) >> 0x1c == 0xf) {
        if (uStack_6c == puStack_34[uVar23 * 2]) {
          if ((*(byte *)((int)puVar12 + 7) & 0xf) == 0) {
LAB_0800c6a4:
            sub_08065230(auStack_178,*puVar12 >> 4,puVar12[1] & 0xfff,*(undefined2 *)(iVar4 + 0xb0),
                         *(undefined2 *)(iVar4 + 0xb2));
          }
          else {
            sub_08065264(auStack_178,*puVar12 >> 4,puVar12[1] & 0xfff,*(undefined2 *)(iVar4 + 0xb0),
                         *(undefined2 *)(iVar4 + 0xb2));
          }
        }
        else if ((*(uint *)DWORD_0800c698 & 1) != 0) {
          if ((*(byte *)((int)puVar12 + 7) & 0xf) == 0) goto LAB_0800c6a4;
          sub_08065264(auStack_178,*puVar12 >> 4,puVar12[1] & 0xfff,*(undefined2 *)(iVar4 + 0xb0),
                       *(undefined2 *)(iVar4 + 0xb2));
        }
      }
    }
    uVar23 = 0;
    puVar8 = (undefined2 *)DWORD_0800c74c;
    do {
      if (((uVar23 == 0) || (iVar4 = sub_08057C34(uVar23), iVar4 != 0)) &&
         ((uVar23 != 0xe || ((*(uint *)DWORD_0800c750 >> 1 & 1) == 0)))) {
        puVar19 = auStack_f8 + uVar23;
        sub_08065370(puStack_38,uVar23 & 0xffff,puVar19,auStack_c8 + uVar23 * 2,1);
        if (uVar23 == uStack_74) {
          sub_080652E0(puStack_38,*puVar8,puVar8[1],uVar23 & 0xffff,*puVar19,1);
        }
        else {
          sub_080659BC(puStack_38,*puVar8,puVar8[1],uVar23,*puVar19,1);
        }
      }
      puVar8 = puVar8 + 2;
      uVar23 = uVar23 + 1;
    } while (uVar23 < 0x18);
    if ((*(uint *)DWORD_0800c7b0 >> 8 & 1) == 0) {
      if (uStack_74 == 0xff) {
        sub_0801A664(0x12,2);
      }
      else {
        iVar4 = sub_08007290(uStack_74 + DWORD_0800c7b4 | 0x140000);
        iVar7 = sub_0801A638(iVar4 + 2);
        sub_0801A3D0(iVar4 + 2,0xf - iVar7 / 2,0x12);
      }
    }
    sub_080003F0();
    iVar4 = sub_08002204();
    if (iVar4 == 0) {
      if ((*(byte *)(*(int *)(DWORD_0800c894 + 0x148) + 7) & 0xf) == 2) goto LAB_0800c852;
      goto LAB_0800c0b2;
    }
    uVar23 = 0;
    sVar20 = 0;
    uVar22 = 0;
    if (uStack_60 != 0) {
      piVar16 = (int *)(DWORD_0800c838 + 0x148);
      do {
        if (((*(byte *)(*piVar16 + 7) & 0xf) != 0) &&
           (uStack_74 == (uint)(*(int *)(*piVar16 + 4) << 0xd) >> 0x18)) {
          uVar23 = uVar23 * 0x10000 + 0x10000 >> 0x10;
        }
        sVar20 = (short)uVar23;
        piVar16 = piVar16 + 0x53;
        uVar22 = uVar22 + 1;
      } while (uVar22 < uStack_60);
    }
    if ((int)sVar20 == uStack_60) {
      *(byte *)(*(int *)(DWORD_0800c838 + 0x148) + 7) =
           *(byte *)(*(int *)(DWORD_0800c838 + 0x148) + 7) & 0xf0 | 2;
LAB_0800c852:
      if ((uStack_74 != 0) && (iVar4 = sub_08002204(), iVar4 != 0)) {
        *(byte *)(*(int *)(DWORD_0800c894 + 0x144) + 7) =
             *(byte *)(*(int *)(DWORD_0800c894 + 0x144) + 7) & 0xf0 | 2;
        sub_08057624(5);
      }
LAB_0800c87e:
      sub_0801A664(0,0x14);
      dVar3 = DWORD_0800c978;
      if (uStack_74 == 0) {
        bVar1 = *(byte *)(DWORD_0800c978 + 3);
        while ((bVar1 & 1) != 0) {
          sub_080003F0();
          bVar1 = *(byte *)(dVar3 + 3);
        }
      }
      else {
        sub_08067C18();
        while (iVar4 = sub_08067C08(), iVar4 == 0) {
          sub_080003F0();
        }
        sub_08067BF8();
      }
      sub_08022E60(uStack_74,1);
      sub_080003F0();
      sub_0801A664(2,0xc);
      sub_080003F0();
      sub_0801A664(2,0xc);
      sub_080003F0();
      sub_080586D0(2);
      sub_0801ABE8(6);
      dVar3 = DWORD_0800c97c;
      iVar7 = uStack_6c * 0x14c;
      piVar16 = (int *)(iVar7 + DWORD_0800c97c + 0x144);
      iVar4 = *piVar16;
      *(byte *)(iVar4 + 7) = *(byte *)(iVar4 + 7) & 0xf0;
      iVar4 = *piVar16;
      *(ushort *)(iVar4 + 4) = (ushort)DWORD_0800c980 & *(ushort *)(iVar4 + 4);
      sub_08058404(uStack_40);
      if (**(short **)DWORD_0800c984 == 0) {
        (*(short **)DWORD_0800c984)[0x1b] = 0;
        *(undefined2 *)(iVar7 + dVar3 + 0x1c) = 4;
      }
      else {
        *(uint *)DWORD_0800c978 = *(uint *)DWORD_0800c978 & DWORD_0800c988;
        sub_08056E64();
        sub_0805A66C();
        uVar23 = 0;
        do {
          sub_080003F0();
          uVar23 = uVar23 + 1;
        } while (uVar23 < 0x14);
        *(undefined2 *)(uStack_6c * 0x14c + DWORD_0800c97c + 0x2e) = 0;
        sub_08057170();
        sub_080572A4();
        sub_080169C8();
        sub_0805D4F4();
        sub_080003F0();
      }
      sub_08056E78();
      dVar3 = DWORD_0800c9e4;
      *(uint *)DWORD_0800c9e4 = *(uint *)DWORD_0800c9e4 & 0xffffffdf;
      sub_08065158(puStack_38,DWORD_0800c9e8,9,4,0);
      sub_0800903C(0,0,0,0,0,0);
      *(uint *)dVar3 = *(uint *)dVar3 & DWORD_0800c9ec;
      sub_08000420(DWORD_0800c9f0);
      return in_lr;
    }
  } while( true );
}


