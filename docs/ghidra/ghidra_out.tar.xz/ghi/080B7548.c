
undefined4 SoundInit(dword *param_1)

{
  dword dVar1;
  undefined4 in_lr;
  undefined4 uStack_10;
  
  *param_1 = 0;
  dVar1 = DWORD_080b75dc;
  *(undefined2 *)DWORD_080b75dc = 0;
  *(undefined2 *)(dVar1 + 0xc) = 0;
  dVar1 = DWORD_080b75e0;
  *(undefined2 *)DWORD_080b75e0 = 0x8f;
  *(short *)(dVar1 - 2) = (short)DWORD_080b75e4;
  *(byte *)DWORD_080b75e8 = *(byte *)DWORD_080b75e8 & 0x3f | 0x40;
  dVar1 = DWORD_080b75ec;
  *(dword **)DWORD_080b75ec = param_1 + 0xd4;
  *(dword *)(dVar1 + 4) = DWORD_080b75f0;
  *(dword **)(dVar1 + 0xc) = param_1 + 0x260;
  *(dword *)(dVar1 + 0x10) = DWORD_080b75f4;
  *(dword **)DWORD_080b75f8 = param_1;
  uStack_10 = 0;
  CpuSet(&uStack_10,param_1,DWORD_080b75fc);
  *(undefined1 *)((int)param_1 + 6) = 8;
  *(undefined1 *)((int)param_1 + 7) = 0xf;
  param_1[0xe] = DWORD_080b7600;
  dVar1 = DWORD_080b7604;
  param_1[10] = DWORD_080b7604;
  param_1[0xb] = dVar1;
  param_1[0xc] = dVar1;
  param_1[0xf] = dVar1;
  dVar1 = DWORD_080b7608;
  MPlayJumpTableCopy(DWORD_080b7608);
  param_1[0xd] = dVar1;
  SampleFreqSet(0x40000);
  *param_1 = DWORD_080b760c;
  return in_lr;
}


