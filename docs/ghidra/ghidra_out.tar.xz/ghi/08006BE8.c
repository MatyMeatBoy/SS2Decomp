
undefined4 sub_08006BE8(void)

{
  undefined4 in_lr;
  
  m4aMPlayAllStop();
  sub_08006C14();
  return in_lr;
}


