
undefined4 sub_0802F424(int param_1)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  undefined4 in_lr;
  
  iVar1 = sub_08002164();
  if (iVar1 == 1) {
    sub_0802939C(param_1,5);
    sub_08028D98(param_1,0x28,100,0x3c);
    piVar2 = (int *)(*(int *)DWORD_0802f460 + DWORD_0802f464);
    uVar3 = 0;
    do {
      if (*piVar2 == param_1) goto LAB_0802f49a;
      uVar3 = uVar3 + 1;
      piVar2 = piVar2 + 0x1c;
    } while (uVar3 < 0xf);
  }
  else {
    sub_0802939C(param_1,5);
    sub_08028D98(param_1,0,100,0x3c);
    piVar2 = (int *)(*(int *)DWORD_0802f4a8 + DWORD_0802f4ac);
    uVar3 = 0;
    do {
      if (*piVar2 == param_1) goto LAB_0802f49a;
      uVar3 = uVar3 + 1;
      piVar2 = piVar2 + 0x1c;
    } while (uVar3 < 0xf);
  }
  sub_080003F0();
  piVar2 = (int *)0x0;
LAB_0802f49a:
  if (piVar2 != (int *)0x0) {
    *(undefined2 *)((int)piVar2 + 0x36) = 4;
  }
  return in_lr;
}


