
undefined4 sub_080B4B48(void)

{
  dword dVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_lr;
  
  dVar1 = DWORD_080b4b78;
  iVar2 = sub_08001494(0xa0);
  *(int *)dVar1 = iVar2;
  if (iVar2 != 0) {
    uVar3 = 0;
    do {
      *(undefined4 *)(uVar3 * 0x28 + *(int *)dVar1 + 8) = 0;
      uVar3 = uVar3 + 1 & 0xff;
    } while (uVar3 < 4);
  }
  return in_lr;
}


