
undefined4 sub_08024538(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_08024558;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & DWORD_0802455c | 1;
  while (iVar2 = sub_08067D74(), iVar2 == 0) {
    sub_08057624(1);
  }
  sub_08057624(0x3c);
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & 0xfffffffc;
  while (iVar2 = sub_08067D74(), iVar2 == 0) {
    sub_08057624(1);
  }
  iVar2 = sub_0800CF80();
  if (iVar2 == 0) {
    *(undefined1 *)(iVar1 + 0x68) = 1;
  }
  while (iVar2 = sub_0806617C(), iVar2 == 0) {
    sub_08057624(1);
  }
  if (param_1 == 0) {
    uVar3 = *(uint *)(iVar1 + 0x30);
    uVar4 = 0x800000;
  }
  else {
    uVar3 = *(uint *)(iVar1 + 0x30);
    uVar4 = 0x1000000;
  }
  *(uint *)(iVar1 + 0x30) = uVar3 | uVar4;
  return in_lr;
}


