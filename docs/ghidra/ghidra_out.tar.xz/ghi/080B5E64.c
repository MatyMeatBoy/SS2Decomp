
undefined4 sub_080B5E64(void)

{
  int iVar1;
  dword dVar2;
  ushort uVar3;
  short sVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  short *psVar8;
  int iVar9;
  int iVar10;
  uint uVar11;
  undefined4 in_lr;
  
  uVar11 = 1;
  psVar8 = (short *)(*(int *)DWORD_080b5f40 + 0x32a);
  iVar1 = *(int *)DWORD_080b5f40;
  do {
    dVar2 = DWORD_080b5f48;
    if ((*(uint *)DWORD_080b5f44 & 1 << uVar11) != 0) {
      iVar10 = (*(int *)(*(int *)DWORD_080b5f48 + 0x14) - *(int *)(iVar1 + 0x2f4)) * 0x100 >> 0x10;
      iVar9 = (*(int *)(*(int *)DWORD_080b5f48 + 0x18) - *(int *)(iVar1 + 0x2f8)) * 0x100 >> 0x10;
      uVar3 = Sqrt(iVar10 * iVar10 + iVar9 * iVar9);
      if (((((uVar3 < 0x14) && (*(short *)(*(int *)dVar2 + 0x5c) != 0)) && (psVar8[0x19] == 0)) &&
          ((iVar5 = sub_0800CDF8(), iVar5 == 0 && (iVar5 = sub_0800CD8C(), iVar5 == 0)))) &&
         ((iVar5 = sub_0800CCCC(), iVar5 == 0 &&
          ((iVar5 = *(int *)dVar2, *(short *)(iVar5 + 0xc) != 0xb &&
           (*(int *)(iVar1 + 0x334) != *(int *)(iVar5 + 0x50))))))) {
        *(undefined2 *)(iVar1 + 0x2ec) = 10;
        sVar4 = sub_0801EF14(iVar5,iVar1 + 0x2e0);
        *psVar8 = *psVar8 + sVar4;
        iVar6 = *(int *)dVar2;
        iVar5 = *(int *)(iVar6 + 0x50);
        *(int *)(iVar1 + 0x334) = iVar5;
        *(int *)(iVar6 + 0x50) = iVar5 + 1;
        iVar9 = ArcTan2(iVar10,iVar9);
        uVar7 = (uint)(iVar9 << 0x10) >> 0x1d;
        if (0x80000000 < (uint)(iVar9 * 0x80000)) {
          if (uVar7 < 7) {
            uVar7 = uVar7 + 1;
          }
          else {
            uVar7 = 0;
          }
        }
        if (uVar7 == 0) {
          sVar4 = 6;
        }
        else if (uVar7 == 1) {
          sVar4 = 7;
        }
        else {
          sVar4 = (short)uVar7 + -2;
        }
        psVar8[0x1a] = sVar4;
        psVar8[0x1b] = 0x400;
        *(undefined2 *)(iVar1 + 0x35c) = 8;
      }
    }
    psVar8 = psVar8 + 0x170;
    uVar11 = uVar11 + 1 & 0xff;
    iVar1 = iVar1 + 0x2e0;
  } while (uVar11 < 5);
  return in_lr;
}


