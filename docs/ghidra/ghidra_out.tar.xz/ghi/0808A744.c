
undefined8 sub_0808A744(int param_1)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  ushort *puVar5;
  undefined4 in_lr;
  
  if (*(short *)(*(int *)DWORD_0808a754 + 0x10) == 0) {
    while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
      sub_080003F0();
    }
    iVar2 = sub_080020F4();
    puVar5 = (ushort *)(param_1 + (uint)*(ushort *)(*(int *)DWORD_0808a7c0 + 0x36) * 0x24 + 4);
    sub_0800CCDC();
    iVar3 = sub_080020F4();
    dVar1 = DWORD_0808a7c4;
    iVar3 = iVar3 * 0x14c;
    *(uint *)(iVar3 + DWORD_0808a7c4 + 0x8c) = (uint)*puVar5 << 8;
    *(uint *)(iVar3 + dVar1 + 0x90) = (uint)puVar5[1] << 8;
    iVar3 = iVar3 + dVar1;
    *(undefined4 *)(iVar3 + 0x94) = *(undefined4 *)(iVar3 + 0x8c);
    *(undefined4 *)(iVar3 + 0x98) = *(undefined4 *)(iVar3 + 0x90);
    sub_08009930(0,10);
    while (iVar3 = sub_0800BA6C(), iVar3 == 0) {
      sub_080003F0();
    }
    iVar2 = iVar2 * 0x14c + DWORD_0808a80c;
    uVar4 = sub_0800CCCC();
    sub_0800AD04(iVar2,iVar2 + 4,uVar4);
    sub_08057328(0,DWORD_0808a810);
    sub_08015EF8();
    sub_08015C38();
    iVar2 = *(int *)DWORD_0808a814;
    *(undefined2 *)(iVar2 + 0x10) = 1;
    *(undefined2 *)(iVar2 + 0x1c) = 1;
  }
  else {
    iVar2 = sub_08088B6C(param_1,1);
    if (iVar2 != 0) {
      uVar4 = 1;
      goto LAB_0808a82a;
    }
  }
  uVar4 = 0;
LAB_0808a82a:
  return CONCAT44(in_lr,uVar4);
}


