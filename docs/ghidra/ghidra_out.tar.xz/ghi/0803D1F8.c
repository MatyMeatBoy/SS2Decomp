
undefined4 sub_0803D1F8(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_0803d224;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) | 1;
  sub_0800D0F4();
  sub_0802949C(param_1,0);
  while (iVar1 = sub_0805F184(), iVar1 != 0) {
    sub_080003F0();
  }
  uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,DWORD_0803d250);
  while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
    sub_080003F0();
  }
  iVar1 = sub_0805EF14(uVar2);
  if (iVar1 != 0) {
    iVar1 = sub_0800CE30();
    if (iVar1 == 0) {
      iVar3 = *(int *)DWORD_0803d2ac;
      iVar1 = 0x1b8;
    }
    else {
      iVar3 = *(int *)DWORD_0803d280;
      iVar1 = 0x1c4;
    }
    *(byte *)(iVar3 + iVar1) = *(byte *)(iVar3 + iVar1) | 0x40;
    if ((*(uint *)DWORD_0803d2b0 & 0x20) == 0) {
      sub_08006D08(0x32);
    }
  }
  while (iVar1 = sub_0805F184(), iVar1 != 0) {
    sub_080003F0();
  }
  uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,DWORD_0803d2dc);
  while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
    sub_080003F0();
  }
  iVar1 = sub_0805EF14(uVar2);
  if (iVar1 != 0) {
    iVar1 = sub_0800CE30();
    if (iVar1 == 0) {
      iVar3 = *(int *)DWORD_0803d360;
      iVar1 = 0x1b8;
    }
    else {
      iVar3 = *(int *)DWORD_0803d30c;
      iVar1 = 0x1c4;
    }
    *(byte *)(iVar3 + iVar1) = *(byte *)(iVar3 + iVar1) | 0x80;
    if ((*(uint *)DWORD_0803d364 & 0x20) == 0) {
      sub_08006D08(0x32);
    }
  }
  sub_08029788(param_1);
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_0803d368;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


