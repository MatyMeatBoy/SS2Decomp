
undefined4 sub_08021214(uint param_1,uint param_2)

{
  undefined1 uVar1;
  short sVar2;
  int iVar3;
  undefined4 in_lr;
  undefined4 auStack_64 [2];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined1 uStack_48;
  undefined1 uStack_47;
  undefined2 uStack_30;
  undefined2 uStack_2e;
  short sStack_2c;
  short sStack_2a;
  uint uStack_28;
  uint uStack_24;
  
  sub_08065158(auStack_64,DWORD_08021274,1,0xffffffff,0);
  sub_08000AF0(0x17,uStack_58,2);
  uStack_48 = 7;
  uStack_47 = 8;
  uStack_28 = DWORD_08021278 & param_1;
  uStack_24 = param_2 >> 0x10;
  param_2 = param_2 & 0xff;
  uStack_30 = 0;
  uStack_2e = 0;
  sVar2 = 0;
  sub_0805865C(param_2 + DWORD_0802127c);
  while ((iVar3 = sub_0800CB78(), iVar3 == 0 && (sVar2 == 0))) {
    sVar2 = sub_08065370(auStack_64,param_2,&uStack_30,&uStack_2e,0);
    iVar3 = sub_0800CC98();
    if ((iVar3 == 0) &&
       ((iVar3 = sub_0800CD8C(), iVar3 == 0 && (iVar3 = sub_0800CCCC(), iVar3 == 0)))) {
      sub_0800BC08((int)(short)uStack_28,(int)(short)(param_1 >> 0x10),&sStack_2c,&sStack_2a,0x10,0)
      ;
      uVar1 = sub_0800BC44(uStack_28,param_1 >> 0x10,0);
      sub_08007870((int)sStack_2c,sStack_2a + 1,param_2,uStack_30,uVar1,&uStack_48,uStack_5c,
                   auStack_64[0]);
    }
    sub_080003F0();
  }
  *(uint *)DWORD_08021338 = *(uint *)DWORD_08021338 & ~(1 << (uStack_24 & 0xff));
  return in_lr;
}


