
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_080308B4(void)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_080308e8;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) | 1;
  sub_0800D0F4();
  iVar1 = sub_0800CE30();
  if (iVar1 == 0) {
    iVar1 = *(int *)DWORD_0803090c;
    iVar3 = 0x1b2;
  }
  else {
    iVar1 = *(int *)DWORD_080308ec;
    iVar3 = 0x1be;
  }
  switch(*(undefined1 *)(iVar1 + iVar3)) {
  case 0:
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,_UNK_0803095c);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      iVar1 = sub_0800CDF8();
      if (iVar1 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
    break;
  case 1:
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,_UNK_080309b4);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      iVar1 = sub_0800CDF8();
      if (iVar1 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
    break;
  case 2:
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,_UNK_08030a0c);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      iVar1 = sub_0800CDF8();
      if (iVar1 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
    break;
  case 3:
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,_UNK_08030a60);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      iVar1 = sub_0800CDF8();
      if (iVar1 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
    iVar1 = sub_0800CE30();
    if (iVar1 == 0) {
      iVar3 = *_UNK_08030aa4;
      iVar1 = _UNK_08030aa8;
    }
    else {
      iVar3 = *_UNK_08030a90;
      iVar1 = _UNK_08030a94;
    }
    *(undefined1 *)(iVar3 + iVar1) = 3;
    break;
  case 4:
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,_UNK_08030ae0);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      iVar1 = sub_0800CDF8();
      if (iVar1 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
  }
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_08030b24;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


