
undefined4 sub_0805990C(uint param_1)

{
  int iVar1;
  dword dVar2;
  byte *pbVar3;
  undefined4 in_lr;
  
  iVar1 = sub_0800CE30();
  if (iVar1 == 0) {
    iVar1 = *(int *)DWORD_0805994c;
    dVar2 = DWORD_08059950;
  }
  else {
    iVar1 = *(int *)DWORD_08059928;
    dVar2 = DWORD_0805992c;
  }
  pbVar3 = (byte *)(iVar1 + dVar2 + (param_1 >> 3));
  *pbVar3 = (byte)(1 << (param_1 & 7)) | *pbVar3;
  return in_lr;
}


