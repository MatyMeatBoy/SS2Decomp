
bool sub_08092080(void)

{
  return *(char *)DWORD_0809208c == '\r';
}


