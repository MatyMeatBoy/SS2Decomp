
/* WARNING: Possible PIC construction at 0x0809e4ba: Changing call to branch */
/* WARNING: Possible PIC construction at 0x0809ec92: Changing call to branch */

void sub_0809E468(void)

{
  dword dVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  bool bVar5;
  ushort auStack_2c [4];
  int iStack_24;
  
  bVar5 = false;
  *(undefined2 *)DWORD_0809e504 = 0;
  *(undefined1 *)DWORD_0809e508 = 0;
  *(undefined1 *)DWORD_0809e50c = 0;
  *(undefined1 *)DWORD_0809e510 = 0;
  iStack_24 = 1;
  do {
    iVar2 = sub_0800CD8C();
    if ((((iVar2 == 0) && (iVar2 = sub_0800CCCC(), iVar2 == 0)) &&
        (iVar2 = sub_0800CD34(), iVar2 == 0)) && (iVar2 = sub_0800CC98(), iVar2 == 0)) {
      bVar5 = false;
      sub_0800BD48(2,0);
      sub_0800115C(DWORD_0809e550);
      sub_080011E4(DWORD_0809e554);
      if (*(short *)(*(int *)DWORD_0809e558 + 0x5c) == 0) {
        iStack_24 = 0;
      }
      else if (*(byte *)DWORD_0809e570 < 9) {
                    /* WARNING: Could not recover jumptable at 0x0809e56e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)((uint)*(byte *)DWORD_0809e570 * 4 + DWORD_0809e574))();
        return;
      }
      if (*(byte *)DWORD_0809ea74 < 9) {
                    /* WARNING: Could not recover jumptable at 0x0809ea72. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)((uint)*(byte *)DWORD_0809ea74 * 4 + DWORD_0809ea78))();
        return;
      }
    }
    else if (!bVar5) {
      bVar5 = true;
      sub_08000E48();
      sub_0800CC18();
      sub_0800115C(0);
      sub_080011E4(0);
      sub_0800903C(0,0,0,0,0,0);
      sub_0800BD48(2,1);
      iVar2 = sub_0800CD8C();
      if (iVar2 == 0) {
        sub_080009C0(0x400,0,0);
      }
      else {
        sub_080009F8(0x400,0,0);
      }
    }
    sub_080003F0();
    if (iStack_24 == 0) {
      bVar5 = false;
      uVar4 = 0;
      *(undefined2 *)DWORD_0809ed24 = 0;
      *(undefined1 *)DWORD_0809ed28 = 0;
      *(undefined1 *)DWORD_0809ed2c = 0;
      *(undefined1 *)DWORD_0809ed30 = 0;
      dVar1 = DWORD_0809ed34;
      do {
        iVar2 = sub_0800CD8C();
        if (((iVar2 == 0) && (iVar2 = sub_0800CCCC(), iVar2 == 0)) &&
           ((iVar2 = sub_0800CD34(), iVar2 == 0 && (iVar2 = sub_0800CC98(), iVar2 == 0)))) {
          bVar5 = false;
          sub_0800BD48(2);
          sub_0800115C(DWORD_0809edd4);
          sub_080011E4(DWORD_0809edd8);
          uVar3 = __modsi3((int)(uVar4 * 0x10000 + DWORD_0809eddc) >> 0x10,0xff);
          uVar4 = uVar3 & 0xffff;
          sub_0800BBA8(2,0,(int)(short)uVar3);
          auStack_2c[0] = (ushort)dVar1 & *(ushort *)DWORD_0809ede0 | 1;
          sub_08000AA8(1,auStack_2c);
          auStack_2c[0] = (ushort)dVar1 & *(ushort *)DWORD_0809ede4 | 2;
          sub_08000AA8(2,auStack_2c);
          sub_0800903C(4,0x28,1,6,0xe,0);
          sub_0800CC18();
          if (*(ushort *)(DWORD_0809ede8 + 6) < 0x3a) {
            sub_08001108(0x3a - (uint)*(ushort *)(DWORD_0809ede8 + 6));
          }
          else {
            sub_08001108(0);
          }
          sub_08000D8C();
        }
        else if (!bVar5) {
          bVar5 = true;
          sub_08000E48();
          sub_0800CC18();
          sub_0800115C(0);
          sub_080011E4(0);
          sub_0800903C(0,0,0,0,0,0);
          sub_0800BD48(2,1);
          iVar2 = sub_0800CD8C();
          if (iVar2 == 0) {
            sub_080009C0(0x400,0,0);
          }
          else {
            sub_080009F8(0x400,0,0);
          }
        }
        sub_080003F0();
      } while( true );
    }
  } while( true );
}


