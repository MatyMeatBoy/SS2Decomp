
undefined4 sub_08098044(void)

{
  dword dVar1;
  int iVar2;
  undefined4 in_lr;
  
  dVar1 = DWORD_0809805c;
  iVar2 = sub_08001494(0x28);
  *(int *)dVar1 = iVar2;
  *(undefined4 *)(iVar2 + 8) = 0;
  return in_lr;
}


