
undefined8 sub_0801FC34(int *param_1,ushort *param_2,undefined4 param_3)

{
  undefined1 uVar1;
  ushort uVar2;
  int *piVar3;
  bool bVar4;
  uint uVar5;
  int iVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  undefined4 in_lr;
  uint uStack_24;
  
  iVar6 = *(int *)(*(int *)DWORD_0801fc58 + 0x48);
  if (iVar6 == 0) {
    piVar3 = (int *)0x0;
  }
  else {
    piVar7 = (int *)(*(int *)DWORD_0801fc58 + DWORD_0801fd18);
    uVar9 = 0;
    piVar3 = param_1;
    piVar10 = (int *)DWORD_0801fc58;
    if (iVar6 != 0) {
      do {
        if ((2 < (ushort)((short)piVar7[5] - 10U)) && ((*(byte *)(piVar7[8] + 6) & 1) == 0)) {
          uVar5 = (uStack_24 & DWORD_0801fd1c | (uint)*(ushort *)(piVar7[8] + 0xc)) & DWORD_0801fd20
          ;
          uStack_24 = uVar5 | (uint)*(ushort *)(piVar7[8] + 0xe) << 0x10;
          iVar8 = param_1[1] - piVar7[1] >> 8;
          iVar6 = *param_1 - *piVar7 >> 8;
          if (iVar6 < 0) {
            iVar6 = -iVar6;
          }
          if ((int)((uint)*param_2 + (uVar5 & 0xffff)) >> 1 < iVar6) {
LAB_0801fcda:
            bVar4 = false;
          }
          else {
            if (iVar8 < 0) {
              iVar8 = -iVar8;
            }
            bVar4 = true;
            if ((int)((uint)param_2[1] + (uStack_24 >> 0x10)) >> 1 < iVar8) goto LAB_0801fcda;
          }
          if (bVar4) {
            *(short *)(piVar7 + 4) = (short)piVar7[4] - (short)param_3;
            uVar2 = sub_0801DE60();
            *(ushort *)((int)piVar7 + 0x12) = uVar2 & 0xff;
            if ((*(ushort *)(piVar7 + 4) & 0x8000) == 0) {
              uVar1 = sub_0801DE60();
              piVar3 = (int *)sub_08028368(uVar9,param_3,uVar1);
            }
            else {
              *(undefined2 *)(piVar7 + 4) = 0;
              uVar1 = sub_0801DE60();
              piVar3 = (int *)sub_08028368(uVar9,DWORD_0801fd24,uVar1);
            }
            *(undefined2 *)(piVar7 + 5) = 10;
            piVar10 = (int *)DWORD_0801fd60;
          }
        }
        uVar9 = uVar9 + 1;
        piVar7 = piVar7 + 9;
      } while (uVar9 < *(uint *)(*piVar10 + 0x48));
    }
  }
  return CONCAT44(in_lr,piVar3);
}


