
undefined8 sub_0805A7C4(undefined4 param_1,int param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 in_lr;
  
  uVar4 = 0;
  puVar5 = (undefined4 *)(*(int *)DWORD_0805a7e4 + DWORD_0805a7e8 + 0x48);
  puVar3 = (undefined4 *)(*(int *)DWORD_0805a7e4 + DWORD_0805a7e8);
  do {
    if (0xe < uVar4) {
      uVar2 = 0;
LAB_0805a866:
      return CONCAT44(in_lr,uVar2);
    }
    iVar1 = sub_08000470(puVar5);
    if (iVar1 == 0) {
      iVar1 = *(int *)DWORD_0805a858;
      *(uint *)(iVar1 + 0x54) = *(uint *)(iVar1 + 0x54) | 1 << (uVar4 & 0xff);
      *puVar3 = *(undefined4 *)(iVar1 + 0x4c);
      *(int *)(iVar1 + 0x4c) = *(int *)(iVar1 + 0x4c) + 1;
      puVar3[1] = param_1;
      puVar3[0xf] = 1;
      puVar3[2] = param_2 << 8;
      puVar3[3] = param_3 << 8;
      puVar3[0x14] = 0x3c;
      iVar1 = sub_08001494(0x400);
      puVar3[0x1a] = iVar1;
      puVar3[0x15] = DWORD_0805a85c;
      puVar3[0x16] = iVar1 + 0x3fc;
      puVar3[0x1b] = DWORD_0805a860;
      sub_08000274(puVar5,puVar3);
      uVar2 = *puVar3;
      goto LAB_0805a866;
    }
    uVar4 = uVar4 + 1;
    puVar5 = puVar3 + 0x2e;
    puVar3 = puVar3 + 0x1c;
  } while( true );
}


