
undefined4 sub_080811E0(int param_1)

{
  ushort uVar1;
  dword dVar2;
  ushort *puVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 in_lr;
  short sStack_60;
  short sStack_5e;
  short sStack_5c;
  short sStack_5a;
  short sStack_40;
  short sStack_3e;
  short sStack_1c;
  short sStack_1a;
  short sStack_18;
  short sStack_16;
  short sStack_14;
  short sStack_12;
  
  dVar2 = DWORD_0808121c;
  iVar4 = *(int *)DWORD_0808121c;
  if (*(int *)(iVar4 + 0x1c) == 0x16) {
    puVar3 = *(ushort **)(iVar4 + 0xf0);
    uVar1 = *puVar3;
    if (uVar1 == 1) {
      sub_0801BA74(param_1,0,&sStack_60,&sStack_40,*(int *)DWORD_08081254 + 0x30);
      uVar1 = *(ushort *)(*(int *)(*(int *)dVar2 + 0xf0) + 2);
joined_r0x080812da:
      if (uVar1 == 9) {
        sStack_5e = sStack_5e + 1;
      }
      else if (uVar1 < 10) {
        if (uVar1 == 8) {
          sStack_60 = sStack_60 + 1;
        }
      }
      else if (uVar1 == 10) {
        sStack_5a = sStack_5a + 1;
      }
      else if (uVar1 == 0xb) {
        sStack_5c = sStack_5c + 1;
      }
      goto LAB_0808133e;
    }
    if ((uVar1 == 0) || (5 < uVar1)) {
      puVar3 = *(ushort **)(*(int *)DWORD_0808121c + 0xf0);
      iVar4 = *(int *)DWORD_0808126c + 0x30;
    }
    else if ((char)puVar3[4] == '\0') {
      iVar4 = *(int *)DWORD_08081220 + 0x30;
    }
    else {
LAB_080812a0:
      iVar4 = *(int *)DWORD_080812b8 + 0x30;
      puVar3 = (ushort *)0x0;
    }
  }
  else {
    puVar3 = (ushort *)(iVar4 + 0xf4);
    uVar1 = *puVar3;
    if (uVar1 == 1) {
      sub_0801BA74(param_1,0,&sStack_60,&sStack_40,*(int *)DWORD_080812e8 + 0x30);
      uVar1 = *(ushort *)(*(int *)dVar2 + 0xf6);
      goto joined_r0x080812da;
    }
    if ((uVar1 == 0) || (5 < uVar1)) {
      sub_0801BA74(param_1,*(int *)DWORD_0808121c + 0xf4,&sStack_60,&sStack_40,
                   *(int *)DWORD_08081514 + 0x30);
      goto LAB_0808133e;
    }
    if (*(char *)(iVar4 + 0xfc) != '\0') goto LAB_080812a0;
    iVar4 = *(int *)DWORD_0808129c + 0x30;
  }
  sub_0801BA74(param_1,puVar3,&sStack_60,&sStack_40,iVar4);
LAB_0808133e:
  uVar5 = 2;
  if ((sStack_40 <= *(short *)(param_1 + 0x58)) &&
     (uVar5 = 0, sStack_40 < *(short *)(param_1 + 0x58))) {
    uVar5 = 1;
  }
  sub_0805FB7C(6,0xe,(int)sStack_40,uVar5);
  uVar5 = 2;
  if ((sStack_3e <= *(short *)(param_1 + 0x5a)) &&
     (uVar5 = 0, sStack_3e < *(short *)(param_1 + 0x5a))) {
    uVar5 = 1;
  }
  sub_0805FB7C(6,0xf,(int)sStack_3e,uVar5);
  uVar5 = 2;
  if ((sStack_1c <= *(short *)(param_1 + 0x7c)) &&
     (uVar5 = 0, sStack_1c < *(short *)(param_1 + 0x7c))) {
    uVar5 = 1;
  }
  sub_0805FB7C(0x16,0xe,(int)sStack_1c,uVar5);
  uVar5 = 2;
  if ((sStack_1a <= *(short *)(param_1 + 0x7e)) &&
     (uVar5 = 0, sStack_1a < *(short *)(param_1 + 0x7e))) {
    uVar5 = 1;
  }
  sub_0805FB7C(0x16,0xf,(int)sStack_1a,uVar5);
  uVar5 = 2;
  if ((sStack_18 <= *(short *)(param_1 + 0x80)) &&
     (uVar5 = 0, sStack_18 < *(short *)(param_1 + 0x80))) {
    uVar5 = 1;
  }
  sub_0805FB7C(0x16,0x10,(int)sStack_18,uVar5);
  uVar5 = 2;
  if ((sStack_16 <= *(short *)(param_1 + 0x82)) &&
     (uVar5 = 0, sStack_16 < *(short *)(param_1 + 0x82))) {
    uVar5 = 1;
  }
  sub_0805FB7C(0x1d,0xe,(int)sStack_16,uVar5);
  uVar5 = 2;
  if ((sStack_14 <= *(short *)(param_1 + 0x84)) &&
     (uVar5 = 0, sStack_14 < *(short *)(param_1 + 0x84))) {
    uVar5 = 1;
  }
  sub_0805FB7C(0x1d,0xf,(int)sStack_14,uVar5);
  uVar5 = 2;
  if ((sStack_12 <= *(short *)(param_1 + 0x86)) &&
     (uVar5 = 0, sStack_12 < *(short *)(param_1 + 0x86))) {
    uVar5 = 1;
  }
  sub_0805FB7C(0x1d,0x10,(int)sStack_12,uVar5);
  uVar5 = 2;
  if ((sStack_60 <= *(short *)(param_1 + 0x38)) &&
     (uVar5 = 0, sStack_60 < *(short *)(param_1 + 0x38))) {
    uVar5 = 1;
  }
  sub_0805FB7C(0xf,0xe,(int)sStack_60,uVar5);
  uVar5 = 2;
  if ((sStack_5a <= *(short *)(param_1 + 0x3e)) &&
     (uVar5 = 0, sStack_5a < *(short *)(param_1 + 0x3e))) {
    uVar5 = 1;
  }
  sub_0805FB7C(6,0x10,(int)sStack_5a,uVar5);
  uVar5 = 2;
  if ((sStack_5c <= *(short *)(param_1 + 0x3c)) &&
     (uVar5 = 0, sStack_5c < *(short *)(param_1 + 0x3c))) {
    uVar5 = 1;
  }
  sub_0805FB7C(0xf,0x10,(int)sStack_5c,uVar5);
  uVar5 = 2;
  if ((sStack_5e <= *(short *)(param_1 + 0x3a)) &&
     (uVar5 = 0, sStack_5e < *(short *)(param_1 + 0x3a))) {
    uVar5 = 1;
  }
  sub_0805FB7C(0xf,0xf,(int)sStack_5e,uVar5);
  return in_lr;
}


