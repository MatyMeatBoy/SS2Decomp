
undefined4 sub_080B6992(undefined4 param_1)

{
  return param_1;
}


