
ushort sub_08057314(void)

{
  return *(ushort *)(*(int *)DWORD_08057324 + 4) >> 8 & 1;
}


