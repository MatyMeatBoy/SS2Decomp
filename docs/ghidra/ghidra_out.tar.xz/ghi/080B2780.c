
undefined4 sub_080B2780(void)

{
  dword dVar1;
  int iVar2;
  undefined4 in_lr;
  
  if (*(short *)(*(int *)DWORD_080b27f4 + 0x5c) == 0) {
    if (*(short *)(*(int *)DWORD_080b27f8 + 0x5c) == 0) goto LAB_080b27dc;
  }
  sub_080B4B7C();
  sub_08097C6C();
  dVar1 = DWORD_080b27fc;
  iVar2 = sub_08000470(*(undefined4 *)DWORD_080b27fc);
  if (iVar2 != 0) {
    sub_080003A8(*(undefined4 *)dVar1);
  }
  sub_08001538(*(undefined4 *)dVar1);
  *(undefined4 *)dVar1 = 0;
  dVar1 = DWORD_080b2800;
  iVar2 = sub_08000470(*(undefined4 *)DWORD_080b2800);
  if (iVar2 != 0) {
    sub_080003A8(*(undefined4 *)dVar1);
  }
  sub_08001538(*(undefined4 *)dVar1);
  *(undefined4 *)dVar1 = 0;
LAB_080b27dc:
  sub_08068384();
  *(undefined4 *)DWORD_080b2804 = 0;
  sub_08016ECC(*(undefined2 *)DWORD_080b2808);
  return in_lr;
}


