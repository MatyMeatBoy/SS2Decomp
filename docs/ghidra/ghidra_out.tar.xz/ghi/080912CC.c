
undefined4 sub_080912CC(void)

{
  dword dVar1;
  short sVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  int unaff_r9;
  undefined4 in_lr;
  undefined4 uStack_28;
  
  dVar1 = DWORD_08091310;
  puVar3 = (undefined4 *)sub_08001494(0x44);
  *(undefined4 **)dVar1 = puVar3;
  iVar4 = sub_0800086C();
  iVar6 = (iVar4 << 0x10) >> 0x10;
  uVar5 = (iVar6 + (iVar6 - ((iVar4 << 0x10) >> 0x1f) >> 1) * -2) * 0x10000 >> 0x10;
  if ((int)uVar5 < 0) {
    uVar5 = -uVar5;
  }
  uVar5 = uVar5 & 0xff;
  if (uVar5 == 0) {
    sub_08065158(puVar3,DWORD_08091328,0,0xffffffff,0);
  }
  else if (uVar5 == 1) {
    sub_08065158(puVar3,DWORD_0809137c,0,0xffffffff,0);
  }
  *(undefined1 *)(puVar3 + 7) = 0;
  *(undefined2 *)(puVar3 + 0xf) = 10;
  puVar7 = puVar3 + 0x10;
  *(undefined2 *)puVar7 = 0;
  *(undefined2 *)((int)puVar3 + 0x3e) = 0;
  puVar3[0xd] = 0x10000;
  puVar3[0xe] = 0x5800;
  uStack_28 = 1;
  sVar2 = 0;
  uVar8 = 0;
  if (*(int *)DWORD_08091380 != 0) {
    do {
      if (uVar8 == 1) {
        if (unaff_r9 != 0) {
          if (uVar5 == 0) {
            sub_08065158(puVar3,DWORD_08091418,0,0xffffffff,0);
          }
          else if (uVar5 == 1) {
            sub_08065158(puVar3,DWORD_08091444,0,0xffffffff,0);
          }
          uStack_28 = 1;
          *(undefined2 *)(puVar3 + 0xf) = 10;
          *(undefined2 *)puVar7 = 0;
          *(undefined2 *)((int)puVar3 + 0x3e) = 0;
          uVar8 = 2;
        }
      }
      else if (uVar8 < 2) {
        if ((uVar8 == 0) &&
           (iVar4 = puVar3[0xd] + DWORD_080913a8, puVar3[0xd] = iVar4, iVar4 < 0x8001)) {
          if (uVar5 == 0) {
            sub_08065158(puVar3,DWORD_080913c0,0,0xffffffff,0);
          }
          else if (uVar5 == 1) {
            sub_08065158(puVar3,DWORD_080913f0,0,0xffffffff,0);
          }
          uStack_28 = 0;
          *(undefined1 *)(puVar3 + 7) = 0;
          *(undefined2 *)(puVar3 + 0xf) = 10;
          *(undefined2 *)puVar7 = 0;
          *(undefined2 *)((int)puVar3 + 0x3e) = 0;
          uVar8 = 1;
        }
      }
      else if (uVar8 == 2) {
        iVar4 = puVar3[0xd] + DWORD_08091460;
        puVar3[0xd] = iVar4;
        if (iVar4 <= (int)DWORD_08091464) {
          sVar2 = 0;
          uVar8 = 6;
        }
      }
      else if ((uVar8 == 6) && (sVar2 = sVar2 + 1, sVar2 == 0x3d)) {
        uVar8 = 0xff;
      }
      sub_08000AF0(0x10,puVar3[3],1);
      unaff_r9 = sub_08065370(puVar3,*(undefined2 *)(puVar3 + 0xf),(int)puVar3 + 0x3e,puVar7,
                              uStack_28);
      sub_08007870((int)puVar3[0xd] >> 8,(int)puVar3[0xe] >> 8,*(undefined2 *)(puVar3 + 0xf),
                   *(undefined2 *)((int)puVar3 + 0x3e),0,puVar3 + 7,puVar3[2],*puVar3);
      sub_080003F0();
      dVar1 = DWORD_080914ec;
    } while ((uVar8 != 0xff) && (*(int *)DWORD_080914ec != 0));
    if (*(int *)DWORD_080914ec != 0) {
      sub_08001538();
      *(undefined4 *)dVar1 = 0;
    }
  }
  return in_lr;
}


