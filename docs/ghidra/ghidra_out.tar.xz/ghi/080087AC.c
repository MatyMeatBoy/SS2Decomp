
undefined8
sub_080087AC(int param_1,int param_2,uint param_3,uint param_4,byte param_5,int param_6,int param_7,
            int param_8,byte param_9)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  char *pcVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  uint uVar12;
  undefined4 in_lr;
  int iStack_30;
  uint uStack_2c;
  
  if ((*(uint *)DWORD_080087ec < 0x80) && ((param_3 & 0xffff) <= (uint)*(ushort *)(param_7 + 2))) {
    iVar4 = *(int *)DWORD_080088b0;
    iVar6 = param_7 + *(int *)(param_7 + 8) + (param_3 & 0xffff) * 0xc;
    iVar11 = *(int *)(param_7 + 4) + param_7 +
             (uint)*(ushort *)(iVar6 + *(int *)(iVar6 + 8) + (param_4 & 0xffff) * 4) * 0xc;
    puVar5 = (undefined4 *)(*(int *)(iVar11 + 8) + iVar11);
    pcVar8 = (char *)(*(uint *)DWORD_080087ec * 8 + DWORD_080088b4);
    iStack_30 = *(int *)DWORD_080088b8 + iVar4 * 0x20;
    uVar12 = 0;
    iVar6 = 0;
    uStack_2c = 0;
    if (*(short *)(iVar11 + 2) != 0) {
      bVar3 = (param_5 & 3) << 2;
      do {
        uVar7 = puVar5[1];
        *(undefined4 *)pcVar8 = *puVar5;
        *(undefined4 *)(pcVar8 + 4) = uVar7;
        *(undefined2 *)(pcVar8 + 6) = *(undefined2 *)(pcVar8 + 6);
        iVar10 = *pcVar8 + param_2;
        iVar9 = ((int)((uint)*(ushort *)(pcVar8 + 2) << 0x17) >> 0x17) + param_1;
        if (((iVar9 + 0x40U < 0x131) && (iVar10 < 0xa1)) && (-0x41 < iVar10)) {
          bVar1 = pcVar8[1];
          pcVar8[1] = bVar1 & 0xf3 | (param_9 & 3) << 2;
          iStack_30 = iStack_30 + iVar6;
          bVar2 = pcVar8[5];
          pcVar8[5] = bVar2 & 0xf3 | bVar3;
          pcVar8[5] = bVar2 & 3 | bVar3 | *(char *)(param_6 + (uint)(bVar2 >> 4)) << 4;
          *(ushort *)(pcVar8 + 2) =
               (ushort)DWORD_0800893c & *(ushort *)(pcVar8 + 2) |
               (ushort)iVar9 & (ushort)DWORD_08008938;
          *pcVar8 = (char)iVar10;
          *(ushort *)(pcVar8 + 4) =
               *(ushort *)(pcVar8 + 4) & (ushort)DWORD_08008944 |
               (short)iVar4 + (short)uVar12 & (ushort)DWORD_08008940;
          if (bVar1 >> 6 == 0) {
            iVar6 = *(int *)((uint)((byte)pcVar8[3] >> 6) * 4 + DWORD_080089cc);
          }
          else {
            iVar6 = *(int *)((uint)((byte)pcVar8[3] >> 6) * 4 + DWORD_08008948);
          }
          uVar12 = uVar12 + iVar6 & 0xffff;
          iVar9 = *(int *)DWORD_080089d0;
          *(uint *)DWORD_080089d0 = iVar9 + 1U;
          if (0x7f < iVar9 + 1U) {
            iVar4 = 0;
            goto LAB_080089ba;
          }
          iVar6 = iVar6 * 0x20;
          sub_08001348(param_8 + ((((uint)*(byte *)((int)puVar5 + 5) << 0x1c) >> 0x1e) << 10 |
                                 *(ushort *)(puVar5 + 1) & 0x3ff) * 0x20,iStack_30,iVar6);
        }
        else {
          *pcVar8 = -0x60;
          pcVar8[1] = pcVar8[1] & 0x3f;
          pcVar8[3] = pcVar8[3] & 0x3f;
          pcVar8 = pcVar8 + -8;
        }
        uStack_2c = uStack_2c + 1;
        pcVar8 = pcVar8 + 8;
        puVar5 = puVar5 + 2;
      } while (uStack_2c < *(ushort *)(iVar11 + 2));
    }
    *(uint *)DWORD_080089d4 = *(int *)DWORD_080089d4 + uVar12;
    iVar4 = *(int *)DWORD_080089d8 + iVar4 * 0x20;
  }
  else {
    iVar4 = -1;
  }
LAB_080089ba:
  return CONCAT44(in_lr,iVar4);
}


