
undefined8 sub_0805C208(ushort *param_1,uint param_2)

{
  bool bVar1;
  ushort uVar2;
  dword dVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  short *psVar8;
  uint uVar9;
  uint uVar10;
  ushort *puVar11;
  undefined2 *puVar12;
  undefined2 *puVar13;
  ushort *puVar14;
  bool bVar15;
  bool bVar16;
  undefined4 in_lr;
  int iStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  
  bVar16 = false;
  bVar1 = false;
  bVar15 = false;
  uVar2 = *param_1;
  if (uVar2 == 3) {
    uVar4 = sub_08007290(param_1[1] | 0xc0000);
    bVar15 = false;
    puVar14 = (ushort *)DWORD_0805c30c;
    uStack_24 = uVar4;
    goto LAB_0805c330;
  }
  if (uVar2 < 4) {
    if (uVar2 != 2) {
LAB_0805c32c:
      uVar4 = 1;
      goto LAB_0805c4ec;
    }
    iStack_30 = sub_08007290(param_1[1] | 0xb0000);
    puVar14 = (ushort *)DWORD_0805c284;
    puVar11 = (ushort *)DWORD_0805c264;
    if (*(char *)(iStack_30 + 0x9b) == '\t') {
      uVar4 = sub_080008C8();
      puVar14 = puVar11;
      if ((uVar4 & 0xf) < 8) {
LAB_0805c298:
        bVar1 = true;
        bVar15 = true;
        goto LAB_0805c330;
      }
    }
    else {
      uVar4 = sub_080008C8();
      puVar11 = puVar14;
      if (2 < (uVar4 & 0xf)) {
        if ((uVar4 & 0xf) < 8) {
          uVar4 = sub_080008C8();
          if ((uVar4 & 0xf) < 5) goto LAB_0805c298;
          if (10 < (uVar4 & 0xf)) {
            bVar16 = true;
            goto LAB_0805c27e;
          }
          bVar15 = true;
          bVar16 = true;
        }
        else {
          uVar4 = sub_080008C8();
          if ((uVar4 & 0xf) < 5) {
            bVar15 = true;
          }
          else {
            if ((uVar4 & 0xf) < 10) goto LAB_0805c27e;
            bVar16 = true;
          }
        }
        goto LAB_0805c330;
      }
      bVar15 = true;
      bVar16 = true;
    }
LAB_0805c27e:
    bVar1 = true;
    puVar14 = puVar11;
  }
  else {
    if (uVar2 == 4) {
      uVar4 = sub_08007290(param_1[1] | 0xd0000);
      puVar14 = (ushort *)DWORD_0805c328;
      uStack_28 = uVar4;
    }
    else {
      if (uVar2 != 5) goto LAB_0805c32c;
      uVar4 = sub_08007290(param_1[1] | 0xe0000);
      puVar14 = (ushort *)DWORD_0805c2ec;
      uStack_2c = uVar4;
      if (*(char *)(uVar4 + 0xa0) != '\0') {
        puVar14 = (ushort *)DWORD_0805c2f0;
      }
    }
    bVar15 = false;
  }
LAB_0805c330:
  if ((*param_1 < 6) && (2 < *param_1)) {
    uVar4 = sub_080008C8();
    if (7 < (uVar4 & 0xf)) {
      bVar1 = true;
      bVar16 = true;
      goto LAB_0805c360;
    }
    uVar4 = sub_080008C8();
    if (7 < (uVar4 & 0xf)) {
      bVar16 = true;
      goto LAB_0805c360;
    }
LAB_0805c364:
    uVar2 = *puVar14;
    uVar5 = sub_080008C8();
    uVar4 = __umodsi3(uVar5,puVar14[1],uVar5);
    uVar10 = 0;
    if (uVar2 != 0) {
      uVar9 = (uint)puVar14[3];
      puVar14 = puVar14 + 2;
      while (uVar9 < uVar4) {
        do {
          uVar10 = uVar10 + 1;
          puVar11 = puVar14 + 2;
          if (uVar2 <= uVar10) goto LAB_0805c39a;
          bVar1 = uVar4 < uVar9;
          uVar9 = (uint)puVar14[3];
          puVar14 = puVar11;
        } while (bVar1);
      }
      param_1[2] = *puVar14;
    }
  }
  else {
LAB_0805c360:
    if (bVar1) goto LAB_0805c364;
  }
LAB_0805c39a:
  dVar3 = DWORD_0805c3f0;
  if (bVar15) {
    uVar2 = *(ushort *)DWORD_0805c3f0;
    uVar5 = sub_080008C8();
    uVar4 = __umodsi3(uVar5,*(ushort *)(dVar3 + 2) + 1,uVar5);
    uVar10 = 0;
    if (uVar2 != 0xffffffff) {
      uVar9 = (uint)*(ushort *)(dVar3 + 6);
      puVar12 = (undefined2 *)(dVar3 + 4);
      while (uVar9 < uVar4) {
        do {
          uVar10 = uVar10 + 1;
          uVar7 = uVar9 + 1;
          puVar13 = puVar12 + 2;
          if (uVar2 + 1 <= uVar10) goto LAB_0805c3dc;
          uVar9 = (uint)(ushort)puVar12[3];
          puVar12 = puVar13;
        } while (uVar4 < uVar7);
      }
      *(char *)((int)param_1 + 7) = (char)*puVar12;
    }
  }
LAB_0805c3dc:
  if (bVar16) {
    puVar14 = (ushort *)DWORD_0805c3f4;
    if (((param_2 & 1) == 0) &&
       (iVar6 = sub_0800CE30(), puVar14 = (ushort *)DWORD_0805c450, iVar6 != 0)) {
      puVar14 = (ushort *)DWORD_0805c454;
    }
    uVar2 = *puVar14;
    uVar5 = sub_080008C8();
    uVar4 = __umodsi3(uVar5,puVar14[1] + 1,uVar5);
    uVar10 = 0;
    if (uVar2 != 0xffffffff) {
      uVar9 = (uint)puVar14[3];
      puVar14 = puVar14 + 2;
      while (uVar9 < uVar4) {
        do {
          uVar10 = uVar10 + 1;
          uVar7 = uVar9 + 1;
          puVar11 = puVar14 + 2;
          if (uVar2 + 1 <= uVar10) goto LAB_0805c43e;
          uVar9 = (uint)puVar14[3];
          puVar14 = puVar11;
        } while (uVar4 < uVar7);
      }
      *(char *)(param_1 + 3) = (char)*puVar14;
    }
  }
LAB_0805c43e:
  uVar2 = *param_1;
  if (uVar2 == 3) {
    uVar10 = 0;
    psVar8 = (short *)(uStack_24 + 0xa4);
    do {
      if (*psVar8 != 0) goto LAB_0805c4b4;
      psVar8 = psVar8 + 2;
      uVar10 = uVar10 + 1;
    } while (uVar10 < 3);
  }
  else if (uVar2 < 4) {
    if (uVar2 == 2) {
      uVar10 = 0;
      psVar8 = (short *)(iStack_30 + 0xb0);
      do {
        if (*psVar8 != 0) goto LAB_0805c4a4;
        psVar8 = psVar8 + 2;
        uVar10 = uVar10 + 1;
      } while (uVar10 < 3);
    }
  }
  else if (uVar2 == 4) {
    uVar10 = 0;
    psVar8 = (short *)(uStack_28 + 0xa4);
    do {
      if (*psVar8 != 0) goto LAB_0805c4a4;
      psVar8 = psVar8 + 2;
      uVar10 = uVar10 + 1;
    } while (uVar10 < 3);
  }
  else if (uVar2 == 5) {
    uVar10 = 0;
    psVar8 = (short *)(uStack_2c + 0xa4);
    do {
      if (*psVar8 != 0) goto LAB_0805c4b4;
      psVar8 = psVar8 + 2;
      uVar10 = uVar10 + 1;
    } while (uVar10 < 3);
  }
  goto LAB_0805c4d8;
LAB_0805c4b4:
  param_1[2] = 0;
  *(undefined1 *)(param_1 + 3) = 0;
  *(undefined1 *)((int)param_1 + 7) = 0;
  param_2 = 1;
  goto LAB_0805c4d8;
LAB_0805c4a4:
  param_1[2] = 0;
  *(undefined1 *)(param_1 + 3) = 0;
  *(undefined1 *)((int)param_1 + 7) = 0;
  param_2 = 1;
LAB_0805c4d8:
  if (*(int *)(param_1 + 2) != 0) {
    *(bool *)(param_1 + 4) = (param_2 & 1) == 0;
  }
LAB_0805c4ec:
  return CONCAT44(in_lr,uVar4);
}


