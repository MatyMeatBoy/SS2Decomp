
undefined4 sub_080570DC(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_lr;
  
  iVar2 = *(int *)DWORD_0805715c + DWORD_08057160;
  uVar3 = 0;
  do {
    iVar1 = sub_08000470(iVar2);
    if (iVar1 != 0) {
      sub_080003A8(iVar2);
    }
    uVar3 = uVar3 + 1;
    iVar2 = iVar2 + 0x28;
  } while (uVar3 < 0x1e);
  if (param_1 != 0) {
    iVar2 = *(int *)DWORD_0805715c + DWORD_08057164;
    uVar3 = 0;
    do {
      iVar1 = sub_08000470(iVar2);
      if (iVar1 != 0) {
        sub_080003A8(iVar2);
      }
      uVar3 = uVar3 + 1;
      iVar2 = iVar2 + 0x28;
    } while (uVar3 < 0x1e);
  }
  iVar2 = *(int *)DWORD_0805715c + DWORD_08057168;
  uVar3 = 0;
  do {
    iVar1 = sub_08000470(iVar2 + 0x48);
    if (iVar1 != 0) {
      sub_080003A8(iVar2 + 0x48);
    }
    uVar3 = uVar3 + 1;
    iVar2 = iVar2 + 0x70;
  } while (uVar3 < 0xf);
  *(undefined4 *)DWORD_0805716c = 0;
  return in_lr;
}


