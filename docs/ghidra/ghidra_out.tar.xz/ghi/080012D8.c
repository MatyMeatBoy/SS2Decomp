
undefined4 sub_080012D8(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)DWORD_080012e4;
  *(undefined4 *)DWORD_080012e4 = param_1;
  return uVar1;
}


