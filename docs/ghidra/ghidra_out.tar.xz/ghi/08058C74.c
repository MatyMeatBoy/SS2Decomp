
undefined4 sub_08058C74(undefined2 param_1)

{
  undefined4 in_lr;
  
  *(undefined2 *)(*(int *)DWORD_08058c88 + 0x68) = param_1;
  sub_0805AD78();
  return in_lr;
}


