
undefined4 m4aMPlayContinue(void)

{
  undefined4 in_lr;
  
  MPlayContinue();
  return in_lr;
}


