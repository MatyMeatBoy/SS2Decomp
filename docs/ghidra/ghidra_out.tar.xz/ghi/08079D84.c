
undefined4 sub_08079D84(int *param_1,uint param_2)

{
  undefined1 uVar1;
  short sVar2;
  int iVar3;
  uint *puVar4;
  int iVar5;
  undefined4 in_lr;
  undefined1 auStack_64 [12];
  undefined4 uStack_58;
  undefined1 uStack_48;
  undefined1 uStack_47;
  undefined2 uStack_30;
  undefined2 uStack_2e;
  short sStack_2c;
  short sStack_2a;
  int iStack_28;
  int iStack_24;
  
  sub_080020F4();
  sub_08065158(auStack_64,DWORD_08079de8,1,0xffffffff,0);
  sub_08000AF0(0x17,uStack_58,2);
  uStack_48 = 7;
  uStack_47 = 8;
  iStack_28 = (DWORD_08079dec & param_2) << 8;
  iStack_24 = (param_2 >> 0x10) * 0x100;
  uStack_30 = 0;
  uStack_2e = 0;
  sVar2 = 0;
  sub_08068A00(iStack_28,iStack_24,param_1);
  while ((iVar3 = sub_0800CB78(), iVar3 == 0 && (sVar2 == 0))) {
    sVar2 = sub_08065370(auStack_64,0x15,&uStack_30,&uStack_2e,0);
    iVar3 = sub_0800CC98();
    if ((iVar3 == 0) &&
       ((iVar3 = sub_0800CD8C(), iVar3 == 0 && (iVar3 = sub_0800CCCC(), iVar3 == 0)))) {
      iVar5 = iStack_28 >> 8;
      iVar3 = iStack_24 >> 8;
      sub_0800BC08((int)(short)((uint)iStack_28 >> 8),(int)(short)((uint)iStack_24 >> 8),&sStack_2c,
                   &sStack_2a,0x10,0);
      uVar1 = sub_0800BC44(iVar5,iVar3,0);
      if ((*(short *)(DWORD_08079ec4 + 0x8c) == 4) && (iVar3 = sub_0800CDC0(), iVar3 != 0)) {
        uVar1 = 0;
      }
      if ((*(uint *)DWORD_08079ec8 & 1) != 0) {
        sub_080659BC(auStack_64,(int)sStack_2c,sStack_2a + 1,0x15,uStack_30,uVar1);
      }
    }
    sub_080003F0();
  }
  puVar4 = (uint *)(*param_1 * 4 + DWORD_08079ecc);
  *puVar4 = *puVar4 & ~(1 << (param_1[1] & 0xffU));
  return in_lr;
}


