
undefined4 sub_0806D4A4(uint *param_1)

{
  char cVar1;
  ushort uVar2;
  short sVar3;
  ushort uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint *puVar9;
  short *psVar10;
  int iVar11;
  ushort *puVar12;
  uint uVar13;
  short *psVar14;
  uint uVar15;
  uint uVar16;
  int unaff_r10;
  undefined4 in_lr;
  byte abStack_34 [4];
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  int iStack_24;
  
  uVar5 = sub_080020F4();
  uVar6 = *param_1;
  uStack_28 = param_1[1];
  uVar2 = (ushort)param_1[5];
  uVar16 = (uint)uVar2;
  if (uVar6 < 4) {
    unaff_r10 = uVar6 * 0x14c + DWORD_0806d564;
  }
  if (uVar5 == uVar6) {
    iVar7 = sub_080020F4();
    iVar11 = iVar7 * 0x14c + DWORD_0806d564;
    iVar7 = sub_0806898C(param_1[3],param_1[5]);
    puVar12 = (ushort *)(iVar11 + 0xc2);
    iVar7 = (uint)*puVar12 - (iVar7 - 1U & 0xffff);
    *puVar12 = (ushort)iVar7;
    if (iVar7 * 0x10000 < 0) {
      *puVar12 = 0;
    }
  }
  iStack_24 = uVar6 << 2;
  uVar4 = *(ushort *)(unaff_r10 + 0xb4);
  while (uVar4 < 7) {
    if (*(short *)(unaff_r10 + 0x20) == 10) {
      puVar9 = (uint *)(iStack_24 + DWORD_0806d6e4);
      goto LAB_0806d7d0;
    }
    sub_080003F0();
    uVar4 = *(ushort *)(unaff_r10 + 0xb4);
  }
  if (((uVar5 == uVar6) && (iVar7 = sub_0800CCCC(), iVar7 == 0)) &&
     (iVar7 = sub_0800CD34(), iVar7 == 0)) {
    sub_0805865C(0x166);
  }
  uStack_30 = (uint)(**(ushort **)(unaff_r10 + 0x148) >> 4);
  uStack_2c = (*(ushort **)(unaff_r10 + 0x148))[1] & 0xfff;
  uVar13 = 0;
  for (uVar15 = 0; uVar8 = sub_08002164(), uVar15 < uVar8; uVar15 = uVar15 + 1 & 0xffff) {
    iVar7 = uVar15 * 0x14c + DWORD_0806d674;
    puVar12 = *(ushort **)(iVar7 + 0x148);
    uVar8 = uVar13;
    if (((-1 < (int)((uint)(byte)puVar12[2] * 0x4000000)) &&
        (cVar1 = *(char *)(iVar7 + 0x68), cVar1 == *(char *)(unaff_r10 + 0x68))) && (cVar1 != '\0'))
    {
      if (uVar16 == 5) {
LAB_0806d5da:
        uVar8 = uVar13 + 1 & 0xffff;
        abStack_34[uVar13] = (byte)uVar15;
      }
      else {
        iVar7 = (int)(((*puVar12 >> 4) - uStack_30) * 0x10000) >> 0x13;
        if (iVar7 < 0) {
          iVar7 = -iVar7;
        }
        iVar11 = uVar16 + 1;
        if (iVar7 + iVar11 * -2 < 0 != SBORROW4(iVar7,iVar11 * 2)) {
          iVar7 = (int)(((puVar12[1] & 0xfff) - uStack_2c) * 0x10000) >> 0x13;
          if (iVar7 < 0) {
            iVar7 = -iVar7;
          }
          if (iVar7 + iVar11 * -2 < 0 != SBORROW4(iVar7,iVar11 * 2)) goto LAB_0806d5da;
        }
      }
    }
    uVar13 = uVar8;
  }
  uVar15 = 0;
  if (uVar13 != 0) {
    do {
      sub_08074DE8(abStack_34[uVar15],10);
      uVar15 = uVar15 + 1 & 0xffff;
    } while (uVar15 < uVar13);
  }
  sVar3 = (short)uVar6;
  if (uVar5 == uVar6) {
    psVar14 = *(short **)(unaff_r10 + 0x34);
    uVar4 = 0;
    psVar10 = psVar14;
    do {
      if (((0 < *psVar10) && ((ushort)psVar10[1] < 4)) &&
         ((*(short *)((uint)(ushort)psVar10[1] * 0x14c + DWORD_0806d674 + 100) == 4 &&
          (psVar10[2] == 4)))) {
        if ((ushort)psVar10[3] < uVar16) {
          psVar10[3] = uVar2;
          *psVar10 = (uVar2 * 10 + 0x28) * 0x3c;
          sub_0801E0BC(psVar10 + 0xe,(int)(uVar16 * 0xa0000) >> 0x10);
          psVar10[1] = sVar3;
        }
        goto LAB_0806d6a6;
      }
      uVar4 = uVar4 + 1;
      psVar10 = psVar10 + 0x14;
    } while (uVar4 < 8);
    uVar4 = 0;
    do {
      if (*psVar14 == -1) {
        psVar14[1] = sVar3;
        psVar14[2] = 4;
        psVar14[3] = uVar2;
        *psVar14 = (uVar2 * 10 + 0x28) * 0x3c;
        sub_0801E0BC(psVar14 + 0xe,(int)(uVar16 * 0xa0000) >> 0x10);
        break;
      }
      uVar4 = uVar4 + 1;
      psVar14 = psVar14 + 0x14;
    } while (uVar4 < 8);
LAB_0806d6a6:
    *(undefined2 *)(unaff_r10 + 0x24) = 0;
    *(undefined2 *)(unaff_r10 + 0x26) = 0;
  }
  else {
    uVar6 = 0;
    if (uVar13 != 0) {
      do {
        if (abStack_34[uVar6] == uVar5) {
          iVar7 = uVar5 * 0x14c + DWORD_0806d788;
          psVar10 = *(short **)(iVar7 + 0x34);
          uVar4 = 0;
          goto LAB_0806d742;
        }
        uVar6 = uVar6 + 1 & 0xffff;
      } while (uVar6 < uVar13);
    }
  }
  goto LAB_0806d7c4;
  while( true ) {
    uVar4 = uVar4 + 1;
    psVar10 = psVar10 + 0x14;
    if (7 < uVar4) break;
LAB_0806d742:
    if ((((0 < *psVar10) && ((ushort)psVar10[1] < 4)) &&
        (*(short *)((uint)(ushort)psVar10[1] * 0x14c + DWORD_0806d788 + 100) == 4)) &&
       (psVar10[2] == 4)) {
      if ((ushort)psVar10[3] < uVar16) {
        psVar10[1] = sVar3;
        psVar10[3] = uVar2;
        *psVar10 = (uVar2 * 10 + 0x28) * 0x3c;
        sub_0801E0BC(psVar10 + 0xe,(int)(uVar16 * 0xa0000) >> 0x10);
      }
      goto LAB_0806d7c4;
    }
  }
  psVar10 = *(short **)(iVar7 + 0x34);
  uVar4 = 0;
  do {
    if (*psVar10 == -1) {
      psVar10[1] = sVar3;
      psVar10[2] = 4;
      psVar10[3] = uVar2;
      *psVar10 = (uVar2 * 10 + 0x28) * 0x3c;
      sub_0801E0BC(psVar10 + 0xe,(int)(uVar16 * 0xa0000) >> 0x10);
      break;
    }
    uVar4 = uVar4 + 1;
    psVar10 = psVar10 + 0x14;
  } while (uVar4 < 8);
LAB_0806d7c4:
  puVar9 = (uint *)(iStack_24 + DWORD_0806d7e8);
LAB_0806d7d0:
  *puVar9 = *puVar9 & ~(1 << (uStack_28 & 0xff));
  return in_lr;
}


