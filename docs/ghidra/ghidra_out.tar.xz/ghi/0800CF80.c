
ushort sub_0800CF80(void)

{
  return *(ushort *)(DWORD_0800cf8c + 2) & 1;
}


