
undefined8 sub_0807A56C(undefined1 param_1)

{
  byte bVar1;
  dword dVar2;
  byte bVar3;
  char *pcVar4;
  char *pcVar5;
  uint uVar6;
  undefined4 in_lr;
  
  dVar2 = DWORD_0807a5bc;
  pcVar4 = (char *)sub_08001494(DWORD_0807a5bc);
  sub_08001B04(param_1,0,pcVar4,dVar2);
  bVar3 = 0;
  uVar6 = 0;
  pcVar5 = pcVar4;
  do {
    bVar3 = bVar3 + *pcVar5;
    uVar6 = uVar6 + 1;
    pcVar5 = pcVar5 + 1;
  } while (uVar6 < DWORD_0807a5c0);
  bVar1 = pcVar4[DWORD_0807a5c0];
  if (bVar1 != (byte)~bVar3) {
    sub_08001538(pcVar4);
  }
  else {
    sub_08001538(pcVar4);
  }
  return CONCAT44(in_lr,(uint)(bVar1 == (byte)~bVar3));
}


