
undefined4 sub_08068870(void)

{
  return 1;
}


