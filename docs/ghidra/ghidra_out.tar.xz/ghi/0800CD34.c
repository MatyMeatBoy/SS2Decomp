
uint sub_0800CD34(void)

{
  return *(uint *)DWORD_0800cd40 >> 5 & 1;
}


