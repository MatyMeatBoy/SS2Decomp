
undefined4 sub_08065424(int param_1,undefined4 param_2,dword param_3,uint param_4,uint param_5)

{
  bool bVar1;
  dword dVar2;
  char cVar3;
  undefined4 uVar4;
  char *pcVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 in_lr;
  char acStack_3c [12];
  dword dStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  uint uStack_24;
  
  uStack_2c = param_2;
  param_4 = param_4 & 0xff;
  param_5 = param_5 & 0xff;
  if ((int)param_3 < 0) {
    param_3 = DWORD_080654f8;
  }
  if ((((param_4 != 1) && (1 < param_4)) && (param_4 != 2)) && (param_4 == 3)) {
    param_4 = 0xd;
  }
  dStack_30 = param_3;
  puVar7 = (undefined4 *)((10 - param_5) * 4 + DWORD_080654fc);
  pcVar5 = acStack_3c;
  uVar6 = 0;
  if (param_5 != 0) {
    do {
      uVar4 = *puVar7;
      puVar7 = puVar7 + 1;
      uStack_24 = param_4;
      cVar3 = sub_08000498(&dStack_30,uVar4);
      *pcVar5 = cVar3;
      uVar6 = uVar6 + 1;
      pcVar5 = pcVar5 + 1;
      param_4 = uStack_24;
    } while (uVar6 < param_5);
  }
  dVar2 = DWORD_08065500;
  bVar1 = false;
  param_1 = param_1 + (param_5 - 1) * -6;
  pcVar5 = acStack_3c;
  uVar6 = 0;
  if (param_5 != 0) {
    uStack_28 = param_4 << 0x10;
    do {
      if (((bVar1) || (*pcVar5 != '\0')) || (uVar6 == param_5 - 1)) {
        bVar1 = true;
        sub_08007CF0(param_1,uStack_2c,uStack_28 >> 0x10,*pcVar5,0,dVar2 + 0x1c,
                     *(undefined4 *)(dVar2 + 8),*(undefined4 *)dVar2);
      }
      uVar6 = uVar6 + 1;
      param_1 = param_1 + 6;
      pcVar5 = pcVar5 + 1;
    } while (uVar6 < param_5);
  }
  return in_lr;
}


