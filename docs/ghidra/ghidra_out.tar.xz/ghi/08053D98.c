
undefined4 sub_08053D98(void)

{
  dword dVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_lr;
  
  iVar2 = sub_0800CC98();
  if (iVar2 == 0) {
    iVar2 = sub_0801AB24();
    if (iVar2 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar2 < 2) {
      if (iVar2 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar2 == 2) {
      sub_0801AB90(6);
    }
    while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
      sub_080003F0();
    }
  }
  *(undefined4 *)DWORD_08053e2c = 0xb;
  if ((*(uint *)DWORD_08053e30 & 0x20) == 0) {
    sub_08006CB4(0xb);
  }
  dVar1 = DWORD_08053e38;
  iVar2 = *(int *)DWORD_08053e34;
  uVar3 = 0;
  do {
    if (((*(uint *)dVar1 & 1 << (uVar3 & 0xff)) != 0) && (*(short *)(iVar2 + 0xc) == 0xc)) {
      *(undefined2 *)(iVar2 + 0xc) = 0;
    }
    uVar3 = uVar3 + 1;
    iVar2 = iVar2 + 0x2e0;
  } while (uVar3 < 5);
  sub_08019F04();
  return in_lr;
}


