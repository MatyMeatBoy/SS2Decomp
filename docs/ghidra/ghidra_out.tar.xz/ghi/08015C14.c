
undefined4 sub_08015C14(void)

{
  int iVar1;
  uint *puVar2;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  puVar2 = (uint *)(iVar1 * 0x14c + DWORD_08015c34 + 0x30);
  *puVar2 = *puVar2 | 1;
  return in_lr;
}


