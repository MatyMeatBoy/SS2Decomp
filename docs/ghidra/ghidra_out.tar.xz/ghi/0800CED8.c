
uint sub_0800CED8(void)

{
  return *(uint *)DWORD_0800cee4 >> 0xd & 1;
}


