
undefined4 sub_08053B24(void)

{
  short sVar1;
  dword dVar2;
  short sVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 in_lr;
  undefined1 auStack_28 [4];
  undefined1 auStack_24 [4];
  
  dVar2 = DWORD_08053b94;
  sVar3 = *(short *)(DWORD_08053b90 + 0x80);
  sVar1 = *(short *)(DWORD_08053b90 + 0x82);
  iVar5 = 0;
  do {
    sub_080659F4(auStack_28,(int)sVar3,0,iVar5);
    sub_080659F4(auStack_24,(int)sVar1,(int)dVar2 >> 0x10,iVar5);
    sub_0800BB80((int)auStack_28._0_2_,(int)auStack_24._0_2_);
    sub_080003F0();
    iVar5 = iVar5 + 0x400;
  } while (iVar5 < 0x401);
  sVar3 = 1;
  do {
    sub_080003F0();
    iVar5 = sub_080021A8();
    dVar2 = DWORD_08053bbc;
    if (iVar5 != 0) break;
    sVar3 = sVar3 + -1;
  } while (sVar3 != 0);
  iVar5 = *(int *)DWORD_08053bc0 + DWORD_08053bc4;
  for (uVar6 = 0; uVar6 < 0x1e; uVar6 = uVar6 + 1) {
    iVar4 = sub_08000470(iVar5);
    if (iVar4 == 0) goto LAB_08053be0;
    iVar5 = iVar5 + 0x28;
  }
LAB_08053c0a:
  iVar5 = sub_0800CC98();
  if (iVar5 == 0) {
    iVar5 = sub_0801AB24();
    if (iVar5 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar5 < 2) {
      if (iVar5 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar5 == 2) {
      sub_0801AB90(6);
    }
    while (iVar5 = sub_0801AAE0(), iVar5 == 0) {
      sub_080003F0();
    }
  }
  return in_lr;
LAB_08053be0:
  while( true ) {
    iVar4 = sub_08001494(0x400);
    *(int *)(iVar5 + 0x20) = iVar4;
    if (iVar4 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar5 + 8) = 0x3c;
  *(dword *)(iVar5 + 0xc) = dVar2;
  *(int *)(iVar5 + 0x10) = iVar4 + 0x3fc;
  *(undefined4 *)(iVar5 + 0x24) = 0;
  sub_08000274(iVar5,1);
  goto LAB_08053c0a;
}


