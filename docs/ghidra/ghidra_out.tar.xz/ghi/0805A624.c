
undefined4 sub_0805A624(undefined4 param_1)

{
  undefined4 in_lr;
  
  sub_0802413C(param_1,2);
  return in_lr;
}


