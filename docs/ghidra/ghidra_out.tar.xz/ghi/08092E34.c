
int sub_08092E34(void)

{
  return (int)*(short *)DWORD_08092e3c;
}


