
ulonglong EraseFlashChip_LE(void)

{
  ushort uVar1;
  dword dVar2;
  dword dVar3;
  dword dVar4;
  undefined4 uVar5;
  undefined4 in_lr;
  undefined1 auStack_50 [64];
  
  dVar2 = DWORD_080b8c2c;
  uVar1 = (ushort)DWORD_080b8c30;
  *(ushort *)DWORD_080b8c2c =
       *(ushort *)DWORD_080b8c2c & uVar1 | *(ushort *)(*(int *)DWORD_080b8c34 + 0x10);
  dVar3 = DWORD_080b8c38;
  *(undefined1 *)DWORD_080b8c38 = 0xaa;
  dVar4 = DWORD_080b8c3c;
  *(undefined1 *)DWORD_080b8c3c = 0x55;
  *(undefined1 *)dVar3 = 0x80;
  *(undefined1 *)dVar3 = 0xaa;
  *(undefined1 *)dVar4 = 0x55;
  *(undefined1 *)dVar3 = 0x10;
  SetReadFlash1(auStack_50);
  uVar5 = _call_via_r3(3,0xe000000,0xff,*(undefined4 *)DWORD_080b8c40);
  *(ushort *)dVar2 = *(ushort *)dVar2 & uVar1 | 3;
  return CONCAT44(in_lr,uVar5) & 0xffffffff0000ffff;
}


