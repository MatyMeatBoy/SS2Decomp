
undefined4 sub_08097F70(int param_1,int *param_2)

{
  dword dVar1;
  byte bVar2;
  int iVar3;
  ushort *puVar4;
  ushort *puVar5;
  undefined4 in_lr;
  
  dVar1 = DWORD_08097fe0;
  bVar2 = 0;
  puVar4 = (ushort *)(param_1 + -2);
  do {
    puVar5 = puVar4 + 1;
    iVar3 = *param_2;
    *(byte *)puVar5 = (byte)*puVar5 & 0xe0 | (byte)iVar3 & 0x1f;
    *puVar5 = (ushort)dVar1 & *puVar5 | (ushort)iVar3 & 0x3e0;
    *(byte *)((int)puVar4 + 3) =
         *(byte *)((int)puVar4 + 3) & 0x83 | (byte)(((uint)(iVar3 << 0x11) >> 0x1b) << 2);
    bVar2 = bVar2 + 1;
    puVar4 = puVar5;
    param_2 = (int *)((int)param_2 + 2);
  } while (bVar2 < 0x10);
  return in_lr;
}


