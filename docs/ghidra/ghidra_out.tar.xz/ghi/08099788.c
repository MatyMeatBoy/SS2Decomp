
undefined4 sub_08099788(void)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  uVar4 = 0;
  iVar3 = *(int *)DWORD_080997bc;
  do {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 != 0) {
      sub_080003A8(iVar3);
    }
    dVar1 = DWORD_080997bc;
    iVar3 = iVar3 + 0x28;
    uVar4 = uVar4 + 1;
  } while (uVar4 < 0x40);
  sub_08001538(*(undefined4 *)DWORD_080997bc);
  *(undefined4 *)dVar1 = 0;
  return in_lr;
}


