
undefined4 sub_080A0FC4(void)

{
  dword dVar1;
  int iVar2;
  undefined4 in_lr;
  
  dVar1 = DWORD_080a0fe8;
  iVar2 = sub_08000470(*(undefined4 *)DWORD_080a0fe8);
  if (iVar2 != 0) {
    sub_080003A8(*(undefined4 *)dVar1);
  }
  sub_08001538(*(undefined4 *)dVar1);
  *(undefined4 *)dVar1 = 0;
  return in_lr;
}


