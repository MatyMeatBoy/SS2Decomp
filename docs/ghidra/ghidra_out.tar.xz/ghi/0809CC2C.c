
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_0809CC2C(uint param_1)

{
  char cVar1;
  undefined1 uVar2;
  undefined2 uVar3;
  short sVar4;
  dword dVar5;
  short *psVar6;
  uint uVar7;
  undefined4 uVar8;
  ushort *puVar9;
  uint uVar10;
  int iVar11;
  ushort *puVar12;
  int *piVar13;
  ushort *puVar14;
  undefined2 *puVar15;
  undefined4 in_lr;
  bool bVar16;
  undefined4 auStack_e4 [13];
  undefined4 auStack_b0 [13];
  short sStack_7c;
  short sStack_7a;
  uint uStack_78;
  undefined2 *puStack_74;
  undefined4 *puStack_70;
  uint uStack_6c;
  uint uStack_68;
  int iStack_64;
  undefined4 uStack_60;
  dword dStack_5c;
  dword dStack_58;
  dword dStack_54;
  uint uStack_50;
  uint uStack_4c;
  undefined4 uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  int iStack_34;
  undefined4 uStack_30;
  short *psStack_2c;
  ushort *puStack_28;
  uint uStack_24;
  
  uStack_78 = param_1 & 0xff;
  puVar15 = (undefined2 *)(*(int *)DWORD_0809cc80 + uStack_78 * 0x2e0 + 0x2e0);
  sub_0801A0A4(puVar15);
  *(uint *)DWORD_0809cc84 = *(uint *)DWORD_0809cc84 | 1 << (uStack_78 + 1 & 0xff);
  *(undefined2 **)(uStack_78 * 4 + DWORD_0809cc88) = puVar15;
  dVar5 = DWORD_0809cc90;
  if ((uStack_78 == 0) || (dVar5 = DWORD_0809cd9c, uStack_78 == 1)) {
    *(dword *)(puVar15 + 10) = dVar5;
  }
  *(dword *)(puVar15 + 0xc) = DWORD_0809cda0;
  iVar11 = uStack_78 + 1;
  sub_0801623C(puVar15,DWORD_0809cda4,iVar11);
  puStack_74 = puVar15 + 0x102;
  sub_08019F60();
  puVar15[0x24] = *(undefined2 *)(DWORD_0809cda8 + 0x90);
  *puVar15 = (short)iVar11;
  puVar15[1] = (short)uStack_78 + 5;
  *(undefined4 *)(puVar15 + 0x28) = 1;
  *(undefined4 *)(puVar15 + 0x2a) = 0;
  *(byte *)(puVar15 + 0xfe) = *(byte *)(puVar15 + 0xfe) & 0xf0 | (byte)iVar11 & 0xf;
  *(undefined2 *)((int)puVar15 + DWORD_0809cdac) = puVar15[1];
  *(undefined1 *)(puVar15 + 0x100) = 0xff;
  *(undefined1 *)((int)puVar15 + DWORD_0809cdb0) = 2;
  sub_08065158(auStack_e4,DWORD_0809cdb4,6,0xffffffff,0);
  sub_08065158(auStack_b0,DWORD_0809cdb8,6,0xffffffff,0);
  sVar4 = puStack_74[3];
  puVar15[0xeb] = sVar4 * 3;
  puVar15[0x2e] = sVar4 * 3;
  sVar4 = puStack_74[2];
  puVar15[0xea] = sVar4 * 0x14;
  puVar15[0x2f] = sVar4 * 0x14;
  psVar6 = puVar15 + 0x36;
  *psVar6 = 0;
  puVar14 = puVar15 + 0x35;
  *puVar14 = 0;
  puVar12 = puVar15 + 0x34;
  *puVar12 = 0;
  puVar15[6] = 0;
  dStack_5c = 0;
  dStack_58 = DWORD_0809cdbc;
  dStack_54 = DWORD_0809cdbc;
  uStack_4c = 0;
  uStack_50 = 0;
  uStack_38 = 0;
  iVar11 = sub_0800CE30();
  if (iVar11 == 1) {
    uStack_40 = 0x5a;
    uStack_60 = 0x100;
  }
  else {
    uStack_40 = 0xb4;
    uStack_60 = 0x80;
  }
  iStack_34 = uStack_78 << 2;
  uStack_30 = 0x16;
  puStack_28 = puStack_74 + 0x6b;
  psStack_2c = puVar15 + 0x2e;
  do {
    if (*(char *)DWORD_0809d1c0 == '\0') {
      sub_0801A0B0(puVar15);
    }
    else {
      sub_0801A0A4(puVar15);
    }
    if (*(short *)(*(int *)DWORD_0809d228 + 0x5c) == 0) {
      *psStack_2c = 0;
      puVar15[6] = 0xb;
      goto LAB_0809d1e2;
    }
    if ((puVar15[6] == 10) && (uStack_50 == 0)) {
      uStack_50 = 8;
    }
    iVar11 = sub_08058DB0();
    if (iVar11 == 0) {
      sub_0801C8F0(puVar15);
      switch(*(undefined1 *)((int)puVar15 + DWORD_0809ce24)) {
      case 1:
        puVar15[6] = 0;
        iVar11 = sub_080682B8(*puVar15);
        if (iVar11 != 0) {
          *(undefined1 *)((int)puVar15 + _UNK_0809ce74) = *(undefined1 *)(puVar15 + 0xff);
          sub_08065E38(*puVar15);
        }
        break;
      case 2:
        dStack_5c = 0;
        iVar11 = sub_08056F78();
        if (iVar11 != 0) {
          *(undefined1 *)(puVar15 + 0xff) = 4;
          iVar11 = _UNK_0809ce98;
code_r0x0809cf62:
          *(undefined1 *)((int)puVar15 + iVar11) = 1;
code_r0x0809cf66:
          sub_08068330(*puVar15);
        }
        break;
      case 4:
        dStack_5c = 1;
        puVar15[6] = 1;
        iVar11 = sub_08096594(uStack_78);
        uVar7 = *(byte *)(puVar15 + 0xfe) & 0xf | iVar11 << 4;
        *(byte *)(puVar15 + 0xfe) = (byte)uVar7;
        puVar9 = *(ushort **)(((uVar7 << 0x18) >> 0x1c) * 0x14c + _UNK_0809cf14 + 0x148);
        uStack_6c = (uint)(*puVar9 >> 4);
        uStack_68 = puVar9[1] & 0xfff;
        cVar1 = sub_08097AC0(puVar15,uStack_6c,uStack_68,uStack_60,0x30,dStack_5c);
        if (cVar1 == '\0') {
          sub_08097A38(uStack_78);
          *(undefined1 *)(puVar15 + 0xff) = 6;
          *(undefined1 *)((int)puVar15 + _UNK_0809cf18) = 1;
          goto code_r0x0809cf66;
        }
        break;
      case 6:
        dStack_5c = 2;
        puVar15[6] = 2;
        if (((*puVar14 == 1) && (*psVar6 == 0)) && (uStack_38 == 0)) {
          uStack_38 = sub_0809D374(puVar15);
          uStack_38 = uStack_38 & 0xff;
        }
        if (puVar15[0x37] != 0) {
          uStack_38 = 0;
          uStack_44 = 0;
          *(undefined1 *)(puVar15 + 0xff) = 8;
          iVar11 = _UNK_0809cf70;
          goto code_r0x0809cf62;
        }
        break;
      case 8:
        dStack_5c = 0;
        puVar15[6] = 0;
        uVar7 = uStack_44 + 1 & 0xffff;
        bVar16 = uStack_40 <= uStack_44;
        uStack_44 = uVar7;
        if (bVar16) {
          *(undefined1 *)(puVar15 + 0xff) = 4;
          *(undefined1 *)((int)puVar15 + _UNK_0809cfb8) = 1;
          sub_08068330(*puVar15);
        }
      }
    }
    sub_08096640(puVar15);
    if (dStack_5c == 1) {
      puStack_70 = auStack_e4;
      *puVar12 = puVar15[4] + 8;
      uStack_48 = 1;
    }
    else if ((int)dStack_5c < 2) {
      if (dStack_5c == 0) {
        puStack_70 = auStack_e4;
        *puVar12 = puVar15[4];
        uStack_48 = 1;
      }
    }
    else if (dStack_5c == 2) {
      puStack_70 = auStack_b0;
      *puVar12 = puVar15[4];
      uStack_48 = 0;
    }
    if ((dStack_58 != *puVar12) || (dStack_54 != dStack_5c)) {
      dStack_54 = dStack_5c;
      dStack_58 = (dword)*puVar12;
      *psVar6 = 0;
      *puVar14 = 0;
    }
    *(undefined1 *)(puStack_70 + 7) = 6;
    sub_08000AF0(uStack_30,puStack_70[3] + (uint)*puStack_28 * 0x20,1);
    uVar7 = sub_08098004();
    if ((uVar7 & 1) == 0) {
      uVar2 = sub_0800BC44(*(int *)(puVar15 + 10) >> 8,*(int *)(puVar15 + 0xc) >> 8,0);
    }
    else {
      uVar2 = sub_08097FF8();
    }
    iVar11 = sub_0800CD8C();
    if (iVar11 == 0) {
      uVar3 = sub_08065370(puStack_70,*puVar12,puVar14,psVar6,uStack_48);
      puVar15[0x37] = uVar3;
    }
    sub_0800BC08((*(int *)(puVar15 + 10) << 8) >> 0x10,(*(int *)(puVar15 + 0xc) << 8) >> 0x10,
                 &sStack_7c,&sStack_7a,0,0);
    if (uStack_50 == 0) {
      iVar11 = sub_0800CCCC();
      if (((iVar11 == 0) && (iVar11 = sub_0800CC98(), iVar11 == 0)) &&
         (iVar11 = sub_0800CD34(), iVar11 == 0)) {
        uStack_24 = (uint)*puVar14;
        sub_08007870((int)sStack_7c,(int)sStack_7a,*puVar12,uStack_24,uVar2,puStack_70 + 7,
                     puStack_70[2],*puStack_70);
      }
    }
    else {
      uVar7 = uStack_50 - 1 & 0xffff;
      uVar10 = uStack_50 & 1;
      uStack_50 = uVar7;
      if ((((uVar10 != 0) && (iVar11 = sub_0800CCCC(), iVar11 == 0)) &&
          (iVar11 = sub_0800CC98(), iVar11 == 0)) && (iVar11 = sub_0800CD34(), iVar11 == 0)) {
        uStack_24 = (uint)*puVar14;
        sub_08007870((int)sStack_7c,(int)sStack_7a,*puVar12,uStack_24,uVar2,puStack_70 + 7,
                     puStack_70[2],*puStack_70);
      }
    }
    iVar11 = *(int *)(puVar15 + 0x26);
    if ((iVar11 != 0) && (iStack_64 != iVar11)) {
      uStack_4c = 10;
      uStack_3c = 0;
      iStack_64 = iVar11;
    }
    if (uStack_4c == 0) {
      iStack_64 = 0;
      *(undefined4 *)(puVar15 + 0x26) = 0;
    }
    else {
      iVar11 = sub_0800CC98();
      if (((iVar11 == 0) && (iVar11 = sub_0800CCCC(), iVar11 == 0)) &&
         (iVar11 = sub_0800CD34(), iVar11 == 0)) {
        sub_0801A120(puVar15,iStack_64,(int)(short)uStack_3c);
      }
      if ((uStack_4c & 2) != 0) {
        uStack_3c = uStack_3c * 0x10000 + DWORD_0809d190 >> 0x10;
      }
      uStack_4c = uStack_4c - 1 & 0xffff;
    }
    sVar4 = sub_08019CE8(puVar15);
    if (sVar4 != 0) {
      sub_080003F0();
LAB_0809d1e2:
      *(uint *)DWORD_0809d22c =
           *(uint *)DWORD_0809d22c & ~(1 << (**(ushort **)(iStack_34 + DWORD_0809d230) & 0xff));
      uStack_50 = 0x14;
      do {
        *(undefined1 *)(puStack_70 + 7) = 6;
        sub_08000AF0(uStack_30,puStack_70[3] + (uint)*puStack_28 * 0x20,1);
        uVar7 = sub_08098004();
        if ((uVar7 & 1) == 0) {
          uVar2 = sub_0800BC44(*(int *)(puVar15 + 10) >> 8,*(int *)(puVar15 + 0xc) >> 8,0);
        }
        else {
          uVar2 = sub_08097FF8();
        }
        iVar11 = sub_0800CD8C();
        if (iVar11 == 0) {
          uVar3 = sub_08065370(puStack_70,*puVar12,puVar14,psVar6,uStack_48);
          puVar15[0x37] = uVar3;
        }
        sub_0800BC08((*(int *)(puVar15 + 10) << 8) >> 0x10,(*(int *)(puVar15 + 0xc) << 8) >> 0x10,
                     &sStack_7c,&sStack_7a,0,0);
        if (((((uStack_50 & 1) != 0) && (iVar11 = sub_0800CCCC(), iVar11 == 0)) &&
            (iVar11 = sub_0800CC98(), iVar11 == 0)) && (iVar11 = sub_0800CD34(), iVar11 == 0)) {
          uStack_24 = (uint)*puVar14;
          sub_08007870((int)sStack_7c,(int)sStack_7a,*puVar12,uStack_24,uVar2,puStack_70 + 7,
                       puStack_70[2],*puStack_70);
        }
        sub_080003F0();
        uStack_50 = uStack_50 - 1 & 0xffff;
      } while (uStack_50 != DWORD_0809d360);
      iVar11 = sub_080020F4();
      if (((*(uint *)(iVar11 * 0x14c + DWORD_0809d364 + 0x30) & 0x2000) == 0) &&
         (piVar13 = (int *)(iStack_34 + DWORD_0809d368), *(short *)(*piVar13 + 0x5a) != 0)) {
        uVar8 = sub_0801E46C(*(undefined4 *)DWORD_0809d36c,puStack_74);
        uStack_3c = 0x1d;
        do {
          iVar11 = *piVar13;
          *(int *)(iVar11 + 0x18) = *(int *)(iVar11 + 0x18) + -0x20;
          sub_0806171C(iVar11,uVar8);
          sub_080003F0();
          uVar7 = uStack_3c * 0x10000 + DWORD_0809d370;
          uStack_3c = uVar7 >> 0x10;
        } while ((int)uVar7 >> 0x10 != -1);
        sub_0801E4CC(*(undefined4 *)DWORD_0809d36c,uVar8);
      }
      return in_lr;
    }
    sub_080003F0();
  } while( true );
}


