
/* WARNING: Possible PIC construction at 0x0809d8ec: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0809d8f0) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_0809D878(ushort *param_1)

{
  bool bVar1;
  ushort uVar2;
  undefined2 *puVar3;
  dword dVar4;
  dword dVar5;
  char cVar6;
  char cVar7;
  byte bVar8;
  undefined1 uVar9;
  ushort uVar10;
  short sVar11;
  int iVar12;
  uint uVar13;
  ushort *puVar14;
  undefined4 uVar15;
  uint uVar16;
  uint uVar17;
  uint *puVar18;
  int iVar19;
  uint uVar20;
  undefined4 in_lr;
  undefined4 auStack_9c [2];
  undefined4 uStack_94;
  int iStack_90;
  undefined1 auStack_80 [24];
  short sStack_68;
  short sStack_66;
  ushort *puStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  dword dStack_54;
  undefined4 uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  int iStack_30;
  ushort *puStack_2c;
  ushort *puStack_28;
  ushort *puStack_24;
  
  *puRam0809d8f0 = param_1;
  puStack_64 = param_1 + 0x102;
  sub_0801623C(param_1,uRam0809d8f4,0);
  sub_08019F60(puStack_64);
  sub_0801A0A4(param_1);
  puVar14 = puRam0809d8f8;
  uVar10 = sub_08016E04(param_1[0x16c],*(undefined2 *)((int)param_1 + iRam0809d8fc));
  *puVar14 = uVar10;
  puVar18 = puRam0809d904;
  puVar3 = (undefined2 *)DWORD_0809da4c;
  uVar13 = uRam0809d900;
  while (DWORD_0809da4c = (dword)puVar3, uVar10 == uVar13) {
    param_1[6] = 0xb;
    iVar12 = sub_0800CB78();
    if ((iVar12 != 0) || (iVar12 = sub_08056E90(), iVar12 != 0)) {
      *puVar18 = *puVar18 & ~(1 << (*param_1 & 0xff));
      return in_lr;
    }
    sub_080003F0();
    puVar3 = (undefined2 *)DWORD_0809da4c;
    uVar13 = (uint)*(ushort *)DWORD_0809da4c;
  }
  sub_08065158(auStack_9c,DWORD_0809da50,*puVar3,0xffffffff,1);
  auStack_80[0] = (undefined1)*puVar3;
  uVar10 = puStack_64[3];
  param_1[0xeb] = uVar10 * 3;
  param_1[0x2e] = uVar10 * 3;
  uVar10 = puStack_64[2];
  param_1[0xea] = uVar10 * 0x14;
  param_1[0x2f] = uVar10 * 0x14;
  *(byte *)((int)param_1 + DWORD_0809da54) = 2;
  *(byte *)(param_1 + 0xff) = 2;
  param_1[6] = 0;
  uVar20 = 0;
  dStack_54 = DWORD_0809da58;
  uStack_4c = 0;
  uStack_48 = 0;
  sub_08097FE4();
  sub_08097A4C();
  sub_08097C4C();
  sub_0809F918();
  sub_0809F998();
  sub_0809F9F8();
  sub_0809FACC();
  *(undefined2 *)(DWORD_0809da5c + 0x72) = 0x1e;
  puStack_28 = param_1 + 0x36;
  *puStack_28 = (ushort)uStack_48;
  puStack_2c = param_1 + 0x35;
  *puStack_2c = (ushort)uStack_48;
  puVar14 = param_1 + 0x34;
  *puVar14 = (ushort)uStack_48;
  uVar13 = 0;
  uStack_34 = 0;
  uStack_38 = 0;
  uStack_44 = 0;
  uStack_3c = 0;
  param_1[0x28] = 1;
  dVar4 = DWORD_0809da60;
  param_1[0x29] = 0;
  puStack_24 = puStack_64 + 0x6b;
  do {
    uVar17 = 0;
    do {
      *(undefined4 *)((short)uVar17 * 4 + ((int)(uVar13 * 0x10000) >> 0x10) * 0x14c + dVar4) = 0;
      uVar16 = (int)(short)uVar17 + 1;
      uVar17 = uVar16 & 0xffff;
    } while ((int)(uVar16 * 0x10000) >> 0x10 < 5);
    uVar17 = uVar13 * 0x10000 + 0x10000;
    uVar13 = uVar17 >> 0x10;
  } while ((int)uVar17 >> 0x10 < 4);
  *(byte *)(param_1 + 0xfe) = (byte)param_1[0xfe] & 0xf0 | (byte)*param_1 & 0xf;
  *(ushort *)((int)param_1 + DWORD_0809da64) = param_1[1];
  *(byte *)(param_1 + 0x100) = 0xff;
  iStack_30 = 0;
  sub_08067C18();
  while (iVar12 = sub_08067C08(), iVar12 == 0) {
    sub_080003F0();
  }
  sub_08067BF8();
  do {
    iVar12 = sub_0800CB78();
    if ((iVar12 != 0) || (iVar12 = sub_08056E90(), iVar12 != 0)) break;
    if ((param_1[6] == 10) && (uStack_4c == 0)) {
      uStack_4c = 8;
    }
    iVar12 = sub_08058DB0();
    if (iVar12 == 0) {
      sub_0801C8F0(param_1);
      switch(*(byte *)((int)param_1 + DWORD_0809dab4)) {
      case 1:
        param_1[6] = 0;
        iVar12 = sub_08067C08();
        if (iVar12 != 0) {
          *(byte *)((int)param_1 + _UNK_0809db00) = (byte)param_1[0xff];
          sub_08067BF8();
        }
        break;
      case 2:
        uVar20 = 0;
        iVar12 = sub_08056F78();
        if (iVar12 != 0) {
          bVar8 = 3;
          goto code_r0x0809dc70;
        }
        break;
      case 3:
        uVar20 = 1;
        param_1[6] = 1;
        cVar6 = (char)uStack_34;
        iVar12 = cVar6 * 8;
        iStack_60 = *(int *)(iVar12 + _UNK_0809db8c) >> 8;
        iStack_5c = *(int *)(iVar12 + _UNK_0809db8c + 4) >> 8;
        cVar7 = sub_08097AC0(param_1,iStack_60,iStack_5c,0x140,8,0);
        if (cVar7 == '\0') {
          uStack_44 = 0;
          uVar13 = (int)cVar6 + 1;
          uStack_34 = uVar13 & 0xff;
          if ((int)(uVar13 * 0x1000000) >> 0x18 == 5) {
            uStack_34 = 0;
          }
          *(byte *)(param_1 + 0xff) = 4;
          *(byte *)((int)param_1 + _UNK_0809db90) = 1;
          sub_08067C18();
        }
        break;
      case 4:
        uVar20 = 2;
        param_1[6] = 2;
        uStack_44 = uStack_44 + 1 & 0xffff;
        if (0x3b < uStack_44) {
          uStack_44 = 0;
          uVar13 = uStack_38 + 1;
          uStack_38 = uVar13 & 0xff;
          if (uStack_38 == 6) {
            uStack_38 = 0;
            *(byte *)(param_1 + 0xff) = 7;
            iVar12 = _UNK_0809dc10;
          }
          else if ((uVar13 & 1) == 0) {
            *(byte *)(param_1 + 0xff) = 6;
            sub_0809FB18();
            iVar12 = _UNK_0809dc10;
          }
          else {
            *(byte *)(param_1 + 0xff) = 5;
            sub_0809FA64(0);
            sub_0809FA64(1);
            sub_0809FA64(2);
            sub_0809FA64(3);
            iVar12 = _UNK_0809dc10;
          }
          goto code_r0x0809dc76;
        }
        break;
      case 5:
        uVar20 = 2;
        param_1[6] = 2;
        bVar1 = 0x3c < uStack_44;
        uStack_44 = uStack_44 + 1 & 0xffff;
        if (bVar1) {
          uStack_44 = 0;
          bVar8 = 3;
          goto code_r0x0809dc70;
        }
        break;
      case 6:
        uVar20 = 2;
        param_1[6] = 2;
        bVar1 = 0xb4 < uStack_44;
        uStack_44 = uStack_44 + 1 & 0xffff;
        if (bVar1) {
          uStack_44 = 0;
          bVar8 = 3;
          goto code_r0x0809dc70;
        }
        break;
      case 7:
        uVar20 = 2;
        param_1[6] = 2;
        sub_0809F90C();
        bVar8 = 8;
code_r0x0809dc70:
        *(byte *)(param_1 + 0xff) = bVar8;
        iVar12 = _UNK_0809dc80;
code_r0x0809dc76:
        *(byte *)((int)param_1 + iVar12) = 1;
        sub_08067C18();
        break;
      case 8:
        uVar20 = 2;
        param_1[6] = 2;
        *(byte *)(param_1 + 0xff) = 5;
        *(byte *)((int)param_1 + _UNK_0809dcd0) = 1;
        sub_08067C18();
      }
      uStack_3c = uStack_3c + 2 & 0xff;
      *(int *)(param_1 + 0xc) =
           *(int *)(param_1 + 0xc) + ((int)*(short *)(uStack_3c * 2 + DWORD_0809dcd4) >> 1);
    }
    if (uVar20 == 1) {
      *puVar14 = param_1[4] + 8;
      uStack_50 = 1;
    }
    else if (uVar20 < 2) {
      if (uVar20 == 0) {
        uVar10 = param_1[4];
LAB_0809dcfe:
        *puVar14 = uVar10;
        uStack_50 = 1;
      }
    }
    else if (uVar20 == 2) {
      if (*(byte *)((int)param_1 + DWORD_0809dd08) == 5) {
        uVar10 = param_1[4] + 8;
        goto LAB_0809dcfe;
      }
      *puVar14 = 0x18;
      uStack_50 = 0;
    }
    iVar12 = *(int *)DWORD_0809dd60;
    if (dStack_54 != *(ushort *)(iVar12 + 0x68)) {
      dStack_54 = (dword)*(ushort *)(iVar12 + 0x68);
      *(undefined2 *)(iVar12 + 0x6c) = 0;
      *(undefined2 *)(iVar12 + 0x6a) = 0;
    }
    sub_08000AF0(*(ushort *)DWORD_0809dd64 + 0x10,iStack_90 + (uint)*puStack_24 * 0x20,1);
    uVar13 = sub_08098004();
    if ((uVar13 & 1) == 0) {
      uVar9 = sub_0800BC44(*(int *)(param_1 + 10) >> 8,*(int *)(param_1 + 0xc) >> 8,0);
    }
    else {
      uVar9 = sub_08097FF8();
    }
    iVar12 = sub_0800CD8C();
    if (iVar12 == 0) {
      uVar10 = sub_08065370(auStack_9c,*puVar14,puStack_2c,puStack_28,uStack_50);
      param_1[0x37] = uVar10;
    }
    sub_0800BC08((*(int *)(param_1 + 10) << 8) >> 0x10,(*(int *)(param_1 + 0xc) << 8) >> 0x10,
                 &sStack_68,&sStack_66,0,0);
    if (uStack_4c == 0) {
      iVar12 = sub_0800CCCC();
      if (((iVar12 == 0) && (iVar12 = sub_0800CC98(), iVar12 == 0)) &&
         (iVar12 = sub_0800CD34(), iVar12 == 0)) {
        uVar10 = *puVar14;
        uVar2 = *puStack_2c;
        goto LAB_0809de26;
      }
    }
    else {
      uVar13 = uStack_4c - 1 & 0xffff;
      uVar17 = uStack_4c & 1;
      uStack_4c = uVar13;
      if (((uVar17 != 0) && (iVar12 = sub_0800CCCC(), iVar12 == 0)) &&
         ((iVar12 = sub_0800CC98(), iVar12 == 0 && (iVar12 = sub_0800CD34(), iVar12 == 0)))) {
        uVar10 = *puVar14;
        uVar2 = *puStack_2c;
LAB_0809de26:
        iVar12 = sub_08007870((int)sStack_68,0xa0,uVar10,uVar2,uVar9,auStack_80,uStack_94,
                              auStack_9c[0]);
        *(int *)(iVar12 + 0xc) = (int)sStack_66;
      }
    }
    iVar12 = *(int *)(param_1 + 0x26);
    if ((iVar12 != 0) && (iStack_58 != iVar12)) {
      uStack_48 = 10;
      uStack_40 = 0;
      iStack_58 = iVar12;
    }
    if (uStack_48 == 0) {
      iStack_58 = 0;
      param_1[0x26] = 0;
      param_1[0x27] = 0;
    }
    else {
      iVar12 = sub_0800CC98();
      if (((iVar12 == 0) && (iVar12 = sub_0800CCCC(), iVar12 == 0)) &&
         (iVar12 = sub_0800CD34(), iVar12 == 0)) {
        sub_0801A120(param_1,iStack_58,(int)(short)uStack_40);
      }
      if ((uStack_48 & 2) != 0) {
        uStack_40 = uStack_40 * 0x10000 + DWORD_0809dea4 >> 0x10;
      }
      uStack_48 = uStack_48 - 1 & 0xffff;
    }
    sVar11 = sub_08019CE8(param_1);
    if (sVar11 != 0) {
      iStack_30 = 1;
    }
    sub_080003F0();
  } while (iStack_30 == 0);
  *(undefined4 *)DWORD_0809e048 = 0;
  iVar12 = sub_080020F4();
  puVar18 = (uint *)(iVar12 * 0x14c + DWORD_0809e04c + 0x30);
  *puVar18 = *puVar18 | 1;
  sub_0809FAEC();
  sub_0809FA28();
  sub_08097C6C();
  dVar4 = DWORD_0809e050;
  iVar12 = *(int *)DWORD_0809e050;
  *(undefined2 *)(iVar12 + 0x6c) = 0;
  *(undefined2 *)(iVar12 + 0x6a) = 0;
  *(undefined2 *)(iVar12 + 0x68) = 0;
  dVar5 = DWORD_0809e054;
  uStack_40 = 0;
  uStack_48 = 10;
  do {
    iVar12 = sub_080020F4();
    puVar18 = (uint *)(iVar12 * 0x14c + DWORD_0809e04c + 0x30);
    *puVar18 = *puVar18 | 1;
    iVar12 = sub_0800CCCC();
    if (((iVar12 == 0) && (iVar12 = sub_0800CC98(), iVar12 == 0)) &&
       (iVar12 = sub_0800CD34(), iVar12 == 0)) {
      sub_08000AF0(*(ushort *)dVar5 + 0x10,iStack_90 + (uint)*puStack_24 * 0x20,1);
      uVar9 = sub_0800BC44(*(int *)(*(int *)dVar4 + 0x14) >> 8,*(int *)(*(int *)dVar4 + 0x18) >> 8,0
                          );
      auStack_80[0] = (undefined1)*(undefined2 *)dVar5;
      iVar12 = *(int *)dVar4;
      sub_08065370(auStack_9c,*(undefined2 *)(iVar12 + 0x68),iVar12 + 0x6a,iVar12 + 0x6c,0);
      sub_0800BC08((*(int *)(*(int *)dVar4 + 0x14) << 8) >> 0x10,
                   (*(int *)(*(int *)dVar4 + 0x18) << 8) >> 0x10,&sStack_68,&sStack_66,0,0);
      sub_08007870((int)sStack_68,(int)sStack_66,*(undefined2 *)(*(int *)dVar4 + 0x68),
                   *(undefined2 *)(*(int *)dVar4 + 0x6a),uVar9,auStack_80,uStack_94,auStack_9c[0]);
      sub_0801A120(param_1,iStack_58,(int)(short)uStack_40);
    }
    if ((uStack_48 & 2) != 0) {
      uStack_40 = uStack_40 * 0x10000 + DWORD_0809e058 >> 0x10;
    }
    sub_080003F0();
    uStack_48 = uStack_48 - 1 & 0xffff;
  } while (uStack_48 != DWORD_0809e05c);
  sub_080683CC();
  sub_08067CA8(param_1[1]);
  sub_08068330(DWORD_0809e060);
  dVar5 = DWORD_0809e054;
  dVar4 = DWORD_0809e050;
  while (iVar12 = sub_080682B8(DWORD_0809e154), iVar12 == 0) {
    iVar12 = sub_080020F4();
    puVar18 = (uint *)(iVar12 * 0x14c + DWORD_0809e150 + 0x30);
    *puVar18 = *puVar18 | 1;
    iVar12 = sub_0800CCCC();
    if (((iVar12 == 0) && (iVar12 = sub_0800CC98(), iVar12 == 0)) &&
       ((iVar12 = sub_0800CD8C(), iVar12 == 0 && (iVar12 = sub_0800CD34(), iVar12 == 0)))) {
      sub_08000AF0(*(ushort *)dVar5 + 0x10,iStack_90 + (uint)*puStack_24 * 0x20,1);
      uVar9 = sub_0800BC44(*(int *)(*(int *)dVar4 + 0x14) >> 8,*(int *)(*(int *)dVar4 + 0x18) >> 8,0
                          );
      auStack_80[0] = (undefined1)*(undefined2 *)dVar5;
      iVar12 = *(int *)dVar4;
      sub_08065370(auStack_9c,*(undefined2 *)(iVar12 + 0x68),iVar12 + 0x6a,iVar12 + 0x6c,0);
      sub_0800BC08((*(int *)(*(int *)dVar4 + 0x14) << 8) >> 0x10,
                   (*(int *)(*(int *)dVar4 + 0x18) << 8) >> 0x10,&sStack_68,&sStack_66,0,0);
      sub_08007870((int)sStack_68,(int)sStack_66,*(undefined2 *)(*(int *)dVar4 + 0x68),
                   *(undefined2 *)(*(int *)dVar4 + 0x6a),uVar9,auStack_80,uStack_94,auStack_9c[0]);
    }
    sub_080003F0();
  }
  sub_08065E38(DWORD_0809e154);
  dVar5 = DWORD_0809e15c;
  dVar4 = DWORD_0809e158;
  while (iVar12 = sub_08058DB0(), iVar12 != 0) {
    iVar12 = sub_080020F4();
    puVar18 = (uint *)(iVar12 * 0x14c + DWORD_0809e268 + 0x30);
    *puVar18 = *puVar18 | 1;
    iVar12 = sub_0800CCCC();
    if ((((iVar12 == 0) && (iVar12 = sub_0800CC98(), iVar12 == 0)) &&
        (iVar12 = sub_0800CD8C(), iVar12 == 0)) && (iVar12 = sub_0800CD34(), iVar12 == 0)) {
      sub_08000AF0(*(ushort *)dVar4 + 0x10,iStack_90 + (uint)*puStack_24 * 0x20,1);
      uVar9 = sub_0800BC44(*(int *)(*(int *)dVar5 + 0x14) >> 8,*(int *)(*(int *)dVar5 + 0x18) >> 8,0
                          );
      auStack_80[0] = (undefined1)*(undefined2 *)dVar4;
      iVar12 = *(int *)dVar5;
      sub_08065370(auStack_9c,*(undefined2 *)(iVar12 + 0x68),iVar12 + 0x6a,iVar12 + 0x6c,0);
      sub_0800BC08((*(int *)(*(int *)dVar5 + 0x14) << 8) >> 0x10,
                   (*(int *)(*(int *)dVar5 + 0x18) << 8) >> 0x10,&sStack_68,&sStack_66,0,0);
      sub_08007870((int)sStack_68,(int)sStack_66,*(undefined2 *)(*(int *)dVar5 + 0x68),
                   *(undefined2 *)(*(int *)dVar5 + 0x6a),uVar9,auStack_80,uStack_94,auStack_9c[0]);
    }
    sub_080003F0();
  }
  sub_080586B4(0);
  uVar15 = sub_0805DF38(1,0xe,0x19,2,0x3c,DWORD_0809e26c);
  *(undefined4 *)(*(int *)DWORD_0809e270 + 0x720) = uVar15;
  dVar5 = DWORD_0809e278;
  dVar4 = DWORD_0809e274;
  while (iVar12 = sub_0805EEFC(*(undefined4 *)(*(int *)DWORD_0809e41c + 0x720)), iVar12 == 0) {
    iVar12 = sub_080020F4();
    puVar18 = (uint *)(iVar12 * 0x14c + DWORD_0809e418 + 0x30);
    *puVar18 = *puVar18 | 1;
    iVar12 = sub_0800CCCC();
    if (((iVar12 == 0) && (iVar12 = sub_0800CC98(), iVar12 == 0)) &&
       ((iVar12 = sub_0800CD8C(), iVar12 == 0 && (iVar12 = sub_0800CD34(), iVar12 == 0)))) {
      sub_08000AF0(*(ushort *)dVar4 + 0x10,iStack_90 + (uint)*puStack_24 * 0x20,1);
      uVar9 = sub_0800BC44(*(int *)(*(int *)dVar5 + 0x14) >> 8,*(int *)(*(int *)dVar5 + 0x18) >> 8,0
                          );
      auStack_80[0] = (undefined1)*(undefined2 *)dVar4;
      iVar12 = *(int *)dVar5;
      sub_08065370(auStack_9c,*(undefined2 *)(iVar12 + 0x68),iVar12 + 0x6a,iVar12 + 0x6c,0);
      sub_0800BC08((*(int *)(*(int *)dVar5 + 0x14) << 8) >> 0x10,
                   (*(int *)(*(int *)dVar5 + 0x18) << 8) >> 0x10,&sStack_68,&sStack_66,0,0);
      sub_08007870((int)sStack_68,(int)sStack_66,*(undefined2 *)(*(int *)dVar5 + 0x68),
                   *(undefined2 *)(*(int *)dVar5 + 0x6a),uVar9,auStack_80,uStack_94,auStack_9c[0]);
    }
    sub_080003F0();
  }
  iVar12 = sub_080020F4();
  iVar19 = DWORD_0809e418 + 0x30;
  puVar18 = (uint *)(iVar12 * 0x14c + iVar19);
  *puVar18 = *puVar18 & 0xfffffffe;
  sub_08058688(0xd);
  dVar4 = DWORD_0809e420;
  sub_080970CC(*(undefined4 *)DWORD_0809e420,auStack_9c,*puStack_24,*(undefined2 *)DWORD_0809e424);
  iVar12 = sub_080020F4();
  if (((*(uint *)(iVar12 * 0x14c + iVar19) & 0x2000) == 0) &&
     (*(short *)(*(int *)dVar4 + 0x5a) != 0)) {
    uVar15 = sub_0801E46C(*(undefined4 *)DWORD_0809e428,puStack_64);
    uStack_40 = 0x1d;
    do {
      iVar12 = *(int *)DWORD_0809e420;
      *(int *)(iVar12 + 0x18) = *(int *)(iVar12 + 0x18) + -0x20;
      sub_0806171C(iVar12,uVar15);
      sub_080003F0();
      uVar13 = uStack_40 * 0x10000 + DWORD_0809e42c;
      uStack_40 = uVar13 >> 0x10;
    } while ((int)uVar13 >> 0x10 != -1);
    sub_0801E4CC(*(undefined4 *)DWORD_0809e428,uVar15);
  }
  uStack_40 = 0x6f;
  do {
    sub_080003F0();
    uVar13 = uStack_40 * 0x10000 + DWORD_0809e42c;
    uStack_40 = uVar13 >> 0x10;
  } while ((int)uVar13 >> 0x10 != -1);
  sub_08067C18();
  while (iVar12 = sub_08067C08(), iVar12 == 0) {
    sub_080003F0();
  }
  sub_08067BF8();
  sub_08056E24();
  while (iVar12 = sub_08056E90(), iVar12 == 0) {
    sub_080003F0();
  }
  sub_0809F934();
  return in_lr;
}


