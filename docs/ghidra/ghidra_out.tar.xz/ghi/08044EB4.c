
void sub_08044EB4(int param_1)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  dword dVar4;
  short sVar5;
  int iVar6;
  undefined4 uVar7;
  int *piVar8;
  int iVar9;
  dword dVar10;
  uint uVar11;
  
  dVar4 = DWORD_08044ee4;
LAB_08044ec8:
  do {
    iVar6 = sub_0800CE30();
    if (iVar6 == 0) {
      bVar1 = *(byte *)(*(int *)dVar4 + 0x1b8);
    }
    else {
      bVar1 = *(byte *)(*(int *)dVar4 + 0x1c4);
    }
    iVar6 = sub_0800CE30();
    if (iVar6 == 0) {
      iVar6 = *(int *)dVar4;
      iVar9 = 0x1b8;
    }
    else {
      iVar6 = *(int *)dVar4;
      iVar9 = 0x1c4;
    }
    bVar2 = *(byte *)(iVar6 + iVar9);
    sVar5 = 1;
    do {
      sub_080003F0();
      iVar6 = sub_080021A8();
      if (iVar6 != 0) break;
      sVar5 = sVar5 + -1;
    } while (sVar5 != 0);
    iVar6 = sub_0800CE30();
    if (iVar6 == 0) {
      iVar6 = *(int *)dVar4;
      iVar9 = 0x1b8;
    }
    else {
      iVar6 = *(int *)dVar4;
      iVar9 = 0x1c4;
    }
    bVar3 = *(byte *)(iVar6 + iVar9);
    iVar6 = sub_0800CE30();
    if (iVar6 == 0) {
      iVar6 = *(int *)dVar4;
      iVar9 = 0x1b8;
    }
    else {
      iVar6 = *(int *)dVar4;
      iVar9 = 0x1c4;
    }
    uVar11 = DWORD_08044f98;
    if (((int)(uint)bVar1 >> 6 & 1U) != ((int)(uint)bVar3 >> 6 & 1U)) {
      do {
        sub_080003F0();
        iVar6 = sub_080021A8();
        if (iVar6 != 0) break;
        uVar11 = uVar11 - 1 & 0xffff;
      } while (uVar11 != 0);
      sub_0805EFBC();
      do {
        sub_080003F0();
        iVar6 = sub_0805F184();
      } while (iVar6 != 0);
      iVar6 = sub_080020F4();
      iVar6 = iVar6 * 0x14c + DWORD_08044fec;
      *(uint *)(iVar6 + 0x30) = *(uint *)(iVar6 + 0x30) | 1;
      sub_0800D0F4();
      dVar10 = DWORD_08044ff0;
      iVar6 = *(int *)dVar4 + DWORD_08044ff4;
      for (uVar11 = 0; uVar11 < 0x1e; uVar11 = uVar11 + 1) {
        iVar9 = sub_08000470(iVar6);
        if (iVar9 == 0) goto LAB_08045010;
        iVar6 = iVar6 + 0x28;
      }
      goto LAB_0804503a;
    }
  } while ((int)(uint)bVar2 >> 7 == (int)(uint)*(byte *)(iVar6 + iVar9) >> 7);
  sVar5 = 0xc80;
  do {
    sub_080003F0();
    iVar6 = sub_080021A8();
    if (iVar6 != 0) break;
    sVar5 = sVar5 + -1;
  } while (sVar5 != 0);
  sub_0805EFBC();
  do {
    sub_080003F0();
    iVar6 = sub_0805F184();
  } while (iVar6 != 0);
  iVar6 = sub_080020F4();
  iVar6 = iVar6 * 0x14c + DWORD_080451b0;
  *(uint *)(iVar6 + 0x30) = *(uint *)(iVar6 + 0x30) | 1;
  sub_0800D0F4();
  dVar10 = DWORD_080451b4;
  iVar6 = *(int *)dVar4 + DWORD_080451b8;
  for (uVar11 = 0; uVar11 < 0x1e; uVar11 = uVar11 + 1) {
    iVar9 = sub_08000470(iVar6);
    if (iVar9 == 0) goto LAB_080451d4;
    iVar6 = iVar6 + 0x28;
  }
  goto LAB_080451fe;
LAB_08045010:
  while( true ) {
    iVar9 = sub_08001494(0x400);
    *(int *)(iVar6 + 0x20) = iVar9;
    if (iVar9 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar6 + 8) = 0x3c;
  *(dword *)(iVar6 + 0xc) = dVar10;
  *(int *)(iVar6 + 0x10) = iVar9 + 0x3fc;
  *(undefined4 *)(iVar6 + 0x24) = 0;
  sub_08000274(iVar6,0x3c);
LAB_0804503a:
  sub_08028AAC(param_1,0x78,0xfa,0);
  sub_080290E4(param_1,4);
  sub_0802939C(param_1,8);
  sub_08028AAC(param_1,0x78,0x82,100);
  sub_0802939C(param_1,0);
  while (iVar6 = sub_0805F184(), iVar6 != 0) {
    sub_080003F0();
  }
  while (iVar6 = sub_0805EF90(), iVar6 != 0) {
    sub_080003F0();
  }
  uVar7 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_080450a0);
  while (iVar6 = sub_0805EEFC(uVar7), iVar6 == 0) {
    sub_080003F0();
  }
  sub_0802939C(param_1,8);
  sub_080290E4(param_1,6);
  sub_08028AAC(param_1,0xb0,0x82,0x28);
  sub_080290E4(param_1,4);
  sub_08028AAC(param_1,0xb0,0x60,0x1e);
  sub_080290E4(param_1,0);
  sub_0802939C(param_1,0);
  piVar8 = (int *)(*(int *)dVar4 + DWORD_08045144);
  uVar11 = 0;
  do {
    if (*piVar8 == param_1) goto LAB_08045116;
    uVar11 = uVar11 + 1;
    piVar8 = piVar8 + 0x1c;
  } while (uVar11 < 0xf);
  sub_080003F0();
  piVar8 = (int *)0x0;
LAB_08045116:
  if (piVar8 != (int *)0x0) {
    *(undefined2 *)(piVar8 + 6) = 8;
    *(undefined2 *)((int)piVar8 + 0x1a) = 4;
    piVar8[0xf] = piVar8[0xf] | 0x10;
  }
  piVar8 = (int *)(*(int *)dVar4 + DWORD_08045144);
  uVar11 = 0;
  do {
    dVar10 = DWORD_08045148;
    if (*piVar8 == param_1) goto LAB_0804530c;
    uVar11 = uVar11 + 1;
    piVar8 = piVar8 + 0x1c;
  } while (uVar11 < 0xf);
  goto LAB_08045306;
LAB_080451d4:
  while( true ) {
    iVar9 = sub_08001494(0x400);
    *(int *)(iVar6 + 0x20) = iVar9;
    if (iVar9 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar6 + 8) = 0x3c;
  *(dword *)(iVar6 + 0xc) = dVar10;
  *(int *)(iVar6 + 0x10) = iVar9 + 0x3fc;
  *(undefined4 *)(iVar6 + 0x24) = 0;
  sub_08000274(iVar6,0x3c);
LAB_080451fe:
  sub_08028AAC(param_1,0x78,0xfa,0);
  sub_080290E4(param_1,4);
  sub_0802939C(param_1,8);
  sub_08028AAC(param_1,0x78,0x82,100);
  sub_0802939C(param_1,0);
  while (iVar6 = sub_0805F184(), iVar6 != 0) {
    sub_080003F0();
  }
  while (iVar6 = sub_0805EF90(), iVar6 != 0) {
    sub_080003F0();
  }
  uVar7 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_08045264);
  while (iVar6 = sub_0805EEFC(uVar7), iVar6 == 0) {
    sub_080003F0();
  }
  sub_0802939C(param_1,8);
  sub_080290E4(param_1,6);
  sub_08028AAC(param_1,0xb0,0x82,0x28);
  sub_080290E4(param_1,4);
  sub_08028AAC(param_1,0xb0,0x60,0x1e);
  sub_080290E4(param_1,0);
  sub_0802939C(param_1,0);
  piVar8 = (int *)(*(int *)dVar4 + DWORD_0804533c);
  uVar11 = 0;
  do {
    if (*piVar8 == param_1) goto LAB_080452da;
    uVar11 = uVar11 + 1;
    piVar8 = piVar8 + 0x1c;
  } while (uVar11 < 0xf);
  sub_080003F0();
  piVar8 = (int *)0x0;
LAB_080452da:
  if (piVar8 != (int *)0x0) {
    *(undefined2 *)(piVar8 + 6) = 8;
    *(undefined2 *)((int)piVar8 + 0x1a) = 4;
    piVar8[0xf] = piVar8[0xf] | 0x10;
  }
  piVar8 = (int *)(*(int *)dVar4 + DWORD_0804533c);
  uVar11 = 0;
  do {
    dVar10 = DWORD_08045340;
    if (*piVar8 == param_1) goto LAB_0804530c;
    uVar11 = uVar11 + 1;
    piVar8 = piVar8 + 0x1c;
  } while (uVar11 < 0xf);
LAB_08045306:
  sub_080003F0();
  piVar8 = (int *)0x0;
LAB_0804530c:
  if (piVar8 != (int *)0x0) {
    piVar8[0x11] = dVar10;
  }
  sub_08068070(DWORD_08045344,0x17);
  iVar6 = sub_080020F4();
  iVar6 = iVar6 * 0x14c + DWORD_08045348;
  *(uint *)(iVar6 + 0x30) = *(uint *)(iVar6 + 0x30) & 0xfffffffe;
  sub_0800D108();
  goto LAB_08044ec8;
}


