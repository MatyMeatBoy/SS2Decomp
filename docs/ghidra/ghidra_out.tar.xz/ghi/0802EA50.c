
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_0802EA50(int param_1)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  byte *pbVar4;
  undefined1 *puVar5;
  undefined4 uVar6;
  bool bVar7;
  int *piVar8;
  uint uVar9;
  uint uVar10;
  undefined4 in_lr;
  
  iVar2 = sub_080289C0(0x21,0xb6,0x87);
  piVar8 = (int *)(*(int *)DWORD_0802eb40 + DWORD_0802eb44);
  uVar9 = 0;
  do {
    if (*piVar8 == iVar2) goto LAB_0802ea80;
    uVar9 = uVar9 + 1;
    piVar8 = piVar8 + 0x1c;
  } while (uVar9 < 0xf);
  sub_080003F0();
  piVar8 = (int *)0x0;
LAB_0802ea80:
  if (piVar8 != (int *)0x0) {
    *(undefined2 *)(piVar8 + 6) = 8;
    *(undefined2 *)((int)piVar8 + 0x1a) = 0x14;
    piVar8[0xf] = piVar8[0xf] | 0x10;
  }
  dVar1 = DWORD_0802eb48;
  piVar8 = (int *)(*(int *)DWORD_0802eb40 + DWORD_0802eb44);
  uVar9 = 0;
  do {
    if (*piVar8 == iVar2) goto LAB_0802eab4;
    uVar9 = uVar9 + 1;
    piVar8 = piVar8 + 0x1c;
  } while (uVar9 < 0xf);
  sub_080003F0();
  piVar8 = (int *)0x0;
LAB_0802eab4:
  if (piVar8 != (int *)0x0) {
    piVar8[0x11] = dVar1;
  }
  iVar2 = sub_080289C0(8,0x38,0x87);
  piVar8 = (int *)(*(int *)DWORD_0802eb40 + DWORD_0802eb44);
  uVar9 = 0;
  do {
    if (*piVar8 == iVar2) goto LAB_0802eae4;
    uVar9 = uVar9 + 1;
    piVar8 = piVar8 + 0x1c;
  } while (uVar9 < 0xf);
  sub_080003F0();
  piVar8 = (int *)0x0;
LAB_0802eae4:
  if (piVar8 != (int *)0x0) {
    *(undefined2 *)(piVar8 + 6) = 8;
    *(undefined2 *)((int)piVar8 + 0x1a) = 0x14;
    piVar8[0xf] = piVar8[0xf] | 0x10;
  }
  dVar1 = DWORD_0802eb4c;
  piVar8 = (int *)(*(int *)DWORD_0802eb40 + DWORD_0802eb44);
  uVar9 = 0;
  do {
    if (*piVar8 == iVar2) goto LAB_0802eb18;
    uVar9 = uVar9 + 1;
    piVar8 = piVar8 + 0x1c;
  } while (uVar9 < 0xf);
  sub_080003F0();
  piVar8 = (int *)0x0;
LAB_0802eb18:
  if (piVar8 != (int *)0x0) {
    piVar8[0x11] = dVar1;
  }
  sub_0802939C(iVar2,2);
  iVar2 = sub_08002164();
  iVar3 = sub_0800CE30();
  if (iVar3 == 0) {
    pbVar4 = (byte *)(*(int *)DWORD_0802ebc8 + DWORD_0802ebcc);
  }
  else {
    pbVar4 = (byte *)(*(int *)DWORD_0802eb40 + DWORD_0802eb50);
  }
  if ((((int)(uint)*pbVar4 >> 3 & 1U) != 0) || (iVar2 != 1)) {
    sub_08028AAC(6,DWORD_0802ebd0,DWORD_0802ebd0,0);
  }
  if (param_1 != 0) {
    sub_08028AAC(0,0xb8,0xa0,0);
    sub_080290E4(0,4);
  }
  if (param_1 == 1) {
    iVar2 = sub_080020F4();
    iVar2 = iVar2 * 0x14c + DWORD_0802ec08;
    *(uint *)(iVar2 + 0x30) = *(uint *)(iVar2 + 0x30) | 1;
    sub_0800D0F4();
    iVar2 = sub_0800CC98();
    if (iVar2 == 0) {
      iVar2 = sub_0801AB24();
      if (iVar2 == 1) {
        sub_0801AB50(6);
      }
      else if (iVar2 < 2) {
        if (iVar2 == 0) {
          sub_080576A8();
        }
      }
      else if (iVar2 == 2) {
        sub_0801AB90(6);
      }
      while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
        sub_080003F0();
      }
    }
    dVar1 = DWORD_0802ec58;
    uVar10 = 0;
    uVar9 = 0;
    do {
      iVar2 = sub_0800CE30();
      if (iVar2 == 0) {
        bVar7 = true;
        if ((1 << (uVar9 & 0xff) & *(uint *)(*(int *)dVar1 + 0x84)) == 0) goto LAB_0802ec6e;
LAB_0802ec70:
        if (bVar7) goto LAB_0802ec74;
      }
      else {
        if ((1 << (uVar9 & 0xff) & *(uint *)(*(int *)dVar1 + 0x88)) == 0) {
LAB_0802ec6e:
          bVar7 = false;
          goto LAB_0802ec70;
        }
LAB_0802ec74:
        uVar10 = uVar10 + 1;
      }
      uVar9 = uVar9 + 1;
    } while (uVar9 < 0xb);
    iVar2 = sub_0800CE30();
    if (iVar2 == 0) {
      pbVar4 = (byte *)(*(int *)DWORD_0802ecc0 + 0x1b4);
    }
    else {
      pbVar4 = (byte *)(*(int *)DWORD_0802ec94 + 0x1c0);
    }
    if (uVar10 != *pbVar4) {
      switch(uVar10) {
      case 2:
        while (iVar2 = sub_0805F184(), iVar2 != 0) {
          sub_080003F0();
        }
        while (iVar2 = sub_0805EF90(), iVar2 != 0) {
          sub_080003F0();
        }
        uVar6 = sub_0805DF38(1,0xf,2,0,0xffffffff,_UNK_0802ed28);
        while (iVar2 = sub_0805EEFC(uVar6), iVar2 == 0) {
          iVar2 = sub_0800CDF8();
          if (iVar2 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
        break;
      case 3:
        while (iVar2 = sub_0805F184(), iVar2 != 0) {
          sub_080003F0();
        }
        while (iVar2 = sub_0805EF90(), iVar2 != 0) {
          sub_080003F0();
        }
        uVar6 = sub_0805DF38(1,0xf,2,0,0xffffffff,_UNK_0802ed84);
        while (iVar2 = sub_0805EEFC(uVar6), iVar2 == 0) {
          iVar2 = sub_0800CDF8();
          if (iVar2 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
        break;
      case 4:
        while (iVar2 = sub_0805F184(), iVar2 != 0) {
          sub_080003F0();
        }
        while (iVar2 = sub_0805EF90(), iVar2 != 0) {
          sub_080003F0();
        }
        uVar6 = sub_0805DF38(1,0xf,2,0,0xffffffff,_UNK_0802ede0);
        while (iVar2 = sub_0805EEFC(uVar6), iVar2 == 0) {
          iVar2 = sub_0800CDF8();
          if (iVar2 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
        break;
      case 5:
        while (iVar2 = sub_0805F184(), iVar2 != 0) {
          sub_080003F0();
        }
        while (iVar2 = sub_0805EF90(), iVar2 != 0) {
          sub_080003F0();
        }
        uVar6 = sub_0805DF38(1,0xf,2,0,0xffffffff,_UNK_0802ee3c);
        while (iVar2 = sub_0805EEFC(uVar6), iVar2 == 0) {
          iVar2 = sub_0800CDF8();
          if (iVar2 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
        break;
      case 6:
        while (iVar2 = sub_0805F184(), iVar2 != 0) {
          sub_080003F0();
        }
        while (iVar2 = sub_0805EF90(), iVar2 != 0) {
          sub_080003F0();
        }
        uVar6 = sub_0805DF38(1,0xf,2,0,0xffffffff,_UNK_0802ee98);
        while (iVar2 = sub_0805EEFC(uVar6), iVar2 == 0) {
          iVar2 = sub_0800CDF8();
          if (iVar2 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
        break;
      case 7:
        while (iVar2 = sub_0805F184(), iVar2 != 0) {
          sub_080003F0();
        }
        while (iVar2 = sub_0805EF90(), iVar2 != 0) {
          sub_080003F0();
        }
        uVar6 = sub_0805DF38(1,0xf,2,0,0xffffffff,_UNK_0802eef4);
        while (iVar2 = sub_0805EEFC(uVar6), iVar2 == 0) {
          iVar2 = sub_0800CDF8();
          if (iVar2 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
        break;
      case 8:
        while (iVar2 = sub_0805F184(), iVar2 != 0) {
          sub_080003F0();
        }
        while (iVar2 = sub_0805EF90(), iVar2 != 0) {
          sub_080003F0();
        }
        uVar6 = sub_0805DF38(1,0xf,2,0,0xffffffff,_UNK_0802ef50);
        while (iVar2 = sub_0805EEFC(uVar6), iVar2 == 0) {
          iVar2 = sub_0800CDF8();
          if (iVar2 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
        break;
      case 9:
        while (iVar2 = sub_0805F184(), iVar2 != 0) {
          sub_080003F0();
        }
        while (iVar2 = sub_0805EF90(), iVar2 != 0) {
          sub_080003F0();
        }
        uVar6 = sub_0805DF38(1,0xf,2,0,0xffffffff,_UNK_0802efac);
        while (iVar2 = sub_0805EEFC(uVar6), iVar2 == 0) {
          iVar2 = sub_0800CDF8();
          if (iVar2 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
        break;
      case 10:
        while (iVar2 = sub_0805F184(), iVar2 != 0) {
          sub_080003F0();
        }
        while (iVar2 = sub_0805EF90(), iVar2 != 0) {
          sub_080003F0();
        }
        uVar6 = sub_0805DF38(1,0xf,2,0,0xffffffff,_UNK_0802f008);
        while (iVar2 = sub_0805EEFC(uVar6), iVar2 == 0) {
          iVar2 = sub_0800CDF8();
          if (iVar2 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
        break;
      case 0xb:
        while (iVar2 = sub_0805F184(), iVar2 != 0) {
          sub_080003F0();
        }
        while (iVar2 = sub_0805EF90(), iVar2 != 0) {
          sub_080003F0();
        }
        uVar6 = sub_0805DF38(1,0xf,2,0,0xffffffff,_UNK_0802f060);
        while (iVar2 = sub_0805EEFC(uVar6), iVar2 == 0) {
          iVar2 = sub_0800CDF8();
          if (iVar2 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
        if ((*_UNK_0802f0ac & 0x20) == 0) {
          sub_08006D08(0x33);
        }
        iVar2 = sub_0800CE30();
        if (iVar2 == 0) {
          *(uint *)(*(int *)DWORD_0802f0d8 + 0x78) =
               *(uint *)(*(int *)DWORD_0802f0d8 + 0x78) | 0x80000;
        }
        else {
          *(uint *)(*_UNK_0802f0b0 + 0x80) = *(uint *)(*_UNK_0802f0b0 + 0x80) | 0x80000;
        }
      }
      iVar2 = sub_0800CE30();
      if (iVar2 == 0) {
        puVar5 = (undefined1 *)(*(int *)DWORD_0802f0ec + 0x1b4);
      }
      else {
        puVar5 = (undefined1 *)(*(int *)DWORD_0802f0d8 + 0x1c0);
      }
      *puVar5 = (char)uVar10;
    }
  }
  else {
    if (param_1 != 2) {
      iVar2 = sub_0800CC98();
      if (iVar2 != 0) {
        return in_lr;
      }
      iVar2 = sub_0801AB24();
      if (iVar2 == 1) {
        sub_0801AB50(6);
      }
      else if (iVar2 < 2) {
        if (iVar2 == 0) {
          sub_080576A8();
        }
      }
      else if (iVar2 == 2) {
        sub_0801AB90(6);
      }
      while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
        sub_080003F0();
      }
      return in_lr;
    }
    iVar2 = sub_080020F4();
    iVar2 = iVar2 * 0x14c + DWORD_0802f128;
    *(uint *)(iVar2 + 0x30) = *(uint *)(iVar2 + 0x30) | 1;
    sub_0800D0F4();
    iVar2 = sub_0800CC98();
    if (iVar2 == 0) {
      iVar2 = sub_0801AB24();
      if (iVar2 == 1) {
        sub_0801AB50(6);
      }
      else if (iVar2 < 2) {
        if (iVar2 == 0) {
          sub_080576A8();
        }
      }
      else if (iVar2 == 2) {
        sub_0801AB90(6);
      }
      while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
        sub_080003F0();
      }
    }
    while (iVar2 = sub_0805F184(), iVar2 != 0) {
      sub_080003F0();
    }
    while (iVar2 = sub_0805EF90(), iVar2 != 0) {
      sub_080003F0();
    }
    uVar6 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0802f18c);
    while (iVar2 = sub_0805EEFC(uVar6), iVar2 == 0) {
      iVar2 = sub_0800CDF8();
      if (iVar2 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
  }
  iVar2 = sub_080020F4();
  iVar2 = iVar2 * 0x14c + DWORD_0802f1cc;
  *(uint *)(iVar2 + 0x30) = *(uint *)(iVar2 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


