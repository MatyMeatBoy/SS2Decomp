
void sub_08097D0C(undefined2 param_1,undefined2 param_2)

{
  dword dVar1;
  
  dVar1 = DWORD_08097d14;
  *(undefined2 *)(DWORD_08097d14 + 4) = param_1;
  *(undefined2 *)(dVar1 + 6) = param_2;
  return;
}


