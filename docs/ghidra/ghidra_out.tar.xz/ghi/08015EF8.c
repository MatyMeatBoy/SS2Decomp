
undefined4 sub_08015EF8(void)

{
  int iVar1;
  uint *puVar2;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  puVar2 = (uint *)(iVar1 * 0x14c + DWORD_08015f18 + 0x30);
  *puVar2 = *puVar2 & DWORD_08015f1c;
  return in_lr;
}


