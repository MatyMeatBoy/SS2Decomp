
undefined4 sub_08054644(void)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  dVar1 = DWORD_08054654;
  iVar3 = *(int *)DWORD_08054658 + DWORD_0805465c;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_08054678;
    iVar3 = iVar3 + 0x28;
  }
LAB_080546a2:
  dVar1 = DWORD_080546b0;
  iVar3 = *(int *)DWORD_080546b4 + DWORD_080546b8;
  for (uVar4 = 0; uVar4 < 0x1e; uVar4 = uVar4 + 1) {
    iVar2 = sub_08000470(iVar3);
    if (iVar2 == 0) goto LAB_080546d4;
    iVar3 = iVar3 + 0x28;
  }
LAB_080546fe:
  iVar3 = sub_0800CC98();
  if (iVar3 == 0) {
    iVar3 = sub_0801AB24();
    if (iVar3 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar3 < 2) {
      if (iVar3 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar3 == 2) {
      sub_0801AB90(6);
    }
    while (iVar3 = sub_0801AAE0(), iVar3 == 0) {
      sub_080003F0();
    }
  }
  return in_lr;
LAB_08054678:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0xe);
  goto LAB_080546a2;
LAB_080546d4:
  while( true ) {
    iVar2 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  *(dword *)(iVar3 + 0xc) = dVar1;
  *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,0xf);
  goto LAB_080546fe;
}


