
undefined8 sub_08067B50(void)

{
  dword dVar1;
  uint uVar2;
  undefined1 *puVar3;
  undefined4 in_lr;
  
  dVar1 = DWORD_08067b88;
  uVar2 = *(uint *)DWORD_08067b88;
  if (uVar2 < 0x32) {
    puVar3 = (undefined1 *)(*(int *)DWORD_08067b8c + uVar2 * 0x88);
    *(undefined4 *)(puVar3 + 4) = 1;
    *puVar3 = 0x82;
    *(undefined4 *)(puVar3 + 8) = *(undefined4 *)(*(int *)DWORD_08067b90 + 10);
    puVar3[1] = 1;
    *(int *)dVar1 = *(int *)dVar1 + 1;
  }
  return CONCAT44(in_lr,(uint)(uVar2 < 0x32));
}


