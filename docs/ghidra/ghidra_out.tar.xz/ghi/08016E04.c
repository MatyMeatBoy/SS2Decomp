
undefined8 sub_08016E04(int param_1,uint param_2)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  undefined4 in_lr;
  
  uVar6 = 0;
  uVar5 = 0x40000;
  iVar3 = 0;
  do {
    if ((((*(uint *)DWORD_08016e50 & 1 << (uVar6 & 0xff)) != 0) &&
        (*(int *)(iVar3 + DWORD_08016e54) == param_1)) &&
       (*(uint *)(iVar3 + DWORD_08016e54 + 4) == (param_2 & 0xffff))) {
      piVar1 = (int *)(iVar3 + DWORD_08016e54 + 8);
      *piVar1 = *piVar1 + 1;
      uVar5 = uVar5 >> 0x10;
      goto LAB_08016ebe;
    }
    uVar5 = uVar5 + 0x10000;
    iVar3 = iVar3 + 0xc;
    uVar6 = uVar6 + 1;
  } while (uVar6 < 3);
  uVar6 = 0;
  uVar5 = 0x40000;
  iVar7 = 0;
  iVar3 = DWORD_08016ea8 + 4;
  piVar1 = (int *)DWORD_08016ea8;
  do {
    uVar2 = 1 << (uVar6 & 0xff);
    uVar4 = *(uint *)DWORD_08016ea4;
    if ((uVar4 & uVar2) == 0) {
      *piVar1 = param_1;
      *(uint *)(iVar7 + iVar3) = param_2 & 0xffff;
      piVar1[2] = 1;
      *(uint *)DWORD_08016ea4 = uVar4 | uVar2;
      uVar5 = uVar5 >> 0x10;
      goto LAB_08016ebe;
    }
    uVar5 = uVar5 + 0x10000;
    piVar1 = piVar1 + 3;
    iVar7 = iVar7 + 0xc;
    uVar6 = uVar6 + 1;
  } while (uVar6 < 3);
  uVar5 = 0xffff;
LAB_08016ebe:
  return CONCAT44(in_lr,uVar5);
}


