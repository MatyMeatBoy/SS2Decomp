
undefined4 sub_0804EEA8(void)

{
  short sVar1;
  short sVar2;
  int iVar3;
  dword dVar4;
  undefined4 uVar5;
  undefined4 in_lr;
  undefined1 auStack_38 [4];
  undefined1 auStack_34 [4];
  undefined1 auStack_30 [4];
  undefined1 auStack_2c [4];
  undefined1 *puStack_28;
  undefined1 *puStack_24;
  
  iVar3 = sub_080020F4();
  iVar3 = iVar3 * 0x14c + DWORD_0804eefc;
  *(uint *)(iVar3 + 0x30) = *(uint *)(iVar3 + 0x30) | 1;
  sub_0800D0F4();
  *(undefined4 *)DWORD_0804ef00 = 0xc4;
  if ((*(uint *)DWORD_0804ef04 & 0x20) == 0) {
    sub_08006CB4(0xc4);
  }
  sVar2 = 1;
  puStack_28 = auStack_30;
  puStack_24 = auStack_2c;
  do {
    sub_080003F0();
    iVar3 = sub_080021A8();
    if (iVar3 != 0) break;
    sVar2 = sVar2 + -1;
  } while (sVar2 != 0);
  iVar3 = sub_0800CC98();
  if (iVar3 == 0) {
    iVar3 = sub_0801AB24();
    if (iVar3 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar3 < 2) {
      if (iVar3 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar3 == 2) {
      sub_0801AB90(6);
    }
    while (iVar3 = sub_0801AAE0(), iVar3 == 0) {
      sub_080003F0();
    }
  }
  sVar2 = 0x14;
  do {
    sub_080003F0();
    iVar3 = sub_080021A8();
    dVar4 = DWORD_0804efe8;
    if (iVar3 != 0) break;
    sVar2 = sVar2 + -1;
  } while (sVar2 != 0);
  sVar2 = *(short *)(DWORD_0804efe4 + 0x80);
  sVar1 = *(short *)(DWORD_0804efe4 + 0x82);
  iVar3 = 0;
  do {
    sub_080659F4(auStack_38,(int)sVar2,0x68,iVar3);
    sub_080659F4(auStack_34,(int)sVar1,(int)dVar4 >> 0x10,iVar3);
    sub_0800BB80((int)auStack_38._0_2_,(int)auStack_34._0_2_);
    sub_080003F0();
    iVar3 = iVar3 + 0x11;
  } while (iVar3 < 0x401);
  if ((*(uint *)(*(int *)DWORD_0804efec + 0x38) & 0x10) == 0) {
    while (iVar3 = sub_0805F184(), iVar3 != 0) {
      sub_080003F0();
    }
    while (iVar3 = sub_0805EF90(), dVar4 = DWORD_0804f014, iVar3 != 0) {
      sub_080003F0();
    }
  }
  else {
    while (iVar3 = sub_0805F184(), iVar3 != 0) {
      sub_080003F0();
    }
    while (iVar3 = sub_0805EF90(), dVar4 = DWORD_0804f058, iVar3 != 0) {
      sub_080003F0();
    }
  }
  uVar5 = sub_0805DF38(1,0xf,2,0,0x2d,dVar4);
  *(uint *)(*(int *)DWORD_0804f05c + 0x38) = *(uint *)(*(int *)DWORD_0804f05c + 0x38) | 0x10;
  while (iVar3 = sub_0805EEFC(uVar5), iVar3 == 0) {
    sub_080003F0();
  }
  sVar2 = *(short *)(DWORD_0804f114 + 0x80);
  sVar1 = *(short *)(DWORD_0804f114 + 0x82);
  iVar3 = 0;
  do {
    sub_080659F4(puStack_28,(int)sVar2,0,iVar3);
    sub_080659F4(puStack_24,(int)sVar1,0,iVar3);
    sub_0800BB80((int)auStack_30._0_2_,(int)auStack_2c._0_2_);
    sub_080003F0();
    iVar3 = iVar3 + 0x22;
  } while (iVar3 < 0x401);
  *(undefined4 *)DWORD_0804f118 = 0xa5;
  if ((*(uint *)DWORD_0804f11c & 0x20) == 0) {
    sub_08006CB4(0xa5);
  }
  *(ushort *)(*(int *)DWORD_0804f120 + 4) = *(ushort *)(*(int *)DWORD_0804f120 + 4) | 0x20;
  iVar3 = sub_080020F4();
  iVar3 = iVar3 * 0x14c + DWORD_0804f124;
  *(uint *)(iVar3 + 0x30) = *(uint *)(iVar3 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


