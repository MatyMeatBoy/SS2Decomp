
undefined4 sub_0807A064(int param_1)

{
  dword dVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 in_lr;
  
  *(undefined1 *)(param_1 + DWORD_0807a0c0) = 0;
  *(undefined1 *)(param_1 + DWORD_0807a0c4) = 0;
  iVar3 = param_1 * 4;
  *(undefined4 *)(iVar3 + DWORD_0807a0c8) = 0;
  *(undefined4 *)DWORD_0807a0cc = 0;
  uVar2 = sub_08001494(0x280);
  *(undefined4 *)(iVar3 + DWORD_0807a0d0) = uVar2;
  uVar2 = sub_08001494(0x180);
  *(undefined4 *)(iVar3 + DWORD_0807a0d4) = uVar2;
  dVar1 = DWORD_0807a0d8;
  if (param_1 == 0) {
    uVar2 = sub_08001494(0x500);
    *(undefined4 *)dVar1 = uVar2;
    dVar1 = DWORD_0807a0dc;
    uVar2 = sub_08001494(0x180);
    *(undefined4 *)dVar1 = uVar2;
  }
  return in_lr;
}


