
undefined8 sub_0808D390(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 in_lr;
  
  if (*(short *)(*(int *)DWORD_0808d3a8 + 0x10) == 0) {
    sub_0802704C(param_1);
  }
  else {
    iVar1 = sub_08056E90();
    if (iVar1 != 0) {
      sub_0801ABE8(3);
      sub_0800BB40();
      while (iVar1 = sub_0801AAE0(), iVar1 == 0) {
        sub_080003F0();
      }
      sub_0800BB40();
      iVar1 = *(int *)DWORD_0808d3f0;
      *(undefined4 *)(iVar1 + DWORD_0808d3f4) =
           *(undefined4 *)(*(int *)(iVar1 + 0x40) * 4 + DWORD_0808d3f8);
      *(undefined2 *)(iVar1 + 0x10) = 0;
      uVar2 = 1;
      *(undefined2 *)(iVar1 + 0x30) = 1;
      *(undefined2 *)(iVar1 + 0x24) = 1;
      goto LAB_0808d3fe;
    }
  }
  uVar2 = 0;
LAB_0808d3fe:
  return CONCAT44(in_lr,uVar2);
}


