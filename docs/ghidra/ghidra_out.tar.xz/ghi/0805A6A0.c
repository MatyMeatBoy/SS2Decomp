
void sub_0805A6A0(void)

{
  *(ushort *)(*(int *)DWORD_0805a6b0 + 4) =
       (ushort)DWORD_0805a6b4 & *(ushort *)(*(int *)DWORD_0805a6b0 + 4);
  return;
}


