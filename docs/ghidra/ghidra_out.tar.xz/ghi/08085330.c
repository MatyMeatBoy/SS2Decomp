
undefined8 sub_08085330(void)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  undefined4 in_lr;
  
  iVar3 = 0;
  if (**(int **)DWORD_0808535c == 4) {
    uVar2 = 0;
    piVar1 = *(int **)DWORD_0808535c + 0x41;
    do {
      if ((short)*piVar1 == 10) {
        iVar3 = iVar3 + piVar1[1];
      }
      piVar1 = piVar1 + 4;
      uVar2 = uVar2 + 1;
    } while (uVar2 < 0x4b);
  }
  else {
    iVar3 = sub_0805D404();
  }
  return CONCAT44(in_lr,iVar3);
}


