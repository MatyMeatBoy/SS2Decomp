
undefined4 sub_080AF3C4(void)

{
  int iVar1;
  int iVar2;
  undefined4 in_lr;
  
  iVar1 = sub_0800048C();
  iVar2 = *(int *)(iVar1 + 8) + -0x44;
  *(int *)(iVar1 + 8) = iVar2;
  *(uint *)DWORD_080af3ec =
       *(uint *)DWORD_080af3ec & ~(1 << (**(ushort **)(iVar2 * 0xac + DWORD_080af3f0) & 0xff));
  return in_lr;
}


