
undefined8 sub_08089204(int param_1)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  uint *puVar5;
  ushort *puVar6;
  undefined4 in_lr;
  
  if (*(short *)(*(int *)DWORD_08089218 + 0x10) == 0) {
    while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
      sub_080003F0();
    }
    iVar2 = sub_080020F4();
    puVar6 = (ushort *)(param_1 + (uint)*(ushort *)(*(int *)DWORD_080892a8 + 0x36) * 0x24 + 4);
    sub_0800CCDC();
    dVar1 = DWORD_080892ac;
    puVar5 = (uint *)(iVar2 * 0x14c + DWORD_080892ac + 0x30);
    if ((*puVar5 & 0x2000) != 0) {
      sub_0802996C();
    }
    *puVar5 = *puVar5 & DWORD_080892b0;
    sub_08067D74();
    iVar3 = sub_080020F4();
    iVar3 = iVar3 * 0x14c;
    *(uint *)(iVar3 + dVar1 + 0x8c) = (uint)*puVar6 << 8;
    *(uint *)(iVar3 + dVar1 + 0x90) = (uint)puVar6[1] << 8;
    iVar3 = iVar3 + dVar1;
    *(undefined4 *)(iVar3 + 0x94) = *(undefined4 *)(iVar3 + 0x8c);
    *(undefined4 *)(iVar3 + 0x98) = *(undefined4 *)(iVar3 + 0x90);
    sub_08009930(0,2);
    while (iVar3 = sub_0800BA6C(), iVar3 == 0) {
      sub_080003F0();
    }
    *(undefined2 *)(DWORD_08089328 + 0x76) = 0x20;
    iVar2 = iVar2 * 0x14c + DWORD_0808932c;
    uVar4 = sub_0800CCCC();
    sub_0800AD04(iVar2,iVar2 + 4,uVar4);
    iVar2 = *(int *)DWORD_08089330;
    *(undefined2 *)(iVar2 + 0x10) = 1;
    *(undefined2 *)(iVar2 + 0x1c) = 1;
    sub_08015C38();
    sub_08015EF8();
    sub_08057328(0,DWORD_08089334);
  }
  iVar2 = sub_080020F4();
  if (*(int *)(iVar2 * 0x14c + DWORD_08089338 + 0x90) >> 0xb == 0x1f) {
    sub_08015ED4();
    sub_0801ABE8(3);
    sub_0800BB40();
    while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
      sub_080003F0();
    }
    sub_0800BB40();
    iVar2 = *(int *)DWORD_0808936c;
    *(undefined2 *)(iVar2 + 0x36) = 2;
    *(undefined2 *)(iVar2 + 2) = 8;
    *(undefined4 *)(iVar2 + DWORD_08089370) = *(undefined4 *)(DWORD_08089374 + 0x20);
    *(undefined2 *)(iVar2 + 0x10) = 0;
    *(undefined2 *)(iVar2 + 0x1c) = 0;
    uVar4 = 1;
  }
  else {
    uVar4 = 0;
  }
  return CONCAT44(in_lr,uVar4);
}


