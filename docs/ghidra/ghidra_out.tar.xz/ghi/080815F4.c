
void sub_080815F4(undefined4 param_1)

{
  dword dVar1;
  uint uVar2;
  
  dVar1 = DWORD_08081638;
  *(undefined4 *)(&stack0x0000021c + DWORD_08081638) = param_1;
  sub_0805FFBC(0xf,0x12,*(undefined4 *)(&stack0x0000021c + DWORD_08081638),0x80000000);
  sub_0805FC80(0x78,0x20,*(undefined4 *)(&stack0x0000021c + dVar1),8);
  uVar2 = **(ushort **)(&stack0x0000021c + dVar1) - 1;
  if (9 < uVar2) {
    uVar2 = func_0x08082948();
  }
                    /* WARNING: Could not recover jumptable at 0x08081634. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(uVar2 * 4 + DWORD_0808163c))();
  return;
}


