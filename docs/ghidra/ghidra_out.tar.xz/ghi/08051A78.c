
undefined4 sub_08051A78(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 in_lr;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  dword dStack_14;
  
  uStack_18 = 0;
  uStack_20 = 0x7800;
  uStack_1c = 0x5800;
  dStack_14 = DWORD_08051aa4;
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_08051aa8;
  while (iVar2 = sub_08021FE0(iVar1 + 0x8c,&uStack_20,&uStack_18,&dStack_14), iVar2 == 0) {
    sub_080003F0();
  }
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_08051af0;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) | 1;
  sub_0800D0F4();
  iVar1 = sub_0800CE30();
  if (iVar1 == 0) {
    iVar1 = *(int *)DWORD_08051b10;
    iVar2 = 0x1b8;
  }
  else {
    iVar1 = *(int *)DWORD_08051af4;
    iVar2 = 0x1c4;
  }
  if ((int)(uint)*(byte *)(iVar1 + iVar2) >> 7 == 0) {
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar3 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08051bb4);
    while (iVar1 = sub_0805EEFC(uVar3), iVar1 == 0) {
      iVar1 = sub_0800CDF8();
      if (iVar1 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
  }
  else {
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar3 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08051b48);
    while (iVar1 = sub_0805EEFC(uVar3), iVar1 == 0) {
      iVar1 = sub_0800CDF8();
      if (iVar1 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
    sub_08068070(DWORD_08051b78,6);
    sub_08068070(DWORD_08051b7c,0x11);
  }
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_08051bf8;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


