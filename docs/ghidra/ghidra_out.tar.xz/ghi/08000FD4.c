
undefined4 sub_08000FD4(ushort param_1)

{
  dword dVar1;
  dword dVar2;
  dword dVar3;
  ushort uVar4;
  undefined4 in_lr;
  
  dVar3 = DWORD_0800103c;
  dVar2 = DWORD_08001038;
  dVar1 = DWORD_08001034;
  uVar4 = *(ushort *)DWORD_08001030;
  while ((uVar4 & 3) != 0) {
    uVar4 = *(ushort *)DWORD_08001030;
  }
  *(undefined2 *)DWORD_08001034 = 0;
  *(undefined2 *)dVar3 = 0;
  uVar4 = *(ushort *)dVar2 & ~param_1;
  *(ushort *)dVar2 = uVar4;
  *(ushort *)(dVar3 - 8) = uVar4;
  dVar2 = DWORD_0800103c;
  uVar4 = *(ushort *)DWORD_08001030;
  while ((uVar4 & 3) != 0) {
    uVar4 = *(ushort *)DWORD_08001030;
  }
  *(undefined2 *)dVar1 = 1;
  *(undefined2 *)dVar2 = 1;
  return in_lr;
}


