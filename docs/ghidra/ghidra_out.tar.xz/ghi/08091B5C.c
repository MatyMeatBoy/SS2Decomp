
undefined4 sub_08091B5C(void)

{
  dword dVar1;
  short sVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int unaff_r9;
  undefined4 in_lr;
  undefined4 uStack_28;
  
  dVar1 = DWORD_08091bcc;
  puVar3 = (undefined4 *)sub_08001494(0x44);
  *(undefined4 **)dVar1 = puVar3;
  sub_0800086C();
  sub_08065158(puVar3,DWORD_08091bd0,0,0xffffffff,0);
  *(undefined1 *)(puVar3 + 7) = 0;
  *(undefined2 *)(puVar3 + 0xf) = 10;
  puVar4 = puVar3 + 0x10;
  *(undefined2 *)puVar4 = 0;
  *(undefined2 *)((int)puVar3 + 0x3e) = 0;
  puVar3[0xd] = 0x10000;
  puVar3[0xe] = 0x5800;
  uStack_28 = 1;
  sVar2 = 0;
  uVar6 = 0;
  if (*(int *)dVar1 != 0) {
    do {
      if (uVar6 == 1) {
        if (unaff_r9 != 0) {
          sub_08065158(puVar3,DWORD_08091c50,0,0xffffffff,0);
          uStack_28 = 1;
          *(undefined2 *)(puVar3 + 0xf) = 10;
          *(undefined2 *)puVar4 = 0;
          *(undefined2 *)((int)puVar3 + 0x3e) = 0;
          uVar6 = 2;
        }
      }
      else if (uVar6 < 2) {
        if ((uVar6 == 0) &&
           (iVar5 = puVar3[0xd] + DWORD_08091c18, puVar3[0xd] = iVar5, iVar5 < 0x8001)) {
          sub_08065158(puVar3,DWORD_08091c1c,0,0xffffffff,0);
          uStack_28 = 0;
          *(undefined1 *)(puVar3 + 7) = 0;
          *(undefined2 *)(puVar3 + 0xf) = 10;
          *(undefined2 *)puVar4 = 0;
          *(undefined2 *)((int)puVar3 + 0x3e) = 0;
          uVar6 = 1;
        }
      }
      else if (uVar6 == 2) {
        iVar5 = puVar3[0xd] + DWORD_08091c6c;
        puVar3[0xd] = iVar5;
        if (iVar5 <= (int)DWORD_08091c70) {
          sVar2 = 0;
          uVar6 = 6;
        }
      }
      else if ((uVar6 == 6) && (sVar2 = sVar2 + 1, sVar2 == 0x3d)) {
        uVar6 = 0xff;
      }
      sub_08000AF0(0x10,puVar3[3],1);
      unaff_r9 = sub_08065370(puVar3,*(undefined2 *)(puVar3 + 0xf),(int)puVar3 + 0x3e,puVar4,
                              uStack_28);
      sub_08007870((int)puVar3[0xd] >> 8,(int)puVar3[0xe] >> 8,*(undefined2 *)(puVar3 + 0xf),
                   *(undefined2 *)((int)puVar3 + 0x3e),0,puVar3 + 7,puVar3[2],*puVar3);
      sub_080003F0();
      dVar1 = DWORD_08091cf4;
    } while ((uVar6 != 0xff) && (*(int *)DWORD_08091cf4 != 0));
    if (*(int *)DWORD_08091cf4 != 0) {
      sub_08001538();
      *(undefined4 *)dVar1 = 0;
    }
  }
  return in_lr;
}


