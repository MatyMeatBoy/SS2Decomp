
undefined4 sub_08085484(void)

{
  dword dVar1;
  undefined4 in_lr;
  
  dVar1 = DWORD_0808549c;
  **(undefined4 **)DWORD_0808549c = 0;
  sub_08001538();
  *(undefined4 *)dVar1 = 0;
  return in_lr;
}


