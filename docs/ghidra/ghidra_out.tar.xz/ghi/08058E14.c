
void sub_08058E14(uint param_1)

{
  *(uint *)(*(int *)DWORD_08058e24 + 0x6c) =
       *(uint *)(*(int *)DWORD_08058e24 + 0x6c) | 1 << (param_1 & 0xff);
  return;
}


