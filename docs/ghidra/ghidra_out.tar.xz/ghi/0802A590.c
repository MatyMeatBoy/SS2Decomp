
undefined4 sub_0802A590(uint param_1,uint param_2)

{
  uint *puVar1;
  uint uVar2;
  ushort *puVar3;
  uint *puVar4;
  uint uVar5;
  undefined4 in_lr;
  
  param_2 = param_2 & 0xffff;
  puVar1 = (uint *)sub_08001494(param_2 << 5);
  puVar3 = (ushort *)((param_1 & 0xffff) * 0x20 + DWORD_0802a63c);
  CpuSet(puVar3,puVar1,param_2 << 3 | 0x4000000);
  uVar5 = 0;
  puVar4 = puVar1;
  if (param_2 != 0) {
    do {
      uVar2 = *puVar4;
      uVar2 = __udivsi3((uVar2 & 0x1f) + ((uVar2 << 0x16) >> 0x1b) + ((uVar2 << 0x11) >> 0x1b),3);
      uVar2 = uVar2 & 0x1f;
      *(byte *)puVar3 = (byte)*puVar3 & 0xe0 | (byte)uVar2;
      *puVar3 = *puVar3 & (ushort)DWORD_0802a640 | (ushort)(uVar2 << 5);
      *(byte *)((int)puVar3 + 1) = *(byte *)((int)puVar3 + 1) & 0x83 | (byte)(uVar2 << 2);
      uVar5 = uVar5 + 1;
      puVar3 = puVar3 + 1;
      puVar4 = (uint *)((int)puVar4 + 2);
    } while (uVar5 < param_2 << 4);
  }
  sub_08000B38();
  sub_08001538(puVar1);
  return in_lr;
}


