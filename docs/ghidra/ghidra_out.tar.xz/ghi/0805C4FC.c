
undefined8 sub_0805C4FC(ushort *param_1,int param_2,int param_3)

{
  ushort uVar1;
  ushort uVar2;
  undefined2 uVar3;
  short sVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 uVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  ushort *puVar12;
  undefined4 in_lr;
  undefined4 uStack_1c;
  
  uStack_1c = 0;
  CpuSet(&uStack_1c,param_1,DWORD_0805c524);
  if (param_2 == 0) {
    *param_1 = 0;
    param_1[1] = 0;
    uVar5 = 0;
  }
  else {
    uVar3 = sub_080008C8();
    uVar6 = __umodsi3(uVar3,100);
    iVar9 = (param_2 + -1) * 0x24;
    uVar1 = *(ushort *)(iVar9 + DWORD_0805c5c4);
    if (param_3 == 8) {
      param_3 = 6;
    }
    puVar12 = *(ushort **)(param_3 * 4 + iVar9 + DWORD_0805c5c4 + 4);
    uVar2 = *puVar12;
    uVar5 = sub_080008C8();
    uVar7 = __umodsi3(uVar5,puVar12[1] + 1);
    uVar11 = 0;
    uVar10 = 0;
    if (uVar2 != 0) {
      do {
        if ((uVar11 <= uVar7) && (uVar7 <= puVar12[6])) {
          uVar2 = puVar12[4];
          *param_1 = uVar2;
          param_1[1] = puVar12[5];
          if (uVar2 == 10) {
            *(uint *)(param_1 + 2) = uVar7;
            uVar5 = sub_080008C8();
            uVar2 = puVar12[5];
            uVar8 = __udivsi3((uint)uVar2 * 0xf,10);
            uVar7 = __umodsi3(uVar5,uVar8);
            uVar10 = (uint)(uVar2 >> 1);
            if (uVar7 < uVar10) {
              uVar7 = uVar10;
            }
            *(uint *)(param_1 + 2) = uVar7;
          }
          break;
        }
        uVar10 = uVar10 + 1;
        uVar11 = puVar12[6] + 1;
        puVar12 = puVar12 + 4;
      } while (uVar10 < uVar2);
    }
    if (uVar6 <= uVar1) {
      sub_0805C208(param_1,0);
    }
    if (*param_1 == 9) {
      uVar5 = sub_080008C8();
      sVar4 = __umodsi3(uVar5,10);
      param_1[2] = sVar4 + *(short *)(DWORD_0805c61c + 0x8c) * 10;
      iVar9 = sub_0800CE30();
      if (iVar9 != 0) {
        param_1[2] = param_1[2] + 100;
      }
    }
    uVar5 = 1;
  }
  return CONCAT44(in_lr,uVar5);
}


