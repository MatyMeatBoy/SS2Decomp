
void sub_0801A0B0(int param_1)

{
  *(undefined1 *)(param_1 + 0x1dc) = 0;
  return;
}


