
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 sub_0805AE94(undefined2 *param_1)

{
  ushort uVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  char cVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined4 in_lr;
  
  cVar5 = '\0';
  uVar4 = 0;
  uVar6 = 0;
  uVar7 = 0;
  uVar8 = 10;
  switch(*param_1) {
  case 1:
    iVar2 = sub_08007290((ushort)param_1[1] | 0x100000);
    uVar4 = *(uint *)(iVar2 + 0x9c);
    break;
  case 2:
    iVar2 = sub_08007290((ushort)param_1[1] | 0xb0000);
    uVar4 = *(uint *)(iVar2 + 0xa0);
    cVar5 = *(char *)(param_1 + 4);
    uVar6 = (uint)*(byte *)(param_1 + 3);
    uVar7 = (uint)*(byte *)((int)param_1 + 7);
    goto code_r0x0805af68;
  case 3:
    uVar1 = param_1[1];
    uVar7 = 0xc0000;
    goto code_r0x0805af56;
  case 4:
    iVar2 = sub_08007290((ushort)param_1[1] | 0xd0000);
    uVar4 = *(uint *)(iVar2 + 0x9c);
    cVar5 = *(char *)(param_1 + 4);
    uVar6 = (uint)*(byte *)(param_1 + 3);
    uVar7 = (uint)*(byte *)((int)param_1 + 7);
    goto code_r0x0805af68;
  case 5:
    uVar1 = param_1[1];
    uVar7 = 0xe0000;
code_r0x0805af56:
    iVar2 = sub_08007290(uVar1 | uVar7);
    uVar4 = *(uint *)(iVar2 + 0x9c);
    cVar5 = *(char *)(param_1 + 4);
    uVar6 = (uint)*(byte *)(param_1 + 3);
    uVar7 = (uint)*(byte *)((int)param_1 + 7);
code_r0x0805af68:
    if ((ushort)param_1[2] != 0) {
      iVar2 = sub_08007290((ushort)param_1[2] - 1 | 0x130000);
      uVar8 = (uint)*(ushort *)(iVar2 + 0x9c);
    }
    break;
  case 6:
    iVar2 = sub_08007290((ushort)param_1[1] | 0xf0000);
    uVar4 = *(uint *)(iVar2 + 0x9c);
    cVar5 = '\0';
    uVar6 = 0;
    uVar7 = 0;
    break;
  case 7:
    iVar2 = sub_08007290((ushort)param_1[1] | 0x110000);
    uVar4 = *(uint *)(iVar2 + 0x9c);
    cVar5 = '\0';
    uVar6 = 0;
    break;
  case 8:
    iVar2 = sub_08007290((ushort)param_1[1] | 0x120000);
    uVar4 = (uint)*(ushort *)(iVar2 + 0x9c);
    break;
  case 9:
    sub_08007290((ushort)param_1[1] | 0x150000);
    switch(param_1[1]) {
    case 0:
      uVar4 = (uint)(ushort)param_1[2] * 100;
      break;
    case 1:
      uVar4 = (uint)(ushort)param_1[2] * 0xfa;
      break;
    case 2:
      uVar4 = (uint)(ushort)param_1[2] * 200;
      break;
    case 3:
      uVar4 = (uint)(ushort)param_1[2] * 10;
      break;
    case 4:
      uVar4 = (uint)(ushort)param_1[2] * 0x14;
    }
    break;
  case 10:
    uVar4 = *(uint *)(param_1 + 2);
  }
  if (cVar5 == '\0') {
    iVar2 = __udivsi3(uVar4 * uVar8,10);
    iVar2 = __udivsi3(iVar2 * *(int *)(uVar6 * 4 + DWORD_0805b050),10);
    uVar3 = __udivsi3(iVar2 * *(int *)(uVar7 * 4 + DWORD_0805b054),10);
  }
  else {
    uVar3 = 1;
  }
  return CONCAT44(in_lr,uVar3);
}


