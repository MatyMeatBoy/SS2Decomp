
/* WARNING: Possible PIC construction at 0x080998b2: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x080998b6) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_08099838(ushort *param_1)

{
  undefined2 *puVar1;
  ushort *puVar2;
  dword dVar3;
  char cVar4;
  undefined1 uVar5;
  ushort uVar6;
  short sVar7;
  undefined2 uVar8;
  int iVar9;
  uint uVar10;
  undefined4 uVar11;
  uint uVar12;
  uint uVar13;
  uint *puVar14;
  int iVar15;
  undefined4 *puVar16;
  undefined4 *puVar17;
  undefined4 in_lr;
  bool bVar18;
  undefined4 auStack_e8 [7];
  undefined1 uStack_cc;
  undefined4 auStack_b4 [13];
  short sStack_80;
  short sStack_7e;
  undefined4 *puStack_7c;
  ushort *puStack_78;
  undefined4 uStack_74;
  int iStack_70;
  dword dStack_6c;
  dword dStack_68;
  dword dStack_64;
  undefined4 uStack_60;
  uint uStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  undefined4 uStack_48;
  uint uStack_44;
  uint uStack_40;
  int iStack_3c;
  short *psStack_38;
  ushort *puStack_34;
  ushort *puStack_30;
  ushort *puStack_2c;
  ushort *puStack_28;
  undefined4 *puStack_24;
  
  *puRam080998b8 = param_1;
  puStack_78 = param_1 + 0x102;
  sub_0801623C(param_1,uRam080998bc,0);
  sub_08019F60(puStack_78);
  sub_0801A0A4(param_1);
  puVar2 = puRam080998c0;
  uVar6 = sub_08016E04(param_1[0x16c],*(undefined2 *)(iRam080998c4 + (int)param_1));
  *puVar2 = uVar6;
  puVar14 = puRam080998cc;
  puVar1 = (undefined2 *)DWORD_080999dc;
  uVar10 = uRam080998c8;
  while (DWORD_080999dc = (dword)puVar1, uVar6 == uVar10) {
    param_1[6] = 0xb;
    iVar9 = sub_0800CB78();
    if ((iVar9 != 0) || (iVar9 = sub_08056E90(), iVar9 != 0)) {
      *puVar14 = *puVar14 & ~(1 << (*param_1 & 0xff));
      return in_lr;
    }
    sub_080003F0();
    puVar1 = (undefined2 *)DWORD_080999dc;
    uVar10 = (uint)*(ushort *)DWORD_080999dc;
  }
  sub_08065158(auStack_e8,DWORD_080999e0,*puVar1,0xffffffff,1);
  sub_08065158(auStack_b4,DWORD_080999e4,*puVar1,0xffffffff,1);
  param_1[0x36] = 0;
  param_1[0x35] = 0;
  param_1[0x34] = 0;
  uVar6 = puStack_78[3];
  param_1[0xeb] = uVar6 * 3;
  param_1[0x2e] = uVar6 * 3;
  uVar6 = puStack_78[2];
  param_1[0xea] = uVar6 * 0x14;
  param_1[0x2f] = uVar6 * 0x14;
  param_1[6] = 0;
  dStack_6c = 0;
  dStack_68 = DWORD_080999e8;
  dStack_64 = DWORD_080999e8;
  uStack_5c = 0;
  uStack_58 = 0;
  uStack_40 = 0;
  *(byte *)(DWORD_080999ec + (int)param_1) = 2;
  *(byte *)(param_1 + 0xff) = 2;
  sub_0809AE24();
  sub_08097C4C();
  param_1[0x28] = 1;
  dVar3 = DWORD_080999f0;
  param_1[0x29] = 0;
  uVar10 = 0;
  puStack_28 = puStack_78 + 0x6b;
  do {
    uVar13 = 0;
    do {
      *(undefined4 *)((short)uVar13 * 4 + ((int)(uVar10 * 0x10000) >> 0x10) * 0x14c + dVar3) = 0;
      uVar12 = (int)(short)uVar13 + 1;
      uVar13 = uVar12 & 0xffff;
    } while ((int)(uVar12 * 0x10000) >> 0x10 < 5);
    uVar13 = uVar10 * 0x10000 + 0x10000;
    uVar10 = uVar13 >> 0x10;
  } while ((int)uVar13 >> 0x10 < 4);
  puStack_34 = param_1 + 0x34;
  puStack_30 = param_1 + 0x35;
  puStack_2c = param_1 + 0x36;
  iVar9 = sub_0800CE30();
  if (iVar9 == 1) {
    uStack_54 = 0xb4;
    uStack_74 = 0x80;
  }
  else {
    uStack_54 = 0x168;
    uStack_74 = 0x40;
  }
  *(byte *)(param_1 + 0xfe) = (byte)param_1[0xfe] & 0xf0 | (byte)*param_1 & 0xf;
  *(ushort *)(DWORD_08099a44 + (int)param_1) = param_1[1];
  *(byte *)(param_1 + 0x100) = 0xff;
  sub_08097FE4();
  sub_08097A4C();
  iStack_3c = 0;
  uStack_4c = 0;
  sub_08067C18();
  while (iVar9 = sub_08067C08(), iVar9 == 0) {
    sub_080003F0();
  }
  sub_08067BF8();
  do {
    iVar9 = sub_0800CB78();
    if ((iVar9 != 0) || (iVar9 = sub_08056E90(), iVar9 != 0)) break;
    if ((param_1[6] == 10) && (uStack_5c == 0)) {
      uStack_5c = 8;
    }
    iVar9 = sub_08058DB0();
    if (iVar9 == 0) {
      sub_0801C8F0(param_1);
      switch(*(byte *)(DWORD_08099a9c + (int)param_1)) {
      case 1:
        param_1[6] = 0;
        iVar9 = sub_08067C08();
        if (iVar9 != 0) {
          *(byte *)(_UNK_08099ae4 + (int)param_1) = (byte)param_1[0xff];
          sub_08067BF8();
        }
        break;
      case 2:
        dStack_6c = 0;
        iVar9 = sub_08056F78();
        if (iVar9 != 0) {
          *(byte *)(param_1 + 0xff) = 3;
          *(byte *)(_UNK_08099b18 + (int)param_1) = 1;
          sub_08067C18();
          uStack_50 = 0;
        }
        break;
      case 3:
        dStack_6c = 1;
        param_1[6] = 1;
        iVar9 = sub_08096594(0);
        uVar10 = (byte)param_1[0xfe] & 0xf | iVar9 << 4;
        *(byte *)(param_1 + 0xfe) = (byte)uVar10;
        cVar4 = sub_08097A74(param_1,((uVar10 << 0x18) >> 0x1c) * 0x14c + _UNK_08099ba0,uStack_74,
                             0x30);
        if (cVar4 == '\0') {
          *(byte *)(param_1 + 0xff) = 4;
          *(byte *)(_UNK_08099bd8 + (int)param_1) = 1;
          uStack_40 = 0;
          uStack_50 = 0;
          uStack_4c = 0;
          sub_08067C18();
          sub_08097A38(0);
        }
        else {
          bVar18 = uStack_54 < uStack_50;
          uStack_50 = uStack_50 + 1 & 0xffff;
          if (bVar18) {
            *(byte *)(param_1 + 0xff) = 4;
            *(byte *)(_UNK_08099ba4 + (int)param_1) = 1;
            uStack_40 = 0;
            uStack_50 = 0;
            uStack_4c = 0;
            sub_08067C18();
            sub_08097A38(0);
          }
        }
        break;
      case 4:
        dStack_6c = 2;
        param_1[6] = 2;
        if ((*puStack_30 == 2) && (*puStack_2c == 0)) {
          sub_0805865C(0xac);
          if (uStack_40 == 0) {
            uStack_40 = sub_0809A5E0();
            uStack_40 = uStack_40 & 0xff;
          }
          sub_08097CA8(0x3c);
        }
        if ((param_1[0x37] != 0) ||
           (bVar18 = 0x3b < uStack_4c, uStack_4c = uStack_4c + 1 & 0xffff, bVar18)) {
          uStack_4c = 0;
          uVar10 = sub_08002164();
          if (uVar10 == 1) {
            sub_0809AE88(0);
            sub_0809AE88(1);
            sub_0809AE88(2);
            sub_0809AE88(3);
            sub_0809AE88(4);
          }
          else {
            uVar13 = 0;
            for (uVar12 = uStack_4c; uVar12 < uVar10; uVar12 = (int)uVar12 >> 0x10) {
              sub_0809AE88(uVar13);
              uVar12 = uVar13 * 0x10000 + 0x10000;
              uVar13 = uVar12 >> 0x10;
            }
          }
          *(byte *)(_UNK_08099ca0 + (int)param_1) = 1;
          *(byte *)(param_1 + 0xff) = 5;
          sub_08067C18();
        }
        break;
      case 5:
        dStack_6c = 0;
        param_1[6] = 0;
        uVar10 = uStack_4c + 1 & 0xffff;
        bVar18 = 0xb4 < uStack_4c;
        uStack_4c = uVar10;
        if (bVar18) {
          uStack_50 = 0;
          *(byte *)(_UNK_08099cec + (int)param_1) = 1;
          *(byte *)(param_1 + 0xff) = 3;
          sub_08067C18();
        }
      }
    }
    if (dStack_6c == 1) {
      uVar6 = param_1[4] + 8;
LAB_08099d10:
      puStack_7c = auStack_e8;
      *puStack_34 = uVar6;
      uStack_60 = 1;
      uStack_48 = 0x18;
    }
    else if ((int)dStack_6c < 2) {
      if (dStack_6c == 0) {
        uVar6 = param_1[4];
        goto LAB_08099d10;
      }
    }
    else if (dStack_6c == 2) {
      puStack_7c = auStack_b4;
      *puStack_34 = param_1[4];
      uStack_48 = 8;
      uStack_60 = 0;
    }
    iVar9 = *(int *)DWORD_08099d90;
    if ((dStack_68 != *(ushort *)(iVar9 + 0x68)) || (dStack_64 != dStack_6c)) {
      dStack_64 = dStack_6c;
      dStack_68 = (dword)*(ushort *)(iVar9 + 0x68);
      *(undefined2 *)(iVar9 + 0x6c) = 0;
      *(undefined2 *)(iVar9 + 0x6a) = 0;
    }
    *(char *)(puStack_7c + 7) = (char)*(undefined2 *)DWORD_08099d94;
    sub_08000AF0(*(ushort *)DWORD_08099d94 + 0x10,puStack_7c[3] + (uint)*puStack_28 * 0x20,1);
    uVar10 = sub_08098004();
    if ((uVar10 & 1) == 0) {
      uVar5 = sub_0800BC44(*(int *)(param_1 + 10) >> 8,*(int *)(param_1 + 0xc) >> 8,0);
    }
    else {
      uVar5 = sub_08097FF8();
    }
    iVar9 = sub_0800CD8C();
    if (iVar9 == 0) {
      uVar6 = sub_08065370(puStack_7c,*puStack_34,puStack_30,puStack_2c,uStack_60);
      param_1[0x37] = uVar6;
    }
    psStack_38 = &sStack_7e;
    sub_0800BC08((*(int *)(param_1 + 10) << 8) >> 0x10,(*(int *)(param_1 + 0xc) << 8) >> 0x10,
                 &sStack_80,&sStack_7e,0,0);
    if (uStack_5c == 0) {
      iVar9 = sub_0800CCCC();
      if (((iVar9 == 0) && (iVar9 = sub_0800CC98(), iVar9 == 0)) &&
         (iVar9 = sub_0800CD34(), iVar9 == 0)) {
        puVar17 = puStack_7c + 7;
        sub_08007870((int)sStack_80,(int)sStack_7e,*puStack_34,*puStack_30,uVar5,puVar17,
                     puStack_7c[2],*puStack_7c);
        if ((*(uint *)DWORD_08099f48 & 1) != 0) {
          sub_08007870((int)sStack_80,sStack_7e + -1,uStack_48,0,uVar5,puVar17,puStack_7c[2],
                       *puStack_7c);
        }
      }
    }
    else {
      uVar10 = uStack_5c - 1 & 0xffff;
      uVar13 = uStack_5c & 1;
      uStack_5c = uVar10;
      if (((uVar13 != 0) && (iVar9 = sub_0800CCCC(), iVar9 == 0)) &&
         ((iVar9 = sub_0800CC98(), iVar9 == 0 &&
          (iVar9 = sub_0800CD34(), puVar17 = puStack_7c, iVar9 == 0)))) {
        puVar16 = puStack_7c + 7;
        sub_08007870((int)sStack_80,(int)*psStack_38,*puStack_34,*puStack_30,uVar5,puVar16,
                     puStack_7c[2],*puStack_7c);
        sub_08007870((int)sStack_80,*psStack_38 + -1,uStack_48,0,uVar5,puVar16,puVar17[2],*puVar17);
      }
    }
    iVar9 = *(int *)(param_1 + 0x26);
    if ((iVar9 != 0) && (iStack_70 != iVar9)) {
      uStack_58 = 10;
      uStack_44 = 0;
      iStack_70 = iVar9;
    }
    if (uStack_58 == 0) {
      iStack_70 = 0;
      param_1[0x26] = 0;
      param_1[0x27] = 0;
    }
    else {
      iVar9 = sub_0800CC98();
      if (((iVar9 == 0) && (iVar9 = sub_0800CCCC(), iVar9 == 0)) &&
         (iVar9 = sub_0800CD34(), iVar9 == 0)) {
        sub_0801A120(param_1,iStack_70,(int)(short)uStack_44);
      }
      if ((uStack_58 & 2) != 0) {
        uStack_44 = uStack_44 * 0x10000 + DWORD_08099f4c >> 0x10;
      }
      uStack_58 = uStack_58 - 1 & 0xffff;
    }
    sVar7 = sub_08019CE8(param_1);
    if (sVar7 != 0) {
      iStack_3c = 1;
    }
    sub_080003F0();
  } while (iStack_3c == 0);
  *(undefined4 *)DWORD_0809a120 = 0;
  iVar9 = sub_080020F4();
  puVar14 = (uint *)(iVar9 * 0x14c + DWORD_0809a124 + 0x30);
  *puVar14 = *puVar14 | 1;
  sub_08097C6C();
  sub_0809AE50();
  dVar3 = DWORD_0809a128;
  puStack_7c = auStack_e8;
  iVar9 = *(int *)DWORD_0809a128;
  *(undefined2 *)(iVar9 + 0x6c) = 0;
  *(undefined2 *)(iVar9 + 0x6a) = 0;
  *(undefined2 *)(iVar9 + 0x68) = 0;
  uStack_cc = (undefined1)*(undefined2 *)DWORD_0809a12c;
  uStack_44 = 0;
  uStack_58 = 10;
  do {
    iVar9 = sub_080020F4();
    puVar14 = (uint *)(iVar9 * 0x14c + DWORD_0809a124 + 0x30);
    *puVar14 = *puVar14 | 1;
    iVar9 = sub_0800CCCC();
    if (((iVar9 == 0) && (iVar9 = sub_0800CC98(), iVar9 == 0)) &&
       (iVar9 = sub_0800CD34(), iVar9 == 0)) {
      sub_08000AF0(*(ushort *)DWORD_0809a12c + 0x10,puStack_7c[3] + (uint)*puStack_28 * 0x20,1);
      uVar5 = sub_0800BC44(*(int *)(*(int *)dVar3 + 0x14) >> 8,*(int *)(*(int *)dVar3 + 0x18) >> 8,0
                          );
      uVar8 = sub_08065370(puStack_7c,0,*(int *)dVar3 + 0x6a,*(int *)dVar3 + 0x6c,1);
      iVar9 = *(int *)dVar3;
      *(undefined2 *)(iVar9 + 0x6e) = uVar8;
      sub_0800BC08((*(int *)(iVar9 + 0x14) << 8) >> 0x10,(*(int *)(iVar9 + 0x18) << 8) >> 0x10,
                   &sStack_80,&sStack_7e,0,0);
      puVar17 = puStack_7c;
      puStack_24 = puStack_7c + 7;
      sub_08007870((int)sStack_80,(int)sStack_7e,*(undefined2 *)(*(int *)dVar3 + 0x68),
                   *(undefined2 *)(*(int *)dVar3 + 0x6a),uVar5,puStack_24,puStack_7c[2],*puStack_7c)
      ;
      if ((*(uint *)DWORD_0809a130 & 1) != 0) {
        sub_08007870((int)sStack_80,sStack_7e + -1,0x18,0,uVar5,puStack_24,puVar17[2],*puVar17);
      }
      sub_0801A120(param_1,iStack_70,(int)(short)uStack_44);
    }
    if ((uStack_58 & 2) != 0) {
      uStack_44 = uStack_44 * 0x10000 + DWORD_0809a134 >> 0x10;
    }
    sub_080003F0();
    uStack_58 = uStack_58 - 1 & 0xffff;
  } while (uStack_58 != DWORD_0809a138);
  sub_080683CC();
  sub_08067CA8(param_1[1]);
  sub_08068330(DWORD_0809a13c);
  dVar3 = DWORD_0809a128;
  while (iVar9 = sub_080682B8(DWORD_0809a264), iVar9 == 0) {
    iVar9 = sub_080020F4();
    puVar14 = (uint *)(iVar9 * 0x14c + DWORD_0809a258 + 0x30);
    *puVar14 = *puVar14 | 1;
    iVar9 = sub_0800CCCC();
    if (((iVar9 == 0) && (iVar9 = sub_0800CC98(), iVar9 == 0)) &&
       (iVar9 = sub_0800CD34(), iVar9 == 0)) {
      sub_08000AF0(*(ushort *)DWORD_0809a25c + 0x10,puStack_7c[3] + (uint)*puStack_28 * 0x20,1);
      uVar5 = sub_0800BC44(*(int *)(*(int *)dVar3 + 0x14) >> 8,*(int *)(*(int *)dVar3 + 0x18) >> 8,0
                          );
      uVar8 = sub_08065370(puStack_7c,0,*(int *)dVar3 + 0x6a,*(int *)dVar3 + 0x6c,1);
      iVar9 = *(int *)dVar3;
      *(undefined2 *)(iVar9 + 0x6e) = uVar8;
      sub_0800BC08((*(int *)(iVar9 + 0x14) << 8) >> 0x10,(*(int *)(iVar9 + 0x18) << 8) >> 0x10,
                   &sStack_80,&sStack_7e,0,0);
      puVar17 = puStack_7c;
      puStack_24 = puStack_7c + 7;
      sub_08007870((int)sStack_80,(int)sStack_7e,*(undefined2 *)(*(int *)dVar3 + 0x68),
                   *(undefined2 *)(*(int *)dVar3 + 0x6a),uVar5,puStack_24,puStack_7c[2],*puStack_7c)
      ;
      if ((*(uint *)DWORD_0809a260 & 1) != 0) {
        sub_08007870((int)sStack_80,sStack_7e + -1,0x18,0,uVar5,puStack_24,puVar17[2],*puVar17);
      }
    }
    sub_080003F0();
  }
  sub_08065E38(DWORD_0809a264);
  dVar3 = DWORD_0809a268;
  while (iVar9 = sub_08058DB0(), iVar9 != 0) {
    iVar9 = sub_080020F4();
    puVar14 = (uint *)(iVar9 * 0x14c + DWORD_0809a3b8 + 0x30);
    *puVar14 = *puVar14 | 1;
    iVar9 = sub_0800CCCC();
    if (((iVar9 == 0) && (iVar9 = sub_0800CC98(), iVar9 == 0)) &&
       (iVar9 = sub_0800CD34(), iVar9 == 0)) {
      sub_08000AF0(*(ushort *)DWORD_0809a3bc + 0x10,puStack_7c[3] + (uint)*puStack_28 * 0x20,1);
      uVar5 = sub_0800BC44(*(int *)(*(int *)dVar3 + 0x14) >> 8,*(int *)(*(int *)dVar3 + 0x18) >> 8,0
                          );
      uVar8 = sub_08065370(puStack_7c,0,*(int *)dVar3 + 0x6a,*(int *)dVar3 + 0x6c,1);
      iVar9 = *(int *)dVar3;
      *(undefined2 *)(iVar9 + 0x6e) = uVar8;
      sub_0800BC08((*(int *)(iVar9 + 0x14) << 8) >> 0x10,(*(int *)(iVar9 + 0x18) << 8) >> 0x10,
                   &sStack_80,&sStack_7e,0,0);
      puVar17 = puStack_7c;
      puStack_24 = puStack_7c + 7;
      sub_08007870((int)sStack_80,(int)sStack_7e,*(undefined2 *)(*(int *)dVar3 + 0x68),
                   *(undefined2 *)(*(int *)dVar3 + 0x6a),uVar5,puStack_24,puStack_7c[2],*puStack_7c)
      ;
      if ((*(uint *)DWORD_0809a3c0 & 1) != 0) {
        sub_08007870((int)sStack_80,sStack_7e + -1,0x18,0,uVar5,puStack_24,puVar17[2],*puVar17);
      }
    }
    sub_080003F0();
  }
  sub_080586B4(0);
  iVar9 = sub_080020F4();
  puVar14 = (uint *)(iVar9 * 0x14c + DWORD_0809a3b8 + 0x30);
  *puVar14 = *puVar14 | 1;
  uVar11 = sub_0805DF38(1,0xe,0x19,2,0x3c,DWORD_0809a3c4);
  *(undefined4 *)(*(int *)DWORD_0809a3c8 + 0x720) = uVar11;
  dVar3 = DWORD_0809a3cc;
  while (iVar9 = sub_0805EEFC(*(undefined4 *)(*(int *)DWORD_0809a5ac + 0x720)), iVar9 == 0) {
    iVar9 = sub_080020F4();
    puVar14 = (uint *)(iVar9 * 0x14c + DWORD_0809a5a0 + 0x30);
    *puVar14 = *puVar14 | 1;
    iVar9 = sub_0800CCCC();
    if (((iVar9 == 0) && (iVar9 = sub_0800CC98(), iVar9 == 0)) &&
       (iVar9 = sub_0800CD34(), iVar9 == 0)) {
      sub_08000AF0(*(ushort *)DWORD_0809a5a4 + 0x10,puStack_7c[3] + (uint)*puStack_28 * 0x20,1);
      uVar5 = sub_0800BC44(*(int *)(*(int *)dVar3 + 0x14) >> 8,*(int *)(*(int *)dVar3 + 0x18) >> 8,0
                          );
      uVar8 = sub_08065370(puStack_7c,0,*(int *)dVar3 + 0x6a,*(int *)dVar3 + 0x6c,1);
      iVar9 = *(int *)dVar3;
      *(undefined2 *)(iVar9 + 0x6e) = uVar8;
      sub_0800BC08((*(int *)(iVar9 + 0x14) << 8) >> 0x10,(*(int *)(iVar9 + 0x18) << 8) >> 0x10,
                   &sStack_80,&sStack_7e,0,0);
      puVar17 = puStack_7c;
      puStack_24 = puStack_7c + 7;
      sub_08007870((int)sStack_80,(int)sStack_7e,*(undefined2 *)(*(int *)dVar3 + 0x68),
                   *(undefined2 *)(*(int *)dVar3 + 0x6a),uVar5,puStack_24,puStack_7c[2],*puStack_7c)
      ;
      if ((*(uint *)DWORD_0809a5a8 & 1) != 0) {
        sub_08007870((int)sStack_80,sStack_7e + -1,0x18,0,uVar5,puStack_24,puVar17[2],*puVar17);
      }
    }
    sub_080003F0();
  }
  iVar9 = sub_080020F4();
  iVar15 = DWORD_0809a5a0 + 0x30;
  puVar14 = (uint *)(iVar9 * 0x14c + iVar15);
  *puVar14 = *puVar14 & 0xfffffffe;
  sub_08058688(0xd);
  dVar3 = DWORD_0809a5b0;
  sub_080970CC(*(undefined4 *)DWORD_0809a5b0,puStack_7c,*puStack_28,*(undefined2 *)DWORD_0809a5a4);
  iVar9 = sub_080020F4();
  if (((*(uint *)(iVar9 * 0x14c + iVar15) & 0x2000) == 0) && (*(short *)(*(int *)dVar3 + 0x5a) != 0)
     ) {
    uVar11 = sub_0801E46C(*(undefined4 *)DWORD_0809a5b4,puStack_78);
    uStack_44 = 0x1d;
    do {
      iVar9 = *(int *)DWORD_0809a5b0;
      *(int *)(iVar9 + 0x18) = *(int *)(iVar9 + 0x18) + -0x20;
      sub_0806171C(iVar9,uVar11);
      sub_080003F0();
      uVar10 = uStack_44 * 0x10000 + DWORD_0809a5b8;
      uStack_44 = uVar10 >> 0x10;
    } while ((int)uVar10 >> 0x10 != -1);
    sub_0801E4CC(*(undefined4 *)DWORD_0809a5b4,uVar11);
  }
  uStack_44 = 0x6f;
  do {
    sub_080003F0();
    uVar10 = uStack_44 * 0x10000 + DWORD_0809a5b8;
    uStack_44 = uVar10 >> 0x10;
  } while ((int)uVar10 >> 0x10 != -1);
  sub_08067C18();
  while (iVar9 = sub_08067C08(), iVar9 == 0) {
    sub_080003F0();
  }
  sub_08067BF8();
  sub_08056E24();
  return in_lr;
}


