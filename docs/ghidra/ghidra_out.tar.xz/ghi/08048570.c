
undefined4 sub_08048570(int param_1)

{
  dword dVar1;
  short sVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  int unaff_r6;
  undefined4 in_lr;
  
  dVar1 = DWORD_08048590;
  if (param_1 != 0) {
    if (param_1 != 1) {
      return in_lr;
    }
    do {
      sVar2 = 1;
      do {
        sub_080003F0();
        iVar4 = sub_080021A8();
        if (iVar4 != 0) break;
        sVar2 = sVar2 + -1;
      } while (sVar2 != 0);
      if ((*(ushort *)(*(int *)DWORD_0804897c + 4) >> 4 & 1) == 0) {
        iVar4 = sub_08019C3C();
      }
      else {
        iVar4 = 1;
      }
    } while (iVar4 != 0);
    sub_08068070(DWORD_080489ac,3);
    iVar4 = sub_080020F4();
    iVar4 = iVar4 * 0x14c + DWORD_080489b0;
    *(uint *)(iVar4 + 0x30) = *(uint *)(iVar4 + 0x30) | 1;
    sub_0800D0F4();
    while (iVar4 = sub_0805F184(), iVar4 != 0) {
      sub_080003F0();
    }
    while (iVar4 = sub_0805EF90(), iVar4 != 0) {
      sub_080003F0();
    }
    uVar5 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_080489e8);
    while (iVar4 = sub_0805EEFC(uVar5), iVar4 == 0) {
      sub_080003F0();
    }
    iVar4 = sub_080020F4();
    iVar4 = iVar4 * 0x14c + DWORD_08048a1c;
    *(uint *)(iVar4 + 0x30) = *(uint *)(iVar4 + 0x30) & 0xfffffffe;
    sub_0800D108();
    sVar2 = 0x3c;
    do {
      sub_080003F0();
      iVar4 = sub_080021A8();
      if (iVar4 != 0) break;
      sVar2 = sVar2 + -1;
    } while (sVar2 != 0);
    sub_08068070(DWORD_08048a68,7);
    iVar4 = sub_08002164();
    if (iVar4 != 1) {
      return in_lr;
    }
    *(undefined4 *)DWORD_08048a6c = 1;
    if ((*(uint *)DWORD_08048a70 & 0x20) != 0) {
      return in_lr;
    }
    sub_08006CB4(1);
    return in_lr;
  }
  iVar4 = *(int *)DWORD_08048594 + DWORD_08048598;
  for (uVar6 = 0; uVar6 < 0x1e; uVar6 = uVar6 + 1) {
    iVar3 = sub_08000470(iVar4);
    if (iVar3 == 0) goto LAB_080485b4;
    iVar4 = iVar4 + 0x28;
  }
LAB_080485e0:
  sub_0802A080(0x78,0xaf,0x32,0x14);
  uVar6 = *(uint *)(*(int *)DWORD_08048644 + 0x38) & 8;
  if (uVar6 != 0) {
    uVar6 = 1;
  }
  if (uVar6 == 0) {
    iVar4 = sub_08002164();
    if ((iVar4 == 1) &&
       (*(undefined4 *)DWORD_08048648 = 0xa5, (*(uint *)DWORD_0804864c & 0x20) == 0)) {
      sub_08006CB4(0xa5);
    }
    dVar1 = DWORD_08048650;
    uVar6 = *(uint *)(*(int *)DWORD_08048644 + 0x38) & 4;
    if (uVar6 != 0) {
      uVar6 = 1;
    }
    if (uVar6 == 1) {
      iVar4 = *(int *)DWORD_08048644 + DWORD_08048654;
      for (uVar6 = 0; uVar6 < 0x1e; uVar6 = uVar6 + 1) {
        iVar3 = sub_08000470(iVar4);
        if (iVar3 == 0) goto LAB_08048670;
        iVar4 = iVar4 + 0x28;
      }
LAB_0804869a:
      dVar1 = DWORD_080486a8;
      iVar4 = *(int *)DWORD_080486ac + DWORD_080486b0;
      for (uVar6 = 0; uVar6 < 0x1e; uVar6 = uVar6 + 1) {
        iVar3 = sub_08000470(iVar4);
        if (iVar3 == 0) goto LAB_080486cc;
        iVar4 = iVar4 + 0x28;
      }
LAB_080486f6:
      dVar1 = DWORD_08048704;
      iVar4 = *(int *)DWORD_08048708 + DWORD_0804870c;
      for (uVar6 = 0; uVar6 < 0x1e; uVar6 = uVar6 + 1) {
        iVar3 = sub_08000470(iVar4);
        if (iVar3 == 0) goto LAB_08048728;
        iVar4 = iVar4 + 0x28;
      }
LAB_08048752:
      dVar1 = DWORD_08048760;
      iVar4 = *(int *)DWORD_08048764 + DWORD_08048768;
      for (uVar6 = 0; uVar6 < 0x1e; uVar6 = uVar6 + 1) {
        iVar3 = sub_08000470(iVar4);
        if (iVar3 == 0) goto LAB_08048784;
        iVar4 = iVar4 + 0x28;
      }
LAB_080487ae:
      dVar1 = DWORD_080487bc;
      iVar4 = *(int *)DWORD_080487c0 + DWORD_080487c4;
      for (uVar6 = 0; uVar6 < 0x1e; uVar6 = uVar6 + 1) {
        iVar3 = sub_08000470(iVar4);
        if (iVar3 == 0) goto LAB_080487e0;
        iVar4 = iVar4 + 0x28;
      }
LAB_0804880a:
      iVar4 = sub_080020F4();
      iVar4 = iVar4 * 0x14c + DWORD_0804882c;
      *(uint *)(iVar4 + 0x30) = *(uint *)(iVar4 + 0x30) & 0xfffffffe;
      sub_0800D108();
      sVar2 = 0x3c;
      do {
        sub_080003F0();
        iVar4 = sub_080021A8();
        dVar1 = DWORD_0804887c;
        if (iVar4 != 0) break;
        sVar2 = sVar2 + -1;
      } while (sVar2 != 0);
      iVar4 = *(int *)DWORD_08048878;
      uVar6 = 0;
      do {
        if (((*(uint *)dVar1 & 1 << (uVar6 & 0xff)) != 0) && (*(short *)(iVar4 + 0xc) == 0xc)) {
          *(undefined2 *)(iVar4 + 0xc) = 0;
        }
        uVar6 = uVar6 + 1;
        iVar4 = iVar4 + 0x2e0;
      } while (uVar6 < 5);
      sub_08019F04();
    }
    else {
      sub_08068070(DWORD_080488bc,7);
      if ((unaff_r6 != 0) && (iVar4 = sub_08000470(unaff_r6), iVar4 != 0)) {
        sub_080003A8(unaff_r6);
      }
      iVar4 = sub_080020F4();
      iVar4 = iVar4 * 0x14c + DWORD_080488c0;
      *(uint *)(iVar4 + 0x30) = *(uint *)(iVar4 + 0x30) | 1;
      sub_0800D0F4();
      sVar2 = 1;
      do {
        sub_080003F0();
        iVar4 = sub_080021A8();
        if (iVar4 != 0) break;
        sVar2 = sVar2 + -1;
      } while (sVar2 != 0);
      sub_0805EFBC();
      do {
        sub_080003F0();
        iVar4 = sub_0805F184();
        dVar1 = DWORD_080488f8;
      } while (iVar4 != 0);
      iVar4 = *(int *)DWORD_080488fc + DWORD_08048900;
      for (uVar6 = 0; uVar6 < 0x1e; uVar6 = uVar6 + 1) {
        iVar3 = sub_08000470(iVar4);
        if (iVar3 == 0) {
          while( true ) {
            iVar3 = sub_08001494(0x400);
            *(int *)(iVar4 + 0x20) = iVar3;
            if (iVar3 != 0) break;
            sub_080003F0();
          }
          *(undefined4 *)(iVar4 + 8) = 0x3c;
          *(dword *)(iVar4 + 0xc) = dVar1;
          *(int *)(iVar4 + 0x10) = iVar3 + 0x3fc;
          *(undefined4 *)(iVar4 + 0x24) = 0;
          sub_08000274(iVar4,1);
          return in_lr;
        }
        iVar4 = iVar4 + 0x28;
      }
    }
  }
  return in_lr;
LAB_080485b4:
  while( true ) {
    iVar3 = sub_08001494(0x400);
    *(int *)(iVar4 + 0x20) = iVar3;
    if (iVar3 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar4 + 8) = 0x3c;
  *(dword *)(iVar4 + 0xc) = dVar1;
  *(int *)(iVar4 + 0x10) = iVar3 + 0x3fc;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  sub_08000274(iVar4,0);
  unaff_r6 = iVar4;
  goto LAB_080485e0;
LAB_08048670:
  while( true ) {
    iVar3 = sub_08001494(0x400);
    *(int *)(iVar4 + 0x20) = iVar3;
    if (iVar3 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar4 + 8) = 0x3c;
  *(dword *)(iVar4 + 0xc) = dVar1;
  *(int *)(iVar4 + 0x10) = iVar3 + 0x3fc;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  sub_08000274(iVar4,2);
  goto LAB_0804869a;
LAB_080486cc:
  while( true ) {
    iVar3 = sub_08001494(0x400);
    *(int *)(iVar4 + 0x20) = iVar3;
    if (iVar3 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar4 + 8) = 0x3c;
  *(dword *)(iVar4 + 0xc) = dVar1;
  *(int *)(iVar4 + 0x10) = iVar3 + 0x3fc;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  sub_08000274(iVar4,3);
  goto LAB_080486f6;
LAB_08048728:
  while( true ) {
    iVar3 = sub_08001494(0x400);
    *(int *)(iVar4 + 0x20) = iVar3;
    if (iVar3 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar4 + 8) = 0x3c;
  *(dword *)(iVar4 + 0xc) = dVar1;
  *(int *)(iVar4 + 0x10) = iVar3 + 0x3fc;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  sub_08000274(iVar4,4);
  goto LAB_08048752;
LAB_08048784:
  while( true ) {
    iVar3 = sub_08001494(0x400);
    *(int *)(iVar4 + 0x20) = iVar3;
    if (iVar3 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar4 + 8) = 0x3c;
  *(dword *)(iVar4 + 0xc) = dVar1;
  *(int *)(iVar4 + 0x10) = iVar3 + 0x3fc;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  sub_08000274(iVar4,5);
  goto LAB_080487ae;
LAB_080487e0:
  while( true ) {
    iVar3 = sub_08001494(0x400);
    *(int *)(iVar4 + 0x20) = iVar3;
    if (iVar3 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar4 + 8) = 0x3c;
  *(dword *)(iVar4 + 0xc) = dVar1;
  *(int *)(iVar4 + 0x10) = iVar3 + 0x3fc;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  sub_08000274(iVar4,6);
  goto LAB_0804880a;
}


