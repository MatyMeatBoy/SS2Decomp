
undefined4 sub_080653D4(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 in_lr;
  
  iVar2 = param_1 * 0x28 + DWORD_080653f8;
  iVar1 = sub_08000470(iVar2);
  if (iVar1 != 0) {
    sub_080003A8(iVar2);
  }
  return in_lr;
}


