
void sub_0805E0C4(int param_1)

{
  byte bVar1;
  char cVar2;
  char *pcVar3;
  uint uVar4;
  dword dVar5;
  int iVar6;
  byte *pbVar7;
  int iVar8;
  undefined1 auStack_108 [60];
  undefined1 auStack_cc [52];
  char acStack_98 [12];
  char acStack_8c [16];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  uint uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  int iStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  uint uStack_30;
  char *pcStack_2c;
  char *pcStack_28;
  
  pcVar3 = *(char **)(param_1 + 0x60);
  uStack_6c = 0;
  iVar6 = 0;
  uStack_68 = 0;
  uStack_44 = 0;
  iVar8 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  pcStack_2c = acStack_98;
  pcStack_28 = acStack_8c;
  do {
    uStack_70 = 0;
    do {
      auStack_108[uStack_70 + iVar6] = 0xfd;
      uStack_70 = uStack_70 + 1 & 0xffff;
    } while (uStack_70 < 0x12);
    iVar6 = iVar6 + 0x1e;
    iVar8 = iVar8 + 1;
  } while (iVar8 < 2);
  cVar2 = *pcVar3;
  if (cVar2 == '\0') {
    bVar1 = 0xff;
  }
  else {
    bVar1 = cVar2 - 1;
  }
  uStack_30 = (uint)(byte)pcVar3[1];
  uVar4 = sub_0800CE30();
  if (uVar4 == 0) {
    if (bVar1 == 0xff) goto LAB_0805e1f6;
    dVar5 = DWORD_0805e1b8;
    if (0xf < bVar1) {
      dVar5 = DWORD_0805e26c;
      if (0x1f < bVar1) goto LAB_0805e1e4;
      sub_08065158(auStack_cc,DWORD_0805e1d8,0xf,0xffffffff,0);
      bVar1 = bVar1 - 0x10;
      goto LAB_0805e1f0;
    }
  }
  else {
    if (bVar1 == 0xff) goto LAB_0805e1f6;
    dVar5 = DWORD_0805e164;
    if (0xf < bVar1) {
      dVar5 = DWORD_0805e198;
      if (bVar1 < 0x20) {
        sub_08065158(auStack_cc,DWORD_0805e188,0xf,0xffffffff,0);
        bVar1 = bVar1 - 0x10;
      }
      else {
LAB_0805e1e4:
        sub_08065158(auStack_cc,dVar5,0xf,0xffffffff,0);
        bVar1 = bVar1 - 0x20;
      }
LAB_0805e1f0:
      uVar4 = (uint)bVar1;
      goto LAB_0805e1f6;
    }
  }
  uVar4 = sub_08065158(auStack_cc,dVar5,0xf,0xffffffff,0);
LAB_0805e1f6:
  uStack_7c = sub_0801E4B0(uVar4);
  cVar2 = sub_08000498(&uStack_7c,DWORD_0805e270);
  pcVar3 = pcStack_2c;
  iVar8 = 0;
  *pcStack_2c = cVar2;
  cVar2 = sub_08000498(&uStack_7c,DWORD_0805e274);
  pcVar3[1] = cVar2;
  cVar2 = sub_08000498(&uStack_7c,DWORD_0805e278);
  pcVar3[2] = cVar2;
  cVar2 = sub_08000498(&uStack_7c,DWORD_0805e27c);
  pcVar3[3] = cVar2;
  cVar2 = sub_08000498(&uStack_7c,1000);
  pcVar3[4] = cVar2;
  cVar2 = sub_08000498(&uStack_7c,100);
  pcVar3[5] = cVar2;
  cVar2 = sub_08000498(&uStack_7c,10);
  pcVar3[6] = cVar2;
  pcVar3[7] = (char)uStack_7c;
  pcVar3[8] = '\0';
  iStack_50 = 0;
  iVar6 = 0;
  pcVar3 = pcStack_2c;
  do {
    if ((*pcVar3 == '\0') && (iStack_50 == 0)) {
      *pcVar3 = -1;
    }
    else {
      *pcVar3 = *pcVar3 + 'A';
      if (iStack_50 == 0) {
        iVar6 = iVar8;
      }
      iStack_50 = 1;
    }
    pcVar3 = pcVar3 + 1;
    iVar8 = iVar8 + 1;
  } while (iVar8 < 9);
  iVar8 = 0;
  for (; iVar6 < 8; iVar6 = iVar6 + 1) {
    pcStack_2c[iVar8] = pcStack_2c[iVar6];
    iVar8 = iVar8 + 1;
  }
  pcStack_2c[iVar8] = -3;
  pcStack_2c[iVar8 + 1] = '\0';
  iVar6 = sub_080020F4();
  iStack_34 = iVar6 * 0x14c + DWORD_0805e330;
  iVar6 = 0;
  cVar2 = *(char *)DWORD_0805e330;
  *pcStack_28 = cVar2;
  while ((cVar2 != -3 && (iVar6 = iVar6 + 1, iVar6 < 10))) {
    cVar2 = *(char *)(iVar6 + DWORD_0805e330);
    pcStack_28[iVar6] = cVar2;
  }
  iVar8 = sub_08002204();
  if (iVar8 == 0) {
    iVar8 = sub_08007290(DWORD_0805e334);
    if (iVar6 < 0xd) {
      pbVar7 = (byte *)(iVar8 + 2);
      do {
        bVar1 = *pbVar7;
        pcStack_28[iVar6] = bVar1;
        if (0xf1 < bVar1) {
          pcStack_28[iVar6] = 0xfd;
          pcVar3 = pcStack_28 + iVar6 + 1;
          goto LAB_0805e34a;
        }
        iVar6 = iVar6 + 1;
        pbVar7 = pbVar7 + 1;
      } while (iVar6 < 0xd);
    }
  }
  else {
    pcVar3 = pcStack_28 + iVar6 + 1;
LAB_0805e34a:
    *pcVar3 = '\0';
  }
  uStack_4c = 0;
  iStack_50 = 0;
  uStack_48 = 0;
  uStack_38 = 0;
  uStack_64 = 1;
  uStack_5c = 0;
  uStack_58 = 0;
  uStack_78 = 0;
  uStack_60 = 1;
  sub_080653CC();
  uVar4 = *(uint *)(param_1 + 0x74);
  if (7 < uVar4) {
    uVar4 = func_0x0805ecf2();
  }
                    /* WARNING: Could not recover jumptable at 0x0805e386. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(uVar4 * 4 + DWORD_0805e388))();
  return;
}


