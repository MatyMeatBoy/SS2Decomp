
void sub_0800CBEC(void)

{
  *(undefined4 *)DWORD_0800cbf4 = 0;
  return;
}


