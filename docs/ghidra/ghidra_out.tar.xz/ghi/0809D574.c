
undefined4 sub_0809D574(void)

{
  undefined4 in_lr;
  
  sub_0805867C(0xe6);
  if (*(short *)(*(int *)DWORD_0809d5ac + 0x5c) != 0) {
    sub_0809D5E4();
    sub_0809D6D8();
    sub_0809D810();
  }
  sub_08068384();
  *(undefined4 *)DWORD_0809d5b0 = 0;
  sub_08016ECC(*(undefined2 *)DWORD_0809d5b4);
  return in_lr;
}


