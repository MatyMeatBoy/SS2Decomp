
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_0802A228(undefined4 param_1,int param_2)

{
  short sVar1;
  int iVar2;
  undefined2 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 in_lr;
  
  sub_0800BB40();
  sVar1 = 5;
  do {
    sub_080003F0();
    iVar2 = sub_080021A8();
    if (iVar2 != 0) break;
    sVar1 = sVar1 + -1;
  } while (sVar1 != 0);
  switch(param_1) {
  case 0:
    sub_0800CCDC();
    iVar2 = *_UNK_0802a2dc;
    *(undefined4 *)(iVar2 + _UNK_0802a2e0) = *(undefined4 *)(param_2 * 4 + _UNK_0802a2e4);
    *(undefined2 *)(iVar2 + 0x36) = 0;
    goto LAB_0802a56e;
  case 1:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a2f8;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a2fc);
    iVar2 = _UNK_0802a300;
    break;
  case 2:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a314;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a318);
    iVar2 = _UNK_0802a31c;
    break;
  case 3:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a330;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a334);
    iVar2 = _UNK_0802a338;
    break;
  case 4:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a34c;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a350);
    iVar2 = _UNK_0802a354;
    break;
  case 5:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a368;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a36c);
    iVar2 = _UNK_0802a370;
    break;
  case 6:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a384;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a388);
    iVar2 = _UNK_0802a38c;
    break;
  case 7:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a3a0;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a3a4);
    iVar2 = _UNK_0802a3a8;
    break;
  case 8:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a3bc;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a3c0);
    iVar2 = _UNK_0802a3c4;
    break;
  case 9:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a3d8;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a3dc);
    iVar2 = _UNK_0802a3e0;
    break;
  case 10:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a3f4;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a3f8);
    iVar2 = _UNK_0802a3fc;
    break;
  case 0xb:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a410;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a414);
    iVar2 = _UNK_0802a418;
    break;
  case 0xc:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a42c;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a430);
    iVar2 = _UNK_0802a434;
    break;
  case 0xd:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a448;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a44c);
    iVar2 = _UNK_0802a450;
    break;
  case 0xe:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a464;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a468);
    iVar2 = _UNK_0802a46c;
    break;
  case 0xf:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a480;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a484);
    iVar2 = _UNK_0802a488;
    break;
  case 0x10:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a49c;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a4a0);
    iVar2 = _UNK_0802a4a4;
    break;
  case 0x11:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a4b8;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a4bc);
    iVar2 = _UNK_0802a4c0;
    break;
  case 0x12:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a4d4;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a4d8);
    iVar2 = _UNK_0802a4dc;
    break;
  case 0x13:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a4f0;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a4f4);
    iVar2 = _UNK_0802a4f8;
    break;
  case 0x14:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a50c;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a510);
    iVar2 = _UNK_0802a514;
    break;
  case 0x15:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a528;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a52c);
    iVar2 = _UNK_0802a530;
    break;
  case 0x16:
    sub_0800CCEC();
    iVar4 = *_UNK_0802a544;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a548);
    iVar2 = _UNK_0802a54c;
    break;
  case 0x17:
    sub_0800CCEC();
    iVar4 = *(int *)DWORD_0802a584;
    puVar5 = (undefined4 *)(iVar4 + _UNK_0802a588);
    iVar2 = _UNK_0802a58c;
    break;
  default:
    goto LAB_0802a56e;
  }
  *puVar5 = *(undefined4 *)(param_2 * 4 + iVar2);
  *(ushort *)(iVar4 + 4) = *(ushort *)(iVar4 + 4) | 0x10;
LAB_0802a56e:
  puVar3 = *(undefined2 **)DWORD_0802a584;
  puVar3[8] = 0;
  *(int *)(puVar3 + 0x20) = param_2;
  *puVar3 = (short)param_1;
  sub_08028918();
  return in_lr;
}


