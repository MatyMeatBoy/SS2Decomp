
undefined4 sub_0809AE88(undefined2 param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_lr;
  
  iVar2 = *(int *)DWORD_0809ae98;
  uVar3 = 0;
  while( true ) {
    if (4 < uVar3) {
      return in_lr;
    }
    iVar1 = sub_08000470(iVar2);
    if ((iVar1 == 0) && (*(int *)(iVar2 + 8) == 0)) break;
    uVar3 = uVar3 + 1;
    iVar2 = iVar2 + 0x28;
  }
  iVar1 = sub_08001494(0x400);
  *(int *)(iVar2 + 0x20) = iVar1;
  if (iVar1 == 0) {
    return in_lr;
  }
  *(int *)(iVar2 + 0x10) = iVar1 + 0x3fc;
  *(dword *)(iVar2 + 0xc) = DWORD_0809aee4;
  *(undefined4 *)(iVar2 + 0x24) = 0;
  *(undefined4 *)(iVar2 + 8) = 0x46;
  sub_08000274(iVar2,param_1);
  return in_lr;
}


