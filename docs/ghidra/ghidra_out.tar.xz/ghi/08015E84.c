
undefined8 sub_08015E84(int param_1)

{
  int iVar1;
  ushort *puVar2;
  short sVar3;
  uint uVar4;
  undefined4 in_lr;
  
  uVar4 = 7;
  puVar2 = (ushort *)(DWORD_08015ec0 + 0xe);
  while( true ) {
    iVar1 = *(char *)(param_1 + 0x6c) * 10 + (uint)*puVar2;
    sVar3 = (short)iVar1;
    if (iVar1 * 0x10000 < 0) {
      sVar3 = 0;
    }
    if (sVar3 <= *(short *)(param_1 + 0xc2)) break;
    puVar2 = puVar2 + -1;
    uVar4 = uVar4 - 1;
    if ((int)uVar4 < 0) {
      uVar4 = 0;
LAB_08015ece:
      return CONCAT44(in_lr,uVar4);
    }
  }
  uVar4 = uVar4 & 0xffff;
  goto LAB_08015ece;
}


