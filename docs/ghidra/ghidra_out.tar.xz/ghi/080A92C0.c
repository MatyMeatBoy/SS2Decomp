
undefined4 sub_080A92C0(short param_1)

{
  dword dVar1;
  dword dVar2;
  undefined1 uVar3;
  char cVar4;
  ushort uVar5;
  int iVar6;
  undefined4 uVar7;
  ushort *puVar8;
  int iVar9;
  undefined4 in_lr;
  undefined4 auStack_78 [2];
  undefined4 uStack_70;
  int iStack_6c;
  undefined1 auStack_5c [24];
  short sStack_44;
  short sStack_42;
  undefined2 uStack_40;
  undefined2 uStack_3e;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  
  dVar1 = DWORD_080a9310;
  sub_08065158(auStack_78,DWORD_080a930c,*(undefined2 *)DWORD_080a9310,0xffffffff,1);
  auStack_5c[0] = (undefined1)*(undefined2 *)dVar1;
  iStack_34 = *(int *)(*(int *)DWORD_080a9314 + 0x14);
  iStack_30 = *(int *)(*(int *)DWORD_080a9314 + 0x18);
  if (param_1 == 0) {
    iStack_34 = iStack_34 + 0x400;
  }
  else {
    iStack_34 = iStack_34 + DWORD_080a9318;
    iStack_30 = iStack_30 + DWORD_080a9318;
  }
  uStack_3e = 0;
  uStack_40 = 0;
  iStack_24 = 0;
  sub_0805865C(0xe4);
  while( true ) {
    if (param_1 == 0) {
      uStack_2c = 0x3000;
      uStack_28 = 0x11000;
    }
    else {
      uStack_2c = 0x2000;
      uStack_28 = 0x10000;
    }
    sub_080979D8(iStack_34,iStack_30,uStack_2c,uStack_28,&iStack_3c);
    iStack_34 = iStack_34 + iStack_3c * 4;
    iStack_30 = iStack_30 + iStack_38 * 4;
    cVar4 = sub_08097B6C(iStack_34,iStack_30,uStack_2c,uStack_28,0x18);
    if (cVar4 != '\0') break;
    iVar6 = sub_080020F4();
    dVar1 = DWORD_080a943c;
    iVar9 = iStack_34 - *(int *)(iVar6 * 0x14c + DWORD_080a943c + 0x8c);
    iVar6 = sub_080020F4();
    iVar9 = iVar9 * 0x100 >> 0x10;
    iVar6 = (iStack_30 - *(int *)(iVar6 * 0x14c + dVar1 + 0x90)) * 0x100 >> 0x10;
    uVar5 = Sqrt(iVar9 * iVar9 + iVar6 * iVar6);
    if ((((((iStack_24 == 0) && (uVar5 < 0xc)) && (iVar6 = sub_0800CDF8(), iVar6 == 0)) &&
         (((iVar6 = sub_0800CD8C(), iVar6 == 0 &&
           (iVar6 = sub_0800CCCC(), dVar2 = DWORD_080a9440, iVar6 == 0)) &&
          ((*(short *)(*(int *)DWORD_080a9440 + 0xc) != 0xb &&
           ((iVar6 = sub_080020F4(), (*(uint *)(iVar6 * 0x14c + dVar1 + 0x30) & 0x2000) == 0 &&
            (iVar6 = sub_080020F4(), *(char *)(iVar6 * 0x14c + dVar1 + 0x68) != '\0')))))))) &&
        (iVar6 = sub_080020F4(), *(short *)(iVar6 * 0x14c + dVar1 + 0x20) != 0xe)) &&
       (((iVar6 = sub_080020F4(), *(short *)(iVar6 * 0x14c + dVar1 + 0x20) != 0xb &&
         (iVar6 = sub_080020F4(), *(short *)(iVar6 * 0x14c + dVar1 + 0x20) != 0xc)) &&
        (iVar6 = sub_080020F4(),
        *(int *)((uint)**(ushort **)dVar2 * 4 + iVar6 * 0x14c + dVar1 + 0xe4) !=
        *(int *)(*(ushort **)dVar2 + 0x28))))) {
      iVar6 = sub_0800CE30();
      if (iVar6 == 1) {
        sub_08029CEC(1,0x28,3);
      }
      else {
        sub_08029CEC(1,0xf,3);
      }
      iVar6 = sub_080020F4();
      dVar1 = DWORD_080a9530;
      *(short *)(iVar6 * 0x14c + DWORD_080a9530 + 0xb0) = (short)DWORD_080a9534;
      iVar6 = sub_080020F4();
      puVar8 = *(ushort **)DWORD_080a9538;
      iVar9 = *(int *)(puVar8 + 0x28);
      *(int *)((uint)*puVar8 * 4 + iVar6 * 0x14c + dVar1 + 0xe4) = iVar9;
      *(int *)(puVar8 + 0x28) = iVar9 + 1;
      iStack_24 = 1;
    }
    iVar6 = sub_0800CCCC();
    if (((iVar6 == 0) && (iVar6 = sub_0800CC98(), iVar6 == 0)) &&
       ((iVar6 = sub_0800CD8C(), iVar6 == 0 && (iVar6 = sub_0800CD34(), iVar6 == 0)))) {
      sub_0800BC08((iStack_34 << 8) >> 0x10,(iStack_30 << 8) >> 0x10,&sStack_44,&sStack_42,0,0);
      dVar1 = DWORD_080a9538;
      sub_08000AF0(*(ushort *)DWORD_080a953c + 0x10,
                   iStack_6c + (uint)*(ushort *)(*(int *)DWORD_080a9538 + DWORD_080a9540) * 0x20,1);
      sub_08065370(auStack_78,3,&uStack_40,&uStack_3e,0);
      uVar3 = sub_0800BC44(*(int *)(*(int *)dVar1 + 0x14) >> 8,*(int *)(*(int *)dVar1 + 0x18) >> 8,0
                          );
      if (param_1 == 0) {
        uVar7 = 0xa0;
      }
      else {
        uVar7 = 0x10;
      }
      iVar6 = sub_08007870((int)sStack_44,uVar7,3,uStack_40,uVar3,auStack_5c,uStack_70,auStack_78[0]
                          );
      *(int *)(iVar6 + 0xc) = (int)sStack_42;
      if (param_1 == 0) {
        uVar7 = 0xa0;
      }
      else {
        uVar7 = 0x10;
      }
      iVar6 = sub_08007870(sStack_44 + 0x20,uVar7,4,uStack_40,uVar3,auStack_5c,uStack_70,
                           auStack_78[0]);
      *(int *)(iVar6 + 0xc) = sStack_42 + -0x10;
      if (param_1 == 0) {
        uVar7 = 0xa0;
      }
      else {
        uVar7 = 0x10;
      }
      iVar6 = sub_08007870(sStack_44 + 0x40,uVar7,5,uStack_40,uVar3,auStack_5c,uStack_70,
                           auStack_78[0]);
      *(int *)(iVar6 + 0xc) = sStack_42 + -0x20;
    }
    sub_080003F0();
  }
  iVar6 = sub_0800048C();
  *(undefined4 *)(iVar6 + 8) = 0;
  return in_lr;
}


