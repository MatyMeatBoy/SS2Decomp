
undefined4 m4aSongNumStartOrContinue(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 in_lr;
  
  piVar1 = (int *)(((uint)(param_1 << 0x10) >> 0xd) + DWORD_080b72b0);
  piVar2 = *(int **)((uint)*(ushort *)(piVar1 + 1) * 0xc + DWORD_080b72ac);
  iVar3 = *piVar1;
  if (*piVar2 == iVar3) {
    if ((short)piVar2[1] == 0) {
      MPlayStart(piVar2,*piVar2);
    }
    else if (piVar2[1] < 0) {
      MPlayContinue(piVar2);
    }
  }
  else {
    MPlayStart(piVar2,iVar3);
  }
  return in_lr;
}


