
undefined4 sub_08031F28(void)

{
  undefined2 uVar1;
  undefined2 uVar2;
  int iVar3;
  undefined2 *puVar4;
  undefined2 *puVar5;
  undefined4 in_lr;
  
  iVar3 = sub_080020F4();
  iVar3 = iVar3 * 0x14c + DWORD_08031f58;
  *(uint *)(iVar3 + 0x30) = *(uint *)(iVar3 + 0x30) | 1;
  sub_0800D0F4();
  sub_0800CE40();
  sub_0801ABE8(6);
  while (iVar3 = sub_0801AAE0(), iVar3 == 0) {
    sub_080003F0();
  }
  sub_0800BB54();
  sub_080003F0();
  sub_080003F0();
  sub_080003F0();
  sub_080003F0();
  sub_0800CCA8();
  puVar5 = (undefined2 *)(DWORD_08031fb4 + 0x7c);
  uVar1 = *puVar5;
  puVar4 = (undefined2 *)(DWORD_08031fb4 + 0x7e);
  uVar2 = *puVar4;
  sub_08084F9C(2);
  sub_080003F4(DWORD_08031fb8);
  *puVar5 = uVar1;
  *puVar4 = uVar2;
  sub_0800CCB8();
  sub_08000420(DWORD_08031fbc);
  sub_0800CE54();
  while (iVar3 = sub_0801AAE0(), iVar3 == 0) {
    sub_080003F0();
  }
  iVar3 = sub_080020F4();
  iVar3 = iVar3 * 0x14c + DWORD_08031ff4;
  *(uint *)(iVar3 + 0x30) = *(uint *)(iVar3 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


