
undefined4
sub_0800BCDC(undefined4 param_1,int param_2,undefined4 param_3,undefined2 param_4,undefined2 param_5
            )

{
  undefined4 in_lr;
  
  sub_0800B650(param_1,param_2 + 0x1c,param_3,param_4,param_5);
  return in_lr;
}


