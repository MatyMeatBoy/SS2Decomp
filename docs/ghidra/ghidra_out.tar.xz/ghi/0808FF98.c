
undefined8 sub_0808FF98(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 in_lr;
  
  if (*(short *)(*(int *)DWORD_0808ffb0 + 0x10) == 0) {
    sub_0802704C(param_1);
  }
  else {
    iVar1 = sub_08056E90();
    if (iVar1 != 0) {
      sub_0801ABE8(3);
      sub_0800BB40();
      while (iVar1 = sub_0801AAE0(), iVar1 == 0) {
        sub_080003F0();
      }
      sub_0800BB40();
      iVar1 = *(int *)DWORD_0808fff4;
      *(undefined4 *)(iVar1 + DWORD_0808fff8) =
           *(undefined4 *)(*(int *)(iVar1 + 0x40) * 4 + DWORD_0808fffc);
      *(undefined2 *)(iVar1 + 0x10) = 0;
      uVar2 = 1;
      goto LAB_08090002;
    }
  }
  uVar2 = 0;
LAB_08090002:
  return CONCAT44(in_lr,uVar2);
}


