
uint sub_0800CDC0(void)

{
  return *(uint *)DWORD_0800cdcc >> 7 & 1;
}


