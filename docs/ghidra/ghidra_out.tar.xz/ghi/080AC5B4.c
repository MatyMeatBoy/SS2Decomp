
undefined8 sub_080AC5B4(void)

{
  dword dVar1;
  dword dVar2;
  ushort uVar3;
  short sVar4;
  int iVar5;
  int iVar6;
  short *psVar7;
  int iVar8;
  ushort *puVar9;
  int iVar10;
  undefined4 uVar11;
  uint uVar12;
  undefined4 in_lr;
  undefined4 uStack_24;
  
  uStack_24 = 0;
  iVar5 = sub_080020F4();
  dVar2 = DWORD_080ac780;
  dVar1 = DWORD_080ac77c;
  iVar8 = DWORD_080ac780 + 0x8c;
  iVar10 = *(int *)(*(int *)DWORD_080ac77c + 0x14);
  iVar5 = *(int *)(iVar5 * 0x14c + iVar8);
  iVar6 = sub_080020F4();
  iVar10 = (iVar10 - iVar5) * 0x100 >> 0x10;
  iVar5 = ((*(int *)(*(int *)dVar1 + 0x18) - *(int *)(iVar6 * 0x14c + DWORD_080ac784) >> 8) + -8) *
          0x10000 >> 0x10;
  uVar3 = Sqrt(iVar10 * iVar10 + iVar5 * iVar5);
  if ((((((uVar3 < 0x28) && (iVar5 = sub_0800CDF8(), iVar5 == 0)) &&
        (iVar5 = sub_0800CCCC(), iVar5 == 0)) &&
       ((iVar5 = sub_0800CD8C(), iVar5 == 0 && (*(short *)(*(int *)dVar1 + 0xc) != 0xb)))) &&
      ((iVar5 = sub_080020F4(), (*(uint *)(iVar5 * 0x14c + dVar2 + 0x30) & 0x2000) == 0 &&
       ((iVar5 = sub_080020F4(), *(char *)(iVar5 * 0x14c + dVar2 + 0x68) != '\0' &&
        (iVar5 = sub_080020F4(), *(short *)(iVar5 * 0x14c + dVar2 + 0x20) != 0xe)))))) &&
     ((iVar5 = sub_080020F4(), *(short *)(iVar5 * 0x14c + dVar2 + 0x20) != 0xb &&
      (iVar5 = sub_080020F4(), *(short *)(iVar5 * 0x14c + dVar2 + 0x20) != 0xc)))) {
    iVar5 = sub_080020F4();
    if (*(int *)((uint)**(ushort **)dVar1 * 4 + iVar5 * 0x14c + dVar2 + 0xe4) !=
        *(int *)(*(ushort **)dVar1 + 0x28)) {
      iVar5 = sub_080020F4();
      *(undefined2 *)(iVar5 * 0x14c + dVar2 + 0x20) = 10;
      iVar5 = sub_080020F4();
      *(short *)(iVar5 * 0x14c + dVar2 + 0xb0) = (short)DWORD_080ac788;
      iVar5 = sub_080020F4();
      uVar11 = *(undefined4 *)dVar1;
      iVar6 = sub_080020F4();
      sVar4 = sub_0801ED8C(uVar11,iVar6 * 0x14c + dVar2);
      psVar7 = (short *)(iVar5 * 0x14c + dVar2 + 0x88);
      *psVar7 = sVar4 * 2 + *psVar7;
      iVar5 = sub_080020F4();
      puVar9 = *(ushort **)dVar1;
      iVar6 = *(int *)(puVar9 + 0x28);
      *(int *)((uint)*puVar9 * 4 + iVar5 * 0x14c + dVar2 + 0xe4) = iVar6;
      *(int *)(puVar9 + 0x28) = iVar6 + 1;
      uStack_24 = 1;
      iVar5 = sub_080020F4();
      iVar8 = *(int *)(iVar5 * 0x14c + iVar8);
      iVar5 = *(int *)(*(int *)dVar1 + 0x14);
      iVar6 = sub_080020F4();
      iVar5 = ArcTan2((iVar8 - iVar5) * 0x100 >> 0x10,
                      (*(int *)(iVar6 * 0x14c + DWORD_080ac784) - *(int *)(*(int *)dVar1 + 0x18)) *
                      0x100 >> 0x10);
      uVar12 = (uint)(iVar5 << 0x10) >> 0x1d;
      if (0x80000000 < (uint)(iVar5 * 0x80000)) {
        if (uVar12 < 7) {
          uVar12 = uVar12 + 1;
        }
        else {
          uVar12 = 0;
        }
      }
      if (uVar12 == 0) {
        iVar5 = sub_080020F4();
        psVar7 = (short *)(iVar5 * 0x14c + DWORD_080ac7c4 + 0xca);
        sVar4 = 6;
      }
      else if (uVar12 == 1) {
        iVar5 = sub_080020F4();
        psVar7 = (short *)(iVar5 * 0x14c + DWORD_080ac818 + 0xca);
        sVar4 = 7;
      }
      else {
        iVar5 = sub_080020F4();
        sVar4 = (short)uVar12 + -2;
        psVar7 = (short *)(iVar5 * 0x14c + DWORD_080ac7ac + 0xca);
      }
      *psVar7 = sVar4;
      iVar5 = sub_080020F4();
      dVar1 = DWORD_080ac818;
      *(undefined2 *)(iVar5 * 0x14c + DWORD_080ac818 + 0xcc) = 0x400;
      iVar5 = sub_080020F4();
      *(undefined2 *)(iVar5 * 0x14c + dVar1 + 200) = 0x16;
      sub_0805865C(0xbb);
    }
  }
  return CONCAT44(in_lr,uStack_24);
}


