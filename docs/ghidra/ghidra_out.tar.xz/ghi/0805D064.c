
undefined8 sub_0805D064(short *param_1,int param_2)

{
  short sVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 in_lr;
  
  sVar1 = *param_1;
  if (sVar1 == 2) {
    iVar2 = *(int *)DWORD_0805d090 + param_2 * 0x10;
    uVar3 = *(undefined4 *)(param_1 + 2);
    uVar4 = *(undefined4 *)(param_1 + 4);
    *(undefined4 *)(iVar2 + 0x70) = *(undefined4 *)param_1;
    *(undefined4 *)(iVar2 + 0x74) = uVar3;
    *(undefined4 *)(iVar2 + 0x78) = uVar4;
    *(undefined4 *)(iVar2 + 0x7c) = *(undefined4 *)(param_1 + 6);
  }
  return CONCAT44(in_lr,(uint)(sVar1 == 2));
}


