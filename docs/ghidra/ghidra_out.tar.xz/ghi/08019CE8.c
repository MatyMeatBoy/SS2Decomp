
undefined8 sub_08019CE8(int param_1)

{
  undefined4 uVar1;
  short *psVar2;
  undefined4 in_lr;
  
  psVar2 = (short *)(param_1 + 0x5c);
  *psVar2 = *psVar2 - ((ushort)DWORD_08019d28 & *(ushort *)(param_1 + 0x4a));
  *(ushort *)(param_1 + 0x4a) = 0;
  if ((((int)*psVar2 & 0x8000U) == 0) && (*psVar2 != 0)) {
    uVar1 = 0;
  }
  else {
    *(undefined2 *)(param_1 + 0xc) = 0xb;
    *psVar2 = 0;
    uVar1 = 1;
  }
  return CONCAT44(in_lr,uVar1);
}


