
undefined4 sub_0807854C(int param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint *puVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  undefined4 in_lr;
  
  uVar7 = 0;
  puVar4 = (uint *)((param_1 + 4) * 4 + DWORD_080785e8);
  uVar1 = *puVar4 & 1;
  while( true ) {
    if (uVar1 == 0) {
      if (uVar7 < 0x10) {
        iVar2 = (param_1 + 4) * 4;
        piVar6 = (int *)(DWORD_080785ec + iVar2);
        *(undefined4 *)(uVar7 * 0x28 + *piVar6 + 8) = 0x34;
        iVar3 = sub_08001494(0x400);
        iVar5 = uVar7 * 0x28 + *piVar6;
        *(int *)(iVar5 + 0x20) = iVar3;
        if (iVar3 != 0) {
          *(dword *)(iVar5 + 0xc) = DWORD_080785f0;
          *(int *)(iVar5 + 0x10) = iVar3 + 0x3fc;
          *(undefined4 *)(iVar5 + 0x24) = 0;
          sub_08000274(iVar5,param_1,param_2 << 0x10 | uVar7);
          puVar4 = (uint *)(DWORD_080785e8 + iVar2);
          *puVar4 = *puVar4 | 1 << (uVar7 & 0xff);
        }
      }
      return in_lr;
    }
    uVar7 = uVar7 + 1;
    if (0xf < uVar7) break;
    uVar1 = *puVar4 & 1 << (uVar7 & 0xff);
  }
  return in_lr;
}


