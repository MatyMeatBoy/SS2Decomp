
undefined4 sub_08007434(uint param_1,uint param_2,int param_3,int param_4,int param_5)

{
  ushort uVar1;
  byte bVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  undefined4 in_lr;
  
  iVar3 = (param_1 & 0xffff) * 0xc + param_3 + *(int *)(param_3 + 8);
  if ((param_2 & 0xffff) < (uint)*(ushort *)(iVar3 + 4)) {
    iVar6 = *(int *)(param_3 + 4) + param_3 +
            (uint)*(ushort *)(*(int *)(iVar3 + 8) + iVar3 + (param_2 & 0xffff) * 4) * 0xc;
    iVar3 = *(int *)(iVar6 + 8) + iVar6;
    uVar1 = *(ushort *)(iVar3 + 4);
    uVar7 = 0;
    if (*(short *)(iVar6 + 2) != 0) {
      do {
        iVar5 = param_5 + ((*(ushort *)(iVar3 + 4) & 0x3ff) - (uVar1 & 0x3ff)) * 0x20;
        iVar4 = param_4 + (((uint)*(ushort *)(iVar3 + 4) << 0x16) >> 0xc);
        bVar2 = *(byte *)(iVar3 + 1) >> 6;
        if (bVar2 == 1) {
          bVar2 = *(byte *)(iVar3 + 3) >> 6;
          if (bVar2 == 1) {
LAB_0800756c:
            sub_08001348(iVar4,iVar5,0x80);
          }
          else if (bVar2 < 2) {
            if (bVar2 == 0) goto LAB_0800762a;
          }
          else {
            if (bVar2 == 2) {
LAB_0800755e:
              sub_08001348(iVar4,iVar5,0x80);
              iVar4 = iVar4 + 0x400;
              iVar5 = iVar5 + 0x400;
              goto LAB_0800756c;
            }
            if (bVar2 == 4) {
LAB_08007578:
              sub_08001348(iVar4,iVar5,0x100);
              sub_08001348(iVar4 + 0x400,iVar5 + 0x400,0x100);
              sub_08001348(iVar4 + 0x800,iVar5 + 0x800,0x100);
              sub_08001348(iVar4 + 0xc00,iVar5 + 0xc00,0x100);
            }
          }
        }
        else if (bVar2 < 2) {
          if (bVar2 == 0) {
            bVar2 = *(byte *)(iVar3 + 3) >> 6;
            if (bVar2 == 1) {
LAB_0800761c:
              sub_08001348(iVar4,iVar5,0x40);
              iVar4 = iVar4 + 0x400;
              iVar5 = iVar5 + 0x400;
LAB_0800762a:
              sub_08001348(iVar4,iVar5,0x40);
            }
            else if (bVar2 < 2) {
              if (bVar2 == 0) goto LAB_080075f4;
            }
            else {
              if (bVar2 == 2) {
                sub_08001348(iVar4,iVar5,0x80);
                sub_08001348(iVar4 + 0x400,iVar5 + 0x400,0x80);
                iVar4 = iVar4 + 0x800;
                iVar5 = iVar5 + 0x800;
                goto LAB_0800755e;
              }
              if (bVar2 == 3) {
                sub_08001348(iVar4,iVar5,0x100);
                sub_08001348(iVar4 + 0x400,iVar5 + 0x400,0x100);
                sub_08001348(iVar4 + 0x800,iVar5 + 0x800,0x100);
                sub_08001348(iVar4 + 0xc00,iVar5 + 0xc00,0x100);
                iVar4 = iVar4 + 0x1000;
                iVar5 = iVar5 + 0x1000;
                goto LAB_08007578;
              }
            }
          }
        }
        else if (bVar2 == 2) {
          bVar2 = *(byte *)(iVar3 + 3) >> 6;
          if (bVar2 == 1) {
            sub_08001348(iVar4,iVar5,0x20);
            sub_08001348(iVar4 + 0x400,iVar5 + 0x400,0x20);
            iVar4 = iVar4 + 0x800;
            iVar5 = iVar5 + 0x800;
LAB_080075e6:
            sub_08001348(iVar4,iVar5,0x20);
            iVar4 = iVar4 + 0x400;
            iVar5 = iVar5 + 0x400;
LAB_080075f4:
            sub_08001348(iVar4,iVar5,0x20);
          }
          else if (bVar2 < 2) {
            if (bVar2 == 0) goto LAB_080075e6;
          }
          else {
            if (bVar2 == 2) {
              sub_08001348(iVar4,iVar5,0x40);
              sub_08001348(iVar4 + 0x400,iVar5 + 0x400,0x40);
              iVar4 = iVar4 + 0x800;
              iVar5 = iVar5 + 0x800;
              goto LAB_0800761c;
            }
            if (bVar2 == 4) {
              sub_08001348(iVar4,iVar5,0x80);
              sub_08001348(iVar4 + 0x400,iVar5 + 0x400,0x80);
              sub_08001348(iVar4 + 0x800,iVar5 + 0x800,0x80);
              sub_08001348(iVar4 + 0xc00,iVar5 + 0xc00,0x80);
              sub_08001348(iVar4 + 0x1000,iVar5 + 0x1000,0x80);
              sub_08001348(iVar4 + 0x1400,iVar5 + 0x1400,0x80);
              sub_08001348(iVar4 + 0x1800,iVar5 + 0x1800,0x80);
              sub_08001348(iVar4 + 0x1c00,iVar5 + 0x1c00,0x80);
            }
          }
        }
        uVar7 = uVar7 + 1;
        iVar3 = iVar3 + 8;
      } while (uVar7 < *(ushort *)(iVar6 + 2));
    }
  }
  return in_lr;
}


