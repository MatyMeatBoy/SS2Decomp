
undefined4 sub_0808528C(void)

{
  undefined4 in_lr;
  
  *(undefined2 *)DWORD_080852a4 = 4;
  sub_08001108(0x9f);
  sub_0800115C(DWORD_080852a8);
  return in_lr;
}


