
undefined4 sub_0802133C(uint param_1,uint param_2)

{
  undefined1 uVar1;
  short sVar2;
  int iVar3;
  ushort *puVar4;
  uint uVar5;
  short sVar6;
  undefined4 in_lr;
  undefined4 auStack_64 [2];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined1 uStack_48;
  undefined1 uStack_47;
  undefined2 uStack_30;
  undefined2 uStack_2e;
  short sStack_2c;
  short sStack_2a;
  uint uStack_28;
  uint uStack_24;
  
  uStack_28 = param_2;
  sub_08065158(auStack_64,DWORD_080213a4,1,0xffffffff,0);
  uStack_48 = 7;
  uStack_47 = 8;
  sub_08000AF0(0x17,uStack_58,2);
  uStack_30 = 0;
  uStack_2e = 0;
  sVar2 = 0;
  if (param_1 < 4) {
    puVar4 = *(ushort **)(param_1 * 0x14c + DWORD_080213a8 + 0x148);
    uStack_24 = (uint)(*puVar4 >> 4);
    uVar5 = puVar4[1] & 0xfff;
  }
  else {
    iVar3 = param_1 * 0x2e0 + *(int *)DWORD_080213d8 + DWORD_080213dc;
    uStack_24 = *(int *)(iVar3 + 0x14) >> 8;
    uVar5 = *(int *)(iVar3 + 0x18) >> 8;
  }
  sVar6 = (short)uStack_24;
  while ((iVar3 = sub_0800CB78(), iVar3 == 0 && (sVar2 == 0))) {
    sVar2 = sub_08065370(auStack_64,0x22,&uStack_30,&uStack_2e,0);
    iVar3 = sub_0800CC98();
    if ((iVar3 == 0) &&
       ((iVar3 = sub_0800CD8C(), iVar3 == 0 && (iVar3 = sub_0800CCCC(), iVar3 == 0)))) {
      sub_0800BC08((int)sVar6,(int)(short)uVar5,&sStack_2c,&sStack_2a,0x10,0);
      uVar1 = sub_0800BC44(uStack_24,uVar5,0);
      sub_08007870((int)sStack_2c,sStack_2a + 1,0x22,uStack_30,uVar1,&uStack_48,uStack_5c,
                   auStack_64[0]);
    }
    sub_080003F0();
  }
  *(uint *)DWORD_0802148c = *(uint *)DWORD_0802148c & ~(1 << (uStack_28 & 0xff));
  return in_lr;
}


