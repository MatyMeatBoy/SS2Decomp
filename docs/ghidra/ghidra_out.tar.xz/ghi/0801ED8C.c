
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 sub_0801ED8C(int param_1,int param_2)

{
  ushort uVar1;
  undefined2 uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  short sVar8;
  int iVar9;
  undefined4 in_lr;
  
  iVar3 = sub_08007290(*(ushort *)(param_1 + 0x22c) | 0xb0000);
  uVar1 = *(ushort *)(param_2 + 0x5a);
  uVar4 = sub_080008C8();
  if (*(short *)(param_1 + 0x1d0) + 1 < (int)(uVar4 & 0x7f)) {
    iVar9 = 200;
  }
  else {
    sub_0802247C(*(undefined4 *)(param_2 + 0x8c),*(undefined4 *)(param_2 + 0x90));
    iVar9 = 100;
  }
  uVar4 = (uint)*(ushort *)(param_1 + 0x1cc);
  uVar2 = sub_080008C8();
  iVar5 = __umodsi3(uVar2,0x32);
  iVar6 = __divsi3(uVar4 * uVar4 * 10,uVar4 + uVar1);
  uVar2 = __divsi3((iVar5 * 0x10000 + 0x640000U >> 0x10) * iVar6,iVar9);
  uVar4 = __udivsi3(uVar2,10);
  uVar4 = uVar4 & 0xffff;
  if (uVar4 == 0) {
    uVar4 = 1;
  }
  switch(*(undefined2 *)(iVar3 + 0xbc)) {
  case 1:
    sVar8 = *(short *)(param_2 + 0x7c);
    break;
  case 2:
    sVar8 = *(short *)(param_2 + 0x7e);
    break;
  case 3:
    sVar8 = *(short *)(param_2 + 0x80);
    break;
  case 4:
    sVar8 = *(short *)(param_2 + 0x82);
    break;
  case 5:
    sVar8 = *(short *)(param_2 + 0x84);
    break;
  case 6:
  case 7:
    sVar8 = *(short *)(param_2 + 0x86);
    break;
  default:
    goto LAB_0801eeb0;
  }
  uVar7 = __divsi3(uVar4 * _UNK_0801eed4,(int)sVar8 * (int)sVar8 + _UNK_0801eed8);
  uVar4 = uVar7 & 0xffff;
  if ((uVar7 & 0x8000) != 0) {
    uVar4 = 1;
  }
LAB_0801eeb0:
  if ((int)(uVar4 * 0x10000) < 1) {
    uVar4 = 1;
  }
  iVar3 = sub_0800CDC0();
  if (iVar3 == 0) {
    if (iVar9 == 100) {
      uVar4 = uVar4 | 0x8000;
    }
  }
  else if (iVar9 == 100) {
    sub_0805865C(0x27);
  }
  else if (*(short *)(param_2 + 0xc) == 8) {
    sub_0805865C(0x4b);
  }
  else {
    sub_0805865C(*(ushort *)(param_2 + 0xc) + 0x45);
  }
  return CONCAT44(in_lr,uVar4);
}


