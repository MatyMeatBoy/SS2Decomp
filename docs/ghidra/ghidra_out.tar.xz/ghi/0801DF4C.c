
undefined4 sub_0801DF4C(uint param_1)

{
  int iVar1;
  uint uVar2;
  undefined4 in_lr;
  
  uVar2 = 0;
  if (*(ushort *)(*(int *)DWORD_0801df7c + 2) != param_1) {
    iVar1 = 0;
    do {
      iVar1 = iVar1 + 0x2e0;
      uVar2 = uVar2 + 1;
      if (4 < uVar2) {
        return in_lr;
      }
    } while (*(ushort *)(*(int *)DWORD_0801df7c + iVar1 + 2) != param_1);
  }
  return in_lr;
}


