
undefined4 sub_08060DB0(int param_1)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 in_lr;
  
  if (param_1 == 0) {
    *(undefined4 *)(DWORD_08060de4 + 8) = 0x65;
    iVar3 = 0;
  }
  else {
    iVar3 = param_1 * 4;
    *(undefined4 *)(param_1 * 0x28 + DWORD_08060dcc + 8) = 0x3c;
  }
  piVar4 = (int *)((iVar3 + param_1) * 8 + DWORD_08060de8);
  while( true ) {
    iVar2 = sub_08001494(0x200);
    *piVar4 = iVar2;
    dVar1 = DWORD_08060e3c;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  iVar3 = (iVar3 + param_1) * 8;
  *(dword *)(iVar3 + DWORD_08060e3c + 0xc) = DWORD_08060e40;
  *(int *)(iVar3 + dVar1 + 0x10) = *(int *)(iVar3 + dVar1 + 0x20) + 0x1fc;
  *(undefined4 *)(iVar3 + dVar1 + 0x24) = 0;
  sub_08000274(iVar3 + dVar1,param_1);
  return in_lr;
}


