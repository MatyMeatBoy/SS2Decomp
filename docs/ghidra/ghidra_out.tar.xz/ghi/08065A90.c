
undefined4 sub_08065A90(undefined4 param_1,undefined4 param_2)

{
  dword dVar1;
  dword dVar2;
  int iVar3;
  undefined4 in_lr;
  
  dVar1 = DWORD_08065aa8;
  iVar3 = sub_08000470(DWORD_08065aa8);
  if (iVar3 == 0) {
    *(undefined4 *)(dVar1 + 8) = 0x3c;
    while( true ) {
      iVar3 = sub_08001638(0x200);
      *(int *)(dVar1 + 0x20) = iVar3;
      dVar2 = DWORD_08065ae0;
      if (iVar3 != 0) break;
      sub_080003F0();
    }
    *(dword *)(DWORD_08065ae0 + 0xc) = DWORD_08065ae4;
    *(int *)(dVar2 + 0x10) = *(int *)(dVar2 + 0x20) + 0x1fc;
    *(undefined4 *)(dVar2 + 0x24) = 0;
    sub_08000274(dVar2,param_1,param_2);
  }
  return in_lr;
}


