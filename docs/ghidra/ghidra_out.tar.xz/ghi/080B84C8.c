
void ply_xtype(undefined4 param_1,int param_2)

{
  *(undefined1 *)(param_2 + 0x24) = **(undefined1 **)(param_2 + 0x40);
  *(int *)(param_2 + 0x40) = *(int *)(param_2 + 0x40) + 1;
  return;
}


