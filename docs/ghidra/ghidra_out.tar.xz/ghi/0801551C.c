
undefined4 sub_0801551C(void)

{
  short sVar1;
  int iVar2;
  int iVar3;
  dword *pdVar4;
  dword dVar5;
  int iVar6;
  undefined4 in_lr;
  
  iVar2 = sub_080020F4();
  dVar5 = DWORD_0801556c;
  iVar6 = iVar2 * 0x28;
  iVar3 = sub_08000470(iVar6 + DWORD_0801556c);
  if (iVar3 == 0) {
    iVar3 = iVar2 * 0x14c + DWORD_08015598;
    sVar1 = *(short *)(iVar3 + 0x10);
    if (sVar1 == 4) {
      pdVar4 = (dword *)(iVar6 + dVar5 + 0xc);
      dVar5 = DWORD_080155d0;
    }
    else {
      if (sVar1 != 5) {
        return in_lr;
      }
      if (*(short *)(iVar3 + 0xc) == 4) {
        pdVar4 = (dword *)(iVar6 + dVar5 + 0xc);
        dVar5 = DWORD_080155ac;
      }
      else {
        pdVar4 = (dword *)(iVar6 + dVar5 + 0xc);
        dVar5 = DWORD_0801559c;
      }
    }
    *pdVar4 = dVar5;
    *(undefined4 *)(iVar2 * 0x28 + DWORD_080155d4 + 8) = 0x34;
    while( true ) {
      iVar3 = sub_08001494(0x400);
      dVar5 = DWORD_0801561c;
      iVar6 = iVar2 * 0x28;
      *(int *)(iVar6 + DWORD_0801561c + 0x20) = iVar3;
      if (iVar3 != 0) break;
      sub_080003F0();
    }
    *(int *)(iVar6 + dVar5 + 0x10) = iVar3 + 0x3fc;
    *(undefined4 *)(iVar6 + dVar5 + 0x24) = 0;
    sub_08000274(iVar6 + dVar5);
  }
  else {
    iVar3 = sub_080020F4();
    if (iVar3 == iVar2) {
      iVar3 = iVar2 * 0x14c + DWORD_08015570;
      if ((1 < (ushort)(*(short *)(iVar3 + 0x20) - 10U)) &&
         ((*(uint *)(iVar2 * 0x14c + DWORD_08015570 + 0x30) & 0x2000) == 0)) {
        *(undefined2 *)(iVar3 + 0x20) = 0;
      }
    }
  }
  return in_lr;
}


