
undefined4 sub_080A7F30(void)

{
  dword dVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined4 in_lr;
  
  dVar1 = DWORD_080a7f58;
  uVar2 = sub_08001494(0x50);
  *(undefined4 *)dVar1 = uVar2;
  iVar4 = 0;
  iVar3 = 1;
  do {
    *(undefined4 *)(iVar4 + *(int *)dVar1 + 8) = 0;
    iVar4 = iVar4 + 0x28;
    iVar3 = iVar3 + -1;
  } while (-1 < iVar3);
  return in_lr;
}


