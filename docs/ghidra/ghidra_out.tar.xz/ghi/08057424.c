
void sub_08057424(void)

{
  sub_08000470();
  return;
}


