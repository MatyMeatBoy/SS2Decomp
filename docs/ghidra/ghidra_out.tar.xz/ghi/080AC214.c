
undefined4 sub_080AC214(char param_1)

{
  dword dVar1;
  ushort uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 in_lr;
  
  dVar1 = DWORD_080ac2e0;
  if (param_1 == '\0') {
    iVar3 = sub_080020F4();
    if (*(short *)(iVar3 * 0x14c + dVar1 + 0x20) != 0xb) {
      iVar3 = sub_080020F4();
      if (*(short *)(iVar3 * 0x14c + dVar1 + 0x20) != 0xe) {
        iVar3 = sub_080020F4();
        if (*(short *)(iVar3 * 0x14c + dVar1 + 0x20) != 0xc) {
          iVar3 = sub_080020F4();
          if ((*(uint *)(iVar3 * 0x14c + dVar1 + 0x30) & 0x2000) == 0) {
            iVar3 = sub_080020F4();
            if (*(char *)(iVar3 * 0x14c + dVar1 + 0x68) != '\0') {
              iVar3 = sub_080020F4();
              iVar4 = sub_080020F4();
              iVar5 = *(int *)(iVar4 * 0x14c + dVar1 + 0x8c);
              iVar4 = sub_080020F4();
              uVar2 = sub_08095FC8(iVar5 >> 8,*(int *)(iVar4 * 0x14c + dVar1 + 0x90) >> 8,
                                   *(int *)(*(int *)DWORD_080ac2e4 + 0x14) >> 8,
                                   *(int *)(*(int *)DWORD_080ac2e4 + 0x18) >> 8);
              *(ushort *)(iVar3 * 0x14c + dVar1 + 0xca) = uVar2 & 0xff;
              iVar3 = sub_080020F4();
              *(undefined2 *)(iVar3 * 0x14c + dVar1 + 0xcc) = 0x200;
              iVar3 = sub_080020F4();
              *(undefined2 *)(iVar3 * 0x14c + dVar1 + 200) = 1;
            }
          }
        }
      }
    }
  }
  return in_lr;
}


