
undefined8 sub_08067CE8(undefined4 param_1)

{
  dword dVar1;
  undefined1 *puVar2;
  uint uVar3;
  undefined4 in_lr;
  
  dVar1 = DWORD_08067d18;
  uVar3 = *(uint *)DWORD_08067d18;
  if (uVar3 < 0x32) {
    puVar2 = (undefined1 *)(*(int *)DWORD_08067d1c + uVar3 * 0x88);
    *(undefined4 *)(puVar2 + 4) = 1;
    *puVar2 = 0xb0;
    *(undefined4 *)(puVar2 + 8) = param_1;
    puVar2[1] = 1;
    *(int *)dVar1 = *(int *)dVar1 + 1;
  }
  return CONCAT44(in_lr,(uint)(uVar3 < 0x32));
}


