
undefined8 sub_0808A008(int param_1)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  uint uVar6;
  ushort *puVar7;
  undefined4 in_lr;
  
  dVar1 = DWORD_0808a01c;
  if (*(short *)(*(int *)DWORD_0808a01c + 0x10) == 0) {
    while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
      sub_080003F0();
    }
    iVar2 = sub_080020F4();
    puVar7 = (ushort *)(param_1 + (uint)*(ushort *)(*(int *)DWORD_0808a088 + 0x36) * 0x24 + 4);
    sub_0800CCDC();
    iVar3 = sub_080020F4();
    dVar1 = DWORD_0808a08c;
    iVar3 = iVar3 * 0x14c;
    *(uint *)(iVar3 + DWORD_0808a08c + 0x8c) = (uint)*puVar7 << 8;
    *(uint *)(iVar3 + dVar1 + 0x90) = (uint)puVar7[1] << 8;
    iVar3 = iVar3 + dVar1;
    *(undefined4 *)(iVar3 + 0x94) = *(undefined4 *)(iVar3 + 0x8c);
    *(undefined4 *)(iVar3 + 0x98) = *(undefined4 *)(iVar3 + 0x90);
    sub_08009930(0,8);
    while (iVar3 = sub_0800BA6C(), iVar3 == 0) {
      sub_080003F0();
    }
    iVar2 = iVar2 * 0x14c + DWORD_0808a0f0;
    uVar4 = sub_0800CCCC();
    sub_0800AD04(iVar2,iVar2 + 4,uVar4);
    iVar2 = *(int *)DWORD_0808a0f4;
    *(undefined2 *)(iVar2 + 0x10) = 1;
    *(undefined2 *)(iVar2 + 0x1c) = 1;
    sub_08015C38();
    iVar2 = sub_0800CB9C();
    if ((iVar2 == 0) && (iVar2 = sub_08057AE8(0x1a), iVar2 == 0)) {
      sub_08058688(0xdb);
    }
    sub_08057328(0,DWORD_0808a0f8);
    sub_08015EF8();
    sub_08015C38();
  }
  else {
    iVar2 = sub_080020F4();
    iVar2 = iVar2 * 0x14c + DWORD_0808a158;
    uVar6 = 1;
    do {
      puVar7 = (ushort *)((uint)*(ushort *)(*(int *)dVar1 + 0x36) * 0x24 + 4 + param_1 + uVar6 * 8);
      iVar3 = (*(int *)(iVar2 + 0x8c) >> 0xb) - (uint)*puVar7;
      if (iVar3 < 0) {
        iVar3 = -iVar3;
      }
      if ((iVar3 < 2) && (*(int *)(iVar2 + 0x90) >> 0xb == (uint)puVar7[1])) {
        sub_08015ED4();
        sub_0801ABE8(3);
        sub_0800BB40();
        while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
          sub_080003F0();
        }
        sub_0800BB40();
        piVar5 = (int *)DWORD_0808a184;
        if ((puVar7[2] == 7) && (uVar6 != 2)) {
          if (uVar6 == 3) {
            *(undefined2 *)(*(int *)dVar1 + 0x36) = 1;
          }
        }
        else {
          *(undefined2 *)(*(int *)dVar1 + 0x36) = 0;
          piVar5 = (int *)DWORD_0808a1ac;
        }
        iVar2 = *piVar5;
        *(ushort *)(iVar2 + 2) = puVar7[2];
        *(undefined4 *)(iVar2 + DWORD_0808a1b0) =
             *(undefined4 *)((uint)puVar7[2] * 4 + DWORD_0808a1b4);
        *(undefined2 *)(iVar2 + 0x10) = 0;
        *(undefined2 *)(iVar2 + 0x1c) = 0;
        uVar4 = 1;
        goto LAB_0808a28a;
      }
      uVar6 = uVar6 + 1;
    } while (uVar6 < 4);
  }
  iVar2 = sub_080020F4();
  dVar1 = DWORD_0808a1e8;
  if (*(int *)(iVar2 * 0x14c + DWORD_0808a1e8 + 0x8c) >> 0xb < 0x1c) {
    iVar2 = sub_080020F4();
    if (*(int *)(iVar2 * 0x14c + dVar1 + 0x90) >> 0xb < 0x25) {
      uVar4 = 0;
    }
    else {
      sub_08015ED4();
      sub_0801ABE8(3);
      sub_0800BB40();
      while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
        sub_080003F0();
      }
      sub_0800BB40();
      iVar2 = *(int *)DWORD_0808a27c;
      *(undefined2 *)(iVar2 + 0x36) = 4;
      *(undefined2 *)(iVar2 + 2) = 0;
      *(undefined4 *)(iVar2 + DWORD_0808a280) = *(undefined4 *)DWORD_0808a284;
      *(undefined2 *)(iVar2 + 0x10) = 0;
      *(undefined2 *)(iVar2 + 0x1c) = 0;
      uVar4 = 1;
    }
  }
  else {
    sub_08015ED4();
    sub_0801ABE8(3);
    sub_0800BB40();
    while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
      sub_080003F0();
    }
    sub_0800BB40();
    iVar2 = *(int *)DWORD_0808a21c;
    *(undefined2 *)(iVar2 + 0x36) = 3;
    *(undefined2 *)(iVar2 + 2) = 1;
    *(undefined4 *)(iVar2 + DWORD_0808a220) = *(undefined4 *)(DWORD_0808a224 + 4);
    *(undefined2 *)(iVar2 + 0x10) = 0;
    *(undefined2 *)(iVar2 + 0x1c) = 0;
    uVar4 = 1;
  }
LAB_0808a28a:
  return CONCAT44(in_lr,uVar4);
}


