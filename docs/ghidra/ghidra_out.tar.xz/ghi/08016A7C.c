
undefined4 sub_08016A7C(int param_1)

{
  dword dVar1;
  dword dVar2;
  dword dVar3;
  ushort *puVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  undefined4 in_lr;
  
  dVar1 = DWORD_08016b20;
  iVar8 = *(int *)DWORD_08016b20;
  uVar9 = 0;
  uVar7 = 0;
  do {
    uVar5 = 1 << (uVar7 & 0xff);
    if (((*(uint *)DWORD_08016b24 & uVar5) != 0) && (*(int *)(iVar8 + 0x2c) == param_1)) {
      uVar9 = uVar9 | uVar5;
    }
    uVar7 = uVar7 + 1;
    iVar8 = iVar8 + 0x2e0;
  } while (uVar7 < 5);
  uVar7 = 0;
  iVar8 = 0;
  do {
    if ((1 << (uVar7 & 0xff) & uVar9) != 0) {
      puVar4 = (ushort *)(iVar8 + *(int *)dVar1 + 0x7a);
      *puVar4 = *puVar4 | 1;
    }
    dVar3 = DWORD_08016b2c;
    dVar2 = DWORD_08016b28;
    iVar8 = iVar8 + 0x2e0;
    uVar7 = uVar7 + 1;
  } while (uVar7 < 5);
  uVar7 = 0;
  do {
    if ((((int)(uint)*(ushort *)dVar2 >> (uVar7 & 0xff) & 1U) != 0) &&
       (piVar6 = (int *)(uVar7 * 8 + *(int *)dVar3), *piVar6 == param_1)) {
      *(undefined1 *)(piVar6 + 1) = 0xff;
    }
    uVar7 = uVar7 + 1;
  } while (uVar7 < 2);
  return in_lr;
}


