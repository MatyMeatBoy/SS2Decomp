
undefined4 sub_0804F390(void)

{
  short sVar1;
  dword dVar2;
  short sVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  undefined4 in_lr;
  int iStack_c0;
  int iStack_bc;
  int iStack_b8;
  int iStack_b4;
  int iStack_b0;
  int iStack_ac;
  int iStack_a8;
  int iStack_a4;
  int iStack_a0;
  int iStack_9c;
  int iStack_98;
  int iStack_94;
  int iStack_90;
  int iStack_8c;
  int iStack_88;
  int iStack_84;
  int iStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_74;
  dword dStack_70;
  int *piStack_6c;
  int *piStack_68;
  int *piStack_64;
  int *piStack_60;
  uint uStack_5c;
  int *piStack_58;
  int *piStack_54;
  int *piStack_50;
  int *piStack_4c;
  int *piStack_48;
  int *piStack_44;
  int *piStack_40;
  int *piStack_3c;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  
  sVar3 = *(short *)(DWORD_0804f460 + 0x80);
  sVar1 = *(short *)(DWORD_0804f460 + 0x82);
  uVar4 = 0;
  piStack_6c = &iStack_b8;
  piStack_68 = &iStack_b4;
  piStack_64 = &iStack_b0;
  piStack_60 = &iStack_ac;
  piStack_58 = &iStack_a8;
  piStack_54 = &iStack_a4;
  piStack_50 = &iStack_a0;
  piStack_4c = &iStack_9c;
  piStack_48 = &iStack_98;
  piStack_44 = &iStack_94;
  piStack_40 = &iStack_90;
  piStack_3c = &iStack_8c;
  piStack_38 = &iStack_88;
  piStack_34 = &iStack_84;
  piStack_30 = &iStack_80;
  piStack_2c = &iStack_7c;
  piStack_28 = &iStack_78;
  piStack_24 = &iStack_74;
  do {
    iVar6 = (int)(short)uVar4;
    sub_080659F4(&iStack_c0,(int)sVar3,0,iVar6);
    sub_080659F4(&iStack_bc,(int)sVar1,0xffffffff,iVar6);
    sub_0800BB94((int)(short)iStack_c0,(int)(short)iStack_bc);
    sub_08097D18(-iStack_c0,-iStack_bc);
    sub_080003F0();
    uVar4 = iVar6 + 0x200U & 0xffff;
  } while ((int)((iVar6 + 0x200U) * 0x10000) >> 0x10 < 0x401);
  sVar3 = 2;
  do {
    sub_080003F0();
    iVar6 = sub_080021A8();
    if (iVar6 != 0) break;
    sVar3 = sVar3 + -1;
  } while (sVar3 != 0);
  sVar3 = *(short *)(DWORD_0804f4ec + 0x80);
  sVar1 = *(short *)(DWORD_0804f4ec + 0x82);
  uVar4 = 0;
  do {
    iVar6 = (int)(short)uVar4;
    sub_080659F4(piStack_6c,(int)sVar3,0,iVar6);
    sub_080659F4(piStack_68,(int)sVar1,0,iVar6);
    sub_0800BB94((int)(short)iStack_b8,(int)(short)iStack_b4);
    sub_08097D18(-iStack_b8,-iStack_b4);
    sub_080003F0();
    uVar4 = iVar6 + 0x200U & 0xffff;
  } while ((int)((iVar6 + 0x200U) * 0x10000) >> 0x10 < 0x401);
  sVar3 = 2;
  do {
    sub_080003F0();
    iVar6 = sub_080021A8();
    dVar2 = DWORD_0804f57c;
    if (iVar6 != 0) break;
    sVar3 = sVar3 + -1;
  } while (sVar3 != 0);
  sVar3 = *(short *)(DWORD_0804f578 + 0x80);
  sVar1 = *(short *)(DWORD_0804f578 + 0x82);
  uVar4 = 0;
  do {
    iVar6 = (int)(short)uVar4;
    sub_080659F4(piStack_64,(int)sVar3,0,iVar6);
    sub_080659F4(piStack_60,(int)sVar1,(int)dVar2 >> 0x10,iVar6);
    sub_0800BB94((int)(short)iStack_b0,(int)(short)iStack_ac);
    sub_08097D18(-iStack_b0,-iStack_ac);
    sub_080003F0();
    uVar4 = iVar6 + 0x200U & 0xffff;
  } while ((int)((iVar6 + 0x200U) * 0x10000) >> 0x10 < 0x401);
  sVar3 = 2;
  do {
    sub_080003F0();
    iVar6 = sub_080021A8();
    if (iVar6 != 0) break;
    sVar3 = sVar3 + -1;
  } while (sVar3 != 0);
  sVar3 = *(short *)(DWORD_0804f608 + 0x80);
  sVar1 = *(short *)(DWORD_0804f608 + 0x82);
  uVar4 = 0;
  do {
    iVar6 = (int)(short)uVar4;
    sub_080659F4(piStack_58,(int)sVar3,0,iVar6);
    sub_080659F4(piStack_54,(int)sVar1,0,iVar6);
    sub_0800BB94((int)(short)iStack_a8,(int)(short)iStack_a4);
    sub_08097D18(-iStack_a8,-iStack_a4);
    sub_080003F0();
    uVar4 = iVar6 + 0x200U & 0xffff;
  } while ((int)((iVar6 + 0x200U) * 0x10000) >> 0x10 < 0x401);
  sVar3 = 2;
  do {
    sub_080003F0();
    iVar6 = sub_080021A8();
    if (iVar6 != 0) break;
    sVar3 = sVar3 + -1;
  } while (sVar3 != 0);
  uVar4 = 1;
  dStack_70 = DWORD_0804f69c;
  do {
    sVar3 = *(short *)(dStack_70 + 0x80);
    sVar1 = *(short *)DWORD_0804f6a0;
    uVar5 = 0;
    uStack_5c = uVar4 + 1;
    do {
      iVar6 = (int)(short)uVar5;
      sub_080659F4(piStack_50,(int)sVar3,0,iVar6);
      sub_080659F4(piStack_4c,(int)sVar1,0xfffffffd,iVar6);
      sub_0800BB94((int)(short)iStack_a0,(int)(short)iStack_9c);
      sub_08097D18(-iStack_a0,-iStack_9c);
      sub_080003F0();
      uVar5 = iVar6 + 0x200U & 0xffff;
    } while ((int)((iVar6 + 0x200U) * 0x10000) >> 0x10 < 0x401);
    sVar3 = 2;
    do {
      sub_080003F0();
      iVar6 = sub_080021A8();
      if (iVar6 != 0) break;
      sVar3 = sVar3 + -1;
    } while (sVar3 != 0);
    sVar3 = *(short *)(dStack_70 + 0x80);
    sVar1 = *(short *)DWORD_0804f728;
    uVar4 = 0;
    do {
      iVar6 = (int)(short)uVar4;
      sub_080659F4(piStack_48,(int)sVar3,0,iVar6);
      sub_080659F4(piStack_44,(int)sVar1,0,iVar6);
      sub_0800BB94((int)(short)iStack_98,(int)(short)iStack_94);
      sub_08097D18(-iStack_98,-iStack_94);
      sub_080003F0();
      uVar4 = iVar6 + 0x200U & 0xffff;
    } while ((int)((iVar6 + 0x200U) * 0x10000) >> 0x10 < 0x401);
    sVar3 = 2;
    do {
      sub_080003F0();
      iVar6 = sub_080021A8();
      dVar2 = DWORD_0804f7c4;
      if (iVar6 != 0) break;
      sVar3 = sVar3 + -1;
    } while (sVar3 != 0);
    uVar4 = uStack_5c & 0xffff;
  } while (uVar4 < 0x3c);
  sVar3 = *(short *)(DWORD_0804f7c0 + 0x80);
  sVar1 = *(short *)(DWORD_0804f7c0 + 0x82);
  uVar4 = 0;
  do {
    iVar6 = (int)(short)uVar4;
    sub_080659F4(piStack_40,(int)sVar3,0,iVar6);
    sub_080659F4(piStack_3c,(int)sVar1,(int)dVar2 >> 0x10,iVar6);
    sub_0800BB94((int)(short)iStack_90,(int)(short)iStack_8c);
    sub_08097D18(-iStack_90,-iStack_8c);
    sub_080003F0();
    uVar4 = iVar6 + 0x200U & 0xffff;
  } while ((int)((iVar6 + 0x200U) * 0x10000) >> 0x10 < 0x401);
  sVar3 = 2;
  do {
    sub_080003F0();
    iVar6 = sub_080021A8();
    if (iVar6 != 0) break;
    sVar3 = sVar3 + -1;
  } while (sVar3 != 0);
  sVar3 = *(short *)(DWORD_0804f850 + 0x80);
  sVar1 = *(short *)(DWORD_0804f850 + 0x82);
  uVar4 = 0;
  do {
    iVar6 = (int)(short)uVar4;
    sub_080659F4(piStack_38,(int)sVar3,0,iVar6);
    sub_080659F4(piStack_34,(int)sVar1,0,iVar6);
    sub_0800BB94((int)(short)iStack_88,(int)(short)iStack_84);
    sub_08097D18(-iStack_88,-iStack_84);
    sub_080003F0();
    uVar4 = iVar6 + 0x200U & 0xffff;
  } while ((int)((iVar6 + 0x200U) * 0x10000) >> 0x10 < 0x401);
  sVar3 = 2;
  do {
    sub_080003F0();
    iVar6 = sub_080021A8();
    dVar2 = DWORD_0804f8e0;
    if (iVar6 != 0) break;
    sVar3 = sVar3 + -1;
  } while (sVar3 != 0);
  sVar3 = *(short *)(DWORD_0804f8dc + 0x80);
  sVar1 = *(short *)(DWORD_0804f8dc + 0x82);
  uVar4 = 0;
  do {
    iVar6 = (int)(short)uVar4;
    sub_080659F4(piStack_30,(int)sVar3,0,iVar6);
    sub_080659F4(piStack_2c,(int)sVar1,(int)dVar2 >> 0x10,iVar6);
    sub_0800BB94((int)(short)iStack_80,(int)(short)iStack_7c);
    sub_08097D18(-iStack_80,-iStack_7c);
    sub_080003F0();
    uVar4 = iVar6 + 0x200U & 0xffff;
  } while ((int)((iVar6 + 0x200U) * 0x10000) >> 0x10 < 0x401);
  sVar3 = 2;
  do {
    sub_080003F0();
    iVar6 = sub_080021A8();
    if (iVar6 != 0) break;
    sVar3 = sVar3 + -1;
  } while (sVar3 != 0);
  sVar3 = *(short *)(DWORD_0804f96c + 0x80);
  sVar1 = *(short *)(DWORD_0804f96c + 0x82);
  uVar4 = 0;
  do {
    iVar6 = (int)(short)uVar4;
    sub_080659F4(piStack_28,(int)sVar3,0,iVar6);
    sub_080659F4(piStack_24,(int)sVar1,0,iVar6);
    sub_0800BB94((int)(short)iStack_78,(int)(short)iStack_74);
    sub_08097D18(-iStack_78,-iStack_74);
    sub_080003F0();
    uVar4 = iVar6 + 0x200U & 0xffff;
  } while ((int)((iVar6 + 0x200U) * 0x10000) >> 0x10 < 0x401);
  sVar3 = 2;
  do {
    sub_080003F0();
    iVar6 = sub_080021A8();
    if (iVar6 != 0) {
      return in_lr;
    }
    sVar3 = sVar3 + -1;
  } while (sVar3 != 0);
  return in_lr;
}


