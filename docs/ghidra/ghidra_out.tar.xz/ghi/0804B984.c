
undefined4 sub_0804B984(void)

{
  short sVar1;
  short sVar2;
  dword dVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  int iVar7;
  byte *pbVar8;
  uint uVar9;
  undefined4 in_lr;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined2 uStack_3c;
  undefined2 uStack_3a;
  dword dStack_38;
  undefined4 uStack_34;
  undefined1 auStack_2c [4];
  undefined1 auStack_28 [4];
  uint uStack_24;
  
  iVar4 = sub_0800CE30();
  dVar3 = DWORD_0804bb30;
  if (iVar4 == 0) {
    pbVar8 = (byte *)(*(int *)DWORD_0804b9ec + 0x1b8);
    piVar5 = (int *)DWORD_0804b9ec;
  }
  else {
    pbVar8 = (byte *)(*(int *)DWORD_0804b9a8 + 0x1c4);
    piVar5 = (int *)DWORD_0804b9a8;
  }
  uVar9 = *(uint *)(*piVar5 + 0x38) & 2;
  if (uVar9 != 0) {
    uVar9 = 1;
  }
  uStack_24 = *(uint *)(*piVar5 + 0x38) & 1;
  if (uStack_24 != 0) {
    uStack_24 = 1;
  }
  if (((int)(uint)*pbVar8 >> 6 & 1U) == 0) {
    if (uVar9 == 0) {
      sVar1 = *(short *)(DWORD_0804bb2c + 0x80);
      sVar2 = *(short *)(DWORD_0804bb2c + 0x82);
      iVar4 = 0;
      do {
        sub_080659F4(auStack_2c,(int)sVar1,0,iVar4);
        sub_080659F4(auStack_28,(int)sVar2,(int)dVar3 >> 0x10,iVar4);
        sub_0800BB80((int)auStack_2c._0_2_,(int)auStack_28._0_2_);
        sub_080003F0();
        iVar4 = iVar4 + 0x400;
      } while (iVar4 < 0x401);
      uVar6 = sub_080289C0(0x13,0xa0,0x85);
      sub_08028AAC(6,0xb8,0xca,0);
      if (uStack_24 == 0) {
        iVar4 = sub_0800CE30();
        if (iVar4 == 0) {
          uStack_44 = 0x910003;
          uVar9 = 0;
          do {
            *(undefined1 *)((int)&uStack_40 + uVar9) = 0;
            uVar9 = uVar9 + 1;
          } while (uVar9 < 0xc);
          while (iVar4 = sub_08067B9C(0x2100,0x6f00,&uStack_44), iVar4 == 0) {
            sub_080003F0();
          }
        }
        else {
          uStack_44 = 0x230003;
          uVar9 = 0;
          do {
            *(undefined1 *)((int)&uStack_40 + uVar9) = 0;
            uVar9 = uVar9 + 1;
          } while (uVar9 < 0xc);
          while (iVar4 = sub_08067B9C(0x2100,0x6f00,&uStack_44), iVar4 == 0) {
            sub_080003F0();
          }
        }
        *(uint *)(*(int *)DWORD_0804bb98 + 0x38) = *(uint *)(*(int *)DWORD_0804bb98 + 0x38) | 1;
      }
      dVar3 = DWORD_0804bb9c;
      iVar4 = *(int *)DWORD_0804bb98 + DWORD_0804bba0;
      for (uVar9 = 0; uVar9 < 0x1e; uVar9 = uVar9 + 1) {
        iVar7 = sub_08000470(iVar4);
        if (iVar7 == 0) goto LAB_0804bbbc;
        iVar4 = iVar4 + 0x28;
      }
    }
    else {
      uVar6 = sub_080289C0(0x13,0xb8,0xbb);
      sub_08028AAC(6,0xb8,0xca,0);
      dVar3 = DWORD_0804ba20;
      iVar4 = *piVar5 + DWORD_0804ba24;
      for (uVar9 = 0; uVar9 < 0x1e; uVar9 = uVar9 + 1) {
        iVar7 = sub_08000470(iVar4);
        if (iVar7 == 0) {
          uStack_44 = 0xb700;
          uStack_40 = 0xd200;
          uStack_3c = 0x14;
          uStack_3a = 5;
          dStack_38 = dVar3;
          *(undefined4 *)(iVar4 + 8) = 0x3c;
          uStack_34 = uVar6;
          iVar7 = sub_08001494(0x400);
          *(int *)(iVar4 + 0x20) = iVar7;
          *(dword *)(iVar4 + 0xc) = DWORD_0804ba8c;
          *(int *)(iVar4 + 0x10) = iVar7 + 0x3fc;
          *(undefined4 *)(iVar4 + 0x24) = 0;
          sub_08000274(iVar4,&uStack_44,1);
          sub_080003F0();
          sub_080003F0();
          break;
        }
        iVar4 = iVar4 + 0x28;
      }
    }
  }
  else {
    sub_08028AAC(6,DWORD_0804b9f0,DWORD_0804b9f0,0);
  }
LAB_0804bbe6:
  iVar4 = sub_0800CC98();
  if (iVar4 == 0) {
    iVar4 = sub_0801AB24();
    if (iVar4 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar4 < 2) {
      if (iVar4 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar4 == 2) {
      sub_0801AB90(6);
    }
    while (iVar4 = sub_0801AAE0(), iVar4 == 0) {
      sub_080003F0();
    }
  }
  return in_lr;
LAB_0804bbbc:
  while( true ) {
    iVar7 = sub_08001494(0x400);
    *(int *)(iVar4 + 0x20) = iVar7;
    if (iVar7 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar4 + 8) = 0x3c;
  *(dword *)(iVar4 + 0xc) = dVar3;
  *(int *)(iVar4 + 0x10) = iVar7 + 0x3fc;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  sub_08000274(iVar4,uVar6);
  goto LAB_0804bbe6;
}


