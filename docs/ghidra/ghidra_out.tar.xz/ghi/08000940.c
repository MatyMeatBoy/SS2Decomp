
undefined4 sub_08000940(void)

{
  dword dVar1;
  undefined4 in_lr;
  
  sub_08001040(8);
  dVar1 = DWORD_08000964;
  *(byte *)DWORD_08000964 = *(byte *)DWORD_08000964 & 0x7f;
  Ram04000000 = *(undefined2 *)dVar1;
  sub_08006BF8();
  return in_lr;
}


