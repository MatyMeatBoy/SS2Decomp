
undefined4 sub_08067ACC(void)

{
  return 1;
}


