
void sub_080B6A44(void)

{
  int iVar1;
  int in_r3;
  code *UNRECOVERED_JUMPTABLE;
  
  iVar1 = sub_080B69AC();
  *(short *)(iVar1 + 0x1c) = (short)(in_r3 * 2);
  *(short *)(iVar1 + 0x20) = (short)((uint)*(ushort *)(iVar1 + 0x1e) * in_r3 * 2 >> 8);
                    /* WARNING: Could not recover jumptable at 0x080b6a56. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)();
  return;
}


