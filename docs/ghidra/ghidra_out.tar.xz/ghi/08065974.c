
undefined8 sub_08065974(void)

{
  uint uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 in_lr;
  
  uVar1 = sub_08002164();
  uVar3 = 0;
  if (uVar1 != 0) {
    puVar4 = (undefined4 *)(DWORD_0806599c + 0x148);
    do {
      if ((*(byte *)*puVar4 & 0xf) == 0xe) {
        uVar2 = 1;
        goto LAB_080659aa;
      }
      puVar4 = puVar4 + 0x53;
      uVar3 = uVar3 + 1;
    } while (uVar3 < uVar1);
  }
  uVar2 = 0;
LAB_080659aa:
  return CONCAT44(in_lr,uVar2);
}


