
void sub_0800207C(void)

{
  *(undefined4 *)DWORD_08002088 = 0x80000000;
  return;
}


