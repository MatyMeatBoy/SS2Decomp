
void sub_080B6AD8(void)

{
  byte *extraout_r1;
  byte in_r3;
  code *UNRECOVERED_JUMPTABLE;
  
  sub_080B69AC();
  extraout_r1[0xf] = in_r3;
  *extraout_r1 = *extraout_r1 | 0xc;
                    /* WARNING: Could not recover jumptable at 0x080b6ae8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)();
  return;
}


