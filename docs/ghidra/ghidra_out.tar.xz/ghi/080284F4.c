
undefined4 sub_080284F4(undefined4 *param_1)

{
  ushort uVar1;
  dword dVar2;
  undefined1 uVar3;
  undefined2 uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  short *psVar8;
  int iVar9;
  ushort *puVar10;
  undefined4 in_lr;
  undefined4 auStack_a8 [2];
  undefined4 uStack_a0;
  int iStack_9c;
  undefined1 auStack_8c [24];
  undefined1 auStack_74 [52];
  short sStack_40;
  short sStack_3e;
  undefined2 uStack_3c;
  undefined2 uStack_3a;
  int iStack_38;
  int iStack_34;
  uint uStack_30;
  int iStack_2c;
  undefined1 *puStack_28;
  undefined1 *puStack_24;
  
  param_1[0xf] = 2;
  param_1[0x11] = 0;
  *(undefined2 *)((int)param_1 + 0x36) = 0;
  *(undefined2 *)(param_1 + 0xe) = 0;
  *(undefined2 *)((int)param_1 + 0x2e) = 0;
  *(undefined2 *)(param_1 + 0xc) = 0;
  uVar4 = (undefined2)((uint)param_1[1] >> 0x10);
  *(undefined2 *)(param_1 + 9) = uVar4;
  *(undefined2 *)(param_1 + 0xb) = uVar4;
  *(undefined2 *)(param_1 + 0xd) = 1;
  dVar2 = DWORD_080285a0;
  param_1[1] = param_1[1] & DWORD_080285a0;
  *(undefined2 *)(param_1 + 10) = 0;
  *(undefined2 *)((int)param_1 + 0x26) = 0;
  *(undefined2 *)((int)param_1 + 0x42) = 0;
  uStack_30 = (uStack_30 & DWORD_080285a4 | 0x10) & dVar2 | 0x100000;
  iVar5 = sub_080020F4();
  dVar2 = DWORD_080285ac;
  iVar5 = iVar5 * 0x14c + DWORD_080285a8;
  iStack_2c = 0;
  uStack_3a = 0;
  uStack_3c = 0;
  sub_08065158(auStack_a8,*(undefined4 *)(param_1[1] * 8 + DWORD_080285ac),4,0xffffffff,0);
  if (*(int *)(param_1[1] * 8 + dVar2 + 4) == 3) {
    *(undefined2 *)(param_1 + 0x10) = (undefined2)iStack_2c;
    puStack_28 = auStack_8c;
    puStack_24 = auStack_74;
  }
  else {
    puStack_28 = auStack_8c;
    puStack_24 = auStack_74;
    while( true ) {
      iVar6 = sub_080283C4(100,*(undefined2 *)(param_1[1] * 8 + DWORD_080285d4 + 4));
      *(short *)(param_1 + 0x10) = (short)iVar6;
      if (iVar6 * 0x10000 - DWORD_080285d8 != 0) break;
      sub_080003F0();
    }
  }
  puVar10 = (ushort *)(param_1 + 0x10);
  puStack_28[*(int *)(param_1[1] * 8 + DWORD_08028620 + 4)] = (char)*puVar10;
  sub_08065158(puStack_24,DWORD_08028624,*puVar10,0xffffffff,0);
  while (*(short *)((int)param_1 + 0x36) != 4) {
    if (((((*(uint *)(iVar5 + 0x30) & 0x2000) == 0) && ((*(ushort *)(iVar5 + 0x14) & 1) != 0)) &&
        ((*(ushort *)(*(int *)DWORD_080287e4 + 4) >> 7 & 1) == 0)) && (param_1[0x11] != 0)) {
      iStack_38 = *(short *)(*(short *)(*(short *)(iVar5 + 0x1c) * 2 + DWORD_080287e8) * 0x20 + 0x80
                            + DWORD_080287ec) * 0x10 + *(int *)(iVar5 + 0x8c);
      iStack_34 = *(short *)(*(short *)(*(short *)(iVar5 + 0x1c) * 2 + DWORD_080287e8) * 0x20 +
                            DWORD_080287ec) * 0x10 + *(int *)(iVar5 + 0x90);
      iVar6 = sub_08021FE0(param_1 + 2,&iStack_38,param_1 + 6,&uStack_30);
      if (iVar6 != 0) {
        sub_0805A58C(*param_1,param_1[0x11]);
      }
    }
    uVar1 = *(ushort *)((int)param_1 + 0x36);
    if (((uVar1 != 2) && (2 < uVar1)) && (uVar1 == 3)) {
      *(undefined2 *)((int)param_1 + 0x36) = 0;
      *(short *)(param_1 + 0xb) = *(short *)(param_1 + 9) + *(short *)(param_1 + 0xe);
    }
    if ((*(ushort *)(*(int *)DWORD_080287e4 + 4) & 0x200) == 0) {
      uVar4 = sub_08065370(auStack_a8,*(undefined2 *)(param_1 + 0xb),(int)param_1 + 0x2e,
                           param_1 + 0xc,*(undefined2 *)(param_1 + 0xd));
      *(undefined2 *)((int)param_1 + 0x32) = uVar4;
    }
    iVar9 = param_1[2];
    iVar6 = param_1[3];
    uVar7 = sub_0800CCCC();
    uVar3 = sub_0800BC44(iVar9 >> 8,iVar6 >> 8,uVar7);
    uVar7 = sub_0800CCCC();
    sub_0800BC08((int)(param_1[2] << 8) >> 0x10,(int)(param_1[3] << 8) >> 0x10,&sStack_40,&sStack_3e
                 ,0x30,uVar7);
    iVar6 = sub_0800CC98();
    if ((iVar6 == 0) && (iVar6 = sub_0800CD34(), iVar6 == 0)) {
      iVar6 = *(int *)(param_1[1] * 8 + DWORD_080287f0 + 4);
      if ((iVar6 != 3) && ((*(ushort *)(*(int *)DWORD_080287e4 + 4) & 0x200) == 0)) {
        sub_08000AF0(*puVar10 + 0x10,iStack_9c + iVar6 * 0x20,1);
      }
      sub_08007870((int)sStack_40,(int)sStack_3e,*(undefined2 *)(param_1 + 0xb),
                   *(undefined2 *)((int)param_1 + 0x2e),uVar3,puStack_28,uStack_a0,auStack_a8[0]);
      psVar8 = (short *)((int)param_1 + 0x42);
      if (*psVar8 != 0) {
        if (iStack_2c != 0) {
          iStack_2c = 0;
        }
        iVar6 = sub_08065370(puStack_24,*psVar8,&uStack_3c,&uStack_3a,0);
        if (iVar6 == 0) {
          sub_08065230(puStack_24,(int)sStack_40,sStack_3e + -0x20,*psVar8,uStack_3c);
        }
        else {
          *psVar8 = 0;
          uStack_3c = 0;
          uStack_3a = 0;
          iStack_2c = 1;
        }
      }
    }
    sub_080003F0();
  }
  *param_1 = 0;
  return in_lr;
}


