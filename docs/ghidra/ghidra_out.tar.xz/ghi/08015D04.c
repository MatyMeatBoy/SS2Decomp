
undefined4 sub_08015D04(void)

{
  int iVar1;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_08015d24;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & DWORD_08015d28;
  return in_lr;
}


