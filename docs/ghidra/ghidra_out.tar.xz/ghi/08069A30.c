
undefined4
sub_08069A30(undefined4 param_1,undefined4 param_2,undefined2 param_3,undefined2 param_4,
            undefined2 param_5)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  undefined2 *puVar4;
  uint uVar5;
  undefined4 in_lr;
  
  uVar5 = 0;
  uVar1 = *(uint *)DWORD_08069ad8 & 1;
  while( true ) {
    if (uVar1 == 0) {
      if (uVar5 < 0x20) {
        puVar4 = (undefined2 *)(*(int *)DWORD_08069adc + uVar5 * 0xc);
        *puVar4 = (short)((uint)param_1 >> 8);
        puVar4[1] = (short)((uint)param_2 >> 8);
        puVar4[4] = param_3;
        puVar4[5] = (short)uVar5;
        puVar4[2] = param_4;
        puVar4[3] = param_5;
        iVar2 = sub_08001494(0x500);
        iVar3 = uVar5 * 0x28 + *(int *)DWORD_08069ae0;
        *(int *)(iVar3 + 0x20) = iVar2;
        if (iVar2 != 0) {
          *(undefined4 *)(iVar3 + 8) = 0x34;
          *(dword *)(iVar3 + 0xc) = DWORD_08069ae4;
          *(dword *)(iVar3 + 0x10) = iVar2 + DWORD_08069ae8;
          *(undefined4 *)(iVar3 + 0x24) = 0;
          sub_08000274(iVar3,puVar4);
          *(uint *)DWORD_08069ad8 = *(uint *)DWORD_08069ad8 | 1 << (uVar5 & 0xff);
        }
      }
      return in_lr;
    }
    uVar5 = uVar5 + 1;
    if (0x1f < uVar5) break;
    uVar1 = *(uint *)DWORD_08069ad8 & 1 << (uVar5 & 0xff);
  }
  return in_lr;
}


