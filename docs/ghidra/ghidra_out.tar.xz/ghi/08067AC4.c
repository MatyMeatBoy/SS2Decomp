
undefined4 sub_08067AC4(void)

{
  return 1;
}


