
undefined8 sub_08097A74(int param_1,int param_2,undefined4 param_3,short param_4)

{
  char cVar1;
  undefined2 uVar2;
  undefined4 in_lr;
  
  cVar1 = sub_08096060(param_1,**(ushort **)(param_2 + 0x148) >> 4,
                       (*(ushort **)(param_2 + 0x148))[1] & 0xfff,(int)param_4);
  if (cVar1 != 0) {
    uVar2 = sub_08013E90(param_3,param_1 + 0x14,*(undefined2 *)(param_1 + 8),0,0);
    *(undefined2 *)(param_1 + 8) = uVar2;
  }
  return CONCAT44(in_lr,(int)cVar1);
}


