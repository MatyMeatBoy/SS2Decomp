
undefined4 sub_08088AA8(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 in_lr;
  
  uVar3 = 0;
  iVar4 = *(int *)DWORD_08088ac0 + DWORD_08088ac4 + 0x48;
  iVar2 = *(int *)DWORD_08088ac0 + DWORD_08088ac4;
  while( true ) {
    if (0xe < uVar3) {
      return in_lr;
    }
    iVar1 = sub_08000470(iVar4);
    if (iVar1 == 0) break;
    uVar3 = uVar3 + 1;
    iVar4 = iVar2 + 0xb8;
    iVar2 = iVar2 + 0x70;
  }
  *(short *)(iVar2 + 0x40) = (short)uVar3;
  iVar1 = sub_08001494(0x800);
  *(int *)(iVar2 + 0x68) = iVar1;
  *(dword *)(iVar2 + 0x54) = DWORD_08088b1c;
  *(dword *)(iVar2 + 0x58) = iVar1 + DWORD_08088b20;
  *(undefined4 *)(iVar2 + 0x50) = 10;
  *(undefined4 *)(iVar2 + 0x6c) = 0;
  sub_08000274(iVar4,iVar2,param_1);
  sub_08057624(2);
  return in_lr;
}


