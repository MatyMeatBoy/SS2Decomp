
undefined4 sub_080A1DA8(void)

{
  dword dVar1;
  dword dVar2;
  ushort uVar3;
  short sVar4;
  int iVar5;
  short *psVar6;
  uint uVar7;
  ushort *puVar8;
  undefined4 uVar9;
  int iVar10;
  int iVar11;
  undefined4 in_lr;
  
  dVar1 = DWORD_080a1e44;
  iVar10 = *(int *)(*(int *)DWORD_080a1e40 + 0x14);
  iVar11 = *(int *)(*(int *)DWORD_080a1e40 + 0x18);
  iVar5 = sub_080020F4();
  uVar3 = **(ushort **)(iVar5 * 0x14c + dVar1 + 0x148);
  iVar5 = sub_080020F4();
  iVar10 = (int)(((uint)(uVar3 >> 4) - ((iVar10 << 8) >> 0x10)) * 0x10000) >> 0x10;
  iVar5 = (int)(((*(ushort *)(*(int *)(iVar5 * 0x14c + dVar1 + 0x148) + 2) & 0xfff) -
                ((iVar11 << 8) >> 0x10)) * 0x10000) >> 0x10;
  uVar3 = Sqrt(iVar10 * iVar10 + iVar5 * iVar5);
  if (uVar3 < 0x20) {
    iVar5 = ArcTan2(iVar10,iVar5);
    uVar7 = (uint)(iVar5 << 0x10) >> 0x1d;
    if (0x80000000 < (uint)(iVar5 * 0x80000)) {
      if (uVar7 < 7) {
        uVar7 = uVar7 + 1;
      }
      else {
        uVar7 = 0;
      }
    }
    sVar4 = *(short *)(*(int *)DWORD_080a1f7c + 8);
    if (((((((sVar4 == 0) && (uVar7 == 2)) || ((sVar4 == 1 && (uVar7 == 3)))) ||
          (((sVar4 == 2 && (uVar7 == 4)) || ((sVar4 == 3 && (uVar7 == 5)))))) ||
         ((((sVar4 == 4 && (uVar7 == 6)) || ((sVar4 == 5 && (uVar7 == 7)))) ||
          ((sVar4 == 6 && (uVar7 == 0)))))) || ((sVar4 == 7 && (uVar7 == 1)))) &&
       ((((((iVar5 = sub_0800CDF8(), iVar5 == 0 && (iVar5 = sub_0800CCCC(), iVar5 == 0)) &&
           (iVar5 = sub_0800CD8C(), dVar1 = DWORD_080a1f7c, iVar5 == 0)) &&
          ((*(short *)(*(int *)DWORD_080a1f7c + 0xc) != 0xb &&
           (iVar5 = sub_080020F4(), dVar2 = DWORD_080a1f80,
           (*(uint *)(iVar5 * 0x14c + DWORD_080a1f80 + 0x30) & 0x2000) == 0)))) &&
         ((iVar5 = sub_080020F4(), *(char *)(iVar5 * 0x14c + dVar2 + 0x68) != '\0' &&
          ((iVar5 = sub_080020F4(), *(short *)(iVar5 * 0x14c + dVar2 + 0x20) != 0xe &&
           (iVar5 = sub_080020F4(), *(short *)(iVar5 * 0x14c + dVar2 + 0x20) != 0xb)))))) &&
        (iVar5 = sub_080020F4(), *(short *)(iVar5 * 0x14c + dVar2 + 0x20) != 0xc)))) {
      iVar5 = sub_080020F4();
      *(undefined2 *)(iVar5 * 0x14c + dVar2 + 0x20) = 10;
      iVar5 = sub_080020F4();
      *(short *)(iVar5 * 0x14c + dVar2 + 0xb0) = (short)DWORD_080a1f84;
      iVar5 = sub_080020F4();
      uVar9 = *(undefined4 *)dVar1;
      iVar10 = sub_080020F4();
      sVar4 = sub_0801ED8C(uVar9,iVar10 * 0x14c + dVar2);
      psVar6 = (short *)(iVar5 * 0x14c + dVar2 + 0x88);
      *psVar6 = sVar4 + *psVar6;
      iVar5 = sub_080020F4();
      puVar8 = *(ushort **)dVar1;
      iVar10 = *(int *)(puVar8 + 0x28);
      *(int *)((uint)*puVar8 * 4 + iVar5 * 0x14c + dVar2 + 0xe4) = iVar10;
      *(int *)(puVar8 + 0x28) = iVar10 + 1;
    }
  }
  return in_lr;
}


