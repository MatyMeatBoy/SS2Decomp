
undefined4
sub_08057E74(int param_1,int param_2,undefined2 param_3,undefined2 param_4,undefined4 param_5,
            undefined4 param_6)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_lr;
  int iStack_38;
  int iStack_34;
  undefined2 uStack_30;
  undefined2 uStack_2e;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  
  iVar2 = *(int *)DWORD_08057e9c + DWORD_08057ea0;
  uVar3 = 0;
  while( true ) {
    if (0x1d < uVar3) {
      return in_lr;
    }
    iVar1 = sub_08000470(iVar2);
    if (iVar1 == 0) break;
    uVar3 = uVar3 + 1;
    iVar2 = iVar2 + 0x28;
  }
  iStack_38 = param_1 << 8;
  iStack_34 = param_2 << 8;
  uStack_2c = param_5;
  uStack_28 = param_6;
  *(undefined4 *)(iVar2 + 8) = 0x3c;
  uStack_30 = param_3;
  uStack_2e = param_4;
  iVar1 = sub_08001494(0x400);
  *(int *)(iVar2 + 0x20) = iVar1;
  *(dword *)(iVar2 + 0xc) = DWORD_08057f14;
  *(int *)(iVar2 + 0x10) = iVar1 + 0x3fc;
  *(undefined4 *)(iVar2 + 0x24) = 0;
  sub_08000274(iVar2,&iStack_38,1);
  sub_080003F0();
  sub_080003F0();
  return in_lr;
}


