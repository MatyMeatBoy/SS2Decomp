
undefined4 sub_0806DB1C(uint *param_1)

{
  char cVar1;
  ushort uVar2;
  short sVar3;
  undefined2 uVar4;
  ushort uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  uint *puVar11;
  short *psVar12;
  short *psVar13;
  int iVar14;
  ushort *puVar15;
  uint uVar16;
  uint uVar17;
  int unaff_r10;
  undefined4 in_lr;
  byte abStack_48 [4];
  undefined2 auStack_44 [6];
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  int iStack_24;
  
  uVar6 = sub_080020F4();
  uStack_2c = *param_1;
  uStack_28 = param_1[1];
  uVar2 = (ushort)param_1[5];
  uVar10 = (uint)uVar2;
  if (uStack_2c < 4) {
    unaff_r10 = uStack_2c * 0x14c + DWORD_0806dbd0;
  }
  uStack_38 = uVar10;
  if (uVar6 == uStack_2c) {
    iVar7 = sub_080020F4();
    iVar14 = iVar7 * 0x14c + DWORD_0806dbd0;
    iVar7 = sub_0806898C(param_1[3],param_1[5]);
    puVar15 = (ushort *)(iVar14 + 0xc2);
    iVar7 = (uint)*puVar15 - (iVar7 - 1U & 0xffff);
    *puVar15 = (ushort)iVar7;
    if (iVar7 * 0x10000 < 0) {
      *puVar15 = 0;
    }
  }
  iStack_24 = uStack_2c << 2;
  uVar5 = *(ushort *)(unaff_r10 + 0xb4);
  while (uVar5 < 7) {
    if (*(short *)(unaff_r10 + 0x20) == 10) {
      puVar11 = (uint *)(iStack_24 + DWORD_0806dd90);
      goto LAB_0806de72;
    }
    sub_080003F0();
    uVar5 = *(ushort *)(unaff_r10 + 0xb4);
  }
  uStack_34 = (uint)(**(ushort **)(unaff_r10 + 0x148) >> 4);
  uStack_30 = (*(ushort **)(unaff_r10 + 0x148))[1] & 0xfff;
  uVar17 = 0;
  for (uVar16 = 0; uVar8 = sub_08002164(), uVar16 < uVar8; uVar16 = uVar16 + 1 & 0xffff) {
    iVar7 = uVar16 * 0x14c + DWORD_0806dd28;
    puVar15 = *(ushort **)(iVar7 + 0x148);
    uVar8 = uVar17;
    if (((-1 < (int)((uint)(byte)puVar15[2] * 0x4000000)) &&
        (cVar1 = *(char *)(iVar7 + 0x68), cVar1 == *(char *)(unaff_r10 + 0x68))) && (cVar1 != '\0'))
    {
      if (uStack_38 != 0) {
        iVar7 = ((*puVar15 >> 4) - uStack_34) * 0x10000;
        iVar14 = iVar7 >> 0x10;
        iVar7 = iVar7 >> 0x13;
        if (iVar7 < 0) {
          iVar7 = -iVar7;
        }
        if (iVar7 < 0xd) {
          iVar7 = ((puVar15[1] & 0xfff) - uStack_30) * 0x10000;
          iVar9 = iVar7 >> 0x10;
          iVar7 = iVar7 >> 0x13;
          if (iVar7 < 0) {
            iVar7 = -iVar7;
          }
          if (iVar7 < 0xd) {
            uVar4 = Sqrt(iVar14 * iVar14 + iVar9 * iVar9);
            auStack_44[uVar17] = uVar4;
            uVar8 = uVar17 + 1 & 0xffff;
            abStack_48[uVar17] = (byte)uVar16;
          }
        }
      }
    }
    uVar17 = uVar8;
  }
  uVar16 = 0;
  if (uVar17 != 0) {
    do {
      sub_08074DE8(abStack_48[uVar16],9);
      uVar16 = uVar16 + 1 & 0xffff;
    } while (uVar16 < uVar17);
  }
  sVar3 = *(short *)(unaff_r10 + 0xb6);
  while (sVar3 == 0) {
    sub_080003F0();
    sVar3 = *(short *)(unaff_r10 + 0xb6);
  }
  if (((uVar6 == uStack_2c) || (3 < uStack_2c)) &&
     ((iVar7 = sub_0800CCCC(), iVar7 == 0 && (iVar7 = sub_0800CD34(), iVar7 == 0)))) {
    sub_0805865C(DWORD_0806dd2c);
  }
  if (uVar6 == uStack_2c) {
    psVar12 = *(short **)(unaff_r10 + 0x34);
    uVar5 = 0;
    psVar13 = psVar12;
    do {
      if (((0 < *psVar13) && (*(short *)(uVar6 * 0x14c + DWORD_0806dd28 + 100) == 4)) &&
         ((psVar13[2] == 3 && ((ushort)psVar13[1] < 100)))) {
        if ((ushort)psVar13[3] < uVar10) {
          psVar13[3] = uVar2;
          *psVar13 = (uVar2 * 10 + 0x28) * 0x3c;
          psVar13[8] = uVar2 * 0x14;
        }
        goto LAB_0806dd5e;
      }
      uVar5 = uVar5 + 1;
      psVar13 = psVar13 + 0x14;
    } while (uVar5 < 8);
    uVar5 = 0;
    do {
      if (*psVar12 == -1) {
        psVar12[1] = (short)uStack_2c;
        *psVar12 = (uVar2 * 10 + 0x28) * 0x3c;
        psVar12[2] = 3;
        psVar12[3] = uVar2;
        psVar12[8] = uVar2 * 0x14;
        break;
      }
      uVar5 = uVar5 + 1;
      psVar12 = psVar12 + 0x14;
    } while (uVar5 < 8);
LAB_0806dd5e:
    *(undefined2 *)(unaff_r10 + 0x24) = 0;
    *(undefined2 *)(unaff_r10 + 0x26) = 0;
  }
  else {
    uVar16 = 0;
    if ((uVar17 != 0) && (uStack_38 != 0)) {
      do {
        if (abStack_48[uVar16] == uVar6) {
          iVar7 = uVar6 * 0x14c + DWORD_0806de28;
          psVar13 = *(short **)(iVar7 + 0x34);
          uVar5 = 0;
          goto LAB_0806ddf4;
        }
        uVar16 = uVar16 + 1 & 0xffff;
      } while ((uVar16 < uVar17) && (uStack_38 != 0));
    }
  }
LAB_0806de6c:
  puVar11 = (uint *)(iStack_24 + DWORD_0806de90);
LAB_0806de72:
  *puVar11 = *puVar11 & ~(1 << (uStack_28 & 0xff));
  return in_lr;
  while( true ) {
    uVar5 = uVar5 + 1;
    psVar13 = psVar13 + 0x14;
    if (7 < uVar5) break;
LAB_0806ddf4:
    if ((((0 < *psVar13) && ((ushort)psVar13[1] < 4)) &&
        (*(short *)((uint)(ushort)psVar13[1] * 0x14c + DWORD_0806de28 + 100) == 4)) &&
       (psVar13[2] == 3)) {
      if ((ushort)psVar13[3] < uVar10) {
        *psVar13 = (uVar2 * 10 + 0x28) * 0x3c;
        psVar13[3] = uVar2;
        psVar13[8] = uVar2 * 0x14;
      }
      goto LAB_0806de6c;
    }
  }
  psVar13 = *(short **)(iVar7 + 0x34);
  uVar5 = 0;
  do {
    if (*psVar13 == -1) {
      psVar13[1] = (short)uStack_2c;
      *psVar13 = (uVar2 * 10 + 0x28) * 0x3c;
      psVar13[2] = 3;
      psVar13[3] = uVar2;
      psVar13[8] = uVar2 * 0x14;
      break;
    }
    uVar5 = uVar5 + 1;
    psVar13 = psVar13 + 0x14;
  } while (uVar5 < 8);
  goto LAB_0806de6c;
}


