
undefined4 sub_0803B194(void)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_0803b1c4;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) | 1;
  sub_0800D0F4();
  iVar1 = sub_0800CE30();
  if (iVar1 == 0) {
    uVar4 = *(uint *)(*(int *)DWORD_0803b1e4 + 0x74);
  }
  else {
    uVar4 = *(uint *)(*(int *)DWORD_0803b1c8 + 0x7c);
  }
  iVar1 = sub_0800CE30();
  if (iVar1 == 0) {
    iVar1 = *(int *)DWORD_0803b200;
    iVar3 = 0x1ba;
  }
  else {
    iVar1 = *(int *)DWORD_0803b1e4;
    iVar3 = 0x1c6;
  }
  if (((int)(uint)*(byte *)(iVar1 + iVar3) >> 2 & 1U) == 0) {
    if ((uVar4 & 0x200) == 0) {
      if ((uVar4 & 0x100) == 0) {
        if ((uVar4 & 0x80) == 0) {
          if ((uVar4 & 0x40) == 0) {
            if ((uVar4 & 0x20) == 0) {
              if ((uVar4 & 0x10) == 0) {
                if ((uVar4 & 8) == 0) {
                  if ((uVar4 & 4) == 0) {
                    if ((uVar4 & 2) == 0) {
                      if ((uVar4 & 1) == 0) {
                        while (iVar1 = sub_0805F184(), iVar1 != 0) {
                          sub_080003F0();
                        }
                        while (iVar1 = sub_0805EF90(), iVar1 != 0) {
                          sub_080003F0();
                        }
                        uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803b654);
                        while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
                          iVar1 = sub_0800CDF8();
                          if (iVar1 != 0) {
                            sub_0805EFBC();
                            break;
                          }
                          sub_080003F0();
                        }
                      }
                      else {
                        while (iVar1 = sub_0805F184(), iVar1 != 0) {
                          sub_080003F0();
                        }
                        while (iVar1 = sub_0805EF90(), iVar1 != 0) {
                          sub_080003F0();
                        }
                        uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803b600);
                        while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
                          iVar1 = sub_0800CDF8();
                          if (iVar1 != 0) {
                            sub_0805EFBC();
                            break;
                          }
                          sub_080003F0();
                        }
                      }
                    }
                    else {
                      while (iVar1 = sub_0805F184(), iVar1 != 0) {
                        sub_080003F0();
                      }
                      while (iVar1 = sub_0805EF90(), iVar1 != 0) {
                        sub_080003F0();
                      }
                      uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803b5a0);
                      while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
                        iVar1 = sub_0800CDF8();
                        if (iVar1 != 0) {
                          sub_0805EFBC();
                          break;
                        }
                        sub_080003F0();
                      }
                    }
                  }
                  else {
                    while (iVar1 = sub_0805F184(), iVar1 != 0) {
                      sub_080003F0();
                    }
                    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
                      sub_080003F0();
                    }
                    uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803b540);
                    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
                      iVar1 = sub_0800CDF8();
                      if (iVar1 != 0) {
                        sub_0805EFBC();
                        break;
                      }
                      sub_080003F0();
                    }
                  }
                }
                else {
                  while (iVar1 = sub_0805F184(), iVar1 != 0) {
                    sub_080003F0();
                  }
                  while (iVar1 = sub_0805EF90(), iVar1 != 0) {
                    sub_080003F0();
                  }
                  uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803b4e0);
                  while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
                    iVar1 = sub_0800CDF8();
                    if (iVar1 != 0) {
                      sub_0805EFBC();
                      break;
                    }
                    sub_080003F0();
                  }
                }
              }
              else {
                while (iVar1 = sub_0805F184(), iVar1 != 0) {
                  sub_080003F0();
                }
                while (iVar1 = sub_0805EF90(), iVar1 != 0) {
                  sub_080003F0();
                }
                uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803b480);
                while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
                  iVar1 = sub_0800CDF8();
                  if (iVar1 != 0) {
                    sub_0805EFBC();
                    break;
                  }
                  sub_080003F0();
                }
              }
            }
            else {
              while (iVar1 = sub_0805F184(), iVar1 != 0) {
                sub_080003F0();
              }
              while (iVar1 = sub_0805EF90(), iVar1 != 0) {
                sub_080003F0();
              }
              uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803b420);
              while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
                iVar1 = sub_0800CDF8();
                if (iVar1 != 0) {
                  sub_0805EFBC();
                  break;
                }
                sub_080003F0();
              }
            }
          }
          else {
            while (iVar1 = sub_0805F184(), iVar1 != 0) {
              sub_080003F0();
            }
            while (iVar1 = sub_0805EF90(), iVar1 != 0) {
              sub_080003F0();
            }
            uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803b3c0);
            while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
              iVar1 = sub_0800CDF8();
              if (iVar1 != 0) {
                sub_0805EFBC();
                break;
              }
              sub_080003F0();
            }
          }
        }
        else {
          while (iVar1 = sub_0805F184(), iVar1 != 0) {
            sub_080003F0();
          }
          while (iVar1 = sub_0805EF90(), iVar1 != 0) {
            sub_080003F0();
          }
          uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803b360);
          while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
            iVar1 = sub_0800CDF8();
            if (iVar1 != 0) {
              sub_0805EFBC();
              break;
            }
            sub_080003F0();
          }
        }
      }
      else {
        while (iVar1 = sub_0805F184(), iVar1 != 0) {
          sub_080003F0();
        }
        while (iVar1 = sub_0805EF90(), iVar1 != 0) {
          sub_080003F0();
        }
        uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803b300);
        while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
          iVar1 = sub_0800CDF8();
          if (iVar1 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
      }
    }
    else {
      while (iVar1 = sub_0805F184(), iVar1 != 0) {
        sub_080003F0();
      }
      while (iVar1 = sub_0805EF90(), iVar1 != 0) {
        sub_080003F0();
      }
      uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803b29c);
      while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
        iVar1 = sub_0800CDF8();
        if (iVar1 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
    }
  }
  else {
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803b238);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      iVar1 = sub_0800CDF8();
      if (iVar1 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
  }
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_0803b698;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


