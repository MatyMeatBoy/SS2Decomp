
undefined4 sub_08047970(void)

{
  dword dVar1;
  short sVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int unaff_r6;
  undefined4 in_lr;
  
  dVar1 = DWORD_08047980;
  iVar4 = *(int *)DWORD_08047984 + DWORD_08047988;
  for (uVar5 = 0; uVar5 < 0x1e; uVar5 = uVar5 + 1) {
    iVar3 = sub_08000470(iVar4);
    if (iVar3 == 0) goto LAB_080479a4;
    iVar4 = iVar4 + 0x28;
  }
LAB_080479d0:
  sub_0802A080(0x3c,0xbe,0xa0,100);
  if ((unaff_r6 != 0) && (iVar4 = sub_08000470(unaff_r6), iVar4 != 0)) {
    sub_080003A8(unaff_r6);
  }
  sVar2 = 1;
  do {
    sub_080003F0();
    iVar4 = sub_080021A8();
    if (iVar4 != 0) break;
    sVar2 = sVar2 + -1;
  } while (sVar2 != 0);
  sub_0805EFBC();
  do {
    sub_080003F0();
    iVar4 = sub_0805F184();
    dVar1 = DWORD_08047a28;
  } while (iVar4 != 0);
  iVar4 = *(int *)DWORD_08047a2c + DWORD_08047a30;
  for (uVar5 = 0; uVar5 < 0x1e; uVar5 = uVar5 + 1) {
    iVar3 = sub_08000470(iVar4);
    if (iVar3 == 0) goto LAB_08047a4c;
    iVar4 = iVar4 + 0x28;
  }
LAB_08047a76:
  dVar1 = DWORD_08047a84;
  iVar4 = *(int *)DWORD_08047a88 + DWORD_08047a8c;
  for (uVar5 = 0; uVar5 < 0x1e; uVar5 = uVar5 + 1) {
    iVar3 = sub_08000470(iVar4);
    if (iVar3 == 0) goto LAB_08047aa8;
    iVar4 = iVar4 + 0x28;
  }
LAB_08047ad2:
  sVar2 = 0x3c;
  do {
    sub_080003F0();
    iVar4 = sub_080021A8();
    dVar1 = DWORD_08047b28;
    if (iVar4 != 0) break;
    sVar2 = sVar2 + -1;
  } while (sVar2 != 0);
  iVar4 = *(int *)DWORD_08047b24;
  uVar5 = 0;
  do {
    if (((*(uint *)dVar1 & 1 << (uVar5 & 0xff)) != 0) && (*(short *)(iVar4 + 0xc) == 0xc)) {
      *(undefined2 *)(iVar4 + 0xc) = 0;
    }
    uVar5 = uVar5 + 1;
    iVar4 = iVar4 + 0x2e0;
  } while (uVar5 < 5);
  sub_08019F04();
  return in_lr;
LAB_080479a4:
  while( true ) {
    iVar3 = sub_08001494(0x400);
    *(int *)(iVar4 + 0x20) = iVar3;
    if (iVar3 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar4 + 8) = 0x3c;
  *(dword *)(iVar4 + 0xc) = dVar1;
  *(int *)(iVar4 + 0x10) = iVar3 + 0x3fc;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  sub_08000274(iVar4,0);
  unaff_r6 = iVar4;
  goto LAB_080479d0;
LAB_08047a4c:
  while( true ) {
    iVar3 = sub_08001494(0x400);
    *(int *)(iVar4 + 0x20) = iVar3;
    if (iVar3 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar4 + 8) = 0x3c;
  *(dword *)(iVar4 + 0xc) = dVar1;
  *(int *)(iVar4 + 0x10) = iVar3 + 0x3fc;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  sub_08000274(iVar4,2);
  goto LAB_08047a76;
LAB_08047aa8:
  while( true ) {
    iVar3 = sub_08001494(0x400);
    *(int *)(iVar4 + 0x20) = iVar3;
    if (iVar3 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar4 + 8) = 0x3c;
  *(dword *)(iVar4 + 0xc) = dVar1;
  *(int *)(iVar4 + 0x10) = iVar3 + 0x3fc;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  sub_08000274(iVar4,3);
  goto LAB_08047ad2;
}


