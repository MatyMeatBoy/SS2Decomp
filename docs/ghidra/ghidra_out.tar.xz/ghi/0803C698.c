
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 sub_0803C698(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int iVar4;
  short *psVar5;
  int unaff_r4;
  uint uVar6;
  int iVar7;
  undefined4 in_lr;
  undefined2 uStack_34;
  undefined2 uStack_32;
  undefined1 auStack_30 [28];
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_0803c6c4;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) | 1;
  sub_0800D0F4();
  sub_0802939C(param_1,2);
  while (iVar1 = sub_0805F184(), iVar1 != 0) {
    sub_080003F0();
  }
  while (iVar1 = sub_0805EF90(), iVar1 != 0) {
    sub_080003F0();
  }
  uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803c6fc);
  while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
    iVar1 = sub_0800CDF8();
    if (iVar1 != 0) {
      sub_0805EFBC();
      break;
    }
    sub_080003F0();
  }
  iVar1 = sub_0800CE30();
  if (iVar1 == 0) {
    iVar1 = *(int *)DWORD_0803c750;
    iVar4 = 0x1b6;
  }
  else {
    iVar1 = *(int *)DWORD_0803c72c;
    iVar4 = 0x1c2;
  }
  uVar3 = (uint)*(byte *)(iVar1 + iVar4);
  switch(uVar3) {
  case 0:
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,_UNK_0803c7a8);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      sub_080003F0();
    }
    break;
  case 1:
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,_UNK_0803c7e4);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      sub_080003F0();
    }
    break;
  case 2:
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,_UNK_0803c820);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      sub_080003F0();
    }
    break;
  case 3:
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,_UNK_0803c85c);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      sub_080003F0();
    }
    break;
  case 4:
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,_UNK_0803c898);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      sub_080003F0();
    }
    break;
  case 5:
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,_UNK_0803c8d4);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      sub_080003F0();
    }
    break;
  case 6:
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,_UNK_0803c910);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      sub_080003F0();
    }
    break;
  case 7:
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,_UNK_0803c94c);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      sub_080003F0();
    }
    break;
  case 8:
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,_UNK_0803c988);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      sub_080003F0();
    }
    break;
  case 9:
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,_UNK_0803c9c4);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      sub_080003F0();
    }
    break;
  default:
    goto LAB_0803c9de;
  }
  unaff_r4 = sub_0805EF14(uVar2);
LAB_0803c9de:
  if (unaff_r4 == 0) {
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803cc00);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      iVar1 = sub_0800CDF8();
      if (iVar1 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
  }
  else {
    iVar1 = 0;
    psVar5 = (short *)(*(int *)DWORD_0803caac + 0x150);
    iVar7 = uVar3 + 1;
    iVar4 = 0x18;
    do {
      if (*psVar5 == 10) {
        iVar1 = iVar1 + *(int *)(psVar5 + 2);
      }
      iVar4 = iVar4 + -1;
      psVar5 = psVar5 + 8;
    } while (-1 < iVar4);
    psVar5 = (short *)(*(int *)DWORD_0803caac + 0x2e0);
    for (iVar4 = (uint)*(ushort *)(*(int *)DWORD_0803caac + 0x6a) * 0xf; iVar4 != 0;
        iVar4 = iVar4 + -1) {
      if (*psVar5 == 10) {
        iVar1 = iVar1 + *(int *)(psVar5 + 2);
      }
      psVar5 = psVar5 + 8;
    }
    if (iVar1 + iVar7 * -100 < 0 == SBORROW4(iVar1,iVar7 * 100)) {
      iVar1 = sub_0805CFA0();
      if (iVar1 < 0) {
        while (iVar1 = sub_0805F184(), iVar1 != 0) {
          sub_080003F0();
        }
        while (iVar1 = sub_0805EF90(), iVar1 != 0) {
          sub_080003F0();
        }
        uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803cb58);
        while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
          iVar1 = sub_0800CDF8();
          if (iVar1 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
      }
      else {
        if ((*(uint *)DWORD_0803cab0 & 0x20) == 0) {
          sub_08006D08(0x33);
        }
        sub_0807C014(uVar3 * 100 + 100);
        uStack_34 = 1;
        uStack_32 = 0x24;
        uVar6 = 0;
        do {
          auStack_30[uVar6] = 0;
          uVar6 = uVar6 + 1;
        } while (uVar6 < 0xc);
        iVar1 = 0;
        do {
          sub_0805AB20(&uStack_34);
          iVar1 = iVar1 + 1;
        } while (iVar1 == 0);
        if (uVar3 != 9) {
          iVar1 = sub_0800CE30();
          if (iVar1 == 0) {
            iVar1 = *(int *)DWORD_0803cac8;
            iVar4 = 0x1b6;
          }
          else {
            iVar1 = *(int *)DWORD_0803cab4;
            iVar4 = 0x1c2;
          }
          *(char *)(iVar1 + iVar4) = (char)iVar7;
        }
        while (iVar1 = sub_0805F184(), iVar1 != 0) {
          sub_080003F0();
        }
        while (iVar1 = sub_0805EF90(), iVar1 != 0) {
          sub_080003F0();
        }
        uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803cb00);
        while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
          iVar1 = sub_0800CDF8();
          if (iVar1 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
      }
    }
    else {
      while (iVar1 = sub_0805F184(), iVar1 != 0) {
        sub_080003F0();
      }
      while (iVar1 = sub_0805EF90(), iVar1 != 0) {
        sub_080003F0();
      }
      uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803cbac);
      while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
        iVar1 = sub_0800CDF8();
        if (iVar1 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
    }
  }
  sub_0802939C(param_1,0);
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_0803cc4c;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


