
undefined4 sub_0801AB90(undefined2 param_1)

{
  dword dVar1;
  undefined4 in_lr;
  
  dVar1 = DWORD_0801abdc;
  if ((-1 < *(short *)DWORD_0801abd8) || ((*(ushort *)DWORD_0801abdc & 0x8000) == 0)) {
    *(undefined2 *)DWORD_0801abd8 = 0xffff;
    *(undefined2 *)DWORD_0801abe0 = param_1;
    *(undefined2 *)dVar1 = param_1;
    sub_08000420(100);
    *(ushort *)DWORD_0801abe4 = *(ushort *)DWORD_0801abe4 & 0xfff7 | 0x10;
  }
  return in_lr;
}


