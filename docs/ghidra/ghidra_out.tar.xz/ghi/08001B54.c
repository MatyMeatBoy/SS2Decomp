
undefined8 sub_08001B54(undefined2 param_1)

{
  undefined4 uVar1;
  undefined4 in_lr;
  
  if (*(char *)DWORD_08001b68 == '\0') {
    uVar1 = 1;
  }
  else {
    uVar1 = VerifyFlashSector(param_1);
  }
  return CONCAT44(in_lr,uVar1);
}


