
undefined8 sub_0805B068(ushort *param_1)

{
  ushort uVar1;
  uint *puVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_lr;
  
  uVar5 = 0;
  uVar1 = *param_1;
  if (uVar1 == 3) {
    uVar5 = (uint)param_1[1];
    uVar4 = 0xc0000;
LAB_0805b0ac:
    iVar3 = sub_08007290(uVar5 | uVar4);
    puVar2 = (uint *)(iVar3 + 0x9c);
  }
  else {
    if (3 < uVar1) {
      if (uVar1 == 4) {
        uVar5 = (uint)param_1[1];
        uVar4 = 0xd0000;
      }
      else {
        if (uVar1 != 5) goto LAB_0805b0b6;
        uVar5 = (uint)param_1[1];
        uVar4 = 0xe0000;
      }
      goto LAB_0805b0ac;
    }
    if (uVar1 != 2) goto LAB_0805b0b6;
    iVar3 = sub_08007290(param_1[1] | 0xb0000);
    puVar2 = (uint *)(iVar3 + 0xa0);
  }
  uVar5 = *puVar2;
LAB_0805b0b6:
  for (uVar4 = 10; (iVar3 = sub_08057C34(uVar4), iVar3 == 0 && (1 < uVar4)); uVar4 = uVar4 - 1) {
  }
  iVar3 = sub_0800CE30();
  if (iVar3 == 0) {
    if (5 < uVar4) {
      uVar4 = 5;
    }
    uVar5 = __udivsi3(uVar4 * uVar5,10);
  }
  else {
    uVar5 = uVar5 >> 1;
  }
  return CONCAT44(in_lr,uVar5);
}


