
void Div(void)

{
  software_interrupt(6);
  return;
}


