
undefined4
sub_080659BC(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4,
            undefined2 param_5,undefined1 param_6)

{
  undefined4 in_lr;
  
  sub_08007CF0(param_2,param_3,param_4,param_5,param_6,param_1 + 7,param_1[2],*param_1);
  return in_lr;
}


