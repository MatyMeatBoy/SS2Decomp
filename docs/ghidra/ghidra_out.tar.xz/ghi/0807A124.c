
undefined8 sub_0807A124(void)

{
  dword dVar1;
  byte bVar2;
  char *pcVar3;
  char *pcVar4;
  uint uVar5;
  char *pcVar6;
  uint uVar7;
  undefined4 in_lr;
  
  pcVar3 = (char *)sub_08001494(0x1000);
  pcVar4 = (char *)sub_08001494(0x1000);
  dVar1 = DWORD_0807a1ec;
  memcpy(pcVar3,*(undefined4 *)DWORD_0807a1e8,DWORD_0807a1ec);
  memcpy(pcVar4,*(undefined4 *)DWORD_0807a1f0,DWORD_0807a1f4);
  bVar2 = 0;
  uVar7 = 0;
  pcVar6 = pcVar3;
  do {
    bVar2 = bVar2 + *pcVar6;
    uVar7 = uVar7 + 1;
    pcVar6 = pcVar6 + 1;
  } while (uVar7 < dVar1);
  pcVar3[DWORD_0807a1ec] = ~bVar2;
  dVar1 = DWORD_0807a1e8;
  bVar2 = 0;
  uVar7 = 0;
  pcVar6 = pcVar4;
  do {
    bVar2 = bVar2 + *pcVar6;
    uVar7 = uVar7 + 1;
    pcVar6 = pcVar6 + 1;
  } while (uVar7 < DWORD_0807a1f4);
  pcVar4[DWORD_0807a1f4] = ~bVar2;
  sub_08001B14(*(undefined2 *)(*(int *)dVar1 + 0xe),pcVar3);
  uVar7 = sub_08001B14(*(short *)(*(int *)dVar1 + 0xe) + 8,pcVar4);
  uVar7 = uVar7 & 0xffff;
  if (uVar7 == 0) {
    uVar7 = sub_08001B54(*(undefined2 *)(*(int *)dVar1 + 0xe),pcVar3);
    uVar5 = sub_08001B54(*(short *)(*(int *)dVar1 + 0xe) + 8,pcVar4);
    uVar7 = uVar7 | uVar5;
    if (uVar7 == 0) {
      sub_08001538(pcVar3);
      sub_08001538(pcVar4);
      uVar7 = 0;
      goto LAB_0807a206;
    }
  }
  sub_08001538(pcVar3);
  sub_08001538(pcVar4);
LAB_0807a206:
  return CONCAT44(in_lr,uVar7);
}


