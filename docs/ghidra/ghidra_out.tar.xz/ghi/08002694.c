
/* WARNING: Removing unreachable block (ram,0x0800299c) */

void sub_08002694(void)

{
  bool bVar1;
  bool bVar2;
  undefined4 *puVar3;
  dword dVar4;
  undefined2 *puVar5;
  ushort uVar6;
  int iVar7;
  undefined1 auStack_64 [52];
  undefined2 uStack_30;
  undefined2 uStack_2e;
  uint uStack_2c;
  undefined2 *puStack_28;
  uint *puStack_24;
  
  sub_0805F07C();
  sub_080003F0();
  sub_08006E64(1);
  puStack_24 = &uStack_2c;
  puStack_28 = &uStack_30;
LAB_080026c0:
  do {
    sub_080003F4(0x14);
    if ((*(byte *)DWORD_080026e4 & 0x80) != 0) {
      sub_08000940();
    }
    iVar7 = sub_08002228();
    if (iVar7 != 0) {
      sub_080020E0();
    }
    while (iVar7 = sub_08002228(), iVar7 != 0) {
      sub_080003F0();
    }
    iVar7 = sub_08002228();
    if (iVar7 == 0) {
      sub_0800208C(1);
    }
    sub_080013F8();
    sub_080003F0();
    sub_080003F0();
    sub_080003F0();
    sub_080003F0();
    sub_08000A34(1,0,0,0,0);
    sub_080009F8(0xf00,0,1);
    sub_080009C0(0x1200,0,1);
    uStack_2c = uStack_2c & DWORD_080027a0 | DWORD_080027a4;
    sub_08000AA8(0,puStack_24);
    uStack_2c = CONCAT22(uStack_2c._2_2_,0x1d00);
    sub_08000AA8(1,puStack_24);
    dVar4 = DWORD_080027a8;
    *(undefined2 *)DWORD_080027a8 = 0;
    *(undefined2 *)(dVar4 + 2) = 0;
    *(undefined2 *)(dVar4 + 4) = 0;
    *(undefined2 *)(dVar4 + 6) = 0;
    *(undefined2 *)(dVar4 + 8) = 0;
    *(undefined2 *)(dVar4 + 10) = 0;
    *(undefined2 *)(dVar4 + 0xc) = 0;
    *(undefined2 *)(dVar4 + 0xe) = 0;
    sub_0800BCDC(0x37,1,0x6000000,0,0x10);
    if (*(uint *)DWORD_080027ac < 5) {
                    /* WARNING: Could not recover jumptable at 0x0800279c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*(uint *)DWORD_080027ac * 4 + DWORD_080027b0))();
      return;
    }
    sub_080003F0();
    sub_080003F0();
    *(undefined4 *)DWORD_08002850 = 0;
    bVar1 = true;
    bVar2 = false;
    *puStack_28 = 0;
    uStack_2e = 0;
    sub_08006C70(0xc5);
    uVar6 = 0;
    do {
      sub_080003F0();
      uVar6 = uVar6 + 1;
    } while (uVar6 < 0x14);
    iVar7 = sub_0801AB24();
    if (iVar7 == 0) {
      sub_0801AA34(6);
      puVar3 = (undefined4 *)DWORD_08002894;
    }
    else {
      sub_0801AB50(6);
      puVar3 = (undefined4 *)DWORD_08002894;
    }
    do {
      if (bVar2) {
        if ((*(ushort *)DWORD_08002898 & 0x80) == 0) {
          if ((*(ushort *)DWORD_08002898 & 0x40) == 0) {
            if ((*(ushort *)DWORD_080028dc & 1) != 0) {
              if (((*(ushort *)DWORD_080028e0 & 8) != 0) && (iVar7 = sub_08092080(), iVar7 != 0)) {
                *(undefined4 *)DWORD_08002864 = 3;
                sub_08006D08(0xf);
                break;
              }
              sub_08006D08(0xf);
              bVar1 = false;
            }
          }
          else {
            sub_08006D08(0xe);
            *puVar3 = 0;
          }
        }
        else {
          sub_08006D08(0xe);
          *puVar3 = 1;
        }
      }
      else if ((*(ushort *)DWORD_08002910 & 8) != 0) {
        bVar2 = true;
        sub_08006D08(0xf);
      }
      if (bVar2) {
        sub_08065230(auStack_64,0x78,0x82,0,*(undefined2 *)puVar3);
      }
      else {
        sub_08065370(auStack_64,4,puStack_28,&uStack_2e,1);
        sub_08065230(auStack_64,0x78,0x88,4,*puStack_28);
      }
      sub_080003F0();
    } while (bVar1);
    sub_08006C30(2);
    if (bVar2) {
      *puStack_28 = 0;
      uStack_2e = 0;
    }
    sub_0801ABE8(3);
    puVar5 = puStack_28;
    dVar4 = DWORD_08002960;
    while (iVar7 = sub_0801AAE0(), iVar7 == 0) {
      if (bVar2) {
        sub_08065370(auStack_64,*(int *)dVar4 + 1U & 0xffff,puVar5,&uStack_2e,1);
        sub_08065230(auStack_64,0x78,100,*(int *)dVar4 + 1U & 0xffff,*puVar5);
      }
      else {
        sub_08065370(auStack_64,4,puVar5,&uStack_2e,1);
        sub_08065230(auStack_64,0x78,0x70,4,*puVar5);
      }
      sub_08065230(auStack_64,0x78,0x5a,3,0);
      sub_080003F0();
    }
    sub_08065204(auStack_64);
    sub_0805F07C();
    iVar7 = *(int *)DWORD_08002a0c;
    if (iVar7 == 1) {
      iVar7 = sub_08002228();
      if (iVar7 == 0) {
        sub_0800208C(1);
      }
    }
    else {
      if (iVar7 != 0) {
        if (iVar7 == 2) {
          sub_08088914();
        }
        else if (iVar7 == 3) {
          sub_080920E4();
        }
        goto LAB_080026c0;
      }
      iVar7 = sub_08002228();
      if (iVar7 != 0) {
        sub_080020E0();
      }
      while (iVar7 = sub_08002228(), iVar7 != 0) {
        sub_080003F0();
      }
      sub_0800208C(0);
    }
    sub_080065B0();
  } while( true );
}


