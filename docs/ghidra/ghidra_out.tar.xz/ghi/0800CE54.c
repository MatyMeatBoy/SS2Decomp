
void sub_0800CE54(void)

{
  *(uint *)DWORD_0800ce60 = *(uint *)DWORD_0800ce60 & DWORD_0800ce64;
  return;
}


