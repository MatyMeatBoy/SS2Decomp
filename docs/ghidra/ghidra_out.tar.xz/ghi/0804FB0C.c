
undefined4 sub_0804FB0C(void)

{
  short sVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 in_lr;
  
  iVar2 = sub_080020F4();
  iVar2 = iVar2 * 0x14c + DWORD_0804fb4c;
  *(uint *)(iVar2 + 0x30) = *(uint *)(iVar2 + 0x30) | 1;
  sub_0800D0F4();
  iVar2 = sub_0800CB9C();
  if (iVar2 == 0) {
    if ((*(uint *)DWORD_0804fb50 & 0x20) == 0) {
      *(undefined4 *)DWORD_0804fb54 = 0xa5;
      sub_08006CB4();
    }
  }
  else {
    sub_080586B4(0);
  }
  iVar2 = sub_0800CC98();
  if (iVar2 == 0) {
    iVar2 = sub_0801AB24();
    if (iVar2 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar2 < 2) {
      if (iVar2 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar2 == 2) {
      sub_0801AB90(6);
    }
    while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
      sub_080003F0();
    }
  }
  sVar1 = 0x14;
  do {
    sub_080003F0();
    iVar2 = sub_080021A8();
    if (iVar2 != 0) break;
    sVar1 = sVar1 + -1;
  } while (sVar1 != 0);
  while (iVar2 = sub_0805F184(), iVar2 != 0) {
    sub_080003F0();
  }
  while (iVar2 = sub_0805EF90(), iVar2 != 0) {
    sub_080003F0();
  }
  uVar3 = sub_0805DF38(1,0xf,2,0,0x2d,DWORD_0804fbf0);
  while (iVar2 = sub_0805EEFC(uVar3), iVar2 == 0) {
    sub_080003F0();
  }
  *(ushort *)(*(int *)DWORD_0804fc34 + 4) = *(ushort *)(*(int *)DWORD_0804fc34 + 4) | 0x20;
  iVar2 = sub_080020F4();
  iVar2 = iVar2 * 0x14c + DWORD_0804fc38;
  *(uint *)(iVar2 + 0x30) = *(uint *)(iVar2 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


