
void sub_0805A704(void)

{
  *(ushort *)(*(int *)DWORD_0805a714 + 4) =
       (ushort)DWORD_0805a718 & *(ushort *)(*(int *)DWORD_0805a714 + 4);
  return;
}


