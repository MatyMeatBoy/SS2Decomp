
void sub_0800CD20(void)

{
  *(uint *)DWORD_0800cd30 = *(uint *)DWORD_0800cd30 & 0xffffffef;
  return;
}


