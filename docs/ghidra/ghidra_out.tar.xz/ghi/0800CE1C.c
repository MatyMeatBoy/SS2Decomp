
void sub_0800CE1C(void)

{
  *(uint *)DWORD_0800ce28 = *(uint *)DWORD_0800ce28 & DWORD_0800ce2c;
  return;
}


