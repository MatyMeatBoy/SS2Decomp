
void sub_08097A38(uint param_1)

{
  char *pcVar1;
  
  pcVar1 = (char *)((param_1 & 0xff) + DWORD_08097a48);
  *pcVar1 = *pcVar1 + '\x01';
  return;
}


