
undefined4 sub_0801A9BC(void)

{
  dword dVar1;
  int iVar2;
  undefined4 in_lr;
  
  dVar1 = DWORD_0801aa14;
  *(undefined2 *)(DWORD_0801aa14 + 0x40) = 0xbf;
  *(undefined2 *)(dVar1 + 0x44) = 0x10;
  *(undefined2 *)DWORD_0801aa18 = 0;
  *(undefined2 *)DWORD_0801aa1c = 0;
  *(undefined2 *)DWORD_0801aa20 = 0;
  *(undefined2 *)DWORD_0801aa24 = 0;
  *(undefined2 *)DWORD_0801aa28 = 0;
  sub_08000B50();
  iVar2 = sub_08001494(0x400);
  dVar1 = DWORD_0801aa2c;
  *(dword *)(DWORD_0801aa2c + 0xc) = DWORD_0801aa30;
  *(int *)(dVar1 + 0x10) = iVar2 + 0x3fc;
  *(int *)(dVar1 + 0x20) = iVar2;
  *(undefined4 *)(dVar1 + 8) = 1;
  *(undefined4 *)(dVar1 + 0x24) = 0;
  sub_08000274(dVar1,0);
  return in_lr;
}


