
uint sub_08058E3C(uint param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(*(int *)DWORD_08058e50 + 0x6c) & 1 << (param_1 & 0xff);
  if (uVar1 != 0) {
    uVar1 = 1;
  }
  return uVar1;
}


