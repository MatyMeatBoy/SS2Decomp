
undefined8 sub_08058240(void)

{
  int iVar1;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  return CONCAT44(in_lr,*(int *)(iVar1 * 0x14c + DWORD_0805825c + 0x8c) >> 8);
}


