
undefined8
sub_080072A0(int param_1,int param_2,uint param_3,uint param_4,byte param_5,char param_6,int param_7
            ,short param_8)

{
  ushort uVar1;
  ushort uVar2;
  dword dVar3;
  dword dVar4;
  undefined4 uVar5;
  int iVar6;
  undefined2 *puVar7;
  int iVar8;
  int iVar9;
  char *pcVar10;
  uint uVar11;
  undefined4 in_lr;
  
  dVar4 = DWORD_08007424;
  dVar3 = DWORD_08007420;
  if (*(uint *)DWORD_080072e0 < 0x81) {
    if (((param_3 & 0xffff) < (uint)*(ushort *)(param_7 + 2)) &&
       (iVar6 = (param_3 & 0xffff) * 0xc + param_7 + *(int *)(param_7 + 8),
       (param_4 & 0xffff) < (uint)*(ushort *)(iVar6 + 4))) {
      iVar6 = param_7 + *(int *)(param_7 + 4) +
              (uint)*(ushort *)(*(int *)(iVar6 + 8) + iVar6 + (param_4 & 0xffff) * 4) * 0xc;
      pcVar10 = (char *)(iVar6 + *(int *)(iVar6 + 8));
      uVar1 = *(ushort *)(pcVar10 + 4);
      puVar7 = (undefined2 *)(*(uint *)DWORD_080072e0 * 8 + DWORD_0800741c);
      uVar11 = 0;
      if (*(short *)(iVar6 + 2) != 0) {
        do {
          *puVar7 = *(undefined2 *)pcVar10;
          puVar7[1] = *(undefined2 *)(pcVar10 + 2);
          puVar7[2] = *(undefined2 *)(pcVar10 + 4);
          iVar8 = *pcVar10 + param_2;
          iVar9 = ((int)((uint)*(ushort *)(pcVar10 + 2) << 0x17) >> 0x17) + param_1;
          *(byte *)((int)puVar7 + 5) =
               *(byte *)((int)puVar7 + 5) & 3 | (param_5 & 3) << 2 | param_6 << 4;
          if (0x130 < iVar9 + 0x40U) {
            *(byte *)((int)puVar7 + 1) = *(byte *)((int)puVar7 + 1) & 0x3f;
            *(byte *)((int)puVar7 + 3) = *(byte *)((int)puVar7 + 3) & 0x3f;
            iVar8 = 0xa0;
          }
          if (0xe0 < iVar8 + 0x40U) {
            *(byte *)((int)puVar7 + 1) = *(byte *)((int)puVar7 + 1) & 0x3f;
            *(byte *)((int)puVar7 + 3) = *(byte *)((int)puVar7 + 3) & 0x3f;
            iVar8 = 0xa0;
          }
          puVar7[1] = (ushort)DWORD_0800742c & puVar7[1] | (ushort)iVar9 & (ushort)DWORD_08007428;
          *(char *)puVar7 = (char)iVar8;
          uVar2 = (puVar7[2] & 0x3ff) - (uVar1 & 0x3ff) & (ushort)dVar3;
          puVar7[2] = ((ushort)dVar4 & puVar7[2] | uVar2) & (ushort)dVar4 |
                      param_8 + uVar2 & (ushort)dVar3;
          iVar8 = *(int *)DWORD_08007430;
          *(uint *)DWORD_08007430 = iVar8 + 1U;
          if (0x80 < iVar8 + 1U) goto LAB_080072da;
          uVar11 = uVar11 + 1;
          puVar7 = puVar7 + 4;
          pcVar10 = pcVar10 + 8;
        } while (uVar11 < *(ushort *)(iVar6 + 2));
      }
    }
    uVar5 = 1;
  }
  else {
LAB_080072da:
    uVar5 = 0;
  }
  return CONCAT44(in_lr,uVar5);
}


