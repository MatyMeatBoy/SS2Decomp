
undefined4 sub_080B4B7C(void)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  iVar2 = *(int *)DWORD_080b4bb4;
  if (iVar2 != 0) {
    uVar4 = 0;
    do {
      iVar3 = sub_08000470(iVar2);
      if (iVar3 != 0) {
        sub_080003A8(iVar2);
      }
      dVar1 = DWORD_080b4bb4;
      iVar2 = iVar2 + 0x28;
      uVar4 = uVar4 + 1;
    } while (uVar4 < 4);
    sub_08001538(*(undefined4 *)DWORD_080b4bb4);
    *(undefined4 *)dVar1 = 0;
  }
  return in_lr;
}


