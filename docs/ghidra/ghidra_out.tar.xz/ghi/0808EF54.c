
undefined8 sub_0808EF54(undefined4 param_1)

{
  dword dVar1;
  int iVar2;
  undefined4 uVar3;
  uint *puVar4;
  undefined4 in_lr;
  
  dVar1 = DWORD_0808efb8;
  if (*(short *)(*(int *)DWORD_0808efb8 + 0x10) == 0) {
    sub_0800CD9C();
    sub_0802704C(param_1);
    sub_0801674C(DWORD_0808efe4,DWORD_0808efe8);
    sub_0800CD9C();
  }
  else {
    iVar2 = sub_08056E90();
    if (iVar2 != 0) {
      sub_08056FB8(0,2);
      sub_08056E78();
      sub_0800CDAC();
      *(undefined2 *)(*(int *)dVar1 + 0x36) = 3;
      sub_08057BD0(*(undefined2 *)(DWORD_0808efbc + 0x8c));
      iVar2 = sub_080020F4();
      dVar1 = DWORD_0808efc0;
      puVar4 = (uint *)(iVar2 * 0x14c + DWORD_0808efc0 + 0x30);
      *puVar4 = *puVar4 & 0xfffffffd;
      iVar2 = sub_080020F4();
      *(undefined2 *)(iVar2 * 0x14c + dVar1 + 0x20) = 0;
      uVar3 = 1;
      goto LAB_0808efdc;
    }
  }
  uVar3 = 0;
LAB_0808efdc:
  return CONCAT44(in_lr,uVar3);
}


