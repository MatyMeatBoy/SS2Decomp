
undefined4 sub_08015D74(void)

{
  int iVar1;
  uint *puVar2;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  puVar2 = (uint *)(iVar1 * 0x14c + DWORD_08015d94 + 0x30);
  *puVar2 = *puVar2 | 0x1000;
  return in_lr;
}


