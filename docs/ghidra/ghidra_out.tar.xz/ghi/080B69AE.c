
undefined4 sub_080B69AE(undefined4 param_1,int param_2,int param_3)

{
  *(int *)(param_2 + 0x40) = param_3 + 1;
  return param_1;
}


