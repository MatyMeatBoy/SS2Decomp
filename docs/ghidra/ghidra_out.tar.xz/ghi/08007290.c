
void sub_08007290(undefined4 param_1)

{
  sub_08006EE0(param_1,DWORD_0800729c);
  return;
}


