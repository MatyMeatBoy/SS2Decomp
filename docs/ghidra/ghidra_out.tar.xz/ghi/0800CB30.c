
void sub_0800CB30(void)

{
  *(undefined4 *)DWORD_0800cb38 = 0;
  return;
}


