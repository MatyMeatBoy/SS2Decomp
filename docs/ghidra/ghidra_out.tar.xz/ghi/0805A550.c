
undefined4 sub_0805A550(short *param_1,int param_2)

{
  dword dVar1;
  undefined4 in_lr;
  
  dVar1 = DWORD_0805a584;
  if (*param_1 != 0) {
    *(short **)(*(int *)DWORD_0805a584 + DWORD_0805a588 + param_2 * 4) = param_1;
    sub_08023ED8(param_1,param_2);
    *(short *)(*(int *)dVar1 + 10) = *(short *)(*(int *)dVar1 + 10) + 1;
  }
  return in_lr;
}


