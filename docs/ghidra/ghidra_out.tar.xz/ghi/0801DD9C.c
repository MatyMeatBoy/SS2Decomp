
undefined4 sub_0801DD9C(void)

{
  int iVar1;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  sub_0801E024(iVar1 * 0x14c + DWORD_0801ddb4);
  return in_lr;
}


