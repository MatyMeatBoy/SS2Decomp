
undefined4 sub_080257D4(undefined4 param_1,int param_2)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 in_lr;
  
  dVar1 = DWORD_08025810;
  iVar4 = DWORD_08025814 + param_2 * 0x28;
  iVar2 = sub_08000470(*(int *)DWORD_08025810 + iVar4);
  if (iVar2 != 0) {
    sub_080003A8(*(int *)dVar1 + iVar4);
  }
  *(dword *)(*(int *)dVar1 + DWORD_08025818 + param_2 * 0x28) = DWORD_0802581c;
  while( true ) {
    iVar2 = sub_08001494(0x400);
    iVar3 = *(int *)DWORD_0802587c;
    iVar4 = param_2 * 0x28;
    *(int *)(iVar3 + DWORD_08025880 + iVar4) = iVar2;
    dVar1 = DWORD_08025884;
    if (iVar2 != 0) break;
    sub_080003F0();
  }
  *(int *)(iVar3 + DWORD_08025884 + iVar4) = iVar2 + 0x3fc;
  *(undefined4 *)(iVar3 + DWORD_08025888 + iVar4) = 0x46;
  *(undefined4 *)(iVar3 + dVar1 + 0x14 + iVar4) = 0;
  sub_08000274(iVar3 + iVar4 + DWORD_0802588c,param_1);
  return in_lr;
}


