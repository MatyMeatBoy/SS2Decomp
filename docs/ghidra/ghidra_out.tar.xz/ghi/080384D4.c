
undefined4 sub_080384D4(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_08038510;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) | 1;
  sub_0800D0F4();
  sub_0802949C(param_1,0);
  iVar1 = sub_0800CE30();
  if (iVar1 == 0) {
    uVar4 = *(uint *)(*(int *)DWORD_08038530 + 0x74);
  }
  else {
    uVar4 = *(uint *)(*(int *)DWORD_08038514 + 0x7c);
  }
  iVar1 = sub_0800CE30();
  if (iVar1 == 0) {
    iVar1 = *(int *)DWORD_0803854c;
    iVar3 = 0x1ba;
  }
  else {
    iVar1 = *(int *)DWORD_08038530;
    iVar3 = 0x1c6;
  }
  if (((int)(uint)*(byte *)(iVar1 + iVar3) >> 2 & 1U) == 0) {
    if ((uVar4 & 0x100) == 0) {
      if ((uVar4 & 0x80) == 0) {
        if ((uVar4 & 0x40) == 0) {
          if ((uVar4 & 0x20) == 0) {
            if ((uVar4 & 0x10) == 0) {
              if ((uVar4 & 8) == 0) {
                if ((uVar4 & 4) == 0) {
                  if ((uVar4 & 2) == 0) {
                    if ((uVar4 & 1) == 0) {
                      while (iVar1 = sub_0805F184(), iVar1 != 0) {
                        sub_080003F0();
                      }
                      while (iVar1 = sub_0805EF90(), iVar1 != 0) {
                        sub_080003F0();
                      }
                      uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803893c);
                      while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
                        iVar1 = sub_0800CDF8();
                        if (iVar1 != 0) {
                          sub_0805EFBC();
                          break;
                        }
                        sub_080003F0();
                      }
                    }
                    else {
                      while (iVar1 = sub_0805F184(), iVar1 != 0) {
                        sub_080003F0();
                      }
                      while (iVar1 = sub_0805EF90(), iVar1 != 0) {
                        sub_080003F0();
                      }
                      uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_080388e8);
                      while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
                        iVar1 = sub_0800CDF8();
                        if (iVar1 != 0) {
                          sub_0805EFBC();
                          break;
                        }
                        sub_080003F0();
                      }
                    }
                  }
                  else {
                    while (iVar1 = sub_0805F184(), iVar1 != 0) {
                      sub_080003F0();
                    }
                    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
                      sub_080003F0();
                    }
                    uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08038888);
                    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
                      iVar1 = sub_0800CDF8();
                      if (iVar1 != 0) {
                        sub_0805EFBC();
                        break;
                      }
                      sub_080003F0();
                    }
                  }
                }
                else {
                  while (iVar1 = sub_0805F184(), iVar1 != 0) {
                    sub_080003F0();
                  }
                  while (iVar1 = sub_0805EF90(), iVar1 != 0) {
                    sub_080003F0();
                  }
                  uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08038828);
                  while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
                    iVar1 = sub_0800CDF8();
                    if (iVar1 != 0) {
                      sub_0805EFBC();
                      break;
                    }
                    sub_080003F0();
                  }
                }
              }
              else {
                while (iVar1 = sub_0805F184(), iVar1 != 0) {
                  sub_080003F0();
                }
                while (iVar1 = sub_0805EF90(), iVar1 != 0) {
                  sub_080003F0();
                }
                uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_080387c8);
                while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
                  iVar1 = sub_0800CDF8();
                  if (iVar1 != 0) {
                    sub_0805EFBC();
                    break;
                  }
                  sub_080003F0();
                }
              }
            }
            else {
              while (iVar1 = sub_0805F184(), iVar1 != 0) {
                sub_080003F0();
              }
              while (iVar1 = sub_0805EF90(), iVar1 != 0) {
                sub_080003F0();
              }
              uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08038768);
              while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
                iVar1 = sub_0800CDF8();
                if (iVar1 != 0) {
                  sub_0805EFBC();
                  break;
                }
                sub_080003F0();
              }
            }
          }
          else {
            while (iVar1 = sub_0805F184(), iVar1 != 0) {
              sub_080003F0();
            }
            while (iVar1 = sub_0805EF90(), iVar1 != 0) {
              sub_080003F0();
            }
            uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08038708);
            while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
              iVar1 = sub_0800CDF8();
              if (iVar1 != 0) {
                sub_0805EFBC();
                break;
              }
              sub_080003F0();
            }
          }
        }
        else {
          while (iVar1 = sub_0805F184(), iVar1 != 0) {
            sub_080003F0();
          }
          while (iVar1 = sub_0805EF90(), iVar1 != 0) {
            sub_080003F0();
          }
          uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_080386a8);
          while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
            iVar1 = sub_0800CDF8();
            if (iVar1 != 0) {
              sub_0805EFBC();
              break;
            }
            sub_080003F0();
          }
        }
      }
      else {
        while (iVar1 = sub_0805F184(), iVar1 != 0) {
          sub_080003F0();
        }
        while (iVar1 = sub_0805EF90(), iVar1 != 0) {
          sub_080003F0();
        }
        uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08038648);
        while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
          iVar1 = sub_0800CDF8();
          if (iVar1 != 0) {
            sub_0805EFBC();
            break;
          }
          sub_080003F0();
        }
      }
    }
    else {
      while (iVar1 = sub_0805F184(), iVar1 != 0) {
        sub_080003F0();
      }
      while (iVar1 = sub_0805EF90(), iVar1 != 0) {
        sub_080003F0();
      }
      uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_080385e8);
      while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
        iVar1 = sub_0800CDF8();
        if (iVar1 != 0) {
          sub_0805EFBC();
          break;
        }
        sub_080003F0();
      }
    }
  }
  else {
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08038584);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      iVar1 = sub_0800CDF8();
      if (iVar1 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
  }
  sub_08029788(param_1);
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_08038988;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & 0xfffffffe;
  sub_0800D108();
  return in_lr;
}


