
undefined4 sub_08099468(undefined4 param_1,int param_2)

{
  undefined1 uVar1;
  ushort uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  dword dVar6;
  ushort *puVar7;
  dword dVar8;
  int iVar9;
  int iVar10;
  undefined4 in_lr;
  undefined4 auStack_70 [2];
  undefined4 uStack_68;
  int iStack_64;
  undefined1 uStack_54;
  undefined1 uStack_53;
  short sStack_3c;
  short sStack_3a;
  undefined2 uStack_38;
  undefined1 auStack_36 [2];
  int iStack_34;
  int iStack_30;
  dword dStack_2c;
  short *psStack_28;
  short *psStack_24;
  
  dVar8 = DWORD_080994ac;
  dVar6 = DWORD_080994a8;
  param_2 = param_2 + -1;
  if ((param_2 == 0) || (param_2 == 4)) {
    iStack_30 = __divsi3(*(short *)((uint)*(ushort *)(param_2 * 2 + DWORD_080994ac) * 2 +
                                   DWORD_080994a8) * 0x180,0x130);
  }
  else {
    iStack_30 = *(short *)((uint)*(ushort *)(param_2 * 2 + DWORD_08099704) * 2 + DWORD_08099700) *
                0x180;
    if (iStack_30 < 0) {
      iStack_30 = iStack_30 + 0xff;
    }
    iStack_30 = iStack_30 >> 8;
    dVar6 = DWORD_08099700;
    dVar8 = DWORD_08099704;
  }
  iStack_34 = *(short *)((*(ushort *)(param_2 * 2 + dVar8) + 0x40) * 2 + dVar6) * 0x180;
  if (iStack_34 < 0) {
    iStack_34 = iStack_34 + 0xff;
  }
  iStack_34 = iStack_34 >> 8;
  iVar9 = *(int *)(*(int *)DWORD_08099708 + 0x14);
  iVar3 = *(int *)(*(int *)DWORD_08099708 + 0x18);
  sub_08065158(auStack_70,DWORD_0809970c,5,0xffffffff,0);
  sub_08000AF0(0x15,iStack_64 + 0x20,1);
  uStack_53 = 5;
  dStack_2c = DWORD_08099710;
  psStack_28 = &sStack_3c;
  psStack_24 = &sStack_3a;
  do {
    iVar9 = iVar9 + iStack_34;
    iVar3 = iVar3 + iStack_30;
    sub_0800BC08((int)(short)((uint)iVar9 >> 8),(int)(short)((uint)iVar3 >> 8),psStack_28,psStack_24
                 ,0,0);
    iVar4 = sub_0800CC98();
    if ((((iVar4 == 0) && (iVar4 = sub_0800CD8C(), iVar4 == 0)) &&
        (iVar4 = sub_0800CCCC(), iVar4 == 0)) && (iVar4 = sub_0800CD34(), iVar4 == 0)) {
      sub_08065370(auStack_70,10,&uStack_38,auStack_36,1);
      uVar1 = sub_0800BC44(iVar9 >> 8,iVar3 >> 8,0);
      sub_08007870((int)*psStack_28,(int)*psStack_24,10,uStack_38,uVar1,&uStack_54,uStack_68,
                   auStack_70[0]);
    }
    iVar4 = sub_080020F4();
    dVar6 = DWORD_08099714;
    iVar10 = *(int *)(iVar4 * 0x14c + DWORD_08099714 + 0x8c);
    iVar4 = sub_080020F4();
    iVar10 = (iVar9 - iVar10) * 0x100 >> 0x10;
    iVar4 = (iVar3 - *(int *)(iVar4 * 0x14c + dVar6 + 0x90)) * 0x100 >> 0x10;
    uVar2 = Sqrt(iVar10 * iVar10 + iVar4 * iVar4);
    if ((((uVar2 < 0x14) && (iVar4 = sub_0800CDF8(), iVar4 == 0)) &&
        ((iVar4 = sub_0800CCCC(), iVar4 == 0 &&
         ((iVar4 = sub_0800CD8C(), dVar8 = DWORD_08099708, iVar4 == 0 &&
          (*(short *)(*(int *)DWORD_08099708 + 0xc) != 0xb)))))) &&
       ((iVar4 = sub_080020F4(), (*(uint *)(iVar4 * 0x14c + dVar6 + 0x30) & 0x2000) == 0 &&
        ((((iVar4 = sub_080020F4(), *(char *)(iVar4 * 0x14c + dVar6 + 0x68) != '\0' &&
           (iVar4 = sub_080020F4(), *(short *)(iVar4 * 0x14c + dVar6 + 0x20) != 0xe)) &&
          (iVar4 = sub_080020F4(), *(short *)(iVar4 * 0x14c + dVar6 + 0x20) != 0xb)) &&
         (iVar4 = sub_080020F4(), *(short *)(iVar4 * 0x14c + dVar6 + 0x20) != 0xc)))))) {
      iVar4 = sub_080020F4();
      puVar7 = *(ushort **)dVar8;
      if (*(int *)((uint)*puVar7 * 4 + iVar4 * 0x14c + dVar6 + 0xe4) != *(int *)(puVar7 + 0x28)) {
        sub_08029CEC(1,0x1e,5);
        iVar4 = sub_080020F4();
        *(short *)(iVar4 * 0x14c + dVar6 + 0xb0) = (short)DWORD_08099718;
        iVar4 = sub_080020F4();
        puVar7 = *(ushort **)dVar8;
        *(undefined4 *)((uint)*puVar7 * 4 + iVar4 * 0x14c + dVar6 + 0xe4) =
             *(undefined4 *)(puVar7 + 0x28);
      }
    }
    sub_080003F0();
    uVar5 = dStack_2c * 0x10000 + DWORD_0809971c;
    dStack_2c = uVar5 >> 0x10;
  } while ((int)uVar5 >> 0x10 != -1);
  iVar3 = sub_0800048C();
  *(undefined4 *)(iVar3 + 8) = 0;
  return in_lr;
}


