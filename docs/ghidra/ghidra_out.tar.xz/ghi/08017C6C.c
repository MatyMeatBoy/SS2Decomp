
undefined4 sub_08017C6C(ushort *param_1)

{
  ushort uVar1;
  dword dVar2;
  short sVar3;
  short sVar4;
  ushort uVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  ushort *puVar10;
  int iVar11;
  int iVar12;
  undefined4 in_lr;
  
  iVar6 = *(int *)(param_1 + 10);
  iVar8 = *(int *)(param_1 + 0xc);
  uVar5 = param_1[0x3b];
  if (uVar5 < 5) {
    if ((*(uint *)DWORD_08017e10 & 1) != (*param_1 & 1)) {
      return in_lr;
    }
    puVar10 = param_1 + 0x3d;
    uVar1 = (ushort)DWORD_08017e14 & *puVar10;
    *puVar10 = uVar1;
    if ((((*(byte *)((int)param_1 + DWORD_08017e18) != 0) && (*(int *)(param_1 + 0x108) != 0xff)) &&
        (iVar9 = *(int *)DWORD_08017e1c + (short)uVar5 * 0x2e0,
        (*(uint *)DWORD_08017e20 & 1 << ((int)(short)uVar5 & 0xffU)) != 0)) &&
       ((param_1[6] != 0xb &&
        (sVar3 = (ushort)*(byte *)(iVar9 + DWORD_08017e18) +
                 (ushort)*(byte *)((int)param_1 + DWORD_08017e18), sVar3 != 0)))) {
      iVar12 = (iVar6 - *(int *)(iVar9 + 0x14)) * 0x100 >> 0x10;
      iVar11 = iVar12;
      if (iVar12 < 0) {
        iVar11 = -iVar12;
      }
      if (iVar11 < 8) {
        iVar11 = (iVar8 - *(int *)(iVar9 + 0x18)) * 0x100 >> 0x10;
        iVar9 = iVar11;
        if (iVar11 < 0) {
          iVar9 = -iVar11;
        }
        if (iVar9 < 8) {
          *puVar10 = uVar1 | 0x10;
          sVar4 = Sqrt(iVar12 * iVar12 + iVar11 * iVar11);
          iVar9 = ArcTan2(iVar12,iVar11);
          dVar2 = DWORD_08017e24;
          uVar7 = ((uint)(iVar9 << 0x10) >> 0x18) << 0x10;
          iVar9 = (int)uVar7 >> 0x10;
          iVar11 = ((int)sVar3 - (int)sVar4) * 0x10000 >> 0x11;
          uVar7 = sub_0800B118(*(undefined1 *)((uVar7 >> 0x14) + DWORD_08017e28),
                               iVar6 + iVar11 * *(short *)((iVar9 + 0x40) * 2 + DWORD_08017e24),
                               iVar8 + iVar11 * *(short *)(iVar9 * 2 + DWORD_08017e24),0);
          if ((uVar7 & 0xffff) != 0) {
            iVar9 = (int)((uint)*(ushort *)
                                 (((int)(uVar7 * 0x10000 + DWORD_08017e30) >> 0xf) + DWORD_08017e2c)
                         << 0x14) >> 0x10;
            sVar3 = *(short *)(iVar9 * 2 + dVar2);
            *(int *)(param_1 + 10) = iVar6 + iVar11 * *(short *)((iVar9 + 0x40) * 2 + dVar2);
            *(int *)(param_1 + 0xc) = iVar8 + iVar11 * sVar3;
          }
        }
      }
    }
    uVar5 = param_1[0x3b] + 1;
    param_1[0x3b] = uVar5;
    if (uVar5 < 6) {
      return in_lr;
    }
  }
  param_1[0x3b] = *param_1 + 1;
  return in_lr;
}


