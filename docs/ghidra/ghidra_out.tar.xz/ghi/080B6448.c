
undefined4 sub_080B6448(undefined4 param_1,undefined4 param_2)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  undefined4 in_lr;
  
  dVar1 = DWORD_080b649c;
  if (((*(int *)DWORD_080b649c != 0) && (iVar2 = sub_08000470(), iVar2 == 0)) &&
     (*(int *)(*(int *)dVar1 + 8) == 0)) {
    iVar2 = sub_08001494(0x400);
    iVar3 = *(int *)dVar1;
    *(int *)(iVar3 + 0x20) = iVar2;
    if (iVar2 != 0) {
      *(int *)(iVar3 + 0x10) = iVar2 + 0x3fc;
      *(dword *)(iVar3 + 0xc) = DWORD_080b64a0;
      *(undefined4 *)(iVar3 + 0x24) = 0;
      *(undefined4 *)(iVar3 + 8) = 0x3b;
      sub_08000274(iVar3,param_1,param_2,0);
    }
  }
  return in_lr;
}


