
undefined4 sub_0809C8F4(ushort *param_1)

{
  dword dVar1;
  dword dVar2;
  ushort uVar3;
  short sVar4;
  int iVar5;
  undefined4 uVar6;
  short *psVar7;
  undefined4 uVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  undefined4 in_lr;
  undefined4 auStack_68 [2];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined1 auStack_4c [24];
  short sStack_34;
  short sStack_32;
  undefined2 uStack_30;
  undefined1 auStack_2e [2];
  uint uStack_2c;
  int iStack_28;
  short *psStack_24;
  
  sub_08065158(auStack_68,DWORD_0809cb74,0,0xffffffff,1);
  dVar1 = DWORD_0809cb7c;
  auStack_4c[0] = (undefined1)*(undefined2 *)DWORD_0809cb78;
  iStack_28 = 0;
  uStack_2c = 0xb4;
  psStack_24 = &sStack_32;
  do {
    iVar5 = sub_0800CCCC();
    if ((((iVar5 == 0) && (iVar5 = sub_0800CC98(), iVar5 == 0)) &&
        (iVar5 = sub_0800CD8C(), iVar5 == 0)) &&
       ((iVar5 = sub_0800CD34(), iVar5 == 0 && ((uStack_2c & 1) != 0)))) {
      sub_08000AF0(*(ushort *)DWORD_0809cb78 + 0x10,uStack_5c,1);
      sub_0800BC08((*(int *)(param_1 + 10) << 8) >> 0x10,(*(int *)(param_1 + 0xc) << 8) >> 0x10,
                   &sStack_34,psStack_24,0,0);
      sub_08065370(auStack_68,0x19,&uStack_30,auStack_2e,1);
      iVar5 = sub_08007870((int)sStack_34,*psStack_24 + 1,0x19,uStack_30,0,auStack_4c,uStack_60,
                           auStack_68[0]);
      *(int *)(iVar5 + 0xc) = *psStack_24 + -0x17;
    }
    uVar8 = *(undefined4 *)(param_1 + 10);
    iVar11 = *(int *)(param_1 + 0xc);
    iVar5 = sub_080020F4();
    dVar2 = DWORD_0809cb7c;
    uVar6 = *(undefined4 *)(iVar5 * 0x14c + DWORD_0809cb80);
    iVar5 = sub_080020F4();
    iVar9 = (int)(short)((short)((uint)uVar8 >> 8) - (short)((uint)uVar6 >> 8));
    iVar5 = ((iVar11 >> 8) - (*(int *)(iVar5 * 0x14c + DWORD_0809cb84) >> 8)) * 0x10000 >> 0x10;
    uVar3 = Sqrt(iVar9 * iVar9 + iVar5 * iVar5);
    if (((((iStack_28 == 0) && (uVar3 < 0x30)) &&
         ((iVar5 = sub_0800CDF8(), iVar5 == 0 &&
          (((iVar5 = sub_0800CD8C(), iVar5 == 0 && (iVar5 = sub_0800CCCC(), iVar5 == 0)) &&
           (param_1[6] != 0xb)))))) &&
        ((iVar5 = sub_080020F4(), (*(uint *)(iVar5 * 0x14c + dVar2 + 0x30) & 0x2000) == 0 &&
         (iVar5 = sub_080020F4(), *(char *)(iVar5 * 0x14c + dVar2 + 0x68) != '\0')))) &&
       ((iVar5 = sub_080020F4(), *(short *)(iVar5 * 0x14c + dVar2 + 0x20) != 0xe &&
        ((iVar5 = sub_080020F4(), *(short *)(iVar5 * 0x14c + dVar2 + 0x20) != 0xb &&
         (iVar5 = sub_080020F4(), *(short *)(iVar5 * 0x14c + dVar2 + 0x20) != 0xc)))))) {
      iVar5 = sub_080020F4();
      if (*(int *)((uint)*param_1 * 4 + iVar5 * 0x14c + dVar2 + 0xe4) != *(int *)(param_1 + 0x28)) {
        iStack_28 = 1;
        iVar5 = sub_080020F4();
        *(short *)(iVar5 * 0x14c + dVar2 + 0xb0) = (short)DWORD_0809cb88;
        iVar5 = sub_080020F4();
        *(undefined2 *)(iVar5 * 0x14c + dVar2 + 0x20) = 10;
        iVar5 = sub_080020F4();
        iVar9 = sub_080020F4();
        sVar4 = sub_0801ED8C(param_1,iVar9 * 0x14c + dVar2);
        psVar7 = (short *)(iVar5 * 0x14c + dVar2 + 0x88);
        *psVar7 = sVar4 + *psVar7;
        iVar5 = sub_080020F4();
        iVar9 = *(int *)(param_1 + 0x28);
        *(int *)((uint)*param_1 * 4 + iVar5 * 0x14c + dVar2 + 0xe4) = iVar9;
        *(int *)(param_1 + 0x28) = iVar9 + 1;
        iVar5 = sub_080020F4();
        uVar8 = *(undefined4 *)(iVar5 * 0x14c + DWORD_0809cb80);
        uVar6 = *(undefined4 *)(param_1 + 10);
        iVar5 = sub_080020F4();
        iVar5 = ArcTan2((int)(short)((short)((uint)uVar8 >> 8) - (short)((uint)uVar6 >> 8)),
                        ((*(int *)(iVar5 * 0x14c + DWORD_0809cb84) >> 8) -
                        (*(int *)(param_1 + 0xc) >> 8)) * 0x10000 >> 0x10);
        uVar10 = (uint)(iVar5 << 0x10) >> 0x1d;
        if (0x80000000 < (uint)(iVar5 * 0x80000)) {
          if (uVar10 < 7) {
            uVar10 = uVar10 + 1;
          }
          else {
            uVar10 = 0;
          }
        }
        if (uVar10 == 0) {
          iVar5 = sub_080020F4();
          psVar7 = (short *)(iVar5 * 0x14c + dVar1 + 0xca);
          sVar4 = 6;
        }
        else if (uVar10 == 1) {
          iVar5 = sub_080020F4();
          psVar7 = (short *)(iVar5 * 0x14c + dVar1 + 0xca);
          sVar4 = 7;
        }
        else {
          iVar5 = sub_080020F4();
          sVar4 = (short)uVar10 + -2;
          psVar7 = (short *)(iVar5 * 0x14c + dVar1 + 0xca);
        }
        *psVar7 = sVar4;
        iVar5 = sub_080020F4();
        *(undefined2 *)(iVar5 * 0x14c + dVar1 + 0xcc) = 0x400;
        iVar5 = sub_080020F4();
        *(undefined2 *)(iVar5 * 0x14c + dVar1 + 200) = 8;
        sub_0805865C(0xe2);
      }
    }
    sub_080003F0();
    uStack_2c = uStack_2c - 1 & 0xffff;
  } while (uStack_2c != DWORD_0809cc28);
  iVar5 = sub_0800048C();
  *(undefined4 *)(iVar5 + 8) = 0;
  return in_lr;
}


