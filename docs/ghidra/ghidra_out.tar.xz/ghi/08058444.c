
undefined4 sub_08058444(int param_1,int param_2,uint param_3,int param_4)

{
  int iVar1;
  int iVar2;
  undefined4 in_lr;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  
  uStack_18 = 0;
  iStack_20 = param_1 << 8;
  iStack_1c = param_2 << 8;
  uStack_14 = param_3 & 0xffff | param_4 << 0x10;
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_08058474;
  while (iVar2 = sub_08021FE0(iVar1 + 0x8c,&iStack_20,&uStack_18,&uStack_14), iVar2 == 0) {
    sub_080003F0();
  }
  return in_lr;
}


