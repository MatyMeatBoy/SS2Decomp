
undefined4 sub_0800CB3C(undefined4 param_1)

{
  dword dVar1;
  int iVar2;
  undefined4 in_lr;
  
  dVar1 = DWORD_0800cb70;
  *(dword *)(DWORD_0800cb70 + 0xc) = DWORD_0800cb74;
  iVar2 = sub_08001494(0x400);
  *(int *)(dVar1 + 0x20) = iVar2;
  *(int *)(dVar1 + 0x10) = iVar2 + 0x3fc;
  *(undefined4 *)(dVar1 + 8) = 100;
  *(undefined4 *)(dVar1 + 0x24) = 0;
  sub_08000274(dVar1,param_1);
  return in_lr;
}


