
undefined4 sub_080443EC(void)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 in_lr;
  
  iVar1 = sub_0800CE30();
  if (iVar1 == 0) {
    iVar1 = *(int *)DWORD_0804443c;
    iVar3 = 0x1ba;
  }
  else {
    iVar1 = *(int *)DWORD_08044404;
    iVar3 = 0x1c6;
  }
  if (((int)(uint)*(byte *)(iVar1 + iVar3) >> 4 & 1U) == 0) {
    iVar1 = sub_080020F4();
    iVar1 = iVar1 * 0x14c + DWORD_08044440;
    *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) | 1;
    sub_0800D0F4();
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_08044478);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      iVar1 = sub_0800CDF8();
      if (iVar1 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
    iVar1 = sub_080020F4();
    iVar1 = iVar1 * 0x14c + DWORD_080444bc;
    *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & 0xfffffffe;
    sub_0800D108();
  }
  return in_lr;
}


