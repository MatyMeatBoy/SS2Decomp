
undefined4 sub_0805817C(int param_1,undefined4 param_2,uint param_3)

{
  uint uVar1;
  undefined4 in_lr;
  undefined2 uStack_38;
  undefined2 uStack_36;
  undefined1 auStack_34 [12];
  undefined2 auStack_28 [2];
  undefined4 uStack_24;
  
  if (param_1 == 10) {
    uVar1 = 0;
    if (param_3 != 0) {
      do {
        auStack_28[0] = 10;
        uStack_24 = param_2;
        sub_0805AB20(auStack_28);
        uVar1 = uVar1 + 1;
      } while (uVar1 < param_3);
    }
  }
  else {
    uStack_38 = (undefined2)param_1;
    uStack_36 = (undefined2)param_2;
    uVar1 = 0;
    do {
      auStack_34[uVar1] = 0;
      uVar1 = uVar1 + 1;
    } while (uVar1 < 0xc);
    uVar1 = 0;
    if (param_3 != 0) {
      do {
        sub_0805AB20(&uStack_38);
        uVar1 = uVar1 + 1;
      } while (uVar1 < param_3);
    }
  }
  return in_lr;
}


