
undefined8 sub_08096AF4(int *param_1,char param_2)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  short sVar4;
  undefined4 in_lr;
  
  sVar4 = 0;
  iVar2 = sub_0800CCCC();
  if ((((iVar2 != 0) || (iVar2 = sub_0800CC98(), iVar2 != 0)) ||
      (iVar2 = sub_0800CD8C(), iVar2 != 0)) ||
     (iVar2 = sub_0800CD34(), dVar1 = DWORD_08096b50, iVar2 != 0)) goto LAB_08096b9e;
  if (param_2 == '\0') {
    iVar2 = *param_1 + DWORD_08096b8c;
    if (iVar2 < 0) {
      iVar2 = -iVar2;
    }
    iVar3 = iVar2 * *(short *)((((uint)*(byte *)(DWORD_08096b90 + 0xe) -
                                (uint)*(byte *)(DWORD_08096b90 + 0xd)) * 0x1000000 >> 0x17) +
                              DWORD_08096b94) >> 8;
    if (*param_1 < 0x8001) goto LAB_08096b98;
    iVar3 = param_1[1] - iVar3;
  }
  else {
    iVar2 = *param_1 + *(char *)(DWORD_08096b50 + 0xd) * 0x10;
    *param_1 = iVar2;
    iVar2 = 0x8000 - iVar2;
    iVar3 = iVar2 * *(short *)((((uint)*(byte *)(dVar1 + 0xe) - (uint)*(byte *)(dVar1 + 0xd)) *
                                0x1000000 >> 0x17) + DWORD_08096b54) >> 8;
LAB_08096b98:
    iVar3 = param_1[1] + iVar3;
  }
  sVar4 = (short)iVar2;
  param_1[1] = iVar3;
LAB_08096b9e:
  return CONCAT44(in_lr,(int)sVar4);
}


