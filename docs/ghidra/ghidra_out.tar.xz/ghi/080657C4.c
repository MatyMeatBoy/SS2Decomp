
undefined4 sub_080657C4(undefined4 param_1,int param_2)

{
  int iVar1;
  dword dVar2;
  int iVar3;
  uint uVar4;
  undefined4 in_lr;
  
  iVar3 = *(int *)DWORD_080657d4;
  uVar4 = 0;
  while( true ) {
    if (3 < uVar4) {
      return in_lr;
    }
    iVar1 = sub_08000470(iVar3);
    if (iVar1 == 0) break;
    uVar4 = uVar4 + 1;
    iVar3 = iVar3 + 0x28;
  }
  while( true ) {
    iVar1 = sub_08001494(0x400);
    *(int *)(iVar3 + 0x20) = iVar1;
    if (iVar1 != 0) break;
    sub_080003F0();
  }
  *(undefined4 *)(iVar3 + 8) = 0x3c;
  dVar2 = DWORD_08065810;
  if ((param_2 == 0) || (dVar2 = DWORD_08065834, param_2 == 1)) {
    *(dword *)(iVar3 + 0xc) = dVar2;
  }
  *(int *)(iVar3 + 0x10) = *(int *)(iVar3 + 0x20) + 0x3fc;
  *(undefined4 *)(iVar3 + 0x24) = 0;
  sub_08000274(iVar3,param_1);
  return in_lr;
}


