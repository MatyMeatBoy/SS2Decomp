
void sub_08057390(undefined4 param_1,undefined4 param_2)

{
  sub_08068070(param_2,param_1);
  return;
}


