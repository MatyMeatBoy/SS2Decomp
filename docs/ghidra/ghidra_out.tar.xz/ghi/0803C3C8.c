
undefined4 sub_0803C3C8(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 in_lr;
  
  iVar1 = sub_080020F4();
  iVar1 = iVar1 * 0x14c + DWORD_0803c3ec;
  *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) | 1;
  sub_0800D0F4();
  while (iVar1 = sub_0805F184(), iVar1 != 0) {
    sub_080003F0();
  }
  uVar2 = sub_0805DF38(1,0xf,2,0,0xfffffffe,DWORD_0803c418);
  while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
    sub_080003F0();
  }
  iVar1 = sub_0805EF14(uVar2);
  if (iVar1 == 1) {
    sub_08068820(DWORD_0803c440,0,0);
  }
  else {
    while (iVar1 = sub_0805F184(), iVar1 != 0) {
      sub_080003F0();
    }
    while (iVar1 = sub_0805EF90(), iVar1 != 0) {
      sub_080003F0();
    }
    uVar2 = sub_0805DF38(1,0xf,2,0,0xffffffff,DWORD_0803c478);
    while (iVar1 = sub_0805EEFC(uVar2), iVar1 == 0) {
      iVar1 = sub_0800CDF8();
      if (iVar1 != 0) {
        sub_0805EFBC();
        break;
      }
      sub_080003F0();
    }
    iVar1 = sub_080020F4();
    iVar1 = iVar1 * 0x14c + DWORD_0803c4bc;
    *(uint *)(iVar1 + 0x30) = *(uint *)(iVar1 + 0x30) & 0xfffffffe;
    sub_0800D108();
  }
  return in_lr;
}


