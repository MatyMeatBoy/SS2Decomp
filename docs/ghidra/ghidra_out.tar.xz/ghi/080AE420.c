
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void sub_080AE420(uint param_1)

{
  bool bVar1;
  ushort uVar2;
  short sVar3;
  dword dVar4;
  short *psVar5;
  byte bVar6;
  char cVar7;
  undefined1 uVar8;
  ushort uVar9;
  short sVar10;
  uint uVar11;
  int iVar12;
  uint uVar13;
  char *pcVar14;
  ushort *puVar15;
  int iVar16;
  undefined2 *puVar17;
  undefined4 *puVar18;
  int iVar19;
  int *piVar20;
  ushort *puVar21;
  dword dVar22;
  ushort uStack_94;
  short sStack_92;
  short asStack_90 [2];
  uint uStack_8c;
  ushort *puStack_88;
  int iStack_84;
  int iStack_80;
  int iStack_7c;
  uint uStack_78;
  dword dStack_74;
  uint uStack_70;
  uint uStack_6c;
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined4 uStack_54;
  int iStack_50;
  int iStack_4c;
  ushort *puStack_48;
  ushort *puStack_44;
  undefined2 *puStack_40;
  int iStack_3c;
  int iStack_38;
  short *psStack_34;
  short *psStack_30;
  ushort *puStack_2c;
  ushort *puStack_28;
  ushort *puStack_24;
  
  uStack_8c = param_1 & 0xff;
  puVar21 = (ushort *)(*(int *)DWORD_080ae600 + uStack_8c * 0x2e0);
  *(uint *)DWORD_080ae604 = *(uint *)DWORD_080ae604 | 1 << uStack_8c;
  dVar22 = DWORD_080ae608;
  iStack_4c = uStack_8c * 0xac;
  puVar18 = (undefined4 *)(iStack_4c + DWORD_080ae608);
  *puVar18 = puVar21;
  sub_0801623C(puVar21,DWORD_080ae60c,uStack_8c);
  puStack_88 = puVar21 + 0x102;
  sub_08019F60();
  puVar21[0x2a] = 0;
  puVar21[0x2b] = 0;
  puVar21[0x26] = 0;
  puVar21[0x27] = 0;
  puVar21[0x25] = 0;
  puVar21[0x36] = 0;
  puVar21[8] = 0;
  puStack_48 = puVar21 + 0x34;
  *puStack_48 = 0;
  uStack_94 = 0;
  puStack_44 = puVar21 + 0x35;
  *puStack_44 = 0;
  puVar21[4] = 0;
  *puVar21 = (ushort)uStack_8c;
  puVar21[1] = (ushort)uStack_8c + 4;
  puVar21[6] = 0;
  puVar21[0x24] = *(ushort *)(DWORD_080ae610 + 0x90);
  *(byte *)((int)puVar21 + DWORD_080ae614) = 0x18;
  *(byte *)((int)puVar21 + DWORD_080ae618) = 0x14;
  dVar4 = DWORD_080ae61c;
  uStack_6c = (uint)*(ushort *)(DWORD_080ae61c + 0xc);
  puStack_40 = (undefined2 *)((int)puVar18 + 0xa6);
  *puStack_40 = 4;
  *(undefined2 *)(puVar18 + 0x2a) = *(undefined2 *)(dVar4 + 0xe);
  CpuSet(dVar4 + 0x58,puVar21 + 0xe6,0x18);
  CpuSet(dVar4 + 0x38,puStack_88,0x10);
  sub_0801A0A4(puVar21);
  *(byte *)(puVar21 + 0xee) = 4;
  puVar21[0x2f] = puVar21[0xea];
  *(undefined2 *)((int)puVar21 + DWORD_080ae620) = *(undefined2 *)(dVar4 + 0x5a);
  puVar21[0x16c] = *(ushort *)(dVar4 + 100);
  dVar4 = DWORD_080ae624;
  *(undefined2 *)((int)puVar21 + DWORD_080ae624) = *puStack_40;
  puVar21[0x28] = 1;
  puVar21[0x29] = 0;
  *(byte *)((int)puVar21 + 0x1fd) = 3;
  *(byte *)((int)puVar21 + (dVar4 - 0xdc)) = 3;
  puVar21[6] = 0;
  uStack_78 = 0;
  dStack_74 = DWORD_080ae628;
  uStack_68 = 0;
  uStack_64 = 0;
  puVar21[0x36] = 0;
  uStack_94 = 0;
  *puStack_44 = 0;
  *puStack_48 = 0;
  uStack_5c = 0;
  uStack_60 = 0;
  uStack_54 = 0;
  iStack_50 = 0;
  uVar11 = 0;
  psStack_34 = &sStack_92;
  psStack_30 = asStack_90;
  do {
    *(undefined1 *)((short)uVar11 + iStack_4c + dVar22 + 0xa0) = 0;
    uVar13 = (int)(short)uVar11 + 1;
    uVar11 = uVar13 & 0xffff;
  } while ((int)(uVar13 * 0x10000) >> 0x10 < 4);
  *(byte *)(puVar21 + 0xfe) = (byte)puVar21[0xfe] & 0xf0 | (byte)*puVar21 & 0xf;
  *(ushort *)((int)puVar21 + DWORD_080ae62c) = puVar21[1];
  *(byte *)(puVar21 + 0x100) = 0xff;
  if (uStack_6c < 9) {
                    /* WARNING: Could not recover jumptable at 0x080ae5fc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(uStack_6c * 4 + DWORD_080ae630))();
    return;
  }
  iVar12 = sub_08007290(puStack_88[0x14] | 0xb0000);
  dVar22 = DWORD_080ae900;
  uStack_70 = (uint)*(byte *)(iVar12 + 0x9b);
  iVar19 = uStack_8c * 0xac + DWORD_080ae8fc;
  iVar12 = uStack_70 * 4 + uStack_6c * 0x58;
  iStack_3c = uStack_8c * 0xac + (DWORD_080ae8fc - 4);
  puVar17 = (undefined2 *)(iStack_3c + 0xa6);
  sub_08065158(iVar19,*(undefined4 *)(iVar12 + DWORD_080ae900),*puVar17,0xffffffff,0);
  sub_08065158(iVar19 + 0x34,*(undefined4 *)(iVar12 + dVar22 + 0x2c),*puVar17,0xffffffff,0);
  *(char *)(iStack_3c + 0x20) = (char)*puVar17;
  *(char *)(iStack_3c + 0x54) = (char)*puVar17;
  if (((uStack_6c == 8) || (uStack_6c == 6)) || (uStack_6c == 1)) {
    iVar12 = uStack_8c * 0xac + (DWORD_080ae8fc - 4);
    puVar17 = (undefined2 *)(iVar12 + 0xa6);
    sub_08065158(uStack_8c * 0xac + DWORD_080ae8fc + 0x68,
                 *(undefined4 *)(uStack_6c * 0x58 + DWORD_080ae900 + 0x50),*puVar17,0xffffffff,0);
    *(char *)(iVar12 + 0x88) = (char)*puVar17;
  }
  iVar12 = sub_0800CE30();
  if (iVar12 == 1) {
    puVar21[0x2e] = (puStack_88[3] + 1000) * 3;
    iStack_7c = 5;
    iStack_80 = 5;
  }
  else {
    puVar21[0x2e] = (puStack_88[3] + 500) * 3;
    iStack_7c = 3;
    iStack_80 = 3;
  }
  sub_08068330(*puVar21);
  puStack_24 = puVar21 + 0x36;
  puStack_2c = puVar21 + 0x34;
  puStack_28 = puVar21 + 0x35;
  while (iVar12 = sub_080682B8(*puVar21), iVar12 == 0) {
    sub_080003F0();
  }
  sub_08065E38(*puVar21);
  if ((puVar21[6] == 10) && (uStack_68 == 0)) {
    uStack_68 = 8;
    pcVar14 = (char *)(uStack_8c * 0xac + (uint)puVar21[0x2c] + DWORD_080ae9b0 + 0xa0);
    *pcVar14 = *pcVar14 + '\x01';
  }
  iVar12 = sub_08058DB0();
  if (iVar12 == 0) {
    sub_0801C8F0(puVar21);
    switch(*(byte *)((int)puVar21 + DWORD_080ae9b4)) {
    case 1:
      sub_0801A0B0(puVar21);
      break;
    case 2:
      puVar21[6] = 0;
      iVar12 = sub_080682B8(*puVar21);
      if (iVar12 != 0) {
        *(byte *)((int)puVar21 + _UNK_080aea18) = (byte)puVar21[0xff];
        sub_08065E38(*puVar21);
      }
      break;
    case 3:
      iVar12 = sub_08056F78();
      if (iVar12 != 0) {
        if (*(char *)(uStack_8c * 0xac + _UNK_080aea44 + 0xab) == '\0') {
          bVar6 = 4;
        }
        else {
          bVar6 = 5;
        }
        *(byte *)(puVar21 + 0xff) = bVar6;
        *(byte *)((int)puVar21 + _UNK_080aea5c) = 2;
        goto code_r0x080aedc6;
      }
      break;
    case 4:
      uStack_78 = 1;
      puVar21[6] = 1;
      iVar12 = sub_08096594(uStack_8c);
      uVar11 = (byte)puVar21[0xfe] & 0xf | iVar12 << 4;
      *(byte *)(puVar21 + 0xfe) = (byte)uVar11;
      iVar12 = uStack_8c * 0xac + _UNK_080aead8;
      cVar7 = sub_08097A74(puVar21,((uVar11 << 0x18) >> 0x1c) * 0x14c + _UNK_080aead4,
                           *(undefined2 *)(iVar12 + 0xa4),*(undefined1 *)(iVar12 + 0xaa));
      if (cVar7 == '\0') {
        sub_08097A38(uStack_8c);
        *puStack_24 = 0;
        *puStack_28 = 0;
        if (uStack_6c == 4) {
          bVar6 = 8;
        }
        else {
          bVar6 = 6;
        }
        *(byte *)(puVar21 + 0xff) = bVar6;
        *(byte *)((int)puVar21 + _UNK_080aeaf0) = 2;
        goto code_r0x080aedc6;
      }
      break;
    case 5:
      uStack_78 = 1;
      puVar21[6] = 1;
      iVar12 = sub_08096594(uStack_8c);
      iVar12 = iVar12 * 0x14c + _UNK_080aeb3c;
      if (uStack_6c != 2) {
        if ((uStack_5c & uStack_78) == 0) {
          iVar19 = uStack_8c * 0xac + _UNK_080aeb94;
          cVar7 = sub_08097A74(puVar21,iVar12,*(undefined2 *)(iVar19 + 0xa4),
                               *(undefined1 *)(iVar19 + 0xaa));
          if (cVar7 != '\0') break;
          uStack_5c = uStack_5c + 1 & 0xffff;
          sub_08097A38(uStack_8c);
          *puStack_24 = 0;
          *puStack_28 = 0;
          *(byte *)(puVar21 + 0xff) = 6;
          puVar15 = (ushort *)((int)puVar21 + _UNK_080aeb98);
          bVar6 = 2;
        }
        else {
          uStack_5c = uStack_5c + 1 & 0xffff;
          uStack_60 = 0;
          *(byte *)(puVar21 + 0xff) = 9;
          puVar15 = (ushort *)((int)puVar21 + _UNK_080aeb40);
          bVar6 = 2;
        }
        goto code_r0x080aedc4;
      }
      iVar19 = uStack_8c * 0xac + _UNK_080aebdc;
      cVar7 = sub_08097A74(puVar21,iVar12,*(undefined2 *)(iVar19 + 0xa4),
                           *(undefined1 *)(iVar19 + 0xaa));
      if (cVar7 == '\0') {
        sub_08097A38(uStack_8c);
        *(byte *)(puVar21 + 0xff) = 7;
        *(byte *)((int)puVar21 + _UNK_080aebe0) = (byte)uStack_6c;
        goto code_r0x080aedc6;
      }
      break;
    case 6:
      uStack_78 = 2;
      puVar21[6] = 2;
      if ((puStack_88[0x12] == *puStack_28) && (*puStack_24 == 0)) {
        sub_08058CC4(uStack_70);
      }
      if (puVar21[0x37] != 0) {
        *(int *)(puVar21 + 0x28) = *(int *)(puVar21 + 0x28) + 1;
        *(byte *)((int)puVar21 + _UNK_080aec28) = 2;
        puVar15 = puVar21 + 0xff;
        bVar6 = 10;
        goto code_r0x080aedc4;
      }
      break;
    case 7:
      uStack_78 = 2;
      puVar21[6] = 2;
      *(int *)(puVar21 + 0x28) = *(int *)(puVar21 + 0x28) + 1;
      cVar7 = sub_08096594(uStack_8c);
      puVar15 = puVar21 + 0xfe;
      *(byte *)puVar15 = (byte)*puVar15 & 0xf | cVar7 << 4;
      sub_08097A38(uStack_8c);
      sub_08077D04(*puVar21,(byte)*puVar15 >> 4);
      *(byte *)((int)puVar21 + _UNK_080aec74) = 2;
      puVar15 = puVar21 + 0xff;
      bVar6 = 10;
code_r0x080aedc4:
      *(byte *)puVar15 = bVar6;
code_r0x080aedc6:
      sub_08068330(*puVar21);
      break;
    case 8:
      uStack_78 = 2;
      puVar21[6] = 2;
      if ((puStack_88[0x12] == *puStack_28) && (*puStack_24 == 0)) {
        sub_08058CC4(uStack_70);
      }
      if (puVar21[0x37] != 0) {
        uStack_5c = uStack_5c + 1 & 0xffff;
        *(int *)(puVar21 + 0x28) = *(int *)(puVar21 + 0x28) + 1;
        *(byte *)((int)puVar21 + _UNK_080aecc8) = 2;
        puVar15 = puVar21 + 0xff;
        bVar6 = 10;
        goto code_r0x080aedc4;
      }
      break;
    case 9:
      uStack_78 = 9;
      puVar21[6] = 9;
      uVar8 = sub_08096594(uStack_8c);
      sub_08095F10(puVar21,uVar8);
      *puStack_2c = puVar21[4];
      *puStack_28 = 0;
      bVar1 = 0x28 < uStack_60;
      uStack_60 = uStack_60 + 1 & 0xffff;
      if (bVar1) {
        uStack_60 = 0;
        if (uStack_6c == 6) {
code_r0x080aed74:
          sub_0807386C(*puVar21 + 4,0xd,(byte)puVar21[0xfe] >> 4,iStack_80,iStack_7c);
        }
        else if ((int)uStack_6c < 7) {
          if (uStack_6c == 1) {
            sub_0807386C(*puVar21 + 4,4,(byte)puVar21[0xfe] >> 4,iStack_80 + -1,iStack_7c + -1);
          }
        }
        else if (uStack_6c == 8) goto code_r0x080aed74;
        *(int *)(puVar21 + 0x28) = *(int *)(puVar21 + 0x28) + 1;
        *(byte *)((int)puVar21 + _UNK_080aedd0) = 2;
        puVar15 = puVar21 + 0xff;
        bVar6 = 0xb;
        goto code_r0x080aedc4;
      }
      break;
    case 10:
      uStack_78 = 0;
      puVar21[6] = 0;
      bVar1 = 0x3c < uStack_60;
      uStack_60 = uStack_60 + 1 & 0xffff;
      if (bVar1) {
        uStack_60 = 0;
        *(byte *)((int)puVar21 + _UNK_080aed14) = 2;
        sub_08068330(*puVar21);
        if (*(char *)(uStack_8c * 0xac + _UNK_080aed18 + 0xab) == '\0') {
          *(byte *)(puVar21 + 0xff) = 4;
        }
        else {
          *(byte *)(puVar21 + 0xff) = 5;
        }
      }
      break;
    case 0xb:
      uStack_78 = 9;
      puVar21[6] = 9;
      uVar8 = sub_08096594(uStack_8c);
      sub_08095F10(puVar21,uVar8);
      *puStack_2c = puVar21[4] + 8;
      *puStack_28 = 8;
      uVar11 = uStack_60 + 1 & 0xffff;
      bVar1 = 0xb4 < uStack_60;
      uStack_60 = uVar11;
      if (bVar1) {
        sub_08097A38(uStack_8c);
        uStack_60 = 0;
        *(byte *)(puVar21 + 0xff) = 5;
        *(byte *)((int)puVar21 + _UNK_080aee3c) = 2;
        sub_08068330(*puVar21);
      }
    }
  }
  if (uStack_78 == 1) {
    iStack_50 = 0;
    *puStack_2c = puVar21[4] + 8;
    uStack_54 = 1;
  }
  else if ((int)uStack_78 < 2) {
    if (uStack_78 == 0) {
      iStack_50 = 0;
      *puStack_2c = puVar21[4];
      uStack_54 = 1;
    }
  }
  else if (uStack_78 == 2) {
    iStack_50 = 1;
    *puStack_2c = puVar21[4];
    uStack_54 = 0;
  }
  else if (uStack_78 == 9) {
    iStack_50 = 2;
    uStack_54 = 0;
  }
  if (dStack_74 != *puStack_2c) {
    dStack_74 = (dword)*puStack_2c;
    *puStack_24 = 0;
    *puStack_28 = 0;
  }
  uVar11 = sub_08098004();
  if ((uVar11 & 1) == 0) {
    uVar8 = sub_0800BC44(*(int *)(puVar21 + 10) >> 8,*(int *)(puVar21 + 0xc) >> 8,0);
  }
  else {
    uVar8 = sub_08097FF8();
  }
  iVar12 = sub_0800CD8C();
  if (iVar12 == 0) {
    if ((*(byte *)((int)puVar21 + DWORD_080aeefc) == 0xb) ||
       (*(byte *)((int)puVar21 + DWORD_080aeefc) == 9)) {
      iVar12 = uStack_8c * 0xac + DWORD_080aef00 + iStack_50 * 0x34;
      uVar9 = *puStack_2c;
      puVar15 = &uStack_94;
    }
    else {
      iVar12 = uStack_8c * 0xac + DWORD_080aefdc + iStack_50 * 0x34;
      uVar9 = *puStack_2c;
      puVar15 = puStack_28;
    }
    uVar9 = sub_08065370(iVar12,uVar9,puVar15,puStack_24,uStack_54);
    puVar21[0x37] = uVar9;
  }
  sub_0800BC08((*(int *)(puVar21 + 10) << 8) >> 0x10,(*(int *)(puVar21 + 0xc) << 8) >> 0x10,
               psStack_34,psStack_30,0,0);
  if (uStack_68 == 0) {
    iVar12 = sub_0800CCCC();
    if (((iVar12 != 0) || (iVar12 = sub_0800CC98(), iVar12 != 0)) ||
       (iVar12 = sub_0800CD34(), dVar22 = DWORD_080af084, iVar12 != 0)) goto LAB_080af0c4;
    iVar12 = uStack_8c * 0xac;
    iVar19 = iStack_50 * 0x34;
    iVar16 = iVar19 + iVar12;
    sub_08000AF0(*(ushort *)(iVar12 + DWORD_080af084 + 0xa6) + 0x10,
                 *(int *)(iVar16 + DWORD_080af084 + 0x10) +
                 (uint)*(ushort *)(iVar12 + DWORD_080af084 + 0xa8) * 0x20,1);
    if ((*(byte *)((int)puVar21 + DWORD_080af088) != 0xb) &&
       (*(byte *)((int)puVar21 + DWORD_080af088) != 9)) {
      sub_08007870((int)*psStack_34,(int)*psStack_30,*puStack_2c,*puStack_28,uVar8,
                   iVar12 + dVar22 + 4 + iVar19 + 0x1c,*(undefined4 *)(iVar16 + dVar22 + 0xc),
                   *(undefined4 *)(iVar16 + dVar22 + 4));
      goto LAB_080af0c4;
    }
LAB_080af048:
    sVar10 = *psStack_34;
    sVar3 = *psStack_30;
    uVar9 = *puStack_2c;
    uVar2 = uStack_94;
  }
  else {
    uVar11 = uStack_68 - 1 & 0xffff;
    uVar13 = uStack_68 & 1;
    uStack_68 = uVar11;
    if (((uVar13 == 0) || (iVar12 = sub_0800CCCC(), iVar12 != 0)) ||
       ((iVar12 = sub_0800CC98(), iVar12 != 0 ||
        (iVar12 = sub_0800CD34(), dVar22 = DWORD_080aefe0, iVar12 != 0)))) goto LAB_080af0c4;
    iVar12 = uStack_8c * 0xac;
    iVar19 = iStack_50 * 0x34;
    iVar16 = iVar19 + iVar12;
    sub_08000AF0(*(ushort *)(iVar12 + DWORD_080aefe0 + 0xa6) + 0x10,
                 *(int *)(iVar16 + DWORD_080aefe0 + 0x10) +
                 (uint)*(ushort *)(iVar12 + DWORD_080aefe0 + 0xa8) * 0x20,1);
    if ((*(byte *)((int)puVar21 + DWORD_080aefe4) == 0xb) ||
       (*(byte *)((int)puVar21 + DWORD_080aefe4) == 9)) goto LAB_080af048;
    sVar10 = *psStack_34;
    sVar3 = *psStack_30;
    uVar9 = *puStack_2c;
    uVar2 = *puStack_28;
  }
  sub_08007870((int)sVar10,(int)sVar3,uVar9,uVar2,uVar8,iVar12 + dVar22 + 4 + iVar19 + 0x1c,
               *(undefined4 *)(iVar16 + dVar22 + 0xc),*(undefined4 *)(iVar16 + dVar22 + 4));
LAB_080af0c4:
  iVar12 = *(int *)(puVar21 + 0x26);
  if ((iVar12 != 0) && (iStack_84 != iVar12)) {
    uStack_64 = 10;
    uStack_58 = 0;
    iStack_84 = iVar12;
  }
  if (uStack_64 == 0) {
    iStack_84 = 0;
    puVar21[0x26] = 0;
    puVar21[0x27] = 0;
  }
  else {
    iVar12 = sub_0800CC98();
    if (((iVar12 == 0) && (iVar12 = sub_0800CCCC(), iVar12 == 0)) &&
       (iVar12 = sub_0800CD34(), iVar12 == 0)) {
      sub_0801A120(puVar21,iStack_84,(int)(short)uStack_58);
    }
    if ((uStack_64 & 2) != 0) {
      uStack_58 = uStack_58 * 0x10000 + DWORD_080af128 >> 0x10;
    }
    uStack_64 = uStack_64 - 1 & 0xffff;
  }
  sVar10 = sub_08019CE8(puVar21);
  if (sVar10 == 0) {
    func_0x080ae952();
  }
  sub_080003F0();
  dVar22 = DWORD_080af1bc;
  iVar12 = uStack_8c * 0xac;
  piVar20 = (int *)(iVar12 + DWORD_080af1bc);
  sub_08067CA8(*(undefined2 *)(*piVar20 + 2));
  iVar19 = sub_0800048C();
  psVar5 = psStack_34;
  iVar16 = *(int *)(iVar19 + 8) + -0x44;
  *(int *)(iVar19 + 8) = iVar16;
  *(uint *)DWORD_080af1c0 =
       *(uint *)DWORD_080af1c0 & ~(1 << (**(ushort **)(iVar16 * 0xac + dVar22) & 0xff));
  iStack_50 = 0;
  *(undefined2 *)(*piVar20 + 0x68) = 0x18;
  *puStack_24 = 0;
  *puStack_28 = 0;
  uStack_54 = 0;
  iVar19 = DWORD_080af1c4 + iVar12;
  iStack_38 = iVar19 + 0x1c;
  do {
    uVar11 = sub_08098004();
    if ((uVar11 & 1) == 0) {
      uVar8 = sub_0800BC44(*(int *)(puVar21 + 10) >> 8,*(int *)(puVar21 + 0xc) >> 8,0);
    }
    else {
      uVar8 = sub_08097FF8();
    }
    iVar16 = sub_0800CD8C();
    if (iVar16 == 0) {
      uVar9 = sub_08065370(iVar19,*puStack_2c,puStack_28,puStack_24,uStack_54);
      puVar21[0x37] = uVar9;
    }
    iVar16 = sub_0800CCCC();
    if (((iVar16 == 0) && (iVar16 = sub_0800CC98(), iVar16 == 0)) &&
       ((iVar16 = sub_0800CD34(), iVar16 == 0 &&
        (uVar11 = uStack_68 - 1 & 0xffff, uVar13 = uStack_68 & 1, uStack_68 = uVar11, uVar13 != 0)))
       ) {
      sub_0800BC08((*(int *)(puVar21 + 10) << 8) >> 0x10,(*(int *)(puVar21 + 0xc) << 8) >> 0x10,
                   psVar5,psStack_30,0,0);
      sub_08000AF0(*(ushort *)(iVar12 + DWORD_080af2a0 + 0xa6) + 0x10,
                   *(int *)(iVar12 + DWORD_080af2a0 + 0x10) +
                   (uint)*(ushort *)(iVar12 + DWORD_080af2a0 + 0xa8) * 0x20,1);
      sub_08007870((int)*psVar5,(int)*psStack_30,*puStack_2c,*puStack_28,uVar8,iStack_38,
                   *(undefined4 *)(DWORD_080af2a4 + iVar12),*(undefined4 *)(iVar12 + DWORD_080af2a8)
                  );
    }
    sub_080003F0();
  } while( true );
}


