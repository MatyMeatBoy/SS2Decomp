
void sub_080955CC(void)

{
  dword dVar1;
  
  dVar1 = DWORD_080955e8;
  *(undefined2 *)(DWORD_080955e8 + 6) = 0;
  *(undefined2 *)(dVar1 + 4) = 0;
  *(undefined2 *)(dVar1 + 10) = 0;
  *(undefined2 *)(dVar1 + 8) = 0;
  *(undefined1 *)(dVar1 + 0xc) = 0;
  *(undefined2 *)(dVar1 + 2) = 0x100;
  *(undefined2 *)dVar1 = 0x100;
  return;
}


