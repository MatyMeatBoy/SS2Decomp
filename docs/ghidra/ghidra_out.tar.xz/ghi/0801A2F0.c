
undefined8 sub_0801A2F0(byte *param_1)

{
  byte bVar1;
  undefined4 uVar2;
  byte bVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_lr;
  
  uVar2 = sub_080008C8();
  bVar1 = __umodsi3(uVar2,100);
  uVar5 = 0xff;
  uVar4 = 0;
  bVar3 = param_1[1];
  while (bVar3 <= bVar1) {
    uVar4 = uVar4 + 1;
    if (2 < uVar4) goto LAB_0801a320;
    bVar3 = bVar3 + param_1[5];
    param_1 = param_1 + 4;
  }
  uVar5 = (uint)*param_1;
LAB_0801a320:
  return CONCAT44(in_lr,uVar5);
}


