
void __div0(void)

{
  return;
}


