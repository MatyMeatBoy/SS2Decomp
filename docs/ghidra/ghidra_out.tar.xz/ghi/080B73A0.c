
undefined4 m4aMPlayFadeOut(undefined4 param_1,undefined2 param_2)

{
  undefined4 in_lr;
  
  MPlayFadeOut(param_1,param_2);
  return in_lr;
}


