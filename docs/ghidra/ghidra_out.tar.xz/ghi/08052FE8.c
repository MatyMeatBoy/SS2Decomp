
undefined4 sub_08052FE8(void)

{
  char cVar1;
  int iVar2;
  dword dVar3;
  undefined4 in_lr;
  
  iVar2 = sub_0800CE30();
  if (iVar2 == 0) {
    iVar2 = *(int *)DWORD_08053050;
    dVar3 = DWORD_08053054;
  }
  else {
    iVar2 = *(int *)DWORD_08052ffc;
    dVar3 = DWORD_08053000;
  }
  *(byte *)(iVar2 + dVar3) = *(byte *)(iVar2 + dVar3) & 0xfe;
  cVar1 = sub_0801DE60();
  iVar2 = sub_0800CCCC();
  if (cVar1 == '\x06' && iVar2 == 0) {
    sub_08068070(DWORD_08053058,0x20);
  }
  sub_08068070(DWORD_0805305c,0);
  return in_lr;
}


