
undefined4 sub_0805A9F4(uint param_1)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 in_lr;
  
  uVar3 = param_1 >> 0x10;
  uVar2 = *(undefined4 *)DWORD_0805aa1c;
  *(uint *)DWORD_0805aa1c = param_1 & 0xff;
  if ((*(uint *)DWORD_0805aa20 & 0x20) == 0) {
    sub_08006CB4(param_1 & 0xff);
  }
  for (; uVar3 != 0; uVar3 = uVar3 - 1 & 0xffff) {
    sub_080003F0();
    iVar1 = sub_080021A8();
    if (iVar1 != 0) break;
  }
  iVar1 = sub_0800CC98();
  if ((iVar1 == 0) && (*(undefined4 *)DWORD_0805aa60 = uVar2, (*(uint *)DWORD_0805aa64 & 0x20) == 0)
     ) {
    sub_08006CB4(uVar2);
  }
  return in_lr;
}


