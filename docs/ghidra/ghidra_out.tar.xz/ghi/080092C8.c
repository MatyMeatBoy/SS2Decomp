
undefined4 sub_080092C8(ushort param_1,short *param_2,int param_3,int param_4)

{
  ushort uVar1;
  short sVar2;
  dword dVar3;
  uint uVar4;
  int iVar5;
  ushort *puVar6;
  int iVar7;
  uint uVar8;
  undefined2 *puVar9;
  undefined4 in_lr;
  uint uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  
  dVar3 = DWORD_080093d8;
  uVar4 = (uint)param_1;
  uVar1 = param_2[1];
  sVar2 = *param_2;
  iVar7 = uVar4 * 0x18;
  puVar9 = (undefined2 *)(iVar7 + DWORD_080093d8);
  puVar9[10] = param_1;
  *(uint *)(dVar3 + 0xc + iVar7) = (int)param_2 + (int)sVar2 * (uint)uVar1 * (3 - uVar4) * 2 + 0x10;
  puVar9[8] = *param_2;
  puVar9[9] = param_2[1];
  *puVar9 = 0;
  puVar9[1] = 0;
  puVar9[2] = 0;
  puVar9[3] = 0;
  puVar9[4] = 0;
  puVar9[5] = 0;
  puVar9[0xb] = 1;
  uStack_24 = *(undefined4 *)(uVar4 * 4 + DWORD_080093dc);
  uStack_2c = (uint)(param_3 << 0x10) >> 5;
  uStack_28 = (uint)(param_4 << 0x10) >> 5;
  sub_0800AD04(&uStack_2c,&uStack_28,0);
  iVar5 = (int)*(short *)(dVar3 + 0x7c);
  if (iVar5 < 0) {
    iVar5 = iVar5 + 7;
  }
  *puVar9 = (short)(iVar5 >> 3);
  puVar6 = (ushort *)(dVar3 + 0x7e);
  iVar5 = (int)(short)*puVar6;
  if (iVar5 < 0) {
    iVar5 = iVar5 + 7;
  }
  puVar9[1] = (short)(iVar5 >> 3);
  uVar8 = (uint)*puVar6;
  if ((int)uVar8 < (short)*puVar6 + 0x100) {
    do {
      sub_080094CC(iVar7 + dVar3,(int)*(short *)(dVar3 + 0x7c),(int)(short)uVar8);
      uVar8 = uVar8 + 8 & 0xffff;
    } while ((int)uVar8 < (short)*puVar6 + 0x100);
  }
  sub_08001348(uStack_24,(*(ushort *)(DWORD_080093e0 + uVar4 * 2) >> 8 & 0x1f) * 0x800 + 0x6000000,
               0x800);
  sub_080003F0();
  return in_lr;
}


