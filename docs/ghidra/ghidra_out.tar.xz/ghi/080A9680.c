
undefined8 sub_080A9680(void)

{
  dword dVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 in_lr;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  
  dVar1 = DWORD_080a97bc;
  iVar2 = sub_080020F4();
  if ((((*(short *)(iVar2 * 0x14c + dVar1 + 200) == 0) &&
       (iVar2 = sub_080020F4(), (*(uint *)(iVar2 * 0x14c + dVar1 + 0x30) & 0x2000) == 0)) &&
      (iVar2 = sub_080020F4(), *(char *)(iVar2 * 0x14c + dVar1 + 0x68) != '\0')) &&
     (((iVar2 = sub_080020F4(), *(short *)(iVar2 * 0x14c + dVar1 + 0x20) != 0xe &&
       (iVar2 = sub_080020F4(), *(short *)(iVar2 * 0x14c + dVar1 + 0x20) != 0xb)) &&
      (iVar2 = sub_080020F4(), *(short *)(iVar2 * 0x14c + dVar1 + 0x20) != 0xc)))) {
    iVar2 = sub_080020F4();
    iVar6 = dVar1 + 0x8c;
    iStack_38 = *(int *)(iVar2 * 0x14c + iVar6) >> 8;
    iVar2 = sub_080020F4();
    iVar5 = dVar1 + 0x90;
    iStack_34 = *(int *)(iVar2 * 0x14c + iVar5) >> 8;
    iVar2 = sub_080020F4();
    iStack_30 = *(int *)(iVar2 * 0x14c + iVar6) + 0xc00 >> 8;
    iVar2 = sub_080020F4();
    iStack_2c = (int)(*(int *)(iVar2 * 0x14c + iVar5) + DWORD_080a97c0) >> 8;
    iVar2 = *(int *)DWORD_080a97c4;
    iStack_28 = (int)(*(int *)(iVar2 + 0x14) + DWORD_080a97c8) >> 8;
    iStack_24 = (int)(*(int *)(iVar2 + 0x18) + DWORD_080a97cc) >> 8;
    iStack_20 = *(int *)(iVar2 + 0x14) + 0x4000 >> 8;
    iStack_1c = *(int *)(iVar2 + 0x18) + 0x2000 >> 8;
    iVar2 = sub_080A98E0(&iStack_28,&iStack_20,&iStack_38,&iStack_30);
    if (iVar2 != 0) {
      iVar2 = sub_080020F4();
      iVar3 = sub_080020F4();
      *(undefined4 *)(iVar2 * 0x14c + iVar6) = *(undefined4 *)(iVar3 * 0x14c + dVar1 + 0x94);
      iVar2 = sub_080020F4();
      iVar6 = sub_080020F4();
      *(undefined4 *)(iVar2 * 0x14c + iVar5) = *(undefined4 *)(iVar6 * 0x14c + dVar1 + 0x98);
      uVar4 = 1;
      goto LAB_080a97d2;
    }
  }
  uVar4 = 0;
LAB_080a97d2:
  return CONCAT44(in_lr,uVar4);
}


