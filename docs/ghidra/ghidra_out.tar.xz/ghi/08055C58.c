
undefined4 sub_08055C58(void)

{
  dword dVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  undefined4 in_lr;
  
  iVar2 = sub_080289C0(0x3e,0x78,0x60);
  piVar3 = (int *)(*(int *)DWORD_08055cd8 + DWORD_08055cdc);
  uVar4 = 0;
  do {
    if (*piVar3 == iVar2) goto LAB_08055c84;
    uVar4 = uVar4 + 1;
    piVar3 = piVar3 + 0x1c;
  } while (uVar4 < 0xf);
  sub_080003F0();
  piVar3 = (int *)0x0;
LAB_08055c84:
  if (piVar3 != (int *)0x0) {
    *(undefined2 *)(piVar3 + 6) = 8;
    *(undefined2 *)((int)piVar3 + 0x1a) = 0x1e;
    piVar3[0xf] = piVar3[0xf] | 0x10;
  }
  dVar1 = DWORD_08055ce0;
  piVar3 = (int *)(*(int *)DWORD_08055cd8 + DWORD_08055cdc);
  uVar4 = 0;
  do {
    if (*piVar3 == iVar2) goto LAB_08055cb8;
    uVar4 = uVar4 + 1;
    piVar3 = piVar3 + 0x1c;
  } while (uVar4 < 0xf);
  sub_080003F0();
  piVar3 = (int *)0x0;
LAB_08055cb8:
  if (piVar3 != (int *)0x0) {
    piVar3[0x11] = dVar1;
  }
  iVar2 = sub_0800CC98();
  if (iVar2 == 0) {
    iVar2 = sub_0801AB24();
    if (iVar2 == 1) {
      sub_0801AB50(6);
    }
    else if (iVar2 < 2) {
      if (iVar2 == 0) {
        sub_080576A8();
      }
    }
    else if (iVar2 == 2) {
      sub_0801AB90(6);
    }
    while (iVar2 = sub_0801AAE0(), iVar2 == 0) {
      sub_080003F0();
    }
  }
  return in_lr;
}


