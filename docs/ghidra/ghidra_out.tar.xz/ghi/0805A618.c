
undefined4 sub_0805A618(undefined4 param_1)

{
  undefined4 in_lr;
  
  sub_0802413C(param_1,1);
  return in_lr;
}


