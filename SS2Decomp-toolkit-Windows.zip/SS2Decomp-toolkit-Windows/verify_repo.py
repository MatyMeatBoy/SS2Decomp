#!/usr/bin/env python3
"""Verifica una restauracion inicial; no cambia archivos ni stamps."""
from pathlib import Path, PurePosixPath
import hashlib, json, subprocess, sys

package = Path(__file__).resolve().parent
manifest = json.loads((package / "manifest.json").read_text(encoding="utf-8"))
repo = Path(sys.argv[1]).resolve()
def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()
def checked_path(relative):
    p = PurePosixPath(relative)
    if p.is_absolute() or ".." in p.parts or ":" in relative or "\\" in relative:
        raise SystemExit("Ruta no relativa en manifiesto: " + relative)
    return repo.joinpath(*p.parts)
def git(*args):
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()

if git("rev-parse", "HEAD") != manifest["source"]["revision"]:
    raise SystemExit("HEAD no coincide con SOURCE_REVISION")
expected_head = "refs/remotes/origin/" + manifest["source"]["branch"]
if git("symbolic-ref", "refs/remotes/origin/HEAD") != expected_head:
    raise SystemExit("origin/HEAD incorrecto")
if git("remote", "get-url", "origin") != manifest["source"]["origin"]:
    raise SystemExit("origin no coincide")
for relative, expected in manifest["repo_files"].items():
    path = checked_path(relative)
    if not path.is_file() or path.is_symlink() or sha(path) != expected:
        raise SystemExit("Hash incorrecto/falta archivo: " + relative)
for relative, expected in manifest["source_patch_hashes"].items():
    if sha(checked_path(relative)) != expected:
        raise SystemExit("Parche del snapshot no coincide: " + relative)
for stamp in manifest["sdk_stamps"]:
    text = checked_path(stamp).read_text(encoding="utf-8")
    if "source_directory=" in text:
        raise SystemExit("Stamp contiene ruta de construccion")
    matches = [line.split()[0] for line in text.splitlines()
               if len(line.split()) == 2 and line.split()[1] == "bin/agbcc.exe"]
    executable = checked_path(str(PurePosixPath(stamp).parent / "bin/agbcc.exe"))
    if matches != [sha(executable)]:
        raise SystemExit("Stamp/binario no coincide: " + stamp)
rom = repo / "baserom.gba"
if rom.is_file():
    if hashlib.sha1(rom.read_bytes()).hexdigest() != manifest["rom_sha1"]:
        raise SystemExit("La ROM local no coincide con la ROM europea esperada")
else:
    print("ROM no incluida: copia tu baserom.gba europea antes de compilar")
subprocess.check_call(["git", "-C", str(repo), "diff", "--quiet"])
subprocess.check_call(["git", "-C", str(repo), "diff", "--cached", "--quiet"])
print("Snapshot, herramientas y parches: hashes OK")

