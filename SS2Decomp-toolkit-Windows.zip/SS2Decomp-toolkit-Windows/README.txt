SS2Decomp Windows toolkit - PUBLIC EDITION, NO ROM
=================================================
Download and extract this toolkit into YOUR OWN folder, for example
D:\SS2-Collab\YOUR_NAME. Each contributor/agent needs its own checkout.

1. Install MSYS2 from https://www.msys2.org/ and open MSYS2 UCRT64.
2. Run pacman -Syu, reopen the terminal if requested and finish the update.
3. Start from this extracted toolkit and choose a NEW destination:

   cd /d/SS2-Collab/YOUR_NAME/SS2Decomp-toolkit-Windows
   bash bootstrap.sh /d/SS2-Collab/YOUR_NAME/repo

4. Verify the bundled snapshot BEFORE updating it:

   cd /d/SS2-Collab/YOUR_NAME/repo
   source toolkit-env.sh
   python3 .toolkit/verify_repo.py .
   git pull --ff-only

5. Copy YOUR OWN European ROM to repo/baserom.gba. Expected SHA1:
   aa1288be9257337abdfe3034898cf6c7aa778fbc
   No ROM is included. Never upload your ROM or generated ROMs to Git.

6. Run make -j2 compare, make -j1 nonmatching, then
   python3 tools/scripts/check_tree.py.
   The normal build must report: shiningsoul2_eu.gba: OK.

7. Read the CURRENT collaboration guide in your updated checkout:
   docs/agents/QUICKSTART.md, AGENTS.md and CONTRIBUTING.md.
   Claim an upstream shard before editing. Without upstream write access,
   request an assignment through a GitHub issue; a fork claim does not
   reserve work in the upstream repository. Use English for public reports,
   commits, PR titles and descriptions.

In every new terminal: enter your checkout and source toolkit-env.sh.
The toolkit contains a fixed historical source snapshot and public history;
Git pulls get the latest matches and documentation. Its manifest verifies
that ORIGINAL snapshot, not a later modified or updated checkout.

bootstrap.sh --no-install skips installation of packages already present.
For first setup, omit --build: add your own ROM and build afterwards.
Compilers, SDK variants, m2c, permuter, asm-differ, objdiff and pinned pure
Python dependencies are included. MSYS2 packages are installed with pacman.
Tool licenses and versions are included. No private worktrees, credentials,
ROMs or build output are packaged. Linux/WSL/macOS users should follow the
native setup in the repository; packaged executables target Windows.

Repository: https://github.com/MatyMeatBoy/SS2Decomp
