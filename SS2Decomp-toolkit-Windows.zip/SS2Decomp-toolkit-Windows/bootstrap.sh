#!/usr/bin/env bash
set -euo pipefail
kit=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
install_deps=1
run_build=0
while [[ "${1:-}" == --* ]]; do
    case "$1" in
        --no-install) install_deps=0 ;;
        --build) run_build=1 ;;
        --help) printf '%s\n' 'Uso: bash bootstrap.sh [--no-install] [--build] [directorio NUEVO]'; exit 0 ;;
        *) printf 'Opcion desconocida: %s\n' "$1" >&2; exit 2 ;;
    esac
    shift
done
[[ $# -le 1 ]] || { echo 'Solo se acepta un directorio de destino.' >&2; exit 2; }
destination=${1:-"$PWD/ShiningSoul2Decomp"}
export PATH="/ucrt64/bin:/usr/bin:$PATH"
command -v pacman >/dev/null || { echo 'Abre una terminal MSYS2 UCRT64.' >&2; exit 2; }
if [[ $install_deps == 1 ]]; then
    pacman -S --needed --noconfirm git make \
        mingw-w64-ucrt-x86_64-arm-none-eabi-gcc \
        mingw-w64-ucrt-x86_64-python \
        mingw-w64-ucrt-x86_64-python-capstone \
        mingw-w64-ucrt-x86_64-python-pyelftools \
        mingw-w64-ucrt-x86_64-python-levenshtein \
        mingw-w64-ucrt-x86_64-gcc-libs
fi
for program in git python3 make arm-none-eabi-as arm-none-eabi-ld arm-none-eabi-cpp sha256sum; do
    command -v "$program" >/dev/null || { echo "Falta dependencia: $program" >&2; exit 2; }
done
[[ ! -e "$destination" ]] || { echo 'El destino ya existe; no se modifico.' >&2; exit 2; }
[[ -f "$kit/source.bundle" && -f "$kit/manifest.json" && -f "$kit/SHA256SUMS" ]] ||
    { echo 'Paquete incompleto: falta snapshot/manifiesto final.' >&2; exit 2; }
(cd "$kit" && sha256sum --quiet -c SHA256SUMS)
revision=$(tr -d '\r\n' < "$kit/SOURCE_REVISION")
branch=$(tr -d '\r\n' < "$kit/SOURCE_BRANCH")
git clone -q -c core.autocrlf=false -c core.eol=lf --single-branch --branch "$branch" \
    "$kit/source.bundle" "$destination"
repository=$(cd "$destination" && pwd)
[[ "$(git -C "$repository" rev-parse HEAD)" == "$revision" ]] ||
    { echo 'La revision restaurada no coincide.' >&2; exit 1; }
git -C "$repository" bundle verify "$kit/source.bundle"
git -C "$repository" remote set-url origin https://github.com/MatyMeatBoy/SS2Decomp.git
git -C "$repository" symbolic-ref refs/remotes/origin/HEAD "refs/remotes/origin/$branch"
cp -a "$kit/payload/." "$repository/"
mkdir -p "$repository/.toolkit"
cp "$kit/manifest.json" "$repository/.toolkit/manifest.json"
cp "$kit/verify_repo.py" "$repository/.toolkit/verify_repo.py"
cp "$kit/toolkit-env.sh" "$repository/toolkit-env.sh"
exclude=$(git -C "$repository" rev-parse --git-path info/exclude)
[[ "$exclude" = /* || "$exclude" =~ ^[A-Za-z]: ]] || exclude="$repository/$exclude"
mkdir -p "$(dirname "$exclude")"
cat >> "$exclude" <<'EXCLUDE'

# Toolkit local: ROM y herramientas privadas; nunca se agregan a Git.
/baserom.gba
/.toolkit/
/toolkit-env.sh
/ghi/
/tools/agbcc/
/tools/agbcc_*/
/tools/m2c/
/tools/decomp-permuter/
/tools/asm-differ/
/tools/objdiff/
EXCLUDE
# Validar hashes de binarios, headers/libs y parches ANTES de tocar stamps.
source "$repository/toolkit-env.sh"
python3 "$kit/verify_repo.py" "$repository"
while IFS= read -r stamp; do
    touch -- "$repository/$stamp"
done < <(python3 -c 'import json,sys; print("\n".join(json.load(open(sys.argv[1]))["sdk_stamps"]))' "$kit/manifest.json")
chmod +x "$repository"/tools/agbcc/bin/*.exe "$repository"/tools/agbcc_*/bin/*.exe
(cd "$repository" && sh tools/install_hooks.sh)
if [[ -f "$repository/docs/ghidra/ghidra_out.tar.xz" ]]; then
    (cd "$repository" && tar xJf docs/ghidra/ghidra_out.tar.xz)
fi
python3 -c 'import pycparser,toml,colorama,cxxfilt,elftools,capstone,Levenshtein,watchdog; assert pycparser.__version__=="2.23"; print("Python: dependencias verificadas")'
(cd "$repository" && python3 tools/m2c/m2c.py --help >/dev/null &&
    python3 tools/decomp-permuter/permuter.py --help >/dev/null &&
    python3 tools/asm-differ/diff.py --help >/dev/null &&
    tools/objdiff/objdiff-cli.exe --version)
if [[ $run_build == 1 ]]; then
    [[ -f "$repository/baserom.gba" ]] || { echo "Copia tu ROM europea como $repository/baserom.gba antes de compilar; este paquete no incluye ROM." >&2; exit 2; }
    (cd "$repository" && make -j2 compare && make -j1 nonmatching &&
        python3 tools/scripts/check_tree.py)
fi
printf '\nRestaurado: %s\nRevision: %s\n' "$repository" "$revision"
printf 'En cada terminal: cd "%s" && source toolkit-env.sh\n' "$repository"

