"""Functions for evaluating assembly instructions and building Expression trees."""

from __future__ import annotations
from dataclasses import replace
import struct
from typing import (
    Callable,
    List,
    Optional,
    Tuple,
    Union,
)
from .asm_file import AsmSymbolicData
from .asm_instruction import (
    AsmAddressMode,
    AsmGlobalSymbol,
    AsmLiteral,
    BinOp,
    Register,
)
from .error import DecompFailure
from .options import Target
from .translate import (
    AddressMode,
    AddressOf,
    ArrayAccess,
    BinaryOp,
    CarryBit,
    Cast,
    Condition,
    ErrorExpr,
    ExprCondition,
    ExprStmt,
    Expression,
    FuncCall,
    GlobalSymbol,
    InstrArgs,
    Literal,
    Load3Bytes,
    LocalVar,
    Lwl,
    NodeState,
    RawSymbolRef,
    RegExpression,
    RegInfo,
    StackInfo,
    StoreStmt,
    StructAccess,
    TernaryOp,
    UnalignedLoad,
    UnaryOp,
    as_intish,
    as_intptr,
    as_sintish,
    as_type,
    as_uintish,
    early_unwrap,
    early_unwrap_ints,
    var_for_expr,
)
from .types import (
    FunctionParam,
    FunctionSignature,
    StructDeclaration,
    Type,
)


def error_stmt(msg: str) -> ExprStmt:
    return ExprStmt(ErrorExpr(msg))


def deref(
    arg: Union[AddressMode, RawSymbolRef, Expression],
    regs: RegInfo,
    stack_info: StackInfo,
    *,
    size: int,
    store: bool = False,
) -> Expression:
    if isinstance(arg, Expression):
        offset = 0
        var = arg
    elif isinstance(arg, AddressMode):
        offset = arg.offset
        if stack_info.is_stack_reg(arg.base):
            return stack_info.get_stack_var(offset, store=store)
        var = regs[arg.base]
    else:
        offset = arg.offset
        var = stack_info.global_info.address_of_gsym(arg.sym.symbol_name)

    # Struct member is being dereferenced.

    # Cope slightly better with raw pointers.
    if isinstance(var, Literal) and var.value % (2**16) == 0:
        var = Literal(var.value + offset, type=var.type)
        offset = 0

    # Handle large struct offsets or *(x + offset).
    uw_var = early_unwrap(var)
    if isinstance(uw_var, BinaryOp) and uw_var.op == "+":
        for base, addend in [(uw_var.left, uw_var.right), (uw_var.right, uw_var.left)]:
            arch = stack_info.global_info.arch
            if isinstance(addend, Literal) and (
                arch.is_likely_partial_offset(addend.value)
                or (offset == 0 and addend.value >= 0)
            ):
                offset += addend.value
                var = base
                uw_var = early_unwrap(var)
                break
    if isinstance(uw_var, AddressOf) and isinstance(uw_var.expr, StructAccess):
        base = uw_var.expr.struct_var
        iaddend = uw_var.expr.offset
        target = stack_info.global_info.target
        arch = stack_info.global_info.arch
        if (
            arch.is_likely_partial_offset(iaddend)
            or target.compiler != Target.CompilerEnum.IDO
        ):
            offset += iaddend
            var = base
            uw_var = early_unwrap(var)

    var.type.unify(Type.ptr())
    stack_info.record_struct_access(var, offset)
    type: Type = stack_info.unique_type_for("struct", (uw_var, offset), Type.any())

    if offset >= 0x200000:
        # Structs realistically aren't larger than 2 MB. The offset is more likely
        # to be a raw memory address.
        var = BinaryOp.int(Literal(offset), "+", var)
        offset = 0

    # Struct access with type information.
    array_expr = array_access_from_add(
        var, offset, stack_info, target_size=size, ptr=False
    )
    if array_expr is not None:
        return array_expr
    field_path, field_type, _ = var.type.get_deref_field(offset, target_size=size)
    if field_path is not None:
        field_type.unify(type)
        type = field_type
    else:
        field_path = None

    return StructAccess(
        struct_var=var,
        offset=offset,
        target_size=size,
        field_path=field_path,
        stack_info=stack_info,
        type=type,
    )


def condition_from_expr(expr: Expression) -> Condition:
    uw_expr = early_unwrap(expr)
    if isinstance(uw_expr, Condition) and not (
        isinstance(uw_expr, BinaryOp) and not uw_expr.is_comparison()
    ):
        return uw_expr
    return ExprCondition(expr, type=expr.type)


def imm_add_32(expr: Expression) -> Expression:
    if isinstance(expr, Literal):
        return as_intish(Literal(expr.value + 32))
    else:
        return BinaryOp.int(expr, "+", Literal(32))


def fn_op(fn_name: str, args: List[Expression], type: Type) -> FuncCall:
    fn_sig = FunctionSignature(
        return_type=type,
        params=[FunctionParam(type=arg.type) for arg in args],
        params_known=True,
        is_variadic=False,
    )
    return FuncCall(
        function=GlobalSymbol(c_symbol_name=fn_name, type=Type.function(fn_sig)),
        args=args,
        type=type,
    )


def void_fn_op(fn_name: str, args: List[Expression]) -> ExprStmt:
    fn_call = fn_op(fn_name, args, Type.any_reg())
    fn_call.use()
    return ExprStmt(fn_call)


def load_upper(args: InstrArgs) -> Expression:
    assert not isinstance(
        args.raw_arg(1), Literal
    ), "normalize_instruction should convert lui/lis <literal> to li"

    ref = args.hi_imm(1)
    stack_info = args.stack_info
    source = stack_info.global_info.address_of_gsym(ref.sym.symbol_name)
    imm = Literal(ref.offset)
    return handle_addi_real(args.reg_ref(0), None, source, imm, args)


def handle_convert(expr: Expression, dest_type: Type, source_type: Type) -> Cast:
    # int <-> float casts should be explicit
    silent = dest_type.data().kind != source_type.data().kind
    expr.type.unify(source_type)
    return Cast(expr=expr, type=dest_type, silent=silent, reinterpret=False)


def handle_la(args: InstrArgs) -> Expression:
    output_reg = args.reg_ref(0)
    target = args.memory_ref(1)
    stack_info = args.stack_info
    if isinstance(target, AddressMode):
        return handle_addi(
            output_reg,
            target.base,
            args.regs[target.base],
            Literal(target.offset),
            args,
        )

    sym = stack_info.global_info.address_of_gsym(target.sym.symbol_name)
    return add_imm(output_reg, sym, Literal(target.offset), args)


def handle_lw(args: InstrArgs) -> Expression:
    ref = args.maybe_got_imm(1)
    if ref is not None:
        # Handle `lw $a, %got(x + offset)($gp)` as an address load rather than a load.
        sym = args.stack_info.global_info.address_of_gsym(ref.sym.symbol_name)
        return add_imm(args.reg_ref(0), sym, Literal(ref.offset), args)
    return handle_load(args, type=Type.reg32(likely_float=False))


def handle_or(
    left: Expression, right: Expression, *, is_arm: bool = False
) -> Expression:
    # `or $rD, $rS, $rS` can be used to move $rS into $rD
    if left == right:
        return left

    # So can ors with zero (in particular this occurs with unoptimized agbcc
    # output, where stores sometimes look like "a = (a & 0) | b").
    if isinstance(left, Literal) and left.value == 0:
        return right
    if isinstance(right, Literal) and right.value == 0:
        return left

    if isinstance(left, Literal) and isinstance(right, Literal):
        if (((left.value & 0xFFFF) == 0 and (right.value & 0xFFFF0000) == 0)) or (
            (right.value & 0xFFFF) == 0 and (left.value & 0xFFFF0000) == 0
        ):
            return Literal(value=(left.value | right.value))

    uw_left = early_unwrap(left)
    if (
        is_arm
        and isinstance(uw_left, BinaryOp)
        and uw_left.op == "|"
        and isinstance(uw_left.right, Literal)
        and isinstance(right, Literal)
        and (uw_left.right.value % 0x100 == 0 or right.value % 0x100 == 0)
    ):
        imm = uw_left.right.value | right.value
        return BinaryOp.int(left=uw_left.left, op="|", right=Literal(imm))

    # Regular bitwise OR.
    return BinaryOp.int(left=left, op="|", right=right)


def handle_bitinv(expr: Expression) -> Expression:
    if isinstance(expr, Literal):
        return s32_literal(~expr.value)
    return UnaryOp.int("~", expr)


def handle_sltu(args: InstrArgs) -> Expression:
    right = args.reg(2)
    if args.reg_ref(1) == Register("zero"):
        # (0U < x) is equivalent to (x != 0)
        uw_right = early_unwrap(right)
        if isinstance(uw_right, BinaryOp) and uw_right.op == "^":
            # ((a ^ b) != 0) is equivalent to (a != b)
            return BinaryOp.icmp(uw_right.left, "!=", uw_right.right)
        return BinaryOp.icmp(right, "!=", Literal(0))
    else:
        left = args.reg(1)
        return BinaryOp.ucmp(left, "<", right)


def handle_sltiu(args: InstrArgs) -> Expression:
    left = args.reg(1)
    right = args.s16_imm(2)
    if isinstance(right, Literal):
        value = right.value & 0xFFFFFFFF
        if value == 1:
            # (x < 1U) is equivalent to (x == 0)
            uw_left = early_unwrap(left)
            if isinstance(uw_left, BinaryOp) and uw_left.op == "^":
                # ((a ^ b) == 0) is equivalent to (a == b)
                return BinaryOp.icmp(uw_left.left, "==", uw_left.right)
            return BinaryOp.icmp(left, "==", Literal(0))
        else:
            right = Literal(value)
    return BinaryOp.ucmp(left, "<", right)


def handle_xor(left: Expression, right: Expression) -> Expression:
    if isinstance(right, Literal) and right.value == 1:
        uw_left = early_unwrap(left)
        if isinstance(uw_left, BinaryOp) and uw_left.is_comparison():
            return uw_left.negated()
    return BinaryOp.int(left=left, op="^", right=right)


def handle_addi_mips(args: InstrArgs) -> Expression:
    output_reg = args.reg_ref(0)
    source_reg = args.reg_ref(1)
    ref = args.maybe_gprel_imm(2)
    if ref is not None and source_reg == Register("gp"):
        sym = args.stack_info.global_info.address_of_gsym(ref.sym.symbol_name)
        return add_imm(output_reg, sym, Literal(ref.offset), args)

    return handle_addi(
        output_reg,
        source_reg,
        args.reg(1),
        args.s16_imm(2),
        args,
    )


def handle_addi(
    output_reg: Register,
    source_reg: Register,
    source: Expression,
    imm: Expression,
    args: InstrArgs,
) -> Expression:
    if imm == Literal(0):
        return source

    # `(x + 0xEDCC)` is emitted as `((x + 0x10000) - 0x1234)`,
    # i.e. as an `addis` followed by an `addi`
    # ARM is similar but with (x + 0x344) + 0x12000 or (x + 0x35) + 0x1200
    arm = args.stack_info.global_info.arch.arch == Target.ArchEnum.ARM
    uw_source = early_unwrap(source)
    if (
        isinstance(uw_source, BinaryOp)
        and uw_source.op == "+"
        and isinstance(uw_source.right, Literal)
        and isinstance(imm, Literal)
        and (uw_source.right.value % 0x10000 == 0 or (arm and imm.value % 0x100 == 0))
    ):
        return add_imm(
            output_reg, uw_source.left, Literal(imm.value + uw_source.right.value), args
        )
    return handle_addi_real(output_reg, source_reg, source, imm, args)


def handle_sub_arm(args: InstrArgs) -> Expression:
    stack_info = args.stack_info
    output_reg = args.reg_ref(0)
    source_reg = args.reg_ref(1)
    lhs = args.reg(1)
    rhs = args.reg_or_imm(2)
    if (
        isinstance(rhs, Literal)
        and stack_info.is_stack_reg(source_reg)
        and stack_info.is_stack_reg(output_reg)
    ):
        # Changing sp. Just ignore that.
        return lhs
    return handle_sub(lhs, rhs)


def handle_sub(lhs: Expression, rhs: Expression) -> Expression:
    if isinstance(lhs, Literal) and isinstance(rhs, Literal):
        return s32_literal(lhs.value - rhs.value)
    if rhs == Literal(0):
        return lhs
    return fold_mul_chains(fold_divmod(BinaryOp.intptr(lhs, "-", rhs)))


def handle_addis(args: InstrArgs) -> Expression:
    source_reg = args.reg_ref(1)
    source = args.reg(1)
    imm = args.shifted_u16_imm(2)
    return handle_addi_real(args.reg_ref(0), source_reg, source, imm, args)


def handle_addi_real(
    output_reg: Register,
    source_reg: Optional[Register],
    source: Expression,
    imm: Expression,
    args: InstrArgs,
) -> Expression:
    stack_info = args.stack_info
    if source_reg is not None and stack_info.is_stack_reg(source_reg):
        # Adding to sp, i.e. passing an address.
        assert isinstance(imm, Literal)
        if stack_info.is_stack_reg(output_reg):
            # Changing sp. Just ignore that.
            return source
        # Keep track of all local variables that we take addresses of.
        var = stack_info.get_stack_var(imm.value, store=False)
        if isinstance(var, LocalVar):
            stack_info.add_local_var(var)
        return AddressOf(var, type=var.type.reference())
    else:
        return add_imm(output_reg, source, imm, args)


def add_imm(
    output_reg: Register, source: Expression, imm: Expression, args: InstrArgs
) -> Expression:
    stack_info = args.stack_info
    if imm == Literal(0):
        # addiu $reg1, $reg2, 0 is a move
        # (this happens when replacing %lo(...) by 0)
        return source
    elif source.type.is_pointer_or_array():
        # Pointer addition (this may miss some pointers that get detected later;
        # unfortunately that's hard to do anything about with m2c's single-pass
        # architecture). Don't do this in the case "var_x = var_x + imm": that
        # happens with loops over subarrays and it's better to expose the raw
        # immediate.
        dest_var = stack_info.get_planned_var(output_reg, args.instruction_ref)
        arch = stack_info.global_info.arch
        inplace = dest_var is not None and var_for_expr(source) == dest_var
        if (
            isinstance(imm, Literal)
            and not arch.is_likely_partial_offset(imm.value)
            and not inplace
        ):
            array_access = array_access_from_add(
                source, imm.value, stack_info, target_size=None, ptr=True
            )
            if array_access is not None:
                return array_access

            field_path, field_type, _ = source.type.get_deref_field(
                imm.value, target_size=None
            )
            if field_path is not None:
                return AddressOf(
                    StructAccess(
                        struct_var=source,
                        offset=imm.value,
                        target_size=None,
                        field_path=field_path,
                        stack_info=stack_info,
                        type=field_type,
                    ),
                    type=field_type.reference(),
                )
        if isinstance(imm, Literal):
            target = source.type.get_pointer_target()
            if target:
                target_size = target.get_size_bytes()
                if target_size and imm.value % target_size == 0:
                    # Pointer addition.
                    return BinaryOp(
                        left=source, op="+", right=as_intish(imm), type=source.type
                    )
        return BinaryOp(left=source, op="+", right=as_intish(imm), type=Type.ptr())
    elif isinstance(source, Literal) and isinstance(imm, Literal):
        return Literal(source.value + imm.value)
    else:
        # Regular binary addition.
        return BinaryOp.intptr(left=source, op="+", right=imm)


def handle_load(args: InstrArgs, type: Type) -> Expression:
    size = type.get_size_bytes()
    assert size is not None
    output_reg = args.reg_ref(0)
    expr = deref(args.memory_ref(1), args.regs, args.stack_info, size=size)

    def load_rodata_constant() -> Optional[Expression]:
        if not isinstance(expr, StructAccess):
            return None

        arch = args.stack_info.global_info.arch.arch
        is_arm = arch == Target.ArchEnum.ARM
        is_sh = arch == Target.ArchEnum.SH
        if is_arm and isinstance(args.raw_arg(1), AsmAddressMode):
            # For ARM, only allow constants loaded through `ldr pool`.
            # Do allow non-zero offsets: they occur in raw agbcc output which
            # we use for tests.
            return None
        if (
            not is_arm
            and not is_sh
            and (not type.is_likely_float() or expr.offset != 0)
        ):
            # Outside of ARM/SH, only allow float constants and offset 0.
            return None

        target = early_unwrap(expr.struct_var)
        if not isinstance(target, AddressOf) or not isinstance(
            target.expr, GlobalSymbol
        ):
            return None

        ent = target.expr.asm_data_entry
        if ent is None or not ent.is_readonly:
            return None

        data = ent.data_at_offset(expr.offset, size)
        if data is None:
            return None

        if isinstance(data, bytes) and size in (2, 4, 8):
            ent.used_as_literal = True
            endian = ">" if args.stack_info.global_info.target.is_big_endian() else "<"
            fmt = {2: "H", 4: "I", 8: "Q"}[size]
            val: int = struct.unpack(endian + fmt, data)[0]
            if type.is_signed() and val & (1 << (size * 8 - 1)):
                val -= 1 << (size * 8)
            return Literal(value=val, type=type)

        if (is_arm or is_sh) and ent.is_text and isinstance(data, AsmSymbolicData):
            sym = data.data
            addend = 0
            if (
                isinstance(sym, BinOp)
                and sym.op in ("+", "-")
                and isinstance(sym.rhs, AsmLiteral)
            ):
                addend = sym.rhs.value * (-1 if sym.op == "-" else 1)
                sym = sym.lhs
            if isinstance(sym, AsmGlobalSymbol):
                ent.used_as_literal = True
                addr = args.stack_info.global_info.address_of_gsym(sym.symbol_name)
                addr = add_imm(output_reg, addr, Literal(addend), args)
                return as_type(addr, type, silent=True)

        return None

    const = load_rodata_constant()
    if const is not None:
        return const

    # For now, make the cast silent so that output doesn't become cluttered.
    # Though really, it would be great to expose the load types somehow...
    return as_type(expr, type, silent=True)


def deref_unaligned(
    arg: Union[AddressMode, RawSymbolRef],
    regs: RegInfo,
    stack_info: StackInfo,
    *,
    store: bool = False,
) -> Expression:
    # We don't know the correct size pass to deref. Passing None would signal that we
    # are taking an address, cause us to prefer entire substructs as referenced fields,
    # which would be confusing. Instead, we lie and pass 1. Hopefully nothing bad will
    # happen...
    return deref(arg, regs, stack_info, size=1, store=store)


def handle_lwl(args: InstrArgs) -> Expression:
    # Unaligned load for the left part of a register (lwl can technically merge with
    # a pre-existing lwr, but doesn't in practice, so we treat this as a standard
    # destination-first operation)
    ref = args.memory_ref(1)
    expr = deref_unaligned(ref, args.regs, args.stack_info)
    key: Tuple[int, object]
    if isinstance(ref, AddressMode):
        key = (ref.offset, args.regs[ref.base])
    else:
        key = (ref.offset, ref.sym)
    return Lwl(expr, key)


def handle_lwr(args: InstrArgs) -> Expression:
    # Unaligned load for the right part of a register. This lwr may merge with an
    # existing lwl, if it loads from the same target but with an offset that's ±3.
    uw_old_value = early_unwrap(args.reg(0))
    ref = args.memory_ref(1)
    lwl_key: Tuple[int, object]
    delta = -3 if args.stack_info.global_info.target.is_big_endian() else 3
    if isinstance(ref, AddressMode):
        lwl_key = (ref.offset + delta, args.regs[ref.base])
    else:
        lwl_key = (ref.offset + delta, ref.sym)
    if isinstance(uw_old_value, Lwl) and uw_old_value.key[0] == lwl_key[0]:
        if args.stack_info.global_info.target.is_big_endian():
            load_expr = uw_old_value.load_expr
        else:
            load_expr = deref_unaligned(ref, args.regs, args.stack_info)
        return UnalignedLoad(load_expr)
    # IDO may copy 3 bytes between 4-byte-aligned addresses using lwr+swr, e.g. for
    # the purpose of array initializers. Little endian can use lwl+swl instead,
    # but other compilers don't seem to emit this pattern so we don't handle that
    # at the moment.
    if ref.offset % 4 == 2 and args.stack_info.global_info.target.is_big_endian():
        left_mem_ref = replace(ref, offset=ref.offset - 2)
        load_expr = deref_unaligned(left_mem_ref, args.regs, args.stack_info)
        return Load3Bytes(load_expr)
    return ErrorExpr("Unable to handle lwr; missing a corresponding lwl")


def make_store(args: InstrArgs, type: Type) -> Optional[StoreStmt]:
    size = type.get_size_bytes()
    assert size is not None
    stack_info = args.stack_info
    source_reg = args.reg_ref(0)
    source_raw = args.regs.get_raw(source_reg)
    if type.is_likely_float() and size == 8:
        source_val = args.dreg(0)
    else:
        source_val = args.reg(0)
    target = args.memory_ref(1)
    return make_store_real(source_val, source_raw, target, args.regs, stack_info, type)


def make_store_real(
    source_val: Expression,
    source_raw: Optional[RegExpression],
    target: Union[AddressMode, RawSymbolRef],
    regs: RegInfo,
    stack_info: StackInfo,
    type: Type,
) -> Optional[StoreStmt]:
    size = type.get_size_bytes()
    assert size is not None
    is_stack = isinstance(target, AddressMode) and stack_info.is_stack_reg(target.base)
    if (
        is_stack
        and source_raw is not None
        and stack_info.should_save(source_raw, target.offset)
    ):
        # Elide register preserval.
        return None
    dest = deref(target, regs, stack_info, size=size, store=True)
    dest.type.unify(type)
    return StoreStmt(source=as_type(source_val, type, silent=is_stack), dest=dest)


def make_storex(args: InstrArgs, type: Type) -> Optional[StoreStmt]:
    # "indexed stores" like `stwx rS, rA, rB` write `rS` into `(rA + rB)`
    size = type.get_size_bytes()
    assert size is not None

    source = args.reg(0)
    ptr = BinaryOp.intptr(left=args.reg(1), op="+", right=args.reg(2))

    # TODO: Can we assume storex's are never used to save registers to the stack?
    dest = deref(ptr, args.regs, args.stack_info, size=size, store=True)
    dest.type.unify(type)
    return StoreStmt(source=as_type(source, type, silent=False), dest=dest)


def handle_swl(args: InstrArgs) -> Optional[StoreStmt]:
    # swl in practice only occurs together with swr, so we can treat it as a regular
    # store, with the expression wrapped in UnalignedLoad if needed.
    source = args.reg(0)
    target = args.memory_ref(1)
    if not isinstance(early_unwrap(source), UnalignedLoad):
        source = UnalignedLoad(source)
    if not args.stack_info.global_info.target.is_big_endian():
        target = replace(target, offset=target.offset - 3)
    dest = deref_unaligned(target, args.regs, args.stack_info, store=True)
    return StoreStmt(source=source, dest=dest)


def handle_swr(args: InstrArgs) -> Optional[StoreStmt]:
    expr = early_unwrap(args.reg(0))
    target = args.memory_ref(1)
    if not isinstance(expr, Load3Bytes):
        # Elide swr's that don't come from 3-byte-loading lwr's; they probably
        # come with a corresponding swl which has already been emitted.
        return None
    real_target = replace(target, offset=target.offset - 2)
    dest = deref_unaligned(real_target, args.regs, args.stack_info, store=True)
    return StoreStmt(source=expr, dest=dest)


def handle_shift_right(
    args: InstrArgs, *, signed: bool, arm: bool = False
) -> Expression:
    lhs = args.reg(1)
    shift = args.reg_or_imm(2) if arm else args.s16_imm(2)
    if isinstance(shift, Literal) and shift.value in [16, 24]:
        expr = early_unwrap(lhs)
        pow2 = 1 << shift.value
        if isinstance(expr, BinaryOp) and isinstance(expr.right, Literal):
            if signed:
                tp = Type.s16() if shift.value == 16 else Type.s8()
            else:
                tp = Type.u16() if shift.value == 16 else Type.u8()
            rhs = expr.right.value
            if expr.op == "<<" and rhs == shift.value:
                return as_type(expr.left, tp, silent=False)
            elif expr.op == "<<" and rhs > shift.value:
                new_shift = fold_mul_chains(
                    BinaryOp.int(expr.left, "<<", Literal(rhs - shift.value))
                )
                return as_type(new_shift, tp, silent=False)
            elif expr.op == "*" and rhs % pow2 == 0 and rhs != pow2:
                mul = BinaryOp.int(expr.left, "*", Literal(value=rhs // pow2))
                return as_type(mul, tp, silent=False)
    if signed:
        return fold_divmod(BinaryOp.sshift(lhs, ">>", shift))
    else:
        return BinaryOp.ushift(lhs, ">>", shift)


def handle_sll(args: InstrArgs, *, arm: bool = False) -> Expression:
    lhs = args.reg(1)
    rhs = args.reg_or_imm(2) if arm else args.s16_imm(2)
    if isinstance(lhs, Literal) and isinstance(rhs, Literal):
        return Literal(lhs.value << rhs.value)
    return fold_mul_chains(BinaryOp.int(lhs, "<<", as_intish(rhs)))


def handle_conditional_move(args: InstrArgs, nonzero: bool) -> Expression:
    op = "!=" if nonzero else "=="
    val = args.reg(2)
    type = Type.any_reg()
    return TernaryOp(
        BinaryOp.icmp(val, op, Literal(0, type=val.type)),
        as_type(args.reg(1), type, silent=True),
        as_type(args.reg(0), type, silent=True),
        type,
    )


def fold_divmod(original_expr: BinaryOp) -> BinaryOp:
    """
    Return a new BinaryOp instance if this one can be simplified to a single / or % op.
    This involves simplifying expressions using MULT_HI, MULTU_HI, +, -, <<, >>, and /.

    In GCC 2.7.2, the code that generates these instructions is in expmed.c.

    See also https://ridiculousfish.com/blog/posts/labor-of-division-episode-i.html
    for a modern writeup of a similar algorithm.

    This optimization is also used by MWCC and modern compilers (but not IDO).
    """
    mult_high_ops = ("MULT_HI", "MULTU_HI")
    possible_match_ops = mult_high_ops + ("-", "+", ">>")

    # Only operate on integer expressions of certain operations
    if original_expr.is_floating() or original_expr.op not in possible_match_ops:
        return original_expr

    # Use `early_unwrap_ints` instead of `early_unwrap` to ignore Casts to integer types
    # Although this discards some extra type information, this function largely ignores
    # sign/size information to stay simpler. The result will be made with BinaryOp.int()
    # regardless of input types.
    expr = original_expr
    left_expr = early_unwrap_ints(expr.left)
    right_expr = early_unwrap_ints(expr.right)
    divisor_shift = 0

    # Normalize MULT_HI(N, x) to MULT_HI(x, N)
    if isinstance(left_expr, Literal) and not isinstance(right_expr, Literal):
        left_expr, right_expr = right_expr, left_expr

    # Detect signed power-of-two division: (x >> N) + M2C_CARRY --> x / (1 << N)
    if (
        isinstance(left_expr, BinaryOp)
        and left_expr.op == ">>"
        and isinstance(left_expr.right, Literal)
        and expr.op == "+"
        and isinstance(right_expr, CarryBit)
    ):
        new_denom = 1 << left_expr.right.value
        return BinaryOp.sint(
            left=left_expr.left,
            op="/",
            right=Literal(new_denom),
            silent=True,
        )

    # Fold `/` with `>>`: ((x / N) >> M) --> x / (N << M)
    # NB: If x is signed, this is only correct if there is a sign-correcting subtraction term
    if (
        isinstance(left_expr, BinaryOp)
        and left_expr.op == "/"
        and isinstance(left_expr.right, Literal)
        and expr.op == ">>"
        and isinstance(right_expr, Literal)
    ):
        new_denom = left_expr.right.value << right_expr.value
        if new_denom < (1 << 32):
            return BinaryOp.int(
                left=left_expr.left,
                op="/",
                right=Literal(new_denom),
            )

    # Detect `%`: (x - ((x / y) * y)) --> x % y
    if expr.op == "-" and isinstance(right_expr, BinaryOp) and right_expr.op == "*":
        div_expr = early_unwrap_ints(right_expr.left)
        mod_base = early_unwrap_ints(right_expr.right)
        if (
            isinstance(div_expr, BinaryOp)
            and early_unwrap_ints(div_expr.left) == left_expr
        ):
            # Accept either `(x / y) * y` or `(x >> N) * M` (where `1 << N == M`)
            divisor = early_unwrap_ints(div_expr.right)
            if (div_expr.op == "/" and divisor == mod_base) or (
                div_expr.op == ">>"
                and isinstance(divisor, Literal)
                and isinstance(mod_base, Literal)
                and (1 << divisor.value) == mod_base.value
            ):
                return BinaryOp.int(left=left_expr, op="%", right=right_expr.right)

    # Detect dividing by a negative: ((x >> 31) - (x / N)) --> x / -N
    if (
        expr.op == "-"
        and isinstance(left_expr, BinaryOp)
        and left_expr.op == ">>"
        and early_unwrap_ints(left_expr.right) == Literal(31)
        and isinstance(right_expr, BinaryOp)
        and right_expr.op == "/"
        and isinstance(right_expr.right, Literal)
    ):
        # Swap left_expr & right_expr, but replace the N in right_expr with -N
        left_expr, right_expr = (
            replace(right_expr, right=Literal(-right_expr.right.value)),
            left_expr,
        )

    # Remove outer error term: ((x / N) + ((x / N) >> 31)) --> x / N
    # As N gets close to (1 << 30), this is no longer a negligible error term
    if (
        expr.op == "+"
        and isinstance(left_expr, BinaryOp)
        and left_expr.op == "/"
        and isinstance(left_expr.right, Literal)
        and left_expr.right.value <= (1 << 29)
        and isinstance(right_expr, BinaryOp)
        and early_unwrap_ints(right_expr.left) == left_expr
        and right_expr.op == ">>"
        and early_unwrap_ints(right_expr.right) == Literal(31)
    ):
        return left_expr

    # Remove outer error term: ((x / N) - (x >> 31)) --> x / N
    if (
        expr.op == "-"
        and isinstance(left_expr, BinaryOp)
        and left_expr.op == "/"
        and isinstance(left_expr.right, Literal)
        and isinstance(right_expr, BinaryOp)
        and right_expr.op == ">>"
        and early_unwrap_ints(right_expr.right) == Literal(31)
    ):
        div_expr = left_expr
        shift_var_expr = early_unwrap_ints(right_expr.left)
        div_var_expr = early_unwrap_ints(div_expr.left)
        # Check if the LHS of the shift is the same var that we're dividing by
        if div_var_expr == shift_var_expr:
            if isinstance(div_expr.right, Literal) and div_expr.right.value >= (
                1 << 30
            ):
                return BinaryOp.int(
                    left=div_expr.left,
                    op=div_expr.op,
                    right=div_expr.right,
                )
            return div_expr
        # If the var is under 32 bits, the error term may look like `(x << K) >> 31` instead
        if (
            isinstance(shift_var_expr, BinaryOp)
            and early_unwrap_ints(div_expr.left)
            == early_unwrap_ints(shift_var_expr.left)
            and shift_var_expr.op == "<<"
            and isinstance(shift_var_expr.right, Literal)
        ):
            return div_expr

    # Shift on the result of the mul: MULT_HI(x, N) >> M, shift the divisor by M
    if (
        isinstance(left_expr, BinaryOp)
        and expr.op == ">>"
        and isinstance(right_expr, Literal)
    ):
        divisor_shift += right_expr.value
        expr = left_expr
        left_expr = early_unwrap_ints(expr.left)
        right_expr = early_unwrap_ints(expr.right)

        # Remove inner addition: (MULT_HI(x, N) + x) >> M --> MULT_HI(x, N) >> M
        # MULT_HI performs signed multiplication, so the `+ x` acts as setting the 32nd bit
        # while having a result with the same sign as x.
        # We can ignore it because `round_div` can work with arbitrarily large constants
        if (
            isinstance(left_expr, BinaryOp)
            and left_expr.op == "MULT_HI"
            and expr.op == "+"
            and (
                right_expr == early_unwrap_ints(left_expr.left)
                or right_expr == early_unwrap_ints(left_expr.right)
            )
        ):
            expr = left_expr
            left_expr = early_unwrap_ints(expr.left)
            right_expr = early_unwrap_ints(expr.right)

        # Normalize MULT_HI(N, x) to MULT_HI(x, N)
        if isinstance(left_expr, Literal) and not isinstance(right_expr, Literal):
            left_expr, right_expr = right_expr, left_expr

    # Shift on the LHS of the mul: MULT_HI(x >> M, N) --> MULT_HI(x, N) >> M
    if (
        expr.op in mult_high_ops
        and isinstance(left_expr, BinaryOp)
        and left_expr.op == ">>"
        and isinstance(left_expr.right, Literal)
    ):
        divisor_shift += left_expr.right.value
        left_expr = early_unwrap_ints(left_expr.left)

    # Instead of checking for the error term precisely, just check that
    # the quotient is "close enough" to the integer value
    def round_div(x: int, y: int) -> Optional[int]:
        if y <= 1:
            return None
        result = round(x / y)
        if x / (y + 1) <= result <= x / (y - 1):
            return result
        return None

    if expr.op in mult_high_ops and isinstance(right_expr, Literal):
        denom = round_div(1 << (32 + divisor_shift), right_expr.value)
        if denom is not None:
            return BinaryOp.int(
                left=left_expr,
                op="/",
                right=Literal(denom),
            )

    return original_expr


def replace_clz_shift(expr: BinaryOp) -> BinaryOp:
    """
    Simplify an expression matching `CLZ(x) >> 5` into `x == 0`,
    and further simplify `(a - b) == 0` into `b == a`.
    """
    # Check that the outer expression is `>>`
    if expr.is_floating() or expr.op != ">>":
        return expr

    # Match `CLZ(x) >> 5`, or return the original expr
    left_expr = early_unwrap_ints(expr.left)
    right_expr = early_unwrap_ints(expr.right)
    if not (
        isinstance(left_expr, UnaryOp)
        and left_expr.op == "CLZ"
        and isinstance(right_expr, Literal)
        and right_expr.value == 5
    ):
        return expr

    # If the inner `x` is `(a - b)`, return `b == a`
    sub_expr = early_unwrap(left_expr.expr)
    if (
        isinstance(sub_expr, BinaryOp)
        and not sub_expr.is_floating()
        and sub_expr.op == "-"
    ):
        return BinaryOp.icmp(sub_expr.right, "==", sub_expr.left)

    return BinaryOp.icmp(left_expr.expr, "==", Literal(0, type=left_expr.expr.type))


def replace_bitand(expr: BinaryOp) -> Expression:
    """Simplify expressions using `&`."""
    if not expr.is_floating() and expr.op == "&":
        if expr.right == Literal(0):
            # agbcc emits stores that look like "a = (a & 0) | b"; get rid of the load
            return Literal(0)
        if expr.right == Literal(0xFF):
            return as_type(expr.left, Type.u8(), silent=False)
        if expr.right == Literal(0xFFFF):
            return as_type(expr.left, Type.u16(), silent=False)
    return expr


def fold_mul_chains(expr: Expression, *, allow_sll_chains: bool = False) -> Expression:
    """Simplify an expression involving +, -, * and << to a single multiplication,
    e.g. 4*x - x -> 3*x, or x<<2 -> x*4. This includes some logic for preventing
    folds of consecutive sll, and keeping multiplications by large powers of two
    as bitshifts at the top layer. Set allow_sll_chains for architectures that
    implement larger shifts as consecutive fixed-size shift instructions."""

    def fold(
        expr: Expression, toplevel: bool, allow_sll: bool
    ) -> Tuple[Expression, int]:
        if isinstance(expr, BinaryOp):
            if expr.op in ("<<", "*") and isinstance(expr.right, Literal):
                lbase, lnum = fold(expr.left, False, (expr.op != "<<"))
                rhs = expr.right.value
                if expr.op == "<<" and (allow_sll or allow_sll_chains):
                    # At top level, keep left shifts, unless they are by such
                    # small numbers that they are easier to understand as
                    # multiplications (they compile to the same thing).
                    if toplevel and lnum == 1 and not (1 <= rhs <= 4):
                        return (expr, 1)
                    return (lbase, lnum << rhs)
                if expr.op == "*" and (allow_sll or allow_sll_chains or rhs % 2 != 0):
                    # If we don't allow << to be expanded into multiplication
                    # because the outer layer is already <<'ing, don't allow
                    # multiplication by even numbers either, because the power
                    # of two part of that scalar would have been folded into
                    # the outer shift unless something weird was up, which we
                    # want to highlight.
                    return (lbase, lnum * rhs)
            if expr.op in ("+", "-") and toplevel:
                lbase, lnum = fold(expr.left, False, (expr.op != "<<"))
                rbase, rnum = fold(expr.right, False, (expr.op != "<<"))
                if early_unwrap(lbase) == early_unwrap(rbase):
                    if expr.op == "+":
                        return (lbase, lnum + rnum)
                    if expr.op == "-":
                        return (lbase, lnum - rnum)
        if isinstance(expr, UnaryOp) and expr.op == "-" and not toplevel:
            base, num = fold(expr.expr, False, True)
            return (base, -num)
        uw_expr = early_unwrap(expr)
        if uw_expr is not expr:
            base, num = fold(uw_expr, False, allow_sll)
            if num != 1:
                return (base, num)
        return (expr, 1)

    base, num = fold(expr, True, True)
    if num == 1:
        return expr
    if allow_sll_chains and num > 16 and num & (num - 1) == 0:
        return BinaryOp.int(base, "<<", Literal(num.bit_length() - 1))
    return BinaryOp.int(left=base, op="*", right=Literal(num))


def fold_shift_right(expr: Expression, shift: int, *, signed: bool) -> Expression:
    inner = early_unwrap_ints(expr)
    if (
        isinstance(inner, BinaryOp)
        and inner.op == ">>"
        and inner.type.is_signed() == signed
        and isinstance(inner.right, Literal)
        and inner.right.value + shift < 32
    ):
        expr = inner.left
        shift += inner.right.value
    if signed:
        ret = BinaryOp.sshift(expr, ">>", Literal(shift))
    else:
        ret = BinaryOp.ushift(expr, ">>", Literal(shift))
    return fold_divmod(ret)


def array_access_from_add(
    expr: Expression,
    offset: int,
    stack_info: StackInfo,
    *,
    target_size: Optional[int],
    ptr: bool,
) -> Optional[Expression]:
    """Given `expr` of the form `a + (imm * b + Y)` and an `offset` X, try to
    create a corresponding expression of the form `a->unk(X + Y)[b]` if type
    information allows."""
    expr = early_unwrap(expr)
    if not isinstance(expr, BinaryOp) or expr.op != "+":
        return None
    base = expr.left
    addend = expr.right
    if addend.type.is_pointer_or_array() and not base.type.is_pointer_or_array():
        base, addend = addend, base

    if isinstance(addend, Literal):
        return None

    uw_addend = early_unwrap(addend)
    if isinstance(uw_addend, BinaryOp) and uw_addend.op == "+":
        if isinstance(uw_addend.right, Literal):
            offset += uw_addend.right.value
            addend = uw_addend.left
        elif isinstance(uw_addend.left, Literal):
            offset += uw_addend.left.value
            addend = uw_addend.right

    index = addend
    scale = 1
    uw_addend = early_unwrap(addend)
    if (
        isinstance(uw_addend, BinaryOp)
        and uw_addend.op in ("*", "<<")
        and isinstance(uw_addend.right, Literal)
    ):
        index = uw_addend.left
        scale = uw_addend.right.value
        if uw_addend.op == "<<":
            scale = 1 << scale

    if scale < 0:
        scale = -scale
        index = UnaryOp.sint("-", index)

    target_type = base.type.get_pointer_target()
    if target_type is None:
        return None

    uw_base = early_unwrap(base)
    typepool = stack_info.global_info.typepool

    # In `&x + index * scale`, if the type of `x` is not known, try to mark it as an array.
    # Skip the `scale = 1` case because this often indicates a complex `index` expression,
    # and is not actually a 1-byte array lookup.
    if (
        scale > 1
        and offset == 0
        and isinstance(uw_base, AddressOf)
        and target_type.get_size_bytes() is None
    ):
        inner_type: Optional[Type] = None
        if (
            isinstance(uw_base.expr, GlobalSymbol)
            and uw_base.expr.potential_array_dim(scale)[1] != 0
        ):
            # For GlobalSymbols, use the size of the asm data to check the feasibility of being
            # an array with `scale`. This helps be more conservative around fake symbols.
            pass
        elif scale == 2:
            # This *could* be a struct, but is much more likely to be an int
            inner_type = Type.int_of_size(16)
        elif scale == 4:
            inner_type = Type.reg32(likely_float=False)
        elif typepool.unk_inference and isinstance(uw_base.expr, GlobalSymbol):
            # Make up a struct with a tag name based on the symbol & struct size.
            # Although `scale = 8` could indicate an array of longs/doubles, it seems more
            # common to be an array of structs.
            struct_name = f"_struct_{uw_base.expr.c_symbol_name}_0x{scale:X}"
            struct = typepool.get_struct_by_tag_name(
                struct_name, stack_info.global_info.typemap
            )
            if struct is None:
                struct = StructDeclaration.unknown(
                    typepool, size=scale, tag_name=struct_name
                )
            elif struct.size != scale:
                # This should only happen if there was already a struct with this name in the context
                raise DecompFailure(f"sizeof(struct {struct_name}) != {scale:#x}")
            inner_type = Type.struct(struct)

        if inner_type is not None:
            # This might fail, if `uw_base.expr.type` can't be changed to an array
            uw_base.expr.type.unify(Type.array(inner_type, dim=None))
            # This acts as a backup, and will usually succeed
            target_type.unify(inner_type)

    if target_type.get_size_bytes() == scale:
        # base[index]
        pass
    else:
        # base->subarray[index]
        sub_path, sub_type, remaining_offset = base.type.get_deref_field(
            offset, target_size=scale, exact=False
        )
        # Check if the last item in the path is `0`, which indicates the start of an array
        # If it is, remove it: it will be replaced by `[index]`
        if sub_path is None or len(sub_path) < 2 or sub_path[-1] != 0:
            return None
        sub_path.pop()
        base = StructAccess(
            struct_var=base,
            offset=offset - remaining_offset,
            target_size=None,
            field_path=sub_path,
            stack_info=stack_info,
            type=sub_type,
        )
        offset = remaining_offset
        target_type = sub_type

    ret: Expression = ArrayAccess(base, index, type=target_type)

    # Add .field if necessary by wrapping ret in StructAccess(AddressOf(...))
    ret_ref = AddressOf(ret, type=ret.type.reference())
    field_path, field_type, _ = ret_ref.type.get_deref_field(
        offset, target_size=target_size
    )

    if offset != 0 or (target_size is not None and target_size != scale):
        ret = StructAccess(
            struct_var=ret_ref,
            offset=offset,
            target_size=target_size,
            field_path=field_path,
            stack_info=stack_info,
            type=field_type,
        )

    if ptr:
        ret = AddressOf(ret, type=ret.type.reference())

    return ret


def handle_add(args: InstrArgs) -> Expression:
    output_reg = args.reg_ref(0)
    lhs = args.reg(1)
    rhs = args.reg(2)

    # addiu instructions can sometimes be emitted as addu instead, when the
    # offset is too large.
    if isinstance(rhs, Literal):
        return fold_mul_chains(
            handle_addi_real(output_reg, args.reg_ref(1), lhs, rhs, args)
        )
    if isinstance(lhs, Literal):
        return fold_mul_chains(
            handle_addi_real(output_reg, args.reg_ref(2), rhs, lhs, args)
        )

    return handle_add_real(lhs, rhs, args)


def handle_add_arm(args: InstrArgs) -> Expression:
    if isinstance(args.raw_arg(2), Register):
        return handle_add(args)
    else:
        return handle_addi(
            args.reg_ref(0),
            args.reg_ref(1),
            args.reg(1),
            args.full_imm(2),
            args,
        )


def handle_add_real(
    lhs: Expression,
    rhs: Expression,
    args: InstrArgs,
) -> Expression:
    stack_info = args.stack_info

    if lhs == Literal(0):
        return rhs
    if rhs == Literal(0):
        return lhs

    type = Type.intptr()
    # Because lhs & rhs are in registers, it shouldn't be possible for them to be arrays.
    # If they are, treat them the same as pointers anyways.
    if lhs.type.is_pointer_or_array():
        type = Type.ptr()
    elif rhs.type.is_pointer_or_array():
        type = Type.ptr()

    expr = BinaryOp(left=as_intptr(lhs), op="+", right=as_intptr(rhs), type=type)
    folded_expr = fold_mul_chains(expr)
    if isinstance(folded_expr, BinaryOp):
        folded_expr = fold_divmod(folded_expr)
    if folded_expr is not expr:
        return folded_expr
    array_expr = array_access_from_add(expr, 0, stack_info, target_size=None, ptr=True)
    if array_expr is not None:
        return array_expr
    return expr


def handle_add_float(args: InstrArgs) -> Expression:
    if args.reg_ref(1) == args.reg_ref(2):
        two = Literal(1 << 30, type=Type.f32())
        return BinaryOp.f32(two, "*", args.reg(1))
    return BinaryOp.f32(args.reg(1), "+", args.reg(2))


def handle_add_double(args: InstrArgs) -> Expression:
    if args.reg_ref(1) == args.reg_ref(2):
        two = Literal(1 << 62, type=Type.f64())
        return BinaryOp.f64(two, "*", args.dreg(1))
    return BinaryOp.f64(args.dreg(1), "+", args.dreg(2))


def fold_shift_bgez(expr: Expression) -> Optional[Condition]:
    uw_expr = early_unwrap(expr)
    if not isinstance(uw_expr, BinaryOp) or not isinstance(uw_expr.right, Literal):
        return None
    value = uw_expr.right.value
    if uw_expr.op == "<<":
        shift = value
    elif uw_expr.op == "*" and value > 0 and (value & (value - 1)) == 0:
        shift = value.bit_length() - 1
    else:
        return None
    bitand = BinaryOp.int(uw_expr.left, "&", Literal(1 << (31 - shift)))
    return UnaryOp("!", bitand, type=Type.boolean())


def handle_bgez(args: InstrArgs) -> Condition:
    expr = args.reg(0)
    return fold_shift_bgez(expr) or BinaryOp.scmp(expr, ">=", Literal(0))


def rlwi_mask(mask_begin: int, mask_end: int) -> int:
    # Compute the mask constant used by the rlwi* family of PPC instructions,
    # referred to as the `MASK(MB, ME)` function in the processor manual.
    # Bit 0 is the MSB, Bit 31 is the LSB
    bits_upto: Callable[[int], int] = lambda m: (1 << (32 - m)) - 1
    all_ones = 0xFFFFFFFF
    if mask_begin <= mask_end:
        # Set bits inside the range, fully inclusive
        mask = bits_upto(mask_begin) - bits_upto(mask_end + 1)
    else:
        # Set bits from [31, mask_end] and [mask_begin, 0]
        mask = (bits_upto(mask_end + 1) - bits_upto(mask_begin)) ^ all_ones
    return mask


def handle_rlwinm(
    source: Expression,
    shift: int,
    mask_begin: int,
    mask_end: int,
    simplify: bool = True,
) -> Expression:
    # TODO: Detect shift + truncate, like `(x << 2) & 0xFFF3` or `(x >> 2) & 0x3FFF`

    # The output of the rlwinm instruction is `ROTL(source, shift) & mask`. We write this as
    # ((source << shift) & mask) | ((source >> (32 - shift)) & mask)
    # and compute both OR operands (upper_bits and lower_bits respectively).
    all_ones = 0xFFFFFFFF
    mask = rlwi_mask(mask_begin, mask_end)
    left_shift = shift
    right_shift = 32 - shift
    left_mask = (all_ones << left_shift) & mask
    right_mask = (all_ones >> right_shift) & mask

    # We only simplify if the `simplify` argument is True, and there will be no `|` in the
    # resulting expression. If there is an `|`, the expression is best left as bitwise math
    simplify = simplify and not (left_mask and right_mask)

    if isinstance(source, Literal):
        upper_value = (source.value << left_shift) & mask
        lower_value = (source.value >> right_shift) & mask
        return Literal(upper_value | lower_value)

    upper_bits: Optional[Expression]
    if left_mask == 0:
        upper_bits = None
    else:
        upper_bits = source
        if left_shift != 0:
            upper_bits = BinaryOp.int(
                left=upper_bits, op="<<", right=Literal(left_shift)
            )

        if simplify:
            upper_bits = fold_mul_chains(upper_bits)

        if left_mask != (all_ones << left_shift) & all_ones:
            upper_bits = BinaryOp.int(left=upper_bits, op="&", right=Literal(left_mask))
            if simplify:
                upper_bits = replace_bitand(upper_bits)

    lower_bits: Optional[Expression]
    if right_mask == 0:
        lower_bits = None
    else:
        lower_bits = BinaryOp.uint(left=source, op=">>", right=Literal(right_shift))

        if simplify:
            lower_bits = replace_clz_shift(fold_divmod(lower_bits))

        if right_mask != (all_ones >> right_shift) & all_ones:
            lower_bits = BinaryOp.int(
                left=lower_bits, op="&", right=Literal(right_mask)
            )
            if simplify:
                lower_bits = replace_bitand(lower_bits)

    if upper_bits is None and lower_bits is None:
        return Literal(0)
    elif upper_bits is None:
        assert lower_bits is not None
        return lower_bits
    elif lower_bits is None:
        return upper_bits
    else:
        return BinaryOp.int(left=upper_bits, op="|", right=lower_bits)


def handle_rlwimi(
    base: Expression, source: Expression, shift: int, mask_begin: int, mask_end: int
) -> Expression:
    # This instruction reads from `base`, replaces some bits with values from `source`, then
    # writes the result back into the first register. This can be used to copy any contiguous
    # bitfield from `source` into `base`, and is commonly used when manipulating flags, such
    # as in `x |= 0x10` or `x &= ~0x10`.

    # It's generally more readable to write the mask with `~` (instead of computing the inverse here)
    mask_literal = Literal(rlwi_mask(mask_begin, mask_end))
    mask = UnaryOp("~", mask_literal, type=Type.u32())
    masked_base = BinaryOp.int(left=base, op="&", right=mask)
    if source == Literal(0):
        # If the source is 0, there are no bits inserted. (This may look like `x &= ~0x10`)
        return masked_base
    # Set `simplify=False` to keep the `inserted` expression as bitwise math instead of `*` or `/`
    inserted = handle_rlwinm(source, shift, mask_begin, mask_end, simplify=False)
    if inserted == mask_literal:
        # If this instruction will set all the bits in the mask, we can OR the values
        # together without masking the base. (`x |= 0xF0` instead of `x = (x & ~0xF0) | 0xF0`)
        return BinaryOp.int(left=base, op="|", right=inserted)
    return BinaryOp.int(left=masked_base, op="|", right=inserted)


def handle_rlwnm(
    source: Expression, shift_source: Expression, mask_begin: int, mask_end: int
) -> Expression:
    # This instruction is very similar to rlwinm, but instead of specifying the shift
    # as an immediate value, it comes from the low-order 5 bits of a register.
    # Since this is dynamic, we can't really simplify or calculate things, but we use the
    # same formula.
    mask = rlwi_mask(mask_begin, mask_end)

    # Take the lower 5 bits
    shift = BinaryOp.int(shift_source, "&", Literal(0x1F))

    upper_bits = BinaryOp.int(BinaryOp.int(source, "<<", shift), "&", Literal(mask))
    lower_bits = BinaryOp.int(
        BinaryOp.int(source, ">>", BinaryOp.int(Literal(32), "-", shift)),
        "&",
        Literal(mask),
    )

    return BinaryOp.int(upper_bits, "|", lower_bits)


def handle_cmpnez(source: Expression) -> Expression:
    uw_source = early_unwrap(source)
    if isinstance(uw_source, UnaryOp) and uw_source.op == "-":
        source = uw_source.expr
        uw_source = early_unwrap(source)
    if isinstance(uw_source, BinaryOp) and uw_source.op in ("-", "^"):
        return BinaryOp.icmp(uw_source.right, "!=", uw_source.left)
    return BinaryOp.icmp(source, "!=", Literal(0))


def handle_loadx(args: InstrArgs, type: Type) -> Expression:
    # "indexed loads" like `lwzx rD, rA, rB` read `(rA + rB)` into `rD`
    size = type.get_size_bytes()
    assert size is not None

    ptr = BinaryOp.intptr(left=args.reg(1), op="+", right=args.reg(2))
    expr = deref(ptr, args.regs, args.stack_info, size=size)
    return as_type(expr, type, silent=True)


def handle_arm_mov(args: InstrArgs) -> Expression:
    dest = args.reg_ref(0)
    source = args.raw_arg(1)
    value = args.reg_or_imm(1)
    if (
        isinstance(source, Register)
        and args.stack_info.is_stack_reg(source)
        and not args.stack_info.is_stack_reg(dest)
    ):
        return handle_addi_real(dest, source, value, Literal(0), args)
    return value


def eval_arm_cmp(s: NodeState, lhs: Expression, rhs: Expression) -> None:
    s.set_reg(Register("z"), BinaryOp.icmp(lhs, "==", rhs))
    sub = BinaryOp.intptr(lhs, "-", rhs)
    sval = as_type(sub, Type.s32(), silent=True, unify=False)
    s.set_reg(Register("n"), BinaryOp.scmp(sval, "<", Literal(0)))
    v = fn_op("M2C_OVERFLOW", [sval], Type.boolean())
    s.set_reg(Register("v"), v)
    ulhs = as_type(lhs, Type.u32(), silent=True, unify=False)
    slhs = as_type(lhs, Type.s32(), silent=True, unify=False)
    urhs = as_type(rhs, Type.u32(), silent=True, unify=False)
    srhs = as_type(rhs, Type.s32(), silent=True, unify=False)
    s.set_reg(Register("c"), BinaryOp.ucmp(ulhs, ">=", urhs))
    s.set_reg(Register("hi"), BinaryOp.ucmp(ulhs, ">", urhs))
    s.set_reg(Register("ge"), BinaryOp.scmp(slhs, ">=", srhs))
    s.set_reg(Register("gt"), BinaryOp.scmp(slhs, ">", srhs))


def set_arm_flags_from_add(s: NodeState, val: Expression) -> None:
    s.set_reg(
        Register("z"),
        BinaryOp.icmp(val, "==", Literal(0, type=val.type)),
    )
    sval = as_type(val, Type.s32(), silent=True, unify=False)
    s.set_reg(Register("n"), BinaryOp.scmp(sval, "<", Literal(0)))
    s.set_reg(Register("c"), CarryBit(val))
    v = fn_op("M2C_OVERFLOW", [sval], Type.boolean())
    s.set_reg(Register("v"), v)
    # Remaining flag bits are based on the full mathematical result
    # of unsigned/signed additions. We don't have a good way to
    # write that; let's cheat and treat a cast of the result to
    # s64/u64 as the entire subtraction having been performed as
    # signed/unsigned 64-bit, and hope it gets the picture across.
    u64val = as_type(val, Type.u64(), silent=False, unify=False)
    p32 = Literal(2**32)
    s.set_reg(Register("hi"), BinaryOp.ucmp(u64val, ">", p32))
    s64val = as_type(val, Type.s64(), silent=False, unify=False)
    s.set_reg(Register("ge"), BinaryOp.scmp(s64val, ">=", Literal(0)))
    s.set_reg(Register("gt"), BinaryOp.scmp(s64val, ">", Literal(0)))


def carry_add_to(expr: Expression) -> BinaryOp:
    return fold_divmod(BinaryOp.intptr(expr, "+", CarryBit()))


def carry_sub_from(expr: Expression) -> BinaryOp:
    return BinaryOp.intptr(expr, "-", UnaryOp("!", CarryBit(), type=Type.intish()))


def s32_literal(value: int) -> Literal:
    # TODO: this makes little sense, given that literals don't have fixed
    # integer types... we should make sure that uses of literals do this
    # conversion instead.
    return Literal(((value + 0x80000000) & 0xFFFFFFFF) - 0x80000000)
