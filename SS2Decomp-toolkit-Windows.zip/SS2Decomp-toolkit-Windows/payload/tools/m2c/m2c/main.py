from __future__ import annotations
import argparse
import contextlib
from dataclasses import dataclass
import gc
import io
import sys
import tempfile
import traceback
from pathlib import Path
from typing import Dict, List, Optional, Union

from .c_types import build_typemap, dump_typemap
from .error import DecompFailure
from .flow_graph import FlowGraph, build_flowgraph
from .if_statements import get_function_text
from .options import CodingStyle, Options, Target
from .asm_file import AsmData, Function, parse_file
from .instruction import InstrProcessingFailure
from .translate import (
    Arch,
    FunctionInfo,
    GlobalInfo,
    translate_to_ast,
    narrow_func_call_outputs,
    visualize_flowgraph,
)
from .types import TypePool
from .arch_arm import ArmArch, ArmGbaArch
from .arch_mips import MipsArch, MipseeArch
from .arch_ppc import PpcArch
from .arch_sh import Sh2Arch, Sh4Arch


@dataclass
class DecompilationState:
    @dataclass
    class Valid:
        flow_graph: FlowGraph
        info: Optional[FunctionInfo] = None

    function: Function
    state: Union[Valid, Exception]


@dataclass
class BrowserResult:
    returncode: int
    output: str


def decompile_for_browser(source: str, context: str, flags: List[str]) -> BrowserResult:
    stdout = io.StringIO()
    stderr = io.StringIO()

    with tempfile.TemporaryDirectory(prefix="m2c-browser-") as tmpdir:
        base_path = Path(tmpdir)
        asm_path = base_path / "input.s"
        asm_path.write_text(source, encoding="utf-8")

        argv = flags + ["--no-cache", "--visualize-format=dot"]
        context_path = base_path / "context.c"
        context_path.write_text(context, encoding="utf-8")
        argv.extend(["--context", str(context_path)])
        argv.append(str(asm_path))

        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            options = parse_flags(argv)
            returncode = run(options)

    err = stderr.getvalue()
    if err and (options.visualize_flowgraph is None or returncode != 0):
        stdout.write(err)
    return BrowserResult(returncode, stdout.getvalue())


def print_exception(exc: Exception, sanitize: bool) -> None:
    """Print a traceback for the current exception to stdout.

    If `sanitize` is true, the filename's full path is stripped,
    and the line is set to 0. These changes make the test output
    less brittle."""
    if sanitize:
        tb = traceback.TracebackException(type(exc), exc, exc.__traceback__)
        if tb.exc_type == InstrProcessingFailure and tb.__cause__:
            tb = tb.__cause__
        for frame in tb.stack:
            frame.lineno = 0
            frame.end_lineno = 0
            frame.filename = Path(frame.filename).name
        for line in tb.format(chain=False):
            print(line, end="")
    else:
        traceback.print_exception(type(exc), exc, exc.__traceback__, file=sys.stdout)


def print_exception_as_comment(
    exc: Exception, options: Options, context: Optional[str]
) -> None:
    context_phrase = f" in {context}" if context is not None else ""
    if isinstance(exc, OSError):
        print(f"/* OSError{context_phrase}: {exc} */")
        return
    elif isinstance(exc, DecompFailure):
        print("/*")
        print(f"Decompilation failure{context_phrase}:\n")
        print(exc)
        if options.stacktrace:
            tb = traceback.TracebackException(type(exc), exc, exc.__traceback__)
            tb = tb.__cause__ or tb.__context__
            if tb:
                print()
                for line in tb.format():
                    print(line, end="")
        print("*/")
    else:
        print("/*")
        print(f"Internal error{context_phrase}:\n")
        print_exception(exc, sanitize=options.sanitize_tracebacks)
        print("*/")


def run(options: Options) -> int:
    arch: Arch
    if options.target.arch == Target.ArchEnum.MIPS:
        if options.target.platform == Target.PlatformEnum.MIPSEE:
            arch = MipseeArch()
        else:
            arch = MipsArch()
    elif options.target.arch == Target.ArchEnum.PPC:
        arch = PpcArch()
    elif options.target.arch == Target.ArchEnum.ARM:
        if options.target.platform == Target.PlatformEnum.GBA:
            arch = ArmGbaArch()
        else:
            arch = ArmArch()
    elif options.target.arch == Target.ArchEnum.SH:
        if options.target.platform == Target.PlatformEnum.SH4:
            arch = Sh4Arch()
        else:
            arch = Sh2Arch()
    else:
        raise ValueError(f"Invalid target arch: {options.target.arch}")

    all_functions: Dict[str, Function] = {}
    asm_data = AsmData()
    try:
        for filename in options.filenames:
            if filename == "-":
                asm_file = parse_file(sys.stdin, arch, options)
            else:
                with open(filename, "r", encoding="utf-8-sig") as f:
                    asm_file = parse_file(f, arch, options)
            all_functions.update((fn.name, fn) for fn in asm_file.functions)
            asm_file.asm_data.merge_into(asm_data)

        if options.heuristic_strings:
            asm_data.detect_heuristic_strings()
        typemap = build_typemap(options.c_contexts, arch, use_cache=options.use_cache)
    except Exception as e:
        print_exception_as_comment(e, options, context=None)
        return 1

    if options.dump_typemap:
        dump_typemap(typemap)
        return 0

    if not options.function_indexes_or_names:
        functions = list(all_functions.values())
    else:
        functions_by_c_name = {
            arch.c_symbol_name(name): function
            for name, function in all_functions.items()
        }
        functions = []
        for index_or_name in options.function_indexes_or_names:
            if isinstance(index_or_name, int):
                if not (0 <= index_or_name < len(all_functions)):
                    print(
                        f"Function index {index_or_name} is out of bounds (must be between "
                        f"0 and {len(all_functions) - 1}).",
                        file=sys.stderr,
                    )
                    return 1
                functions.append(list(all_functions.values())[index_or_name])
            else:
                function = all_functions.get(index_or_name)
                if function is None:
                    function = functions_by_c_name.get(index_or_name)
                if function is None:
                    print(f"Function {index_or_name} not found.", file=sys.stderr)
                    return 1
                functions.append(function)

    fmt = options.formatter()
    function_names = set(all_functions.keys())
    typepool = TypePool(
        unknown_field_prefix="unk_" if fmt.coding_style.unknown_underscore else "unk",
        unk_inference=options.unk_inference,
        union_field_overrides=options.union_field_overrides,
    )
    global_info = GlobalInfo(
        asm_data,
        arch,
        options.target,
        function_names,
        typemap,
        typepool,
        deterministic_vars=options.deterministic_vars,
        stack_spill_detection=options.stack_spill_detection,
    )

    decompilations: List[DecompilationState] = []
    for function in functions:
        state: Union[DecompilationState.Valid, Exception]
        try:
            narrow_func_call_outputs(function, global_info)
            flow_graph = build_flowgraph(
                function,
                global_info.asm_data,
                arch,
                fragment=False,
                print_warnings=options.debug,
                debug_patterns=options.debug_patterns,
            )
            state = DecompilationState.Valid(flow_graph)
        except Exception as e:
            # Store the exception for later, to preserve the order in the output
            state = e
        decompilations.append(DecompilationState(function, state))

    # Perform the preliminary passes to improve type resolution, but discard the results
    global_decls_exc: Optional[Exception] = None
    for i in range(options.passes - 1):
        for decomp in decompilations:
            if isinstance(decomp.state, Exception):
                continue
            flow_graph = decomp.state.flow_graph
            try:
                flow_graph.reset_block_info()
                decomp.state.info = translate_to_ast(
                    decomp.function, flow_graph, options, global_info
                )
            except Exception as e:
                decomp.state = e

        if global_decls_exc is None:
            try:
                global_info.global_decls(fmt, options.global_decls, [])
            except Exception as e:
                global_decls_exc = e

        for decomp in decompilations:
            if isinstance(decomp.state, Exception):
                continue
            info = decomp.state.info
            assert info is not None
            try:
                get_function_text(info, options)
            except Exception as e:
                decomp.state = e

        # This operation can change struct field paths, so it is only performed
        # after discarding all of the translated Expressions.
        typepool.prune_structs()

    for decomp in decompilations:
        if isinstance(decomp.state, Exception):
            continue
        flow_graph = decomp.state.flow_graph
        try:
            flow_graph.reset_block_info()
            decomp.state.info = translate_to_ast(
                decomp.function, flow_graph, options, global_info
            )
        except Exception as e:
            decomp.state = e

    if options.visualize_flowgraph is not None:
        decomp = decompilations[0]
        try:
            if isinstance(decomp.state, Exception):
                raise decomp.state from None
            dot_source = visualize_flowgraph(
                decomp.state.flow_graph, options.visualize_flowgraph
            )
            if options.visualize_format == Options.VisualizeFormatEnum.SVG:
                import graphviz

                svg_bytes: bytes = graphviz.Source(dot_source).pipe("svg")
                sys.stdout.buffer.write(svg_bytes)
            else:
                sys.stdout.write(dot_source)
            return 0
        except Exception as e:
            print_exception_as_comment(e, options, context=None)
            return 1

    return_code = 0
    try:
        type_decls = typepool.format_type_declarations(
            fmt, stack_structs=options.print_stack_structs
        )
        if type_decls:
            print(type_decls)

        if global_decls_exc is not None:
            raise global_decls_exc from None

        infos = [
            d.state.info
            for d in decompilations
            if not isinstance(d.state, Exception) and d.state.info is not None
        ]
        global_decls = global_info.global_decls(fmt, options.global_decls, infos)
        if global_decls:
            print(global_decls)
    except Exception as e:
        print_exception_as_comment(e, options, context=None)
        return_code = 1

    for index, decomp in enumerate(decompilations):
        if index != 0:
            print()
        function = decomp.function
        try:
            if options.print_assembly:
                print(function)
                print()

            if isinstance(decomp.state, Exception):
                raise decomp.state from None

            assert decomp.state.info is not None
            function_text = get_function_text(decomp.state.info, options)
            print(function_text)

        except Exception as e:
            print_exception_as_comment(e, options, context=f"function {function.name}")
            return_code = 1

    for warning in typepool.warnings:
        line = fmt.with_comments("", comments=[warning])
        if line:
            print(line)

    return return_code


def parse_flags(flags: List[str]) -> Options:
    parser = argparse.ArgumentParser(
        description="Decompile assembly to C.",
        usage="%(prog)s [-t mips-ido-c] [--context C_FILE] [-f FN ...] filename [filename ...]",
    )

    group = parser.add_argument_group("Input Options")
    group.add_argument(
        metavar="filename",
        nargs="+",
        dest="filenames",
        help="Input asm filename(s)",
    )
    group.add_argument(
        "--context",
        metavar="C_FILE",
        dest="c_contexts",
        action="append",
        type=Path,
        default=[],
        help="Read variable types/function signatures/structs from an existing C file. "
        "The file must already have been processed by the C preprocessor.",
    )
    group.add_argument(
        "--no-cache",
        action="store_false",
        dest="use_cache",
        help="Disable caching of variable types/function signatures/structs from the parsed C context. "
        "This option should be used for untrusted environments. "
        'The cache for "foo/ctx_bar.c" is stored in "foo/ctx_bar.c.m2c". '
        "The *.m2c files automatically regenerate when the source file change, and can be ignored.",
    )
    group.add_argument(
        "-D",
        metavar="SYM[=VALUE]",
        dest="defined",
        action="append",
        default=[],
        help="Mark preprocessor symbol as defined",
    )
    group.add_argument(
        "-U",
        metavar="SYM",
        dest="undefined",
        action="append",
        default=[],
        help="Mark preprocessor symbol as undefined",
    )
    group.add_argument(
        "--incbin-dir",
        dest="incbin_dirs",
        action="append",
        default=[],
        type=Path,
        help="Add search path for loading .incbin directives in the input asm",
    )

    group = parser.add_argument_group("Output Options")
    group.add_argument(
        "-f",
        "--function",
        metavar="FN",
        dest="functions",
        action="append",
        default=[],
        help="Function index or name to decompile",
    )
    group.add_argument(
        "--globals",
        dest="global_decls",
        type=Options.GlobalDeclsEnum,
        choices=list(Options.GlobalDeclsEnum),
        default="used",
        help="Control which global declarations & initializers are emitted. "
        '"all" includes all globals with entries in .data/.rodata/.bss, as well as inferred symbols. '
        '"used" only includes symbols used by the decompiled functions that are not in the context (default). '
        '"none" does not emit any global declarations. ',
    )
    group.add_argument(
        "--stack-structs",
        dest="print_stack_structs",
        action="store_true",
        help=(
            "Include template structs for each function's stack. These can be modified and passed back "
            "into m2c with --context to set the types & names of stack vars."
        ),
    )
    group.add_argument(
        "--debug",
        dest="debug",
        action="store_true",
        help="Print debug info inline",
    )
    group.add_argument(
        "--debug-patterns",
        dest="debug_patterns",
        action="store_true",
        help="Dump assembly after each matched asm pattern",
    )
    group.add_argument(
        "--stacktrace",
        dest="stacktrace",
        action="store_true",
        help="Print internal stack traces for errors",
    )
    group.add_argument(
        "--print-assembly",
        dest="print_assembly",
        action="store_true",
        help="Print assembly of function to decompile",
    )
    group.add_argument(
        "--dump-typemap",
        dest="dump_typemap",
        action="store_true",
        help="Dump information about all functions and structs from the provided C "
        "context. Mainly useful for debugging.",
    )
    group.add_argument(
        "--visualize",
        dest="visualize_flowgraph",
        nargs="?",
        default=None,
        const=Options.VisualizeTypeEnum.C,
        type=Options.VisualizeTypeEnum,
        choices=list(Options.VisualizeTypeEnum),
        help="Print an SVG visualization of the control flow graph using graphviz",
    )
    group.add_argument(
        "--visualize-format",
        dest="visualize_format",
        default=Options.VisualizeFormatEnum.SVG,
        type=Options.VisualizeFormatEnum,
        choices=list(Options.VisualizeFormatEnum),
        help="Visualization output format (default: %(default)s)",
    )
    group.add_argument(
        "--sanitize-tracebacks",
        dest="sanitize_tracebacks",
        action="store_true",
        help=argparse.SUPPRESS,
    )

    group = parser.add_argument_group("Formatting Options")
    group.add_argument(
        "--valid-syntax",
        dest="valid_syntax",
        action="store_true",
        help="Emit valid C syntax, using macros to indicate unknown types or other "
        "unusual statements. Macro definitions are in `m2c_macros.h`.",
    )
    brace_style = group.add_mutually_exclusive_group()
    brace_style.add_argument(
        "--allman",
        dest="allman",
        action="store_true",
        help="Put braces on separate lines",
    )
    brace_style.add_argument(
        "--knr",
        dest="knr",
        action="store_true",
        help="Put function opening braces on separate lines",
    )
    group.add_argument(
        "--indent-switch-contents",
        dest="indent_switch_contents",
        action="store_true",
        help="Indent switch statements' contents an extra level",
    )
    group.add_argument(
        "--pointer-style",
        dest="pointer_style",
        help="Control whether to output pointer asterisks next to the type name (left) "
        "or next to the variable name (right). Default: right",
        choices=["left", "right"],
        default="right",
    )
    group.add_argument(
        "--unk-underscore",
        dest="unknown_underscore",
        help="Emit unk_X instead of unkX for unknown struct accesses",
        action="store_true",
    )
    group.add_argument(
        "--hex-case",
        dest="hex_case",
        help="Display case labels in hex rather than decimal",
        action="store_true",
    )
    group.add_argument(
        "--comment-style",
        dest="comment_style",
        type=CodingStyle.CommentStyle,
        choices=list(CodingStyle.CommentStyle),
        default="multiline",
        help=(
            "Comment formatting. "
            '"multiline" for C-style `/* ... */`, '
            '"oneline" for C++-style `// ...`, '
            '"none" to disable comments. '
            "Default: multiline"
        ),
    )
    group.add_argument(
        "--comment-column",
        dest="comment_column",
        metavar="N",
        type=int,
        default=52,
        help="Column number to justify comments to. Set to 0 to disable justification. Default: 52",
    )
    group.add_argument(
        "--no-casts",
        dest="skip_casts",
        action="store_true",
        help="Don't emit any type casts",
    )
    group.add_argument(
        "--zfill-constants",
        dest="zfill_constants",
        action="store_true",
        help="Pad hex constants with 0's to fill their type's width.",
    )
    group.add_argument(
        "--force-decimal",
        dest="force_decimal",
        action="store_true",
        help="Force decimal values",
    )
    group.add_argument(
        "--deterministic-vars",
        dest="deterministic_vars",
        action="store_true",
        help="Name temp and phi vars after their location in the source asm, "
        "rather than using an incrementing suffix. Can help reduce diff size in tests.",
    )
    group.add_argument(
        "--descending-regs",
        dest="descending_regs",
        action="store_true",
        help="Sort variables in descending order by register number",
    )
    group.add_argument(
        "--backwards-bss",
        dest="backwards_bss",
        action="store_true",
        help="Sort bss variables backwards compared to what's in the asm",
    )

    group = parser.add_argument_group("Analysis Options")
    group.add_argument(
        "-t",
        "--target",
        dest="target",
        type=Target.parse,
        default="mips-ido-c",
        help="Target platform, compiler, and language triple. "
        "Only platform needs to be provided. "
        "Supported platforms: [mips, mipsel, mipsee, ppc, arm, gba, sh2]. "
        "Supported compilers: [ido, gcc, mwcc] "
        "Supported languages: [c, c++]. "
        "Defaults to mips-ido-c. "
        "If compiler is not provided, it defaults to ido for mips, mwcc for ppc, otherwise gcc. "
        "If language is not provided, it defaults to c++ for mwcc, otherwise c.",
    )
    group.add_argument(
        "--passes",
        "-P",
        dest="passes",
        metavar="N",
        type=int,
        default=2,
        help="Number of translation passes to perform. Each pass may improve type resolution and produce better "
        "output, particularly when decompiling multiple functions. Default: 2",
    )
    group.add_argument(
        "--stop-on-error",
        dest="stop_on_error",
        action="store_true",
        help="Stop when encountering any error",
    )
    group.add_argument(
        "--void",
        dest="void",
        action="store_true",
        help="Assume the decompiled function returns void",
    )
    group.add_argument(
        "--gotos-only",
        dest="ifs",
        action="store_false",
        help="Disable control flow generation; emit gotos for everything",
    )
    group.add_argument(
        "--no-ifs",
        dest="ifs",
        action="store_false",
        help=argparse.SUPPRESS,
    )
    group.add_argument(
        "--no-switches",
        dest="switch_detection",
        action="store_false",
        help=(
            "Disable detecting irregular switch statements from if trees. "
            "Jump tables switches are still emitted."
        ),
    )
    group.add_argument(
        "--no-andor",
        dest="andor_detection",
        action="store_false",
        help="Disable detection of &&/||",
    )
    group.add_argument(
        "--no-unk-inference",
        dest="unk_inference",
        action="store_false",
        help=(
            "Disable type inference on unknown struct fields & unknown global symbol types. "
            "See the README for more information on unknown inference."
        ),
    )
    group.add_argument(
        "--no-stack-spill",
        dest="stack_spill_detection",
        action="store_false",
        help=(
            "Disable stack spilling detection, which introduces unnecessary "
            "temporaries in unoptimized code instead of using the stack."
        ),
    )
    group.add_argument(
        "--heuristic-strings",
        dest="heuristic_strings",
        action="store_true",
        help="Heuristically detect strings in rodata even when not defined using .asci/.asciz.",
    )
    group.add_argument(
        "--reg-vars",
        metavar="REGISTERS",
        dest="reg_vars",
        help="Use single variables instead of temps/phis for the given "
        "registers (comma separated)",
    )
    group.add_argument(
        "--goto",
        metavar="PATTERN",
        dest="goto_patterns",
        action="append",
        default=["GOTO"],
        help="Emit gotos for branches on lines containing this substring "
        '(possibly within a comment). Default: "GOTO". Multiple '
        "patterns are allowed.",
    )
    group.add_argument(
        "--pdb-translate",
        dest="pdb_translate",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    group.add_argument(
        "--disable-gc",
        dest="disable_gc",
        action="store_true",
        help="Disable Python garbage collection. Can improve performance at "
        "the risk of running out of memory.",
    )
    group.add_argument(
        "--union-field",
        metavar="STRUCT:FIELD",
        dest="union_fields",
        action="append",
        default=[],
        help="Specify which field to use for a union. "
        "Format: STRUCT_NAME:FIELD_NAME (e.g., MyUnion:int_value). "
        "Can be specified multiple times for different unions.",
    )

    args = parser.parse_args(flags)
    reg_vars = args.reg_vars.split(",") if args.reg_vars else []
    preproc_defines: Dict[str, Optional[int]] = {d: None for d in args.undefined}
    for d in args.defined:
        parts = d.split("=", 1)
        preproc_defines[parts[0]] = int(parts[1], 0) if len(parts) >= 2 else 1

    coding_style = CodingStyle(
        newline_after_function=args.allman or args.knr,
        newline_after_if=args.allman,
        newline_before_else=args.allman,
        switch_indent_level=2 if args.indent_switch_contents else 1,
        pointer_style_left=args.pointer_style == "left",
        unknown_underscore=args.unknown_underscore,
        hex_case=args.hex_case,
        comment_style=args.comment_style,
        comment_column=args.comment_column,
    )

    functions: List[Union[int, str]] = []
    for fn in args.functions:
        try:
            functions.append(int(fn))
        except ValueError:
            functions.append(fn)

    # Parse union field overrides
    union_field_overrides: Dict[str, str] = {}
    for override in args.union_fields:
        parts = override.split(":", 1)
        if len(parts) != 2:
            print(
                f"Error: Invalid union field override '{override}'. "
                "Expected format: STRUCT_NAME:FIELD_NAME",
                file=sys.stderr,
            )
            sys.exit(1)
        struct_name, field_name = parts
        union_field_overrides[struct_name] = field_name

    # The debug output interferes with the visualize output
    if args.visualize_flowgraph is not None:
        args.debug = False
        args.debug_patterns = False

    return Options(
        filenames=args.filenames,
        function_indexes_or_names=functions,
        debug=args.debug,
        debug_patterns=args.debug_patterns,
        stacktrace=args.stacktrace,
        void=args.void,
        ifs=args.ifs,
        switch_detection=args.switch_detection,
        andor_detection=args.andor_detection,
        skip_casts=args.skip_casts,
        zfill_constants=args.zfill_constants,
        force_decimal=args.force_decimal,
        heuristic_strings=args.heuristic_strings,
        reg_vars=reg_vars,
        goto_patterns=args.goto_patterns,
        stop_on_error=args.stop_on_error,
        print_assembly=args.print_assembly,
        visualize_flowgraph=args.visualize_flowgraph,
        visualize_format=args.visualize_format,
        c_contexts=args.c_contexts,
        use_cache=args.use_cache,
        dump_typemap=args.dump_typemap,
        pdb_translate=args.pdb_translate,
        preproc_defines=preproc_defines,
        coding_style=coding_style,
        sanitize_tracebacks=args.sanitize_tracebacks,
        valid_syntax=args.valid_syntax,
        global_decls=args.global_decls,
        target=args.target,
        print_stack_structs=args.print_stack_structs,
        unk_inference=args.unk_inference,
        stack_spill_detection=args.stack_spill_detection,
        passes=args.passes,
        incbin_dirs=args.incbin_dirs,
        deterministic_vars=args.deterministic_vars,
        descending_regs=args.descending_regs,
        backwards_bss=args.backwards_bss,
        disable_gc=args.disable_gc,
        union_field_overrides=union_field_overrides,
    )


def main() -> None:
    # Large functions can sometimes require a higher recursion limit than the
    # CPython default. Cap to INT_MAX to avoid an OverflowError, though.
    sys.setrecursionlimit(min(2**31 - 1, 10 * sys.getrecursionlimit()))
    options = parse_flags(sys.argv[1:])
    if options.disable_gc:
        gc.disable()
        gc.set_threshold(0)
    sys.exit(run(options))


if __name__ == "__main__":
    main()
