SS2Decomp toolkit Windows x86-64 - EDICION PUBLICA SIN ROM
=======================================================
Este ZIP no incluye baserom.gba ni ninguna ROM. Debes aportar tu propia
ROM europea para compilar. No la agregues a Git.

Preparar otro PC (Windows 10/11 x86-64)
-------------------------------------
1. Instala MSYS2 desde https://www.msys2.org/ y abre MSYS2 UCRT64.
2. Ejecuta pacman -Syu; reabre la terminal si lo pide y termina la actualizacion.
3. Extrae este ZIP y entra a SS2Decomp-toolkit-Windows. Ejecuta:

       bash bootstrap.sh /d/Proyectos/ShiningSoul2Decomp

   Usa un destino NUEVO. Se instalan dependencias, se verifica SHA256SUMS,
   se restaura el snapshot Git y se copian las herramientas. No necesita ROM
   para instalar. El origen queda en https://github.com/MatyMeatBoy/SS2Decomp.git.
4. Copia tu ROM europea al proyecto restaurado con el nombre baserom.gba.
   SHA1 esperado: aa1288be9257337abdfe3034898cf6c7aa778fbc
5. En UCRT64:

       cd /d/Proyectos/ShiningSoul2Decomp
       source toolkit-env.sh
       python3 .toolkit/verify_repo.py .
       git pull --ff-only
       make -j2 compare
       make -j1 nonmatching

   La verificacion del snapshot se hace ANTES de actualizar con git pull.
   make compare debe terminar con shiningsoul2_eu.gba: OK.

Contenido
---------
source.bundle contiene solo el snapshot publicado identificado por
SOURCE_REVISION, su rama SOURCE_BRANCH y su historia publica. Se reviso
que no contiene rutas de ROM ni el blob de baserom. El snapshot queda
fijado a su revision original; actualiza con Git para los nuevos matches.

payload contiene agbcc/old_agbcc/ARM, variantes SDK y stamps, include/lib,
m2c, decomp-permuter, asm-differ, objdiff GUI/CLI y dependencias Python
puras fijadas (pycparser 2.23). Licencias y versiones incluidas.
Git, make, ARM binutils/GCC y Python UCRT64 se instalan con pacman.
No incluye builds, expected, credenciales ni worktrees privados.

bootstrap.sh --no-install permite reutilizar dependencias ya instaladas.
--build requiere que la ROM ya exista en el proyecto restaurado; para
una instalacion inicial usa el comando sin --build y compila en el paso 5.
En cada terminal nueva ejecuta source toolkit-env.sh.
Configura tu nombre/correo Git y sigue AGENTS.md: checkout independiente,
claim exclusivo y verificacion ROM/NONMATCHING antes de entregar PRs.
