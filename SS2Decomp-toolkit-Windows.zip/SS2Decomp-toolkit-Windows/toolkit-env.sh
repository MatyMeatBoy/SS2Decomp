#!/usr/bin/env bash
_ss2_toolkit_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
export PATH="/ucrt64/bin:/usr/bin:$PATH"
export PYTHONPATH="$(cygpath -m "$_ss2_toolkit_root/.toolkit/python")"
export PYTHONNOUSERSITE=1
export GHIDRA_OUT="$_ss2_toolkit_root/ghi"
unset _ss2_toolkit_root

